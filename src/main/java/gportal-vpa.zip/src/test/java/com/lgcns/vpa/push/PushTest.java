/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : PushTest.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

/**
 * <PRE>
 * test
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 8. 21.
 */
package com.lgcns.vpa.push;
 
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.push.service.PushService;
import com.lgcns.vpa.push.service.impl.PlannerPushServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PushTest {
	
	@Test
	public void  EventsPushTest() throws RestClientException, URISyntaxException {
		
		RestTemplate restTemplate = new RestTemplate();

		String url = "http://localhost:8080/api/push/120000080021";
		String requestJson = "{\"botId\":\"120000080013\",\"targetUserId\":\"00305\",\"message\":\"EventsPushTest:i love you^^\",\"action\":\"test\",\"title\":\"i wanna go with you\"}";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> entity = new HttpEntity<String>(requestJson,headers);
		String answer = restTemplate.postForObject(url, entity, String.class);
		System.out.println(answer);
		//최승백(79273) 로그인 하면 경조사 메시지 나와야 한다.
		
	}
	
	@Test
	public void PlannerTest() {
		Map<String, String> params = new HashMap<String, String>();
		params.put("botId", "120000080013");
		
		PushConfig pushConfig = new PushConfig();
		pushConfig.setPushId("120000090006");
		
		PushService pushService = new PlannerPushServiceImpl();
		pushService.execute(params, "lgcns", pushConfig);
	}
	
	
	@Test
	public void  MemoPushTest() throws RestClientException, URISyntaxException {
		
		RestTemplate restTemplate = new RestTemplate();

		String url = "http://localhost:8080/api/push/120000090007";
		String requestJson = "{\"botId\":\"120000080013\"}";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> entity = new HttpEntity<String>(requestJson,headers);
		String answer = restTemplate.postForObject(url, entity, String.class);
		System.out.println(answer);
		
	}
	
	@Test
	public void  NotificationPushTest() throws RestClientException, URISyntaxException {
		
		/*RestTemplate restTemplate = new RestTemplate();

		String url = "http://localhost:8080/api/push/PS_0001";
		String requestJson = "{\"botId\":\"120000080013\",\"message\":\"NotificationPushTest:i am rooting for you. cheer up\"}";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> entity = new HttpEntity<String>(requestJson,headers);
		String answer = restTemplate.postForObject(url, entity, String.class);
		System.out.println(answer);*/
		
		String url = "http://localhost:8080/api/push/PS_0001";
		
		Map<String, String> param = new HashMap<String, String>();
		param.put("botId", "120000080013");
		param.put("message", "NotificationPushTest:i am rooting for you. cheer up");
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, param, String.class);
		
		System.out.println(responseEntity.toString());
		
	}
	
	@Test
	public void  PlannerPushTest() throws RestClientException, URISyntaxException {
		
		RestTemplate restTemplate = new RestTemplate();

		String url = "http://localhost:8080/api/push/120000090006";
		String requestJson = "{\"botId\":\"120000080013\"}";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> entity = new HttpEntity<String>(requestJson,headers);
		String answer = restTemplate.postForObject(url, entity, String.class);
		System.out.println(answer);
		
	}
	
	
	
	@Test
	public void  ReplyPushTest() throws RestClientException, URISyntaxException {
		
		RestTemplate restTemplate = new RestTemplate();

		String url = "http://localhost:8080/api/push/120000090001";
		String requestJson = "{\"botId\":\"120000080013\",\"userId\":\"73379\",\"message\":\"ReplyPushTest:how can i suppose to live without you\",\"action\":\"test\",\"title\":\"you are the best\",\"descriptions\":\"you just dont know how i feel about you\",\"text\":\"do your best\"}";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> entity = new HttpEntity<String>(requestJson,headers);
		String answer = restTemplate.postForObject(url, entity, String.class);
		System.out.println(answer);
		
	}
	
}

