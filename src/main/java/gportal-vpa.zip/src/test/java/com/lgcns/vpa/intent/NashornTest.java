/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : NashornTest.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;

import javax.annotation.Resource;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.lgcns.vpa.base.config.MongoConfig;
import com.lgcns.vpa.base.config.OracleDatasourceConfig;
import com.lgcns.vpa.base.config.RedisConfig;
import com.lgcns.vpa.base.config.WebSocketConfig;
import com.lgcns.vpa.security.user.model.User;

@RunWith(SpringRunner.class)
@SpringBootTest(classes={MongoConfig.class, OracleDatasourceConfig.class, RedisConfig.class, WebSocketConfig.class})

public class NashornTest {

	private ScriptEngine engine;
	
	@Before
	public void setUp() throws Exception {
		
		try {
			engine = new ScriptEngineManager().getEngineByName("nashorn");
			URL resource = this.getClass().getClassLoader().getResource("mapper\\datatrans.js");
			engine.eval(new FileReader(new File(resource.toURI())));
		}catch(Exception e){e.printStackTrace();}
	}
	
	@Test
	public void testUserService() {
/*
		List<User> userList = userService.findUsers("dept",  "user");
		Assert.assertEquals(0, userList.size());
*/
	}
	@Test
	public void test1() throws ScriptException {
		engine.eval("print('Hello World!');");
	}

/*	@Test
	public void test2() throws ScriptException, NoSuchMethodException {
		
		Invocable invocable = (Invocable) engine;
		
		Object result = invocable.invokeFunction("fun1", "Peter Parker");
		System.out.println(result);
		System.out.println(result.getClass());
		
		invocable.invokeFunction("fun2", new Date());

		invocable.invokeFunction("fun2", LocalDateTime.now());

		invocable.invokeFunction("fun2", new User());
	}
	
	@Test
	public void test3() throws  ScriptException, NoSuchMethodException {
		
		Invocable invocable = (Invocable) engine;
		
		invocable.invokeFunction("fun3", "Peter Parker");
	}
	
	@Test
	public void test4() throws ScriptException, NoSuchMethodException {
		
		Invocable invocable = (Invocable) engine;
		
		invocable.invokeFunction("fun4");
	}

	@Test
	public void test5() throws ScriptException, NoSuchMethodException {
		Invocable invocable = (Invocable) engine;
		
		invocable.invokeFunction("fun5");
	}
*/	
	@SuppressWarnings("unchecked")
	@Test
	public void test6() throws ScriptException {
		String func  = "function(x) 3 * x + 1";
		String param = "4";
		Function<Object,Object> f = (Function<Object,Object>)engine.eval(
	            String.format("new java.util.function.Function(%s)", func));
	        
        System.out.println(f.apply(param));
	}
	
	@Test
	public void testRedisUser() throws ScriptException, NoSuchMethodException {
		Invocable invocable = (Invocable) engine;
		
		List<User> users = (List<User>)invocable.invokeFunction("Person", "", "홍길동");
		System.out.println(users);
	}
	
	@Test
	public void testFunction() throws ScriptException {
		
		String func  = "function(deptName, userName) beanFactory.getBean(\"redisUserService\").findUsers(deptName, userName)";
		Function f = (Function)engine.eval(
	            String.format("new java.util.function.Function(%s)", func));
	        
        System.out.println(f.apply("dept"));
	}
}
