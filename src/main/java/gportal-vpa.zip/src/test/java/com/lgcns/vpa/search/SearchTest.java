/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : SearchTest.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.search;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonFactory.Feature;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.MongoConfig;
import com.lgcns.vpa.base.config.RedisConfig;
import com.lgcns.vpa.base.config.RestConfig;
import com.lgcns.vpa.channel.service.SearchService;
@RunWith(SpringRunner.class)
@SpringBootTest(classes={MongoConfig.class, RestConfig.class, RedisConfig.class})
public class SearchTest {

	@Resource(name="apiService")
    RestTemplate apiService;
	
	@Resource(name="searchService")
	SearchService search;
	
	String baseUrl = "http://gportaldev.lgcns.com/ikep-webapp/support/search/w3Search.do";
	@Before
	public void setUp() throws Exception {
		
	}

	@Test
	public void testEmployeeAPI() throws RestClientException, URISyntaxException {
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap();
		 
		params.add("query", "TFT");
		params.add("collection", "EMPLOYEE");
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(headers);
		 
		RestTemplate rest = new RestTemplate();
		String result = rest.postForObject(new URI(baseUrl), request, String.class);
		//결과 {“result_code”:”200”,”cmid”:”20130314163439459”}
		System.out.println(result);
	}
	
	@Test
	public void test3() {
		RestTemplate rest = new RestTemplate();
		MultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(new MediaType("application", "json", Charset.forName("UTF-8")));
		HttpEntity<String> name = new HttpEntity<>("홍길동", headers);
		parts.add("name", name);
		parts.add("email", "hong@yourdomain");
		String url = UriComponentsBuilder.fromHttpUrl("http://gportaldev.lgcns.com/ikep-webapp/support/search/w3Search.do?query=2&collection=EMPLOYEE")
				.build().toString();
		String response = rest.postForObject(url, parts, String.class); 
	}
	@Test
	public void testEmployeeAPI2() throws RestClientException, URISyntaxException, JsonParseException, JsonMappingException, IOException {
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap();
		 
		params.add("query", "TFT");
		params.add("collection", "EMPLOYEE");
		
		URI uri = UriComponentsBuilder.fromUriString("http://gportaldev.lgcns.com/ikep-webapp/support/search/w3Search.do?query=2&collection=EMPLOYEE")
				
//		    	.queryParams(params)
		    	.build()
		    	.encode("UTF-8")
		    	.toUri();
		RestTemplate rest = new RestTemplate();
		String result =  rest.getForObject(uri, String.class);
		System.out.println(result);
		
		List<Map<String, Object>> list = new LinkedList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("FULL_PATH_NAME","홍길동");
		list.add(map);
		
		String jsonStr = "";
		
		URL resource = this.getClass().getClassLoader().getResource("templates/searchapi.json");
		BufferedReader br = null;
		try{
			br = new BufferedReader(new InputStreamReader(
					new FileInputStream(resource.getFile()), "utf-8"));
			for( String line; (line = br.readLine()) != null; ) {
				jsonStr += line;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(br != null) try {br.close(); } catch (IOException e) {}
		}

		System.out.println(jsonStr);
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, String> mapper = objectMapper.readValue(
				jsonStr, 
				Map.class);
		
		List<Map<String, Object>> res = new LinkedList<>();
		for( Map<String, Object> row : list ) {
			Map<String, Object> obj = new HashMap<>();
			for( Entry<String, Object> entry : row.entrySet()) {
				String to = mapper.get(entry.getKey());
				obj.put(to, entry.getValue());
			}
			res.add(obj);
		}
		
		JsonNode node = objectMapper.convertValue(res, JsonNode.class);
		System.out.println(objectMapper.writeValueAsString(node));
		
	}
	
	@Test
	public void searchTest() {
		Map<String, String> options = new HashMap<>();
		options.put("searchField", "TITLE");
		System.out.println(search.search("lgcns", "CIC구축", "project", options));
	}

}
