package com.lgcns.vpa.intent;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit4.SpringRunner;

import com.lgcns.vpa.base.config.MongoConfig;
import com.lgcns.vpa.base.config.OracleDatasourceConfig;
import com.lgcns.vpa.base.config.RedisConfig;
import com.lgcns.vpa.base.config.RestConfig;
import com.lgcns.vpa.base.config.WebSocketConfig;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.intent.model.IntentAnalysisResult;
import com.lgcns.vpa.intent.model.IntentBase;
import com.lgcns.vpa.intent.model.IntentMongo;
import com.lgcns.vpa.intent.model.IntentSet;
import com.lgcns.vpa.intent.service.IntentService;
import com.lgcns.vpa.intent.service.impl.IntentServiceImpl;
import com.lgcns.vpa.security.user.model.User;

/**
 * 
 * @author 최환준
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes={MongoConfig.class, RestConfig.class, RedisConfig.class})
public class IntentServiceTest {
	
	@Autowired
	IntentService intentService;
	
	User user;
	
	String tenantId;
	
	String botId;
	
	String userId;
	@Before
	public void setUp() {
		user = new User();
		user.setEmpNo("70399");
		user.setUserId("hwjochoi");
		user.setUserName("최환준");
		user.setTeamName("NCD플랫폼팀");
		
		tenantId="lgcns";
		botId="120000080013";
		userId="70399";
		DataSourceKeyHolder.setDataSourceKey("lgcns");

	}
	
	@Test
	public void findByContext() {
		System.out.println(intentService.findByContext(botId, "출장", true));
		
	}
	@Test
	public void testAll() {
		testPlanner();
		testAsset();
	}
	
	
	@Test
	public void testPlanner() {
		DataSourceKeyHolder.setDataSourceKey("lgcns");
		long current = System.currentTimeMillis();
		IntentAnalysisResult intent = intentService.reasonIntent(tenantId, botId, userId, "하창훈 오늘 오후 1시 일정 조회");
		System.out.println(intent.getIntent());
		System.out.println("ellapsed time : " +( System.currentTimeMillis() - current));
		
		current = System.currentTimeMillis();
		intent = intentService.reasonIntent(tenantId, botId, userId, "내일모레 일정 조회");
		System.out.println(intent.getIntent());
		System.out.println("ellapsed time : " +( System.currentTimeMillis() - current));

	}
	@Test
	public void testDup() {
		IntentAnalysisResult intent = intentService.reasonIntent(tenantId, botId, userId, "이영우 자산 조회");
		System.out.println("이영우 자산 조회*****************************************************************");
		System.out.println(intent.getIntent());
		IntentSet set = (IntentSet)intent.getIntent();
		Iterator<IntentBase> iterator = set.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next().getMessage());
		}
	}
	
	@Test
	public void testSlot() {
		long current = System.currentTimeMillis();
		IntentAnalysisResult intent = intentService.reasonIntent(tenantId, botId, userId, "자산번호 조회");
		System.out.println("1793830 자산번호 조회*****************************************************************");
		System.out.println(intent.getIntent());
		System.out.println("ellapsed time : " +( System.currentTimeMillis() - current));
		
	}
	@Test
	public void testAsset() {
		DataSourceKeyHolder.setDataSourceKey("lgcns");
		long current = System.currentTimeMillis();
		IntentAnalysisResult intent = null;
		intent = intentService.reasonIntent(tenantId, botId, userId, "하창훈 자산 조회");
		System.out.println("자산 조회*****************************************************************");
		System.out.println(intent.getIntent());
		System.out.println("ellapsed time : " +( System.currentTimeMillis() - current));
		
		current = System.currentTimeMillis();	
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "1793830 자산번호 조회");
		System.out.println("1793830 자산번호 조회*****************************************************************");
		System.out.println(intent.getIntent());
		System.out.println("ellapsed time : " +( System.currentTimeMillis() - current));
		
		current = System.currentTimeMillis();			

		intent = intentService.reasonIntent(tenantId, botId, userId, "노트북 구매");
		System.out.println("노트북 구매*****************************************************************");
		System.out.println(intent.getIntent());
		System.out.println("ellapsed time : " +( System.currentTimeMillis() - current));
				
	}
	
	@Test
	public void testInference() {
		
		IntentAnalysisResult intent = intentService.reasonIntent(tenantId, botId, userId, "연차 신청 어떻게 하나요?");
		System.out.println(intent.getIntent().getMessage());
		
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "근태결재자가 팀장님이 아닙니다.");
		System.out.println(intent.getIntent().getMessage());
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "부재로 근태 결재자 권한을 위임하고 싶습니다.방법을 알려주세요");
		System.out.println(intent.getIntent().getMessage());
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "타임키퍼를 지정하고 싶습니다.");
		System.out.println(intent.getIntent().getMessage());

		intent = intentService.reasonIntent(tenantId, botId, userId, "Lack of budget 라는 Error 문구가 발생 했습니다.");
		System.out.println(intent.getIntent().getMessage());

		intent = intentService.reasonIntent(tenantId, botId, userId, "E-001 => You cannot reset this transation 라는 Error 문구가 발생 했습니다.");
		System.out.println(intent.getIntent().getMessage());
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "Unexpected Error! Ask administrator if the situation is repeated 라는 Error 문구가 발생 했습니다.");
		System.out.println(intent.getIntent().getMessage());

		intent = intentService.reasonIntent(tenantId, botId, userId, "Row 1 Error – Select a valid value 라는 Error 문구가 발생 했습니다.");
		System.out.println(intent.getIntent().getMessage());

		intent = intentService.reasonIntent(tenantId, botId, userId, "BT_ALL_COMMON_USER is not a vaild responsibility for the current user.");
		System.out.println(intent.getIntent().getMessage());
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "BT_HQ_GENERAL_USER is not a vaild responsibility for the current user.");
		System.out.println(intent.getIntent().getMessage());
		
		
		System.out.println("===================================================================");
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "자산을 조회해줘");
		System.out.println(intent.getIntent().getMessage());
		
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "1793830 자산번호를 조회해줘");
		System.out.println(intent.getIntent().getMessage());

	}
	
	@Test
	public void testFindByIntentId() {
		IntentMongo intent = intentService.findByIntentId("0", "0");
		System.out.println(intent);
	}
	
	
	@Test
	public void testEntity() {
		IntentAnalysisResult intent;
		intent = intentService.reasonIntent(tenantId, botId, userId, "내일 오후 1시 메모 알림");
		System.out.println(intent.getIntent().getMessage());
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "내일 오전 1시 메모 알림");
		System.out.println(intent.getIntent().getMessage());
		
		intent = intentService.reasonIntent(tenantId, botId, userId, "내일 오전 1시 10분 메모 알림");
		System.out.println(intent.getIntent().getMessage());

		intent = intentService.reasonIntent(tenantId, botId, userId, "내일 11시 22분 메모 알림");
		System.out.println(intent.getIntent().getMessage());

	}
	
	
	@Test
	public void testSuggest() {
		List<IntentMongo> mongos = intentService.findByContext(botId, "자산", true);
		System.out.println(intentService.findByContext(botId, "자", true));
		
	}

}
