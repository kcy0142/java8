/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentModelTest.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.lgcns.vpa.intent.model.IntentBase;
import com.lgcns.vpa.intent.model.IntentMongo;
import com.lgcns.vpa.intent.model.IntentMongo.Parameter;
import com.lgcns.vpa.intent.model.IntentSet;
import com.lgcns.vpa.intent.model.IntentAnalysisResult.Status;

public class IntentModelTest {

	private IntentMongo mongo;
	@Before
	public void setUp() {
		mongo = new IntentMongo("botId", "intentId", "intentName");
		mongo.addParameter(new Parameter("name", "$person.id", ""));
	}
	

}
