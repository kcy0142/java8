/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentConsoleApplication.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent;

import java.util.Scanner;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.lgcns.vpa.GportalVpaApplication;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.intent.model.IntentAnalysisResult;
import com.lgcns.vpa.intent.service.IntentService;

@SpringBootApplication
public class IntentConsoleApplication {
	
	public static void main_1(String[] args) {
		ApplicationContext ctx = SpringApplication.run(GportalVpaApplication.class, args);
        IntentService intentService = ctx.getBean(IntentService.class);
        
        String tenantId = "lgcns";
        String botId = "lgcnsbot";
        
        String message;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("사용자 ID를 입력하세요 [default : 70399]");
        String userId = scan.nextLine();
        if( StringUtils.isEmpty(userId) ) {
        	userId = "70399";
        }
        
        while(true) {
	        System.out.println("1. 질의\n2. 종료");
	        switch(scan.nextLine()) {
	        case "1" :
	        	System.out.println("메시지를 입력하세요");
		        
		        message = scan.nextLine();  
		        System.out.println("질의문 : " + message);
		        DataSourceKeyHolder.setDataSourceKey("lgcns");
		        IntentAnalysisResult result = intentService.reasonIntent(tenantId, botId, userId, message);
		        System.out.println(result.getScore() +" ====> " + result.getIntent());
	        	break;
	        case "2" : 
	        	System.exit(1);
	        	break;
	        }
        }
	}

}
