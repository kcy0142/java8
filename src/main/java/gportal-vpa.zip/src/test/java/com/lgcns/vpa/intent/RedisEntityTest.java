/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : RedisEntityTest.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.lang3.ArrayUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.BoundSetOperations;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.ZSetOperations.TypedTuple;
import org.springframework.test.context.junit4.SpringRunner;

import com.lgcns.vpa.base.config.IntentConfig;
import com.lgcns.vpa.base.config.MongoConfig;
import com.lgcns.vpa.base.config.RedisConfig;
import com.lgcns.vpa.base.config.RestConfig;
import com.lgcns.vpa.base.config.WebSocketConfig;
import com.lgcns.vpa.intent.entity.EntityDictionary;


@RunWith(SpringRunner.class)
@SpringBootTest(classes={MongoConfig.class, RestConfig.class, IntentConfig.class})
public class RedisEntityTest {

	private static final String AUTO_COMPLETE_NAMESPACE = "lgcns:dictionary:date";
	/**
	 * user profile  key {tenantId}:user:{userName}
	 */
	public static final String USER_KEY = "%s:user";
	private String[] words = {"오늘", "지금"};
	@Autowired
	RedisTemplate redisTemplate;
	
	@Autowired
	EntityDictionary dictionary;
	
	@Before
	public void setUp() {
		/*for( String word : words ) {
			addWord(word);
		}
		
		BoundSetOperations<String, String> bso = redisTemplate.boundSetOps("demoSet");
		bso.add("aa", "ab", "ac", "ac");*/
	}
	
	@Test
	public void testUser() {
		System.out.println(dictionary.findUser("lgcns", "70399"));
		System.out.println(dictionary.findUsers("lgcns","",  "이영우"));
		
		System.out.println(dictionary.findUsers("lgcns","",  "이영우", "UC서비스팀"));
		System.out.println(dictionary.findUsers("lgcns","",  "이영우", "하이테크사업부"));
	}
	@Test
	public void test() {
		System.out.println(lookup("지금"));
	}
	
	private List<String> lookup(String prefix) { 
		List<String> results = new ArrayList<>();
		
		long start = redisTemplate.opsForZSet().rank(AUTO_COMPLETE_NAMESPACE, prefix);
		if (start < 0) {
			return Collections.EMPTY_LIST;
		}
		
		Set<TypedTuple<String>> rangeResultsWithScore = redisTemplate.opsForZSet().rangeWithScores(AUTO_COMPLETE_NAMESPACE, start, -1);
		if (rangeResultsWithScore.isEmpty()) return results;

		for (TypedTuple<String> typedTuple : rangeResultsWithScore) {
			String value = typedTuple.getValue();		
			results.add(value);
		}
		return results;
	}
	
	public void addWord(String word) {
		redisTemplate.opsForZSet().add(AUTO_COMPLETE_NAMESPACE, word, 0);
	}
	
	@Test
	public void keys() {
		long current = System.currentTimeMillis();
		
		Set<String> keys = redisTemplate.keys("lgcns:dictionary:user:이영*");
		
		Set<String> userIds = new HashSet<>();
		for( String key : keys ) {
			userIds.addAll(redisTemplate.opsForSet().members(key));
			
		}
		List<Map<String, String>> userList = redisTemplate.opsForHash().multiGet(String.format(USER_KEY, "lgcns"), userIds);
		print(userList);
		System.out.println(String.format("ellapsed time : %d", System.currentTimeMillis() - current));

	}
	
	@Test
	public void scan() {
		long current = System.currentTimeMillis();
		redisTemplate.opsForSet().add("demo","a","ab","bc");
		Cursor<Entry<Object, Object>> cursorMap = redisTemplate.opsForSet().scan("demo", ScanOptions.scanOptions().match("a*").count(100).build());
		Set<String> userIds = new HashSet<>();
        while (cursorMap.hasNext()) {                   
        	userIds.add((String)cursorMap.next().getValue());
        }
        List<Map<String, String>> userList = redisTemplate.opsForHash().multiGet(String.format(USER_KEY, "lgcns"), userIds);
		print(userList);
		System.out.println(String.format("ellapsed time : %d", System.currentTimeMillis() - current));
	}
	
	@Test
	public void scan2() {
		BoundSetOperations<String, String> bso = redisTemplate.boundSetOps("demoSet");
		bso.add("aa", "ab", "ac", "ac");
		Cursor<String> cursor = bso.scan(ScanOptions.scanOptions().match("a*").build());
		System.out.println("------------------------------------------");
        while (cursor.hasNext()) {
            System.out.println(cursor.next());// ac,ab
        }
	}

	private void print(List<Map<String, String>> userList) {
		for( Map<String, String> map : userList ) {
			System.out.println("=============================================");
			for( Entry<String, String> entry : map.entrySet()) {
				System.out.println(entry.getKey() + " = "+  entry.getValue());
			}
		}
	}

}
