/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.web;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.Account;
import com.lgcns.vpa.channel.service.AccountService;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.security.user.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

/**
 * <pre>
 * 사용자 관리 Controller
 * </pre>
 * @author
 * @version
 */
@RequestMapping(value="/api/accounts")
@CrossOrigin(value="*")
@RestController
public class AccountController extends BaseController {

    @Autowired
    private UserService userService;

    @Autowired
    private AccountService accountService;

    /**
     * 로그인 사용자 정보 조회 (초기화 및 사용자 설정 정보 조회)
     * @return
     */
    @RequestMapping(value="/me", method= RequestMethod.GET)
    public ResponseEntity<Account> retrieveMe(Principal principal, HttpServletRequest request) {
        Account account = accountService.retrieveAccount(principal.getName());
        return new ResponseEntity<>(account, HttpStatus.OK);
    }

    /**
     * 사용자 정보 조회
     * @param userId
     * @return
     */
    @RequestMapping(value="/{userId}", method= RequestMethod.GET)
    public ResponseEntity<?> retrieveUser(@PathVariable String userId, Principal principal) {
        if (StringUtils.equals(userId, principal.getName())) {
            User user = userService.selectUser(userId);
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
