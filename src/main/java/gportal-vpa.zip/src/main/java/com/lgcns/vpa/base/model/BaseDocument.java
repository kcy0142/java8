package com.lgcns.vpa.base.model;

import org.springframework.data.annotation.Id;

public abstract class BaseDocument extends BaseModel {

	private static final long serialVersionUID = 4220461820168818965L;
	
    @Id
    private String id;

    public String getId() {
        return id;
    }
    
    public String setId(String id) {
        return this.id = id;
    }    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (this.id == null || obj == null || !(this.getClass().equals(obj.getClass()))) {
            return false;
        }

        BaseDocument that = (BaseDocument) obj;
        return this.id.equals(that.getId());
    }

    @Override
    public int hashCode() {
        return id == null ? 0 : id.hashCode();
    }
}
