package com.lgcns.vpa.channel.model.activity;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseDocument;


import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * <pre>
 *  서비스로그저장 Model
 * </pre>
 * @author
 */
@Document(collection="serviceLog")
@JsonInclude(JsonInclude.Include.NON_NULL)

public class ServiceLog extends BaseDocument {

	
	/**
     * 봇 ID
     */
    private String botId;
	 /**
     * 사용자 ID
     */
    private String userId;
    

	 /**
    * 유형 (map,google)
    */
   private String type;
   
   /**
    * message
    */
   private String message;
    
	 /**
     * 메시지 발신일시
     */
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private Date sentDate;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}    
    
   

}

