/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : Group.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.security.user.model;

import java.util.List;

public class Group {
	/**
	 * 그룹(부서) ID
	 */
	private String groupId;

	/**
	 * 그룹(부서) 이름
	 */
	private String groupName;

	/**
	 * 그룹(부서) 영문 이름
	 */
	private String groupEnglishName;

	/**
	 * 부모(상위) 그룹 ID
	 */
	private String parentGroupId;

	/**
	 * 정렬 순서
	 */
	private String sortOrder;

	/**
	 * 해당 그룹의 그룹 타입 ID
	 */
	private String groupTypeId;

	/**
	 * 자식(하위) 그룹의 수
	 */
	private String childGroupCount;

	/**
	 * 등록자 ID
	 */
	private String registerId;

	/**
	 * 등록자 이름
	 */
	private String registerName;

	/**
	 * 등록일
	 */
	private String registDate;

	/**
	 * 수정자 ID
	 */
	private String updaterId;

	/**
	 * 수정자 이름
	 */
	private String updaterName;

	/**
	 * 수정일
	 */
	private String updateDate;

	/**
	 * 속한 그룹의 리더 아이디
	 */
	private String leaderId;
	
	/**
	 * 조직도 그룹 Type
	 */
	private String groupType;

	/**
	 * 그룹에 속한 유저의 이름과 ID를 담고 있는 리스트(GroupID, UserName, UserID)
	 */
	private List<User> userList;

	/**
	 * 리스트 표시 여부 Flag(0: 안보임, 1:보임)
	 */
	private String viewOption;

	/**
	 * RootNode부터 자신까지의 Path
	 */
	private String fullPath;

	/**
	 * 계층형 조직 정보의 의 Level 값
	 */
	private String groupLevel;

	/**
	 * 그룹별 사용자 수(하위그룹 포함)
	 */	
	private int userCnt = 0;
	
	/**
	 * View_full_path
	 */	
	private int viewFullPath = 1;
	
	/**
	 * 리더 사용자명
	 */
	private String leaderName;
	
	/**
	 * 리더 사용자 영문명
	 */
	private String leaderEnglishName;
	
	/**
	 * 리더 사용자 호칭명
	 */
	private String leaderJobTitleName;
	
	/**
	 * 리더 사용자 호칭영문명
	 */
	private String leaderJobTitleEnglishName;
	
	/**
	 * 리더 사용자 메일
	 */
	private String leaderMail;
	
	/**
	 * 리더 사용자 Mobile 번호
	 */
	private String leaderMobile;
	
	/**
	 * 리더 사용자 사무실전화번호
	 */
	private String leaderOfficePhoneNo;
	
	/**
	 * 상위 부서명
	 */
	private String parentGroupName;
	
	/**
	 * 상위부서 영문명
	 */
	private String parentGroupEnglishName;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupEnglishName() {
		return groupEnglishName;
	}

	public void setGroupEnglishName(String groupEnglishName) {
		this.groupEnglishName = groupEnglishName;
	}

	public String getParentGroupId() {
		return parentGroupId;
	}

	public void setParentGroupId(String parentGroupId) {
		this.parentGroupId = parentGroupId;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getGroupTypeId() {
		return groupTypeId;
	}

	public void setGroupTypeId(String groupTypeId) {
		this.groupTypeId = groupTypeId;
	}

	public String getChildGroupCount() {
		return childGroupCount;
	}

	public void setChildGroupCount(String childGroupCount) {
		this.childGroupCount = childGroupCount;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getRegisterName() {
		return registerName;
	}

	public void setRegisterName(String registerName) {
		this.registerName = registerName;
	}

	public String getRegistDate() {
		return registDate;
	}

	public void setRegistDate(String registDate) {
		this.registDate = registDate;
	}

	public String getUpdaterId() {
		return updaterId;
	}

	public void setUpdaterId(String updaterId) {
		this.updaterId = updaterId;
	}

	public String getUpdaterName() {
		return updaterName;
	}

	public void setUpdaterName(String updaterName) {
		this.updaterName = updaterName;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getLeaderId() {
		return leaderId;
	}

	public void setLeaderId(String leaderId) {
		this.leaderId = leaderId;
	}

	public String getGroupType() {
		return groupType;
	}

	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	public String getViewOption() {
		return viewOption;
	}

	public void setViewOption(String viewOption) {
		this.viewOption = viewOption;
	}

	public String getFullPath() {
		return fullPath;
	}

	public void setFullPath(String fullPath) {
		this.fullPath = fullPath;
	}

	public String getGroupLevel() {
		return groupLevel;
	}

	public void setGroupLevel(String groupLevel) {
		this.groupLevel = groupLevel;
	}

	public int getUserCnt() {
		return userCnt;
	}

	public void setUserCnt(int userCnt) {
		this.userCnt = userCnt;
	}

	public int getViewFullPath() {
		return viewFullPath;
	}

	public void setViewFullPath(int viewFullPath) {
		this.viewFullPath = viewFullPath;
	}

	public String getLeaderName() {
		return leaderName;
	}

	public void setLeaderName(String leaderName) {
		this.leaderName = leaderName;
	}

	public String getLeaderEnglishName() {
		return leaderEnglishName;
	}

	public void setLeaderEnglishName(String leaderEnglishName) {
		this.leaderEnglishName = leaderEnglishName;
	}

	public String getLeaderJobTitleName() {
		return leaderJobTitleName;
	}

	public void setLeaderJobTitleName(String leaderJobTitleName) {
		this.leaderJobTitleName = leaderJobTitleName;
	}

	public String getLeaderJobTitleEnglishName() {
		return leaderJobTitleEnglishName;
	}

	public void setLeaderJobTitleEnglishName(String leaderJobTitleEnglishName) {
		this.leaderJobTitleEnglishName = leaderJobTitleEnglishName;
	}

	public String getLeaderMail() {
		return leaderMail;
	}

	public void setLeaderMail(String leaderMail) {
		this.leaderMail = leaderMail;
	}

	public String getLeaderMobile() {
		return leaderMobile;
	}

	public void setLeaderMobile(String leaderMobile) {
		this.leaderMobile = leaderMobile;
	}

	public String getLeaderOfficePhoneNo() {
		return leaderOfficePhoneNo;
	}

	public void setLeaderOfficePhoneNo(String leaderOfficePhoneNo) {
		this.leaderOfficePhoneNo = leaderOfficePhoneNo;
	}

	public String getParentGroupName() {
		return parentGroupName;
	}

	public void setParentGroupName(String parentGroupName) {
		this.parentGroupName = parentGroupName;
	}

	public String getParentGroupEnglishName() {
		return parentGroupEnglishName;
	}

	public void setParentGroupEnglishName(String parentGroupEnglishName) {
		this.parentGroupEnglishName = parentGroupEnglishName;
	}
	
}
