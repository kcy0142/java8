/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : EntityException.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.exception;

public class EntityException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String field;
	
	public EntityException(String field, String msg) {
		super(msg);
		this.field = field;
	}
	
	public String getField() {
		return this.field;
	}
}
