/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.push.service;

import java.util.List;
import java.util.Map;

import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 데일리 알림 Service
 * </pre>
 * @author
 */
public interface DailyPushService {
    
    /**
     * 데일리 알림 조회
     * @param param
     * @param pushConfig
     * @param bot
     * @param user
     * @param tenantId
     * @return
     */
    List<Attachment> execute(Map<String, String> param, PushConfig pushConfig, Bot bot, User user, String tenantId);
}
