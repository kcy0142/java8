/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.web;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.Conversation;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ServiceLog;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.channel.service.ConversationService;
import com.lgcns.vpa.channel.service.ProxyService;

/**
 * <pre>
 * 봇 대화관리 Controller
 * </pre>
 * @author
 * @version
 */
@RequestMapping(value = "/api/conversations")
@CrossOrigin(value = "*")
@RestController
public class ConversationController extends BaseController {

    @Autowired
    private ConversationService conversationService;

    @Autowired
    private ActivityService activityService;
    
    @Autowired
    private ProxyService proxyService;

    /**
     * Conversation 시작(초기화)
     * @return
     */
    @RequestMapping(value = "/{botId}", method = RequestMethod.POST)
    public ResponseEntity<Conversation> initializeConversation(@PathVariable String botId) {
        Conversation conversation = conversationService.initialize(botId, this.getUser(), this.getTenantId());
        return new ResponseEntity<>(conversation, HttpStatus.OK);
    }

    /**
     * 최근 대화내역 {limit} 건 조회
     * @return
     */
    @RequestMapping(value = "/{botId}/activities/recent", method = RequestMethod.GET)
    public ResponseEntity<List<Activity>> retrieveRecentActivities(@PathVariable String botId, Integer limit) {
        return new ResponseEntity<>(conversationService.retrieveRecentActivityList(botId, this.getUser(), limit, this.getTenantId()), HttpStatus.OK);
    }

    /**
     * 이전 대화내역 {limit} 건 조회
     * @param cursorId
     * @param limit
     * @return
     */
    @RequestMapping(value = "/{botId}/activities/before", method = RequestMethod.GET)
    public ResponseEntity<List<Activity>> retrieveBeforeActivities(@PathVariable String botId, String cursorId, Integer limit) {
        return new ResponseEntity<>(conversationService.retrieveBeforeActivityList(botId, this.getUser(), cursorId, limit, this.getTenantId()), HttpStatus.OK);
    }

    /**
     * 대화내역 전체 삭제
     * @param botId
     * @return
     */
    @RequestMapping(value = "/{botId}/activities", method = RequestMethod.DELETE)
    public ResponseEntity<Object> deleteAllActivities(@PathVariable String botId) {
        activityService.deleteAllActivities(botId, this.getUser());
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
    /**
     * 액티비티 피드백 조회
     * @param botId
     * @param activtyId
     * @return
     */
    @RequestMapping(value = "/{botId}/activities/{activityId}/feedback", method = RequestMethod.GET)
    public ResponseEntity<Activity> retrieveActivityFeedback(@PathVariable String botId, @PathVariable String activityId) {
        return new ResponseEntity<>(activityService.retrieveFeedback(activityId, botId, this.getUser()), HttpStatus.OK);
    } 
    
    /**
     * 액티비티 피드백 저장  
     * @param botId
     * @param activtyId
     * @param activity
     * @return
     */
    @RequestMapping(value = "/{botId}/activities/{activityId}/feedback", method = RequestMethod.POST)
    public ResponseEntity<Activity> updateActivityFeedback(
            @PathVariable String botId,
            @PathVariable String activityId,
            @RequestBody Activity activity) {
    	
    	
    	 Activity feedback = null;
    	 String feedbackType   = activity.getFeedbackType();
		
    	// System.out.println("===================feedbackType:"+feedbackType);
    	 if( StringUtils.isEmpty(feedbackType)) {
    		 feedback = activityService.updateFeedback(activity, this.getUser());
    	 }else{
    		 if(activity.getFeedbackType().equals("user")){
    	    		feedback = activityService.updateUserFeedback(activity, this.getUser());
    		 }else if(activity.getFeedbackType().equals("function")){
    			 feedback = activityService.updateFeedback(activity, this.getUser());
    		 }
    	 }
    	/*if(activity.getFeedbackType().equals("user")){
    		feedback = activityService.updateUserFeedback(activity, this.getUser());
    	}else{
    		  feedback = activityService.updateFeedback(activity, this.getUser());
    	}*/
        return new ResponseEntity<>(feedback, HttpStatus.OK);
    }     

    /**
     * 접속시 인사말
     * @param botId
     * @param eventMessage
     * @return
     */
    @RequestMapping(value = "/{botId}/greetings", method = RequestMethod.GET)
    public ResponseEntity<List<Activity>> greeting(
            @PathVariable String botId,
            @RequestParam(value = "eventMessage", required = false) String eventMessage) {
        
        List<Activity> greetings = conversationService.retrieveGreeting(botId, "Y".equals(eventMessage), this.getTenantId(), this.getUser());
        return new ResponseEntity<>(greetings, HttpStatus.OK);
    }
    
    /**
     * 데일리 알림 조회
     * @param botId
     * @param reloadYn
     * @return
     */
    @RequestMapping(value = "/{botId}/dailypush", method = RequestMethod.GET)
    public ResponseEntity<List<Activity>> retrieveDailyPush(
            @PathVariable String botId, 
            @RequestParam(value = "reload", required = false) String reload) {
        
        List<Activity> greetings = conversationService.retrieveDailyPush(botId, this.getUser(), this.getTenantId(), "Y".equals(reload));
        return new ResponseEntity<>(greetings, HttpStatus.OK);
    }
    
    /**
     * 데일리 알림 업데이트
     * @param botId
     * @param reloadYn
     * @return
     */
    @RequestMapping(value = "/{botId}/updateDailypush", method = RequestMethod.GET)
    public ResponseEntity<Integer> updateDailypush(
            @PathVariable String botId, 
            @RequestParam(value = "reload", required = false) String reload) {
        
    	conversationService.updateDailyPushDate(botId, this.getUser());
    	return new ResponseEntity<>(HttpStatus.OK);
    }
   
    
  
    
        
    /**
     * 나의 축하합니다. 정보 조회
     * @param botId
     * @return
     */
    @RequestMapping(value = "/{botId}/congratulations", method = RequestMethod.GET)
    public ResponseEntity<Map<String, Object>> retrieveMyCongratulation() {
        Map<String, Object> congratulation = new HashMap<>();
        List<Map<String, String>> congratulations = proxyService.retrieveMyCongratulation(this.getUser(), this.getTenantId());
        
        congratulation.put("hasUserCongratulations", !CollectionUtils.isEmpty(congratulations));
        congratulation.put("congratulations", congratulations);
        
        return new ResponseEntity<>(congratulation, HttpStatus.OK);
    }
    
    /**
     * 사용자 피드백 저장  
     * @param botId
     * @param activtyId
     * @param activity
     * @return
     */
    @RequestMapping(value = "/{botId}/activities/{activityId}/userFeedback", method = RequestMethod.POST)
    public ResponseEntity<Activity> updateUserFeedback(
            @PathVariable String botId,
            @PathVariable String activityId,
            @RequestBody Activity activity) {
        
        Activity feedback = activityService.updateFeedback(activity, this.getUser());
        return new ResponseEntity<>(feedback, HttpStatus.OK);
    }  
    
    
    /**
     * 외부 서비스 로그 저장  
     * @param botId
     * @param activtyId
     * @param activity
     * @return
     */
    @RequestMapping(value = "/{botId}/insertServiceLog", method = RequestMethod.POST)
    public ResponseEntity<ServiceLog> insertServiceLog(
    		@PathVariable String botId,
            @RequestBody ServiceLog serviceLog) {
    	
    	ServiceLog result = null;
//    	 System.out.println("===================insertServiceLog:"+serviceLog.getBotId());
//    	 System.out.println("===================insertServiceLog:"+serviceLog.getUserId());
//    	 System.out.println("===================insertServiceLog:"+serviceLog.getType());
//    	 System.out.println("===================insertServiceLog:"+serviceLog.getMessage());
    	 result = activityService.insertServiceLog(serviceLog, this.getUser());
    	
        return new ResponseEntity<>(result, HttpStatus.OK);
    }     
    
    /**
     * 미확인 대화 건수 조회
     * @return
     */
    @RequestMapping(value = "/{botId}/{userId}/unreadCount", method = RequestMethod.GET)
    public ResponseEntity<Integer> retrieveUnreadCount(@PathVariable String botId, @PathVariable String userId) {
    	int count = (int)activityService.getUnreadCount(botId, userId);
    	
        return new ResponseEntity<>(count, HttpStatus.OK);
    }
    
    /**
     *  readDate 업데이트 
     * @return
     */
    @RequestMapping(value = "/{botId}/{userId}/updateReadDate", method = RequestMethod.GET)
    public ResponseEntity<Object> updateReadDate(@PathVariable String botId, @PathVariable String userId) {
    	activityService.updateReadDate(botId,userId);
    	return new ResponseEntity<>(HttpStatus.OK);
    }
    
    
    @RequestMapping(value = "/{botId}/{userId}/unreadPush", method = RequestMethod.GET)
    public ResponseEntity<List<Activity>> retrieveUnreadPush(@PathVariable String botId, @PathVariable String userId) {
    	List<Activity> pushActivities = activityService.getUnreadPush(botId, userId);
    	activityService.updateReadDate(botId,userId);
        return new ResponseEntity<>(pushActivities, HttpStatus.OK);
    }
    
    
    /**
     * 미확인 대화 건수 수정
     * @return
     */
    @RequestMapping(value = "/{botId}/{userId}/read/{activityId}", method = RequestMethod.GET)
    public ResponseEntity<Integer> updateMessageRead(@PathVariable String botId, 
    		@PathVariable String userId,
    		@PathVariable String activityId) {
    	
    	String tempId="";
    	activityService.updateMessageRead(botId, userId, activityId,tempId);
    	
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
    
    /**
     * 세션 조회
     * @return
     */
    @RequestMapping(value = "/session/{userId}", method = RequestMethod.GET)
    public ResponseEntity<String> getRedisSession(@PathVariable String userId) {
    	String message = (String)activityService.getRedisSession( userId);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }
    
    /**
     * webSocketSessionId  조회
     * @return
     */
    @RequestMapping(value = "/webSocketSessionId/{webSocketSessionId}", method = RequestMethod.GET)
    public ResponseEntity<String> getRedisSessionId(@PathVariable String webSocketSessionId) {
    	String message = (String)activityService.getRedisSessionId( webSocketSessionId);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }
    
    
    /**
     *  배치관련 세션 조회
     * @return
     */
    @RequestMapping(value = "/redisSessionTargetAll", method = RequestMethod.GET)
    public ResponseEntity<String> getRedisAllSession() {
    	 String botId="";
    	 List<Activity> sessionList =activityService.getRedisAllSession( botId);
    	 
    	 String result="";
    	 String userList="";
    	 String userTmp=""; 
    	 String msg="";
    	 for(Activity message:sessionList){
    		// System.out.println("getMessage:"+message.getMessage());
    		// System.out.println("getUserId:"+message.getUserId());
    		 userList=userList+"'"+message.getUserId()+"',";
    		 userTmp=message.getUserId();
    		 result=result+message.getMessage()+ "<br>";
    	 }
    	 String userInfo="db.getCollection('conversations').find({userId:{ $in: ["+userList+"'"+userTmp+"' ] }},{botId:1,userId:1,enterDate:1}).sort({enterDate:-1})";
       
    	 String activityInfo="db.getCollection('activities').find({$and:[{userId:{ $in: ["+userList+"'"+userTmp+"' ] }},{ subtype: \"greeting\" },{sentDate:{$gte:new ISODate(\""+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX)+"\") }} ]},{botId:1,userId:1,sentDate:1})";
         
    	 return new ResponseEntity<>(msg+"<br><br>"+result+"<br><br>"+userInfo+"<br><br>"+activityInfo, HttpStatus.OK);
    }
    
    
    /**
     *  배치관련 세션 조회
     * @return
     */
    @RequestMapping(value = "/redisSessionTargetAllTest", method = RequestMethod.GET)
    public ResponseEntity<String> getRedisAllSessionTest() {
    	 String botId="";
    	 List<Activity> sessionList =activityService.getRedisAllSessionTest( botId);
    	 
    	 String result="";
    	 String userList="";
    	 String userTmp=""; 
    	 String msg="";
    	 for(Activity message:sessionList){
    		// System.out.println("getMessage:"+message.getMessage());
    		// System.out.println("getUserId:"+message.getUserId());
    		 userList=userList+"'"+message.getUserId()+"',";
    		 userTmp=message.getUserId();
    		 result=result+message.getMessage()+ "<br>";
    	 }
    	 String userInfo="db.getCollection('conversations').find({userId:{ $in: ["+userList+"'"+userTmp+"' ] }},{botId:1,userId:1,enterDate:1}).sort({enterDate:-1})";
       
    	 String activityInfo="db.getCollection('activities').find({$and:[{userId:{ $in: ["+userList+"'"+userTmp+"' ] }},{sentDate:{$gte:new ISODate(\""+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX)+"\") }} ]},{botId:1,userId:1,sentDate:1})";
         
    	 return new ResponseEntity<>(msg+"<br><br>"+result+"<br><br>"+userInfo+"<br><br>"+activityInfo, HttpStatus.OK);
    }
    
    /**
     * 사용자 세션 삭제
     * @return
     */
    @RequestMapping(value = "/removeSession/{userId}", method = RequestMethod.GET)
    public ResponseEntity<String> removeSession(@PathVariable String userId) {
    	String message = (String)activityService.removeSession( userId);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

}