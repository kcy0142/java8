/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : LogicDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.service.NettyPoolClientService;
import com.lgcns.vpa.dialog.service.dialog.VpaDialog;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.dialog.util.ParameterChecker;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.security.user.service.UserRoleService;

public abstract class LogicDialog extends VpaDialog {

	private static final Logger LOG = LoggerFactory.getLogger(LogicDialog.class);
	
	@Autowired
	private NettyPoolClientService nettyPoolClientService;  
    
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private BotService botService;
	
	@Override
	protected boolean validator(InquiryVO data) {
		Action action = data.getAction();
		boolean isValid = false;
		
		//Parameter validator
		if (action != null) {
			if ( !StringUtils.hasText(action.getActionUri()) ) {
				isValid = true;
			}
			else {
				isValid = true;
				Map<String, Object> newIntentParam = null;
				
				if ( action.getActionUri().startsWith("sql-stored") ) {
					//Intent Parameter 에서 누락된 Parameter 는 각 Type 의 기본 값으로 Parameter 값을 설정함
					newIntentParam = ParameterChecker.parameterValidator(action.getActionUri(), data.getIntentParam());
					data.setIntentParam(newIntentParam);
				}
				
				newIntentParam = ( newIntentParam == null ) ? new HashMap<String, Object>() : newIntentParam;
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
						 "], actionUri:["+action.getActionUri()+"], Intent Param:["+data.getIntentParam()+"]");
			}
		}
		else {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+"], Validation을 수행할 action 정보가 없음");
		}
		
		return isValid;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		
		boolean hasRight = false;
		
		if ( data.getReqUser() == null ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한을 검사할 Req User 정보가 없음");
			return false;
		}
		
		//인텐트별 사용자의 사용 권한 조회
		hasRight = this.userRoleService.validateUserRole(data.getReqUser(), data.getIntentId());
		
		if (!hasRight) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한 없음");
		}
		return hasRight;
	}

	@Override
	protected String processor(InquiryVO data) {
		
		if ( (data == null) || (data.getAction() == null) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 정보가 부정확함");
			return null;
		}
		
		//Backend Proxy 에 Data 요청 (동기식 처리)
		TransferSyncVO transferVO = null;
		String resultJsonData = null;
		long currentTime = System.currentTimeMillis();
		
		try {
			transferVO = new TransferSyncVO(data);
			
			//ActionUri가 있는 경우 Proxy 서버에 질의
			//ActionUri가 없는 경우 Template 정보으로 응답 생성
			if ( StringUtils.hasText(transferVO.getActionUri()) ) {

				resultJsonData = this.nettyPoolClientService.sendToBnpSync(transferVO);
				data.setSpentTimeProxy(System.currentTimeMillis() - currentTime);
				
				if ( (resultJsonData == null) || (!StringUtils.hasText(resultJsonData)) ) {
					//결과가 없음
					resultJsonData = CommonCode.ACTION_RESULT_NONE;
					LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음, spentTimeProxy:["+data.getSpentTimeProxy()+"]");
				}
			}
			else {
				//Template 정보으로 응답 생성
				resultJsonData = CommonCode.ACTION_URI_NONE;
				data.setSpentTimeProxy(System.currentTimeMillis() - currentTime);
			}
			
		} catch (Exception e) {
			
			data.setSpentTimeProxy(System.currentTimeMillis() - currentTime);
			
			//오류 발생
			resultJsonData = CommonCode.ACTION_RESULT_ERROR;
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], spentTimeProxy:["+data.getSpentTimeProxy()+"], Proxy 정보 조회 중 오류 발생, Exception : " + e.toString());
		}
		
		return resultJsonData;
	}

	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet =  null;
			
			TransferSyncVO responseVO =  new  TransferSyncVO();
			ObjectMapper mapper = new ObjectMapper();
			responseVO =  mapper.readValue(proxyResponseJsonData, TransferSyncVO.class);
			
			if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
				proxyResultSet = responseVO.getActionResult();
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				
				if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
					//Proxy에서 조회된 결과(JsonData)에서 Attachment 를 구함
					attachments = this.getAttachment(data, proxyResultSet);
					
					if ( (attachments != null) && (!attachments.isEmpty()) ) {
						
						int count = proxyResultSet.size();
						
						//Activity Message
						StringBuffer activityMessage = new StringBuffer();
						activityMessage.append(data.getIntentMessage());
						
						if (count > 1) {
							activityMessage.append(" ").append(String.format(this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_MULTI_RESULT), count));
						}
						
						resultActivity.setMessage(activityMessage.toString());
						resultActivity.setAttachments(attachments);
						
					}
					else {
						LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
						
						//Data 가 없음
			        	resultActivity = this.commonResponeService.simpleResponseMessage(
								data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
								this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
					}
					
					//의도분석의 Button이 있는 경우 처리
					if ( data.getIntentButtons() != null ) {
						List<RelatedButton> buttons = data.getIntentButtons();
						List<Button> activityButtonList = super.makeActivityButtonList(buttons);
						
						if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
							resultActivity.setButtons(activityButtonList);
						}
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
						
						 
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	protected abstract List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception;

}
