package com.lgcns.vpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GportalVpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GportalVpaApplication.class, args);
	}
}
