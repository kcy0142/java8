package com.lgcns.vpa.base.util;

import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class I18nUtils {

    /**
     * 기본 타임존 ID (Asia/Seoul)
     */
    public static String DEFAULT_ZONE_ID;
 
    @Value("${i18n.default-timezone}")
    public void setDefaultZone(String zoneId) {
        DEFAULT_ZONE_ID = zoneId;
    }
    
    /**
     * 기본 로케일 ID
     */
    public static String DEFAULT_LOCALE_CODE;
    
    @Value("${i18n.default-locale}")
    public void setDefaultLocale(String localeCode) {
        DEFAULT_LOCALE_CODE = localeCode;
    }
    
    /**
     * 디폴트 로케일여부 확인
     * @param localeCode
     * @return
     */
    public static boolean isDefaultLocaleCode(String localeCode) {
        if (StringUtils.isEmpty(localeCode))
            return true;
        else
            return new Locale(DEFAULT_LOCALE_CODE).toString().equals(localeCode);
    }
}
