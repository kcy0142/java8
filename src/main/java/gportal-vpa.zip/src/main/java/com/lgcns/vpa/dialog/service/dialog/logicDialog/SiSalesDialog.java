/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SiSalesDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * SI Project 수주현황조회 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 4.
 */
@Component("SiSalesDialog")
public class SiSalesDialog extends LogicDialog {

	//private static final Logger LOG = LoggerFactory.getLogger(SiSalesDialog.class);
	
	@Autowired
    private MessageSource messageSource;
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	@Override
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			User user = (inquiryData.getReqUser() == null) ? new User() : inquiryData.getReqUser();
			
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        //attachment.setTitle(inquiryData.getIntentMessage());
	        
	        // SI 주요 수주현황이 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("등록된 SI 주요 수주현황이 없습니다.");
	            
	        }
	        // SI 주요 수주현황이 존재하는 경우    
	        else {
	        	
	        	String title = null;
	        	String setSubtitle = null;
	        	String setDescriptions = null;
	        	String setAmount = null;
	        	String setValue = null;
	        	String setUnit = null;
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
	    				title = (proxyResult.get("PJT_NM") != null) ? proxyResult.get("PJT_NM").toString() : "";
	    				setSubtitle = (proxyResult.get("CUST_NM") != null) ? proxyResult.get("CUST_NM").toString() : "";
	    				setDescriptions = 
	    						new StringBuffer(
	    								messageSource.getMessage("meesage.push.daily.sales.sales", 
	    														 null, new Locale(user.getLocaleCode())))
	                            .append(" ")
	                            .append(proxyResult.get("SALES_NM").toString()).toString();
	    				setAmount = (proxyResult.get("CONT_AMT") != null) ? proxyResult.get("CONT_AMT").toString() : "";
	    				setValue = (proxyResult.get("CONT_AMT") != null) ? proxyResult.get("CONT_AMT").toString() : "";  
	    				setUnit = (proxyResult.get("UNIT") != null) ? proxyResult.get("UNIT").toString() : ""; 
	    				
	    				
	    				Element element = new Element();
	    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	    				element.setTitle(title);
	    				element.setSubtitle(setSubtitle);
	    				element.setDescriptions(setDescriptions);
	    				element.setAmount(setAmount);
	    				element.setValue(setValue);
	    				element.setUnit(setUnit);
	    				
	    				attachment.addElement(element);
	        		}
	        	}//for
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}

}
