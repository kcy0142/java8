/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SearchContactDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.ConfigCode;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.push.service.DailyPushService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * 기념일 축하 대상 조회 처리를 위한 Dialog 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 10. 19.
 */
@Component("CongratulationDialog")
public class CongratulationDialog extends VpaDialog {
	
	private static final Logger LOG = LoggerFactory.getLogger(CongratulationDialog.class);

	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private BotService botService;
	
	@Autowired
    private ConfigService configService;
	
	@Autowired
    private ApplicationContext context;
	
	@Autowired
	private DialogConfig dialogConfig;
	
	/**
	 * Parameter mapping & Validation
	 * @param data
	 * @return
	 */
	protected boolean validator(InquiryVO data) {
		return true;
	}
	
	/**
	 * 실행 권한 검사
	 * @param data
	 * @return
	 */
	protected boolean hasActionRight(InquiryVO data) {
		return true;
	}
	
	/**
	 * Legacy system 또는 Redis 등에 질의 처리
	 * @param data
	 * @return
	 */
	protected String processor(InquiryVO data) {
		return "CongratulationDialog";
	}
	
	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
			//resultActivity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_DAILY_PUSH);
			//resultActivity.setAttachmentLayout(ActivityCode.ATTACHMENT_LAYOUT_TYPE_ACCORDION);
            
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet =  null;

			//Proxy에서 조회된 결과(JsonData)에서 Attachment 를 구함
			attachments = this.getAttachment(data, proxyResultSet);
			StringBuffer activityMessage = new StringBuffer(); 
			
			if ( (attachments != null) && (!attachments.isEmpty()) ) {
				
				if ( attachments.get(0) != null ) {
					Attachment attachment = attachments.get(0);
					List<Element> elements = attachment.getElements();
					
					//Activity Result Message  변경
					//생일, 결혼기념일 등 축하대상자 목록이 중복 되었을 경우 "총 N명의 사용자가 조회되었습니다. 질의하실 대상을 선택해주세요." 로 출력함
					//TODO  향 후 의도분석에서 메세지 출력 시 대체함
					if ( (elements != null) && (elements.size() > 0)) {
						activityMessage.append(attachment.getDescriptions());
					}
					else {
						activityMessage.append(" 생일, 결혼기념일 등 축하할 직원정보가 없습니다. \n");
						activityMessage.append(" 알림설정 > 축하합니다 에 설정된 내용을 확인하여 보시기 바랍니다.");
					}
				}
	        	
	        	resultActivity.setMessage(activityMessage.toString());
				resultActivity.setAttachments(attachments);
				
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
				
				activityMessage.append(" 생일, 결혼기념일 등 축하할 직원정보가 없습니다. \n");
				activityMessage.append(" 알림설정 > 축하합니다 에 설정된 내용을 확인하여 보시기 바랍니다.");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						activityMessage.toString());
			}
			
			//의도분석의 Button이 있는 경우 처리
			if ( data.getIntentButtons() != null ) {
				List<RelatedButton> buttons = data.getIntentButtons();
				List<Button> activityButtonList = super.makeActivityButtonList(buttons);
				
				if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
					resultActivity.setButtons(activityButtonList);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( inquiryData == null ) {
			return null;
		}
		
		List<Attachment> attachments = null;
				
		try {
			
			//Congratulation Push Id 정보를 Properties 파일에서 읽어온다.
			String congratulationPushId = this.dialogConfig.getDialogInfo(inquiryData.getTenantId(), "pushId", "congratulation");
			
			Bot bot = botService.retrieveBot(inquiryData.getBotId());
			User reqUser = inquiryData.getReqUser();
			
			//Client Daily Push 에서 데일리 알림 항목 조회
	        PushConfig searchCondition = new PushConfig();
	        searchCondition.setBotId(bot.getBotId());
	        searchCondition.setUserId(reqUser.getUserId());
	        searchCondition.setPushId(congratulationPushId);
	        searchCondition.setPushTypeCode(ConfigCode.PUSH_TYPE_CODE_DAILY);
	        
	        List<PushConfig> dailyPushConfigs = configService.retrievePushConfigList(searchCondition, reqUser);

	        if (!CollectionUtils.isEmpty(dailyPushConfigs)) {
	            
	        	for (PushConfig pushConfig : dailyPushConfigs) {
	                if ( !StringUtils.isEmpty(pushConfig.getWorkerName()) ) {
	                	DailyPushService dailyPushService = context.getBean(pushConfig.getWorkerName(), DailyPushService.class);
                        
                        attachments = dailyPushService.execute(null, pushConfig, bot, reqUser, inquiryData.getTenantId());
	                }
	            }
	        	
	        }
			
		} catch (Exception e) {
			throw e;
		}
		
        return attachments;
	}
}
