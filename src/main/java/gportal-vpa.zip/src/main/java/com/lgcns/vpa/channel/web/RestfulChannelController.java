package com.lgcns.vpa.channel.web;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.nio.charset.Charset;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.base.config.RestConfig.AutoSuggestApi;
import com.lgcns.vpa.base.config.RestConfig.RestfulApi;
import com.lgcns.vpa.base.config.RestConfig.RestfulApiSchem;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.MessengerActivity;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.ActionService;
import com.lgcns.vpa.dialog.service.DialogHandlerService;
import com.lgcns.vpa.dialog.service.dialog.VpaDialog;
import com.lgcns.vpa.dialog.util.DialogUtil;
import com.lgcns.vpa.intent.model.IntentMongo;
import com.lgcns.vpa.intent.service.IntentService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * websocket convert to restful Controller
 * </pre>
 * @author
 */
@RestController
@CrossOrigin(value="*")
@RequestMapping(value="/api")
public class RestfulChannelController extends BaseController {
	
	final Logger logger = LoggerFactory.getLogger(RestfulChannelController.class);
	
	@Autowired
    private MessageSource messageSource;
	
    @Autowired
    DialogHandlerService dialogHandlerService;
    
    @Autowired
    AutoSuggestApi autoSuggest;
    
    @Autowired
    RestTemplate apiService;
    
    @Autowired
    IntentService intentService;

    @Autowired
    ActivityService activityService;
    
    @Autowired
	private ActionService actionService;
    
	@Autowired
	private ApplicationContext context;

    
	@Autowired
	private DialogConfig dialogConfig;

    
    ObjectMapper om = new ObjectMapper();
    
   
    @RequestMapping(value="/message", method= RequestMethod.POST)
    public ResponseEntity<Activity> message(@RequestBody Activity activityRequest) throws Exception {

    	Activity activityResponse;
    	
    	User user = getUser();
    	String tenantId = user.getTenantId();
    	
    	activityRequest.setUserId(this.getUser().getUserId());
        activityRequest.setSentDate(new Date());
        
        activityService.insertActivity(activityRequest);
		activityResponse = dialogHandlerService.syncInquiry(activityRequest, user, tenantId);
		activityResponse.setUserId(this.getUser().getUserId());
        activityResponse.setSentDate(new Date());
        activityResponse.setReplyToId(activityRequest.getId());
        
        //Admin 의도파악 대상 모니터링 
        activityResponse.setRequestMessage(activityRequest.getMessage());     
        activityResponse.setRequestSentDate(activityRequest.getSentDate());
        activityResponse.setLeader(this.getUser().getLeader());	//통계용 정보 추가
        
        activityService.insertActivity(activityResponse);
          
    	 // 3. VPA 응답 : 화면 UI 에서 렌더링 할 수 있도록 응답 데이터를 전송한다.
        return new ResponseEntity<>(activityResponse, HttpStatus.OK);
    	
    }
    
    /**
     * 임시 RESTFUL API autosuggest
     * @return
     */
    @RequestMapping(value = "/autosuggest", method = RequestMethod.POST)
    public Map<String, Object> autosuggest(@RequestBody Activity activityRequest, Principal principal) {
    	
        Map<String, Object> resultMap = new HashMap<>();
        
    	//사용자 질의
        String query   = activityRequest.getMessage();
        
        if( StringUtils.isEmpty(query) || query.length() > 13 ) {
        	return null;
        }

        //자동완성 영역 구분
        String subType = activityRequest.getSubtype();

        List<Map<String, Object>> result = new ArrayList<>();

        for( Entry<String, RestfulApi> suggestInfo : autoSuggest.getApi(getTenantId()).entrySet()) {
            
            String type     = suggestInfo.getKey();
            
            //요청한 subType이 있다면 요청한 subType만 조회되도록 함
            if( !StringUtils.isEmpty(subType) && !subType.equals(type)) {
            	continue;
            }
            String section  = suggestInfo.getKey();
            RestfulApi api  = suggestInfo.getValue();
            
            //추천 section
            Map<String, Object> suggestSection = new HashMap<String, Object>();
            
            //화면에 출력될 포맷
            List<Map<String, String>> suggestList = new ArrayList<>();

            switch(type) {

            case "context" ://type = 의도 분석용  : intent , 시스템/메뉴용 : system/menu
                List<IntentMongo> intentList = intentService.findByContext(activityRequest.getBotId(), query, true, true);

                logger.info("context : length " + intentList + " botId : " + activityRequest.getBotId() + " query : " + query);

                if( intentList == null || intentList.isEmpty() ) {
                    continue;
                }

                suggestSection.put("type", type);
                suggestSection.put("title", api.getTitle());

                intentList.forEach(new Consumer<IntentMongo>() {
                    public void accept(IntentMongo intent) {
                        if( intent.getUtterance() == null ) {
                            return;
                        }                           
                        Map<String, String> suggestData = new HashMap<>();
                        suggestData.put("section", section);
                        suggestData.put("type", type);
                        suggestData.put("name", intent.getUtterance().getText());
                        suggestData.put("action", intent.getUtterance().getText());

                        //params
                        try {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("inquiryType", "autosuggest");
                            params.put("intentId", intent.getIntentId());
                        	suggestData.put("actionParams", om.writeValueAsString(params));
						} catch (JsonProcessingException e) {
						}
                        suggestList.add(suggestData);
                    }
                });
                break;
            }
            
            suggestSection.put("suggestions", suggestList);
            result.add(suggestSection);
        }
        
        resultMap.put("suggestions", result);
        resultMap.put("subtype", activityRequest.getSubtype());
        
        return resultMap;
    }
    @RequestMapping(value = "/message/command/{command}", method = RequestMethod.GET)
    public ResponseEntity<Activity>  command(@RequestBody Activity activity) throws Exception {
    	Activity activityResponse = null;
    	
    	User user = getUser();
    	String tenantId = user.getTenantId();
    	
    	activity.setUserId(this.getUser().getUserId());
    	activity.setSentDate(new Date());
    	activityService.insertActivity(activity);
        //dialogue호출.. 
        String activityType = (StringUtils.hasText(activity.getType())) ? activity.getType() : CommonCode.ACTIVITY_TYPE_MESSAGE;
		//String activitySubType = (StringUtils.hasText(activity.getSubtype())) ? activity.getSubtype() : CommonCode.ACTIVITY_SUBTYPE_BASIC;
		String reqUserId = user.getUserId();
		String botId = activity.getBotId();
		String reqActivityId = activity.getId();
		String reqIp = activity.getUserIp();
		String reqDeviceType = activity.getDeviceType();
		String companyCode = user.getAttr1();
 
        InquiryVO inquiry = new InquiryVO(user, activity.getMessage(), reqIp, reqDeviceType);
		inquiry.setRequestActivity(activity);
		//inquiry.setInquiryId(UUID.randomUUID().toString().replace("-", ""));
		inquiry.setInquiryId(reqActivityId);
		inquiry.setCompanyCode( (StringUtils.hasText(companyCode)) ? companyCode : "LG01" );
		inquiry.setTenantId( (StringUtils.hasText(tenantId)) ? tenantId : "lgcns" );
		inquiry.setBotId(botId);
		inquiry.setReqUser(user);
		
		//Action Param 처리 (직전 요청이 SLOT FILLING, Parameter 중복이었을 경우)
		inquiry.setReqActionParams(activity.getActionParams());
		
		String searchSystemMenuId = this.dialogConfig.getDialogInfo(tenantId, "intentId", "searchSystemMenu");
		
		if ( StringUtils.isEmpty(searchSystemMenuId) ) {
			return  null;
		}
		
			
		//Intent Parameter 정보 처리, companyCode, title
		Map<String , Object> param = new HashMap<String, Object>();
		//param.put("companyCode", inquiry.getCompanyCode());
		param.put("userId", user.getUserId());
		param.put("searchMenu", "");
		
		inquiry.setIntentParam(param);
		
		//Action 정보 처리
		Action action = this.actionService.getActionByIntentId(searchSystemMenuId);
		
		if (action == null) {
			return null;
		}
		else {
			//Action 질의문의 개행문자, 탭문자를 공백문자로 치환
			action.setActionUri( DialogUtil.makeActionUriForRun(action.getActionUri()) );
			
			inquiry.setAction(action);
		}
		
		VpaDialog dialog = (VpaDialog) context.getBean(action.getActionDialogName());
		Activity activityResult = dialog.action(inquiry, true);
		
		//결과가 없으면 의도분석 처리
		if ( activityResult != null ) {
			
			activityResult.setSubtype(CommonCode.SUBTYPE_PREINTENT);
			List <Attachment> attmList = activityResult.getAttachments();
			
			if (attmList == null) {
				activityResult = null;
			}
			else {
				Attachment attm = attmList.get(0);
				if (attm == null) {
					activityResult = null;
				}
				else {
					if ( (attm.getElements() == null) || (attm.getElements().isEmpty()) ) {
						activityResult = null;
					}
				}
			}
		}//if-else, 시스템메뉴 조회 결과 없으면
    	return new ResponseEntity<>(activityResponse, HttpStatus.OK);
    }
    	
    
}