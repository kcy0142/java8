/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentBase.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.intent.entity.ParameterMap;
import com.lgcns.vpa.intent.model.IntentAnalysisResult.Status;
import com.lgcns.vpa.intent.model.IntentMongo.Parameter;
import com.lgcns.vpa.intent.model.IntentMongo.Utterance;

public class IntentBase {
	private String id;
	
	private String botId;

	private String intentId;

	private String extIntentId;
	/**
	 * intent 명
	 */
	private String intentName;
	
	private String intentType;
	
	/**
	 * 대와 문맥
	 */
	private List<String> contexts;
	
	/**
	 * 의도 자동 실행 여부
	 */
	private boolean autorun;
	
	private Status status;
	
	/**
	 * 단순 응답
	 */
	private String message;
	
	/**
	 * 애니메이션
	 */
	private String animation;
	
	/**
	 * 대표 질문
	 */
	private Utterance utterance;
	
	/**
	 * 파라미터 목록
	 */
	private Map<String, Parameter> parameters;
	
	/**
	 * entity 
	 */
	private ParameterMap entities;
	
	public static IntentBase createIntent(Status status, IntentMongo intentMongo) {
		
		IntentBase intent;
		switch(status) {
		
		case DUP_PARAMETER :
			intent = new IntentSet(intentMongo);
			break;
		case COMPLETED : 
			intent = new Intent(intentMongo);
			break;
		default : 
			intent = new IntentBase(intentMongo);
			break;
		}
		
		intent.setStatus(status);
		return intent;
	}
	
	public IntentBase() {
		this(null, null, null, null, null, null, false, null);
	}
	
	public IntentBase(String id, String botId, String intentId, String intentName, String intentType, List<String> contexts, boolean autorun, Utterance utterance) {
		this.id = id;
		this.botId = botId;
		this.intentId = intentId;
		this.intentName = intentName;
		this.intentType = intentType;
		this.contexts = contexts;
		this.utterance = utterance;
		this.parameters = new HashMap<>();
		this.autorun = autorun;
	}
	
	public IntentBase(IntentMongo intent) {
		this(intent.getId(), intent.getBotId(), intent.getIntentId(), intent.getIntentName(), intent.getIntentType(), intent.getContexts(), intent.isAutorun(), intent.getUtterance());
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}

	public String getExtIntentId() {
		return extIntentId;
	}

	public void setExtIntentId(String extIntentId) {
		this.extIntentId = extIntentId;
	}

	public String getIntentName() {
		return intentName;
	}

	public void setIntentName(String intentName) {
		this.intentName = intentName;
	}

	public Status getStatus() {
		return status;
	}
	
	public void setStatus(Status status) {
		this.status = status;
	}
	
	public String getIntentType(){
		return intentType;
	}
	
	public void setIntentType(String intentType) {
		this.intentType = intentType;
	}
	
	public List<String> getContexts() {
		return contexts;
	}

	public void setContexts(List<String> contexts) {
		this.contexts = contexts;
	}
	
	public void setAutorun(boolean autorun) {
		this.autorun = autorun;
	}
	
	public boolean isAutorun() {
		return autorun;
	}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAnimation() {
		return animation;
	}
	
	public void setAnimation(String animation) {
		this.animation = animation;
	}
	
	public Utterance getUtterance() {
		return utterance;
	}

	public void setUtterance(Utterance utterance) {
		this.utterance = utterance;
	}

	public Map<String, Parameter> getParameters() {
		return parameters;
	}

	public Parameter getParameter(String name) {
		if( parameters == null ) {
			return null;
		}
		
		return parameters.get(name);
	}
	public void setParameters(Map<String, Parameter> parameters) {
		this.parameters = parameters;
	}
	
	
	public void putParameters(String param, Parameter value) {
		if( this.parameters == null ) {
			this.parameters = new HashMap<String, Parameter>();
		}
		this.parameters.put(param, value);
	}

	public ParameterMap getEntities() {
		return entities;
	}

	public void setEntities(ParameterMap entities) {
		this.entities = entities;
	}
	
	public boolean isSameContextAs(List<String> tgContexts) {
		
		if( this.contexts != null && tgContexts != null ) {
			for( String context : contexts ) {
				if( tgContexts.contains(context) ) {
					return true;
				}
			}
		}
		return false;
	}

	public String toString() {
		
		return String.format(
				"Intent [ id : %s, " 
				+ "botId : %s, "
				+ "intentId : %s, "
				+ "intentName : %s, "
				+ "status : %s - %s, "
				+ "message : %s, "
				+ "animation : %s, "
				+ "contexts : %s, "
				+ "utterance : %s, "
				+ "parameters : %s ]\n", 
				this.id, this.botId, this.intentId, this.intentName, status, (status==null?"N/A":status.getField()), message, animation, contexts, utterance, parameters);
	}

	
}
