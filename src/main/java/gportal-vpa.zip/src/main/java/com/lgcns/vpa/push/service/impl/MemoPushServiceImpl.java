package com.lgcns.vpa.push.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.model.PushHistory;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.PushService;


/**
 * <pre>
 * 메모 Push 알림 Service
 * </pre>
 * @author
 */
@Service("multi.memoPushService")
public class MemoPushServiceImpl extends PushAbstractService implements PushService {
	
    @Autowired
    RedisMessagePublisher redisMessagePublisher;
    
    @Autowired
	ActivityService activityService;
    
    @Autowired
    private MongoTemplate mongoTemplate;
    
    @Autowired
    private ConfigService configService;
	
    @Override
    public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig){
    	
    	String botId = params.get("botId");
    	
    	checkBotId(botId);
		
		List<PushConfig> pushConfigList = configService.retrievePushConfigAllUserList(pushConfig.getPushId(), null);
		
		TransferSyncVO transferSyncVO =  new TransferSyncVO();
		transferSyncVO.setActionUri(pushConfig.getActionUri());
		transferSyncVO.setTenantId(tenantId);
		
		//mongodb에 실행 이력 저장(초기값 설정)
		PushHistory push=new PushHistory();
		push.setBotId(botId);
		push.setPushId(pushConfig.getPushId());
		push.setJobGroup(tenantId);
		push.setJobName("MemoBatch");
		push.setResponseCount(0);
		push.setExecuteCount(0);
		push.setSentDate(new Date());
		
		List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
		
		int count=0;
		if(proxyResultSet != null){
			
			
			for(Map<String, Object> proxyResult: proxyResultSet){
				
				String userId = StringUtils.toString(proxyResult.get("userId"));
				
				if(pushConfigList.stream().anyMatch(t -> t.getUserId().equals(userId))){
				    String id = StringUtils.toString(proxyResult.get("id"));
					String message = StringUtils.toString(proxyResult.get("message"));
					String title = StringUtils.toString(proxyResult.get("title"));
					String text = StringUtils.toString(proxyResult.get("text"));
					
					String localeCode = pushConfigList.stream()
							.filter(x -> userId.equals(x.getUserId()))
							.map(PushConfig::getLocaleCode)
							.findAny()
							.orElse(ActivityCode.DEFAULT_LOCALE_CODE);
						
					Activity activity = createPushActivity(botId, userId, localeCode, message);
					
					Attachment attachment = new Attachment();
					
					attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
					attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_MEMO);
					
					Element element = new Element();
					element.setId(id);
					element.setTitle(title);
					element.setText(text);
										
					element.addAdditionalProperty("priority", StringUtils.toString(proxyResult.get("priority")));
					element.addAdditionalProperty("completeYn", StringUtils.toString(proxyResult.get("completeYn")));
					element.addAdditionalProperty("deadlineYn", StringUtils.toString(proxyResult.get("deadlineYn")));
					element.addAdditionalProperty("deadlineDate", StringUtils.toString(proxyResult.get("deadlineDate")));
					element.addAdditionalProperty("deadlineTime", StringUtils.toString(proxyResult.get("deadlineTime")));
					element.addAdditionalProperty("todoYn", StringUtils.toString(proxyResult.get("todoYn")));
					element.addAdditionalProperty("alarmYn", StringUtils.toString(proxyResult.get("alarmYn")));
					element.addAdditionalProperty("alarmDate", StringUtils.toString(proxyResult.get("alarmDate")));
					element.addAdditionalProperty("alarmTime", StringUtils.toString(proxyResult.get("alarmTime")));

					attachment.addElement(element);
					activity.addAttachment(attachment);
					
					redisMessagePublisher.publish(activity);
					count=count+1;
				}
				
			}
			
			push.setResponseCount(proxyResultSet.size());
			push.setExecuteCount(count);
		}
		//data가 없어도 배치 수행후 초기값 저장
		mongoTemplate.save(push, "pushHistory");
	}
	
}
