/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : PreProcessService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.preProcess;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.preProcess.excute.PreProcessExcutor;

@Service("multi.preProcessService")
public class PreProcessService {
	
	@Autowired
	private ApplicationContext context;
	
	public Activity preProcessExcute ( InquiryVO inquiry, String tenantId ) {
		
		if ( inquiry == null ) {
			return null;
		}
		
		Activity resultActivity = null;
		PreProcessExcutor preExcutor = null;
		
		switch (tenantId) {
		case "lgcns" :
			preExcutor = (PreProcessExcutor) context.getBean("LGCnsExcutor");
			resultActivity = preExcutor.execute(inquiry);
			break;
		case "gsenc" :
			preExcutor = (PreProcessExcutor) context.getBean("GSEncExcutor");
			resultActivity = preExcutor.execute(inquiry);
			break;
		}
		
		return resultActivity;
	}
	
}
