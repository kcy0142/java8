/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserAutoRunController.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.push.model.UserAutoRun;
import com.lgcns.vpa.push.service.UserAutoRunService;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.security.user.service.UserService;

/**
 * <PRE>
 * 사용자별 자동 알림 설정을 관리하는 Controller
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 11. 29.
 */
@RestController
@CrossOrigin(value="*")
@RequestMapping(value="/api/userAutoRun")
public class UserAutoRunController extends BaseController {

	final Logger logger = LoggerFactory.getLogger(UserAutoRunController.class);
	
	@Autowired
	private UserAutoRunService userAutoRunService;
	
	@Autowired
	private UserService userService;
	
	/**
	 * 사용자별 자동 실행 설정 정보 생성
	 * @param botId
	 * @param params
	 * @return
	 */
	@RequestMapping(value="/{botId}/create", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> createUserAutoRun (
					@PathVariable(value="botId") String botId,
					@RequestBody Map<String, Object> params) {
		
		if ( (params == null) || (params.isEmpty()) ) {
			throw new RuntimeException("정보가 유효하지 않습니다.");
		}
		
		String repeatDay = (params.get("repeatDay") != null) ? (String) params.get("repeatDay") : null;
		String repeatTime = (params.get("repeatTime") != null) ? (String) params.get("repeatTime") : null;
		String intentId = (params.get("intentId") != null) ? (String) params.get("intentId") : null;
		String inquiry = (params.get("inquiry") != null) ? (String) params.get("inquiry") : null;
		String parameter = (params.get("parameter") != null) ? (String) params.get("parameter") : null;
		//String userId = (params.get("userId") != null) ? (String) params.get("userId") : null;
		
		this.logger.info(String.format("botId:[%s], repeateDay:[%s], repeateTime:[%s] intentId:[%s] inquiry:[%s]", 
						 botId, repeatDay, repeatTime, intentId, inquiry));
		
		//Parameter Validation
		if ( StringUtils.isEmpty(repeatDay) || StringUtils.isEmpty(repeatTime) || StringUtils.isEmpty(intentId) || StringUtils.isEmpty(inquiry) ) {
			throw new RuntimeException("정보가 유효하지 않습니다.");
		}
		
		//Session 정보 조회
		//TODO Session User 정보만 처리함
		User reqUser = getSessionUser();
		String reqUserId = ( reqUser != null ) ? reqUser.getUserId() : "70399";
		
		UserAutoRun uas = new UserAutoRun(reqUserId, repeatDay, repeatTime);
		uas.setBotId(botId);
		uas.setInquiry(inquiry);
		uas.setIntentId(intentId);
		
		if ( StringUtils.isEmpty(parameter) ) {
			uas.setParameter("");
		} else {
			uas.setParameter(parameter); 
		}
		
		//실행 상태 초기화
		uas.setProcessStatus(0);
		uas.setResultStatus(0);
		
		//자동 실행 시간 설정
		uas.setNextRunTime(uas.nextExcutionTimeLong());
		
		if (reqUser != null) {
			uas.setRegisterId(reqUser.getUserId());
			uas.setRegisterName(reqUser.getUserName());
			uas.setUpdaterId(reqUser.getUserId());
			uas.setUpdaterName(reqUser.getUserName());
		}
		else {
			//TODO Session 사용자로 처리해야 함
			uas.setRegisterId("70399");
			uas.setRegisterName("최환준");
			uas.setUpdaterId("70399");
			uas.setUpdaterName("최환준");
		}

		//return Result
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			//사용자별 자동 실행 설정 정보 생성
			this.userAutoRunService.create(uas);
			
			String minute = null, hour = null;
			
			if (repeatTime.length() >= 4) {
				minute = repeatTime.substring(2, 4);
				minute = (minute.equals("00")) ? null : minute;
				
				hour = repeatTime.substring(0, 2);
				hour = (hour.startsWith("0")) ? repeatTime.substring(1, 2) : hour;
			}
			else {
				minute = repeatTime.substring(1, 3);
				minute = (minute.equals("00")) ? null : minute;
				
				hour = repeatTime.substring(0, 1);
			}
			
			// 반환 메세지 생성
			StringBuffer strBuf = new StringBuffer();
			strBuf.append("매주 ").append(this.makeDayMessage(repeatDay));
			strBuf.append(" ").append(hour).append("시");
			if (minute != null) {
				strBuf.append(" ").append(minute).append("분");
			}
			strBuf.append("에 질의어:[").append(inquiry).append("]를 조회하여 결과를 알려드릴께요.");
						
			resultMap.put("RESULT", "OK");
			resultMap.put("RESULT_MSG", strBuf.toString());
			
		} catch (Exception e) {
			
			e.printStackTrace();
			resultMap.put("RESULT_CODE", "FAILURE");
			resultMap.put("RESULT_MSG", "사용자 자동실행 목록 생성을 실패하였습니다.");
			
			this.logger.error(e.toString());
		}
		
		return resultMap;
	}
	
	/**
	 * 사용자별 자동 실행 설정정보 삭제
	 * @param botId
	 * @param userAutoRunId
	 * @return
	 */
	@RequestMapping(value="/{botId}/delete/{userAutoRunId}", method=RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> deleteUserAutoRun (
					@PathVariable(value="botId") String botId,
					@PathVariable(value="userAutoRunId") String userAutoRunId) {
		
		System.out.println(String.format("deleteUserAutoRun botId:[%s], userAutoRunId:[%s]", botId, userAutoRunId));
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		try {
			userAutoRunService.delete(botId, userAutoRunId);
			resultMap.put("RESULT", "OK");
			resultMap.put("RESULT_MSG", "사용자 자동실행 목록을 삭제하였습니다.");
			resultMap.put("RESULT_INTENT", "자동 알림 조회");
		} catch (Exception e) {
			
			e.printStackTrace();
			
			resultMap.put("RESULT_CODE", "FAILURE");
			resultMap.put("RESULT_MSG", "사용자 자동실행 목록 삭제를 실패하였습니다.");
			resultMap.put("RESULT_INTENT", "자동 알림 조회");
		}
		
		return resultMap;
	}
	
	/**
	 * 사용자별 자동 실행 알림 배치 잡의 Call 을 처리함
	 * @param botId
	 * @param params
	 * @param req
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/{reqUserId}/startUserAutoRun", method= RequestMethod.POST)
    public ResponseEntity<Object> startUserAutoRun(
    		@PathVariable(value="reqUserId") String reqUserId,
    		@RequestBody (required=false) Map<String, String> params, HttpServletRequest req) throws Exception {
		
		String botId = params.get("botId");
    	String tenantId = params.get("tenantId");
    	
    	if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(reqUserId) || StringUtils.isEmpty(tenantId) ) {
    		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	
    	try {
			//관리자 정보 조회
	    	User adminUser = this.userService.selectUser(reqUserId);
	    	
	    	if ( adminUser == null ) {
	    		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    	}
	    	
	    	//사용자별 자동 실행복록별 처리 (비동기 처리)
	    	this.userAutoRunService.startAutoRunJob(botId, tenantId, adminUser);
    	} catch (Exception e) {
    		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	/**
	 * 실행 중인 USerAutoRun 초기화
	 * @param params
	 * @param req
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/{reqUserId}/runningInit", method= RequestMethod.POST)
    public ResponseEntity<Object> runningUserAutoRunInit(
    		@PathVariable(value="reqUserId") String reqUserId,
    		@RequestBody (required=false) Map<String, String> params, HttpServletRequest req) throws Exception {
		
		String botId = params.get("botId");
    	String tenantId = params.get("tenantId");
    	
    	if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(reqUserId) || StringUtils.isEmpty(tenantId) ) {
    		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	
    	try {
			//관리자 정보 조회
	    	User adminUser = this.userService.selectUser(reqUserId);
	    	
	    	if ( adminUser == null ) {
	    		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    	}
	    	
	    	//실행 중인 자동 실행목록별 초기화 처리 (비동기 처리)
	    	this.userAutoRunService.runningUserAutoRunInit(botId, tenantId, adminUser);
    	} catch (Exception e) {
    		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	private String makeDayMessage (String repeatDay) {
		
		if ( StringUtils.isEmpty(repeatDay) ) {
			return null;
		}
		
		final String [] DAY_EN = {"MON","TUE","WED","THU","FRI","SAT","SUN"};
		final String [] DAY_KR = {"월요일","화요일","수요일","목요일","금요일","토요일","일요일"};
		final String COMMA = ",";
		
		StringBuffer resultDay = new StringBuffer();
		
		for ( int i = 0; i < 7; i++) {
			if (repeatDay.contains(DAY_EN[i])) {
				if (resultDay.length() > 0) {
					resultDay.append(COMMA).append(DAY_KR[i]);
				}
				else {
					resultDay.append(DAY_KR[i]);
				}
			}
		}
		
		return resultDay.toString();
	}
}
