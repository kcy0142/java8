package com.lgcns.vpa.intent.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.util.StringUtils;

/**
 * MongoDB에 저장시 사용되는 value object
 * @author 70399
 *
 */
@Document(collection = "intents")
@CompoundIndexes({
    @CompoundIndex(name = "intent_idx", def = "{'botId':1, 'intentId': 1}")
})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IntentMongo {
		
	public interface IntentType {
		static final String SMALL_TALK 	= "0";
		static final String INQUIRY 	= "1";
		static final String TRANSACTION = "2";
		static final String FAQ 		= "3";
	}

	/**
	 * mongoDB ObjectId
	 */
	@Id
	private String id;
	
	private String botId;

	/**
	 * 자체 key로 index함.. 
	 * TODO @Indexed로 선언한 경우, 지정한 키를 사용할 수 없음
	 */
	@Indexed
	private String intentId;
	
	/**
	 * 등록 1 : 조회 : 2 질의응답 : 3
	 */
	private String intentType;

	/**
	 * intent 명
	 */
	private String intentName;
	
	/**
	 * 대와 문맥
	 */
	private List<String> contexts;
	
	/**
	 * 자동 실행 (사용자 정의 알림)
	 */
	private boolean autorun;
	
	/**
	 * 단순 응답
	 */
	private String message;
	
	/**
	 * animation
	 */
	private String animation;
	
	/**
	 * 사용자 대표 질의문 혹은 최상위 한건
	 */
	private Utterance utterance;
	
	/**
	 * 파라미터 목록
	 */
	private List<Parameter> parameters;
	
	
	private List<Action> actions;
	
	public IntentMongo() {}
	
	public IntentMongo(String botId, String intentId, String intentName) {
		this(botId, intentId, intentName, null, false, null);
	}
	
	public IntentMongo(String botId, String intentId, String intentName, List<String> contexts, boolean autorun, List<Parameter> parameters) {
		this.botId    = botId;
		this.intentId = intentId;
		this.intentName = intentName;
		this.contexts = contexts;
		this.autorun = autorun;
		this.parameters = parameters;
	}
	
	public String getId() {
		return this.id;
	}

	public String getBotId() {
		return botId;
	}
	
	public void setBotId(String botId) {
		this.botId = botId;
	}
	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}

	public String getIntentType() {
		return intentType;
	}

	public void setIntentType(String intentType) {
		this.intentType = intentType;
	}

	public String getIntentName() {
		return intentName;
	}

	public void setIntentName(String intentName) {
		this.intentName = intentName;
	}

	public List<String> getContexts() {
		return contexts;
	}

	public void setContexts(List<String> contexts) {
		this.contexts = contexts;
	}
	
	public void setAutorun(boolean autorun) {
		this.autorun = autorun;
	}
	
	public boolean isAutorun() {
		return this.autorun;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageForDisplay() {
		String messageForDisplay = "";
		
		if ( !StringUtils.isEmpty(message) ) {
			String [] tmpList = StringUtils.splitExeptEmptyString(message, "||[");
			messageForDisplay = StringUtils.getRamdomString(tmpList);
		}
		
		return messageForDisplay;
	}
	
	public String getAnimation() {
		return animation;
	}
	
	public void setAnimation(String animation) {
		this.animation = animation;
	}
	
	public String getAnimationForDisplay() {
		String animationForDisplay = "";
		
		if ( !StringUtils.isEmpty(animation) ) {
			String [] tmpList = StringUtils.splitExeptEmptyString(animation, "||[");
			animationForDisplay = StringUtils.getRamdomString(tmpList);
		}
		
		return animationForDisplay;
	}
	
	/**
	 * 대표 질의문
	 * @return
	 */
	public Utterance getUtterance() {
		return utterance;
	}
	
	public void setUtterance(Utterance utterance) {
		this.utterance = utterance;
	}
	
	private List<Utterance> utterances;
	public List<Utterance> getUtterances() {
		return utterances;
	}
	
	public void setUtterances(List<Utterance> utterances) {
		this.utterances = utterances;
	}
	public List<Parameter> getParameters() {
		if( this.parameters == null ) {
			return Collections.EMPTY_LIST;
		}
		return this.parameters;
	}

	public Parameter getParameter(int index) {
		if( parameters != null && parameters.size() > index) {
			return parameters.get(index);
		}
		return null;
	}
	public void setParameters(List<Parameter> parameters) {
		this.parameters = parameters;
	}
	
	public void setParameter(int index, Parameter parameter) {
		if(this.parameters != null && parameters.size() > index ) {
			parameters.set(index, parameter);
		}
	}

	public void addParameter(Parameter parameter) {
		
		if( parameters == null ) {
			parameters = new ArrayList<Parameter>();
		}
		parameters.add(parameter);
	}

	public void removeParameter(int index) {
		if( parameters != null && parameters.size() > index) {
			parameters.remove(index);
		}
	}

	public List<Action> getActions() {
		if( this.actions != null ) {
			Collections.sort(this.actions, new Comparator<Action>() {
				@Override
				public int compare(Action o1, Action o2) {
					return o1.order - o2.order;
				}
			});
			return this.actions;
		} else {
			return Collections.EMPTY_LIST;
		}
	}
	
	public Action getAction(int index) {
		if( actions != null && actions.size() > index ) {
			return actions.get(index);
		}
		
		return null;
	}
	
	public void setActions(List<Action> actions) {
		this.actions = actions;
	}
	
	public void setAction(int index, Action action) {
		if( this.actions != null && this.actions.size() > index ) {
			this.actions.set(index, action);
		}
	}
	public void addAction(Action action) {
		if( this.actions == null ) {
			this.actions = new ArrayList<Action>();
		}
		
		this.actions.add(action);
	}
	
	public void removeAction(int index) {
		if( this.actions != null && this.actions.size() > index ) {
			this.actions.remove(index);
		}
	}
		
	
	public String toString() {
		
		return String.format(
				"intentId : %s "
				+ "intentName : %s "
				+ "contexts : %s "
				+ "autorun : %s "
				+ "parameters : %s "
				+ "utterances : %s ", 
				this.intentId, this.intentName, contexts, autorun, parameters, utterance);

	}

	/**
	 * 사용자 질의 패턴 
	 * @author 최환준
	 *
	 */
	public static class Utterance {
				
		/**
		 * 개체명이 태깅된 질의문
		 * [홍길동|P] 일정을 조회해줘
		 */
		private String text;
		
		/**
		 * 핛습을 위한 질의문 
		 * Person 일정을 조회해줘
		 */
		private String parsedText;
		
		
		private boolean isRepresentative;
		
		public Utterance() {
			
		}
		public Utterance(String text, String parsedText) {
			this.text = text;
			this.parsedText = parsedText;
			this.isRepresentative = false;
		}
		public String getText() {
			return text;
		}
		public void setText(String text) {
			this.text = text;
		}
		public String getParsedText() {
			return parsedText;
		}
		public void setParsedText(String parsedText) {
			this.parsedText = parsedText;
		}
		
		public boolean isRepresentative() {
			return isRepresentative;
		}
		
		public void setRepresentative(boolean isRepresentative) {
			this.isRepresentative = isRepresentative;
		}
		
		public String toString() {
			return String.format(
					"text : %s "
					+ "parsedText : %s "
					+ "representative : %s ",
					this.text, this.parsedText, this.isRepresentative);
		}
	}
	
	/**
	 * intent분석 결과로 intentid와 함께 리턴될 파라미터정보 
	 * @author 최환준
	 *
	 */
	public static class Parameter {
		/**
		 * 파라미터명
		 */
		private String name;
		/**
		 * 파라미터 값
		 * TODO $로 시작하는 경우, 동 이름의 치환 스크립트를 수행함 
		 */
		private Object value;
		
		private String dataType;

		/**
		 * 필수 여부
		 */
		private boolean required;
		
		/**
		 * 기본 값
		 */
		private String defaultValue;
		
		/**
		 * 누락시 재질의문
		 */
		private String prompt;
		
		public Parameter() {
			
		}
		public Parameter(String name) {
			this(name, null, "text");
		}
		
		public Parameter(String name, Object value, String dataType) {
			this(name, value, dataType, false, null, null);
		}
		
		public Parameter(String name, Object value, String dataType, boolean required) {
			this(name, value, dataType, required, null, null);
		}
		public Parameter(String name, Object value, String dataType, boolean required, String defaultValue,
				String prompt) {
			
			this.name = name;
			this.value = value;
			this.dataType = dataType;
			this.required = required;
			this.defaultValue = defaultValue;
			this.prompt = prompt;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Object getValue() {
			return value;
		}
		public void setValue(Object value) {
			this.value = value;
		}
		public String getDataType() {
			return this.dataType;
		}
		public void setDataType(String dataType) {
			this.dataType = dataType;
		}
		public boolean isRequired() {
			return required;
		}
		public void setRequired(boolean required) {
			this.required = required;
		}
		public String getDefaultValue() {
			return defaultValue;
		}
		public void setDefaultValue(String defaultValue) {
			this.defaultValue = defaultValue;
		}
		public String getPrompt() {
			return prompt;
		}
		public void setPrompt(String prompt) {
			this.prompt = prompt;
		}
		
		
		public String toString() {
			return String.format(
					"name : %s "
					+ "value : %s "
					+ "dataType : %s "
					+ "isRequired : %s "
					+ "defaultValue : %s "
					+ "prompt : %s", 
					this.name, this.value, this.dataType, this.required, this.defaultValue, this.prompt);
		}
		
	}
	
	public static class Action {
		private int order;
		
		private String name;
		
		private String type;
		
		private String intentId;
		
		private String action;
		
		private String prompt;
		
		private String params;
		
		public Action() {
			
		}
		
		public Action(String name, String type, String action) {
			this(name, type, null, action, null);
		}
		
		public Action(String name, String type, String intentId, String action, String prompt) {
			this.name = name;
			this.type = type;
			this.intentId = intentId;
			this.action = action;
			this.prompt = prompt;
			
		}

		public int getOrder() {
			return order;
		}

		public void setOrder(int order) {
			this.order = order;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getIntentId() {
			return intentId;
		}

		public void setIntentId(String intentId) {
			this.intentId = intentId;
		}

		public String getAction() {
			return action;
		}

		public void setAction(String action) {
			this.action = action;
		}
		
		public String getPrompt() {
			return prompt;
		}
		
		public void setPrompt(String prompt) {
			this.prompt = prompt;
		}
		
		public String getParams() {
			return params;
		}

		public void setParams(String params) {
			this.params = params;
		}

		
		public String toString() {
			return String.format(
					"name : %s "
					+ "type : %s "
					+ "intentId : %s "
					+ "action : %s "
					+ "params : %s \n", 
					this.name, this.type, this.intentId, this.action, this.params);
		}
		
	}
}
