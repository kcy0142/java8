package com.lgcns.vpa.channel.web;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.nio.charset.Charset;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.RestConfig.AutoSuggestApi;
import com.lgcns.vpa.base.config.RestConfig.RestfulApi;
import com.lgcns.vpa.base.config.RestConfig.RestfulApiSchem;
import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.dialog.service.DialogHandlerService;
import com.lgcns.vpa.intent.model.IntentMongo;
import com.lgcns.vpa.intent.service.IntentService;

/**
 * <pre>
 * Websocket 컨트롤러
 * </pre>
 * @author
 */
@Controller
@CrossOrigin(origins="*")
public class WebsocketController extends BaseController {
	
	final Logger logger = LoggerFactory.getLogger(WebsocketController.class);
	
    @Autowired
    private SimpMessagingTemplate messagingTemplate;
    
    @Autowired
    DialogHandlerService dialogHandlerService;
    
    @Autowired
    AutoSuggestApi autoSuggest;
    
    @Autowired
    RestTemplate apiService;
    
    @Autowired
    IntentService intentService;

    @Autowired
    ActivityService activityService;
    
	@Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    ObjectMapper om = new ObjectMapper();
    
    /**
     * 사용자의 대화를 처리
     * ActivityMap: {TYPE: message }
     *
     *@param activityRequest
     * @param principal
     * @return
     * @throws Exception
     */
    @MessageMapping("/chat.messages.{botId}")
    //@SendToUser("/topic/chat.messages")
    public void message(@DestinationVariable String botId, 
    		@Payload Activity activityRequest, 
    		Principal principal) throws Exception {
		 
    	//session validate start
		boolean isAlive = true;
		 
		String key = String.format("webscoket:%s", this.getUser().getUserId());

		String webSocketSessionId = (String)redisTemplate.opsForHash().get(key, "webSocketSessionId");
		String sessionId = (String)redisTemplate.opsForHash().get(key, "sessionId");


		String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
		String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
		
		
		/*if( redisTemplate.hasKey(sessionIdKey) ) {
			isAlive = true;
		}*/
		
		logger.info("######chat.messages userId:"+this.getUser().getUserId()+",webSocketSessionIdKey:"+webSocketSessionIdKey+",sessionIdKey:"+sessionIdKey+",isAlive:"+isAlive+"######");
		
		if(!isAlive){
			activityRequest.setType("error");
			this.messagingTemplate.convertAndSend("/topic/chat.messages", activityRequest);
			return ;
		}
       
		//session validate end
		
    	activityRequest.setUserId(this.getUser().getUserId());
        activityRequest.setSentDate(new Date());
        
        activityService.insertActivity(activityRequest);
        
       
        // 1. Message Broadcast
        // 용도 1: 사용자가 전송한 메시지의 실제 물리 ID를 할당한 후 리턴한다.
        // 용도 2: 사용자가 복수의 클라이언트에서 접속한 경우 사용자가 입력한 메시지를 해당 사용자의 전체 채널에 브로드캐스팅
        messagingTemplate.setMessageConverter(new MappingJackson2MessageConverter());
        messagingTemplate.convertAndSendToUser(principal.getName(), "/topic/chat.messages", activityRequest);

      
        // 2. Dialog Handler 호출
        // VPA 업무 처리 : 응답생성기를 통과한 결과를 리턴 받는다.
        Activity activityResponse = dialogHandlerService.syncInquiry(activityRequest, getSessionUser(), getTenantId());
        
        activityResponse.setUserId(this.getUser().getUserId());
        activityResponse.setSentDate(new Date());
        activityResponse.setReplyToId(activityRequest.getId());
        
        //Admin 의도파악 대상 모니터링 
        activityResponse.setRequestMessage(activityRequest.getMessage());     
        activityResponse.setRequestSentDate(activityRequest.getSentDate());
        activityResponse.setLeader(this.getUser().getLeader());	//통계용 정보 추가
    
        
        
        
        activityService.insertActivity(activityResponse);

        // 3. VPA 응답 : 화면 UI 에서 렌더링 할 수 있도록 응답 데이터를 전송한다.
        this.messagingTemplate.convertAndSendToUser(this.getUser().getUserId(), "/topic/chat.messages." + botId, activityResponse);
        //return activityResponse;
    }
    
    /**
     * 사용자가 메시지를 잘 받았음을 처리
     * ActivityMap: {TYPE: message } 
     *
     *@param activityRequest
     * @param principal
     * @return
     * @throws Exception
     */
    @MessageMapping("/chat.messageAccept.{botId}")
    public void messageAccept(@DestinationVariable String botId, 
    		@Payload Activity activityRequest, 
    		Principal principal) throws Exception {

    	activityRequest.setUserId(this.getUser().getUserId());
        activityRequest.setSentDate(new Date());
        
//        logger.info("#############messageAccept activityRequest getBotId :"+activityRequest.getBotId());
//        logger.info("#############messageAccept activityRequest getUserId:"+activityRequest.getUserId());
//        logger.info("#############messageAccept activityRequest getId:"+activityRequest.getId());
//        logger.info("#############messageAccept activityRequest getTempId:"+activityRequest.getTempId());
        
        activityService.updateMessageRead(activityRequest.getBotId(), activityRequest.getUserId(), activityRequest.getId(),activityRequest.getTempId());
        
     // 3. VPA 응답 : 화면 UI 에서 렌더링 할 수 있도록 응답 데이터를 전송한다.
        //this.messagingTemplate.convertAndSendToUser(this.getUser().getUserId(), "/topic/chat.messageAccept." + botId, activityRequest);
       
//        return activityRequest;
    }
    
    /**
     * 자동완성 요청 및 응답 ActivityMap: {TYPE: suggestions, SUBTYPE: ... }
     * @param principal
     * @return
     * @throws Exception
     */
    @MessageMapping("/chat.suggestions.{botId}")
    //@SendToUser("/topic/chat.suggestions")
    public void autosuggest(
    		@DestinationVariable String botId, 
    		@Payload Activity activityRequest, 
    		Principal principal) {
    	
        Map<String, Object> resultMap = new HashMap<>();
        
    	//사용자 질의
        String query   = activityRequest.getMessage();
        
        if( StringUtils.isEmpty(query) || query.length() > 13 || query.contains(" ")) {
        	resultMap.put("suggestions", Collections.EMPTY_LIST);
            this.messagingTemplate.convertAndSendToUser(this.getUser().getUserId(), "/topic/chat.suggestions." + botId, resultMap);
        }
        //자동완성 영역 구분
        String subType = activityRequest.getSubtype();

        List<Map<String, Object>> result = new ArrayList<>();

        for( Entry<String, RestfulApi> suggestInfo : autoSuggest.getApi(getTenantId()).entrySet()) {
            
            String type     = suggestInfo.getKey();
            
            //요청한 subType이 있다면 요청한 subType만 조회되도록 함
            if( !StringUtils.isEmpty(subType) && !subType.equals(type)) {
            	continue;
            }
            String section  = suggestInfo.getKey();
            RestfulApi api  = suggestInfo.getValue();
            
            //추천 section
            Map<String, Object> suggestSection = new HashMap<String, Object>();
            
            //화면에 출력될 포맷
            List<Map<String, String>> suggestList = new ArrayList<>();

            final RestfulApiSchem schem = api.getSchem();
            
            switch(type) {
            case "user" : 
                List<Map<String, Object>> userList = null;
                
                try {
                    JsonNode root = om.readTree(call(api.getUrl(), query, "&listCount=11"));
                    userList = convert(root, schem);
                } catch (Exception e) {
                    //e.printStackTrace();
                    continue;
                }

                if( userList == null || userList.isEmpty() ) {
                    continue;
                }
                suggestSection.put("type", type);
                suggestSection.put("title", api.getTitle());

                userList.forEach(new Consumer<Map<String, Object>>(){
                    public void accept(Map<String, Object> data) {
                        Map<String, String> suggestData = new HashMap<>();

                        for( Entry<String, String> params : schem.getParams().entrySet()) {
                            suggestData.put(params.getKey(), (String)data.getOrDefault(params.getValue(), ""));
                        }

                        suggestData.put("section", section);
                        suggestData.put("type", type);
                        String action = String.format("%s %s %s", suggestData.getOrDefault("groupName", ""), suggestData.get("userName"), suggestData.get("jobTitleName"));
                        suggestData.put("action",action);
                        suggestData.put("name",  String.format("%s %s", suggestData.get("userName"), suggestData.get("jobTitleName")));
                        suggestData.put("mobile",  suggestData.getOrDefault("mobile", ""));
                        suggestData.put("leader",  suggestData.getOrDefault("leader", ""));
                        
                        //params
                        try {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("inquiryType", "autosuggest");//	
                          
                            params.put("intentId", schem.getParams().get("intentId"));
                            params.put("P_", String.format("{\"id\":\"%s\",\"name\":\"%s\"}", 
                            		suggestData.get("userId"), suggestData.get("name")));
                            
                        	suggestData.put("actionParams", om.writeValueAsString(params));
						} catch (JsonProcessingException e) {
						}

                        suggestList.add(suggestData);
                    }
                });
                break;
            case "project" : 

                break;
            case "context" ://type = 의도 분석용  : intent , 시스템/메뉴용 : system/menu
                List<IntentMongo> intentList = intentService.findByContext(activityRequest.getBotId(), query, true, true);

                logger.info("context : length " + intentList + " botId : " + activityRequest.getBotId() + " query : " + query);

                if( intentList == null || intentList.isEmpty() ) {
                    continue;
                }

                suggestSection.put("type", type);
                suggestSection.put("title", api.getTitle());

                intentList.forEach(new Consumer<IntentMongo>() {
                    public void accept(IntentMongo intent) {
                        if( intent.getUtterance() == null ) {
                            return;
                        }                           
                        Map<String, String> suggestData = new HashMap<>();
                        suggestData.put("section", section);
                        suggestData.put("type", type);
                        suggestData.put("name", intent.getUtterance().getText());
                        suggestData.put("action", intent.getUtterance().getText());

                        //params
                        try {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("inquiryType", "autosuggest");
                            params.put("intentId", intent.getIntentId());
                        	suggestData.put("actionParams", om.writeValueAsString(params));
						} catch (JsonProcessingException e) {
						}
                        suggestList.add(suggestData);

                    }
                });
                break;
            }
            
            suggestSection.put("suggestions", suggestList);
            result.add(suggestSection);
        }
        
        resultMap.put("suggestions", result);
        resultMap.put("subtype", activityRequest.getSubtype());
        
        this.messagingTemplate.convertAndSendToUser(this.getUser().getUserId(), "/topic/chat.suggestions." + botId, resultMap);
        //return resultMap;
    }
    
    private List<Map<String, Object>> convert(JsonNode root, RestfulApiSchem schem) {
        
        JsonNode payloadNode = root;
        if( schem != null && !StringUtils.isEmpty(schem.getPath()) ) {
            payloadNode = root.get(schem.getPath());
        }
        return om.convertValue(payloadNode, new TypeReference<List<Map<String, Object>>>(){});
    }
    
    private String call(String url, String query, String option) throws UnsupportedEncodingException {

    	UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(String.format(url, query) + option + "&prefixQuery=<ALIAS:employee> <CORP_CODE:" +getUser().getAttr1()+ ">");
        
        URI uri = uriBuilder.build().encode("UTF-8").toUri();
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(new MediaType("text", "plain", Charset.forName("UTF-8")));

        ResponseEntity<String> result = apiService.exchange(
                uri, 
                HttpMethod.GET, 
                new HttpEntity<String>("parameters", headers), 
                String.class);
        
        if( result != null && result.getStatusCode().equals(HttpStatus.OK) ) {
            return result.getBody();
        } else {
            return "";
        }
    }    
}