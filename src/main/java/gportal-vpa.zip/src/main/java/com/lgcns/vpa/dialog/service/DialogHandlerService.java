/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : DialogHandlerService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.dialog.VpaDialog;
import com.lgcns.vpa.dialog.service.preProcess.PreProcessService;
import com.lgcns.vpa.dialog.util.DialogUtil;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.dialog.util.JsonUtil;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.intent.exception.IntentException;
import com.lgcns.vpa.intent.model.Intent;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.intent.model.IntentAnalysisResult;
import com.lgcns.vpa.intent.model.IntentAnalysisResult.Status;
import com.lgcns.vpa.intent.model.IntentBase;
import com.lgcns.vpa.intent.model.IntentMongo;
import com.lgcns.vpa.intent.model.IntentMongo.Parameter;
import com.lgcns.vpa.intent.model.IntentSet;
import com.lgcns.vpa.intent.model.SimilarIntentSet;
import com.lgcns.vpa.intent.service.IntentService;
import com.lgcns.vpa.intent.service.impl.IntentContext;
import com.lgcns.vpa.intent.translator.MessageTranslator;
import com.lgcns.vpa.push.service.UserAutoRunConfigService;
import com.lgcns.vpa.security.user.model.JobTitle;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.security.user.service.JobTitleService;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
/**
 * <PRE>
 * Dialog Handler Service 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Service("multi.dialogHandlerService")
public class DialogHandlerService {
	
	private static final Logger LOG = LoggerFactory.getLogger(DialogHandlerService.class);
	
	@Autowired
	private ApplicationContext context;
	
	@Autowired
	private IntentService intentService;
	
	@Autowired
	private IntentContext intentContext;
	
	@Autowired
	private ActionService actionService;
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private BotService botService;
	
	@Autowired
	private SynonymService synonymService;
	
	@Autowired
	private JobTitleService jobTitleService;
	
	@Autowired
	private PreProcessService preProcessService;
	
	@Autowired
	private DialogConfig dialogConfig;
	
	@Autowired
	private UserAutoRunConfigService userAutoRunConfigService;
	
	@Autowired
	private MessageTranslator messageTranslator;
	
	@Value("#{'${smsSendIntentId}'.split(',')}") 
	private List<String> smsSendIntentIdList; 
	
	
	/**
	 * 동기식 질의문 처리
	 * 	- activity.getType();		//액티비티 유형 (message: 메시지, notification: 알림, sent-message-response, ping-pong... )
	 *	- activity.getSubtype(); 	//액티비티 Sub 유형 (search, app 등)
	 *	- activity.getText();		//메시지
	 *	- activity.getSenderId();	//액티비티 발신자
	 *  - activity.getReceiverId(); //BotId
	 * @param activity
	 * @param user
	 * @param tenantId
	 * @return
	 */
	public Activity syncInquiry (Activity activity, User reqUser, String tenantId) {
		
		if ( reqUser == null ) {
			LOG.info("syncInquiry() start : reqUser:[null],tenantId:["+tenantId+"],activity:["+JsonUtil.toJson(activity)+"]");
		}
		else {
			LOG.info("syncInquiry() start : reqUser:["+reqUser.getUserId()+"],tenantId:["+tenantId+"],activity:["+JsonUtil.toJson(activity)+"]");
		}
		
		if ( (activity == null) || (!StringUtils.hasText(activity.getMessage())) ) {
			return this.commonResponeService.cannotUnderstand(activity);
		}
		
		long startTime = System.currentTimeMillis();
		long spentTiemPreIntent = 0L;
		
		// DataSourceKey Setting
		DataSourceKeyHolder.setDataSourceKey(tenantId);
		
		//Dialog Object
		VpaDialog dialog = null;
		Activity activityResult = null;
		
		//불용어 처리된 데이터 인지 표시 (좋아요/싫어요 버튼의 추가 여부 결정)
		boolean isStopWordAction = false;
				
		String activityType = (StringUtils.hasText(activity.getType())) ? activity.getType() : CommonCode.ACTIVITY_TYPE_MESSAGE;
		//String activitySubType = (StringUtils.hasText(activity.getSubtype())) ? activity.getSubtype() : CommonCode.ACTIVITY_SUBTYPE_BASIC;
		String reqUserId = reqUser.getUserId();
		String botId = activity.getBotId();
		String reqActivityId = activity.getId();
		String reqIp = activity.getUserIp();
		String reqDeviceType = activity.getDeviceType();
		String companyCode = reqUser.getAttr1();
		
		//유의어 치환 전 메세지를 저장함
		activity.setPreSynonymMessage(activity.getMessage());
		
		//유의어 치환 전 특수문자 제거
		String inquiryData = StringUtils.removeSpecialChar(activity.getMessage());
		inquiryData = (inquiryData == null) ? "" : inquiryData;
		
		//특수문자 제거 후 질의어가 비어있는 경우 처리
		if ( StringUtils.isEmpty(inquiryData) ) {
			
			//특숰문자 제거 전 질의어로 불용어를 검색함
			InquiryVO inquiry = new InquiryVO(reqUser, activity.getPreSynonymMessage(), reqIp, reqDeviceType);
			inquiry.setRequestActivity(activity);
			inquiry.setInquiryId(reqActivityId);
			inquiry.setCompanyCode( companyCode );
			inquiry.setTenantId( tenantId );
			inquiry.setBotId(botId);
			inquiry.setReqUser(reqUser);
			
			dialog = (VpaDialog) context.getBean("StopWordDialog");
			activityResult = dialog.action(inquiry, true);
			
			//불용어 정보가 있으면
			if (activityResult != null) {
				
				if ( activityResult != null ) {
					isStopWordAction = true;//불용어 처리 여부 표시
					LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:["+inquiry.getInquiryData()+"],STATUS:[불용어 처리됨],Message:["+activityResult.getMessage()+"]");
				}
				
				return activityResult;
			}
			//불용어 정보가 없으면
			else {
				return this.commonResponeService.cannotUnderstand(activity);
			}
		}
		
		//TODO 직급명, 직급명+님, 팀장, 팀장님 앞뒤에 공백추가 (연속 공백 제거)
		//NLU에서 직급 구분이 잘되면 없애야 함
		//공백 추가 제거, 2017.12.19
		//inquiryData = this.spaceCheckJobTitle(inquiryData, botId);
		
		//앞 뒤 공백 제거
		inquiryData = inquiryData.trim();
				
		//질의문의 유의어를 치환함,  모든 질의문중 영문은 소문자로 치환함
		inquiryData = synonymService.convertToSynonym(inquiryData.toLowerCase(), botId);
		activity.setMessage(inquiryData.toLowerCase());
		
		//질의에 대한 처리를 담당하는 Object 생성
		InquiryVO inquiry = new InquiryVO(reqUser, inquiryData, reqIp, reqDeviceType);
		inquiry.setRequestActivity(activity);
		//inquiry.setInquiryId(UUID.randomUUID().toString().replace("-", ""));
		inquiry.setInquiryId(reqActivityId);
		inquiry.setCompanyCode( (StringUtils.hasText(companyCode)) ? companyCode : "LG01" );
		inquiry.setTenantId( (StringUtils.hasText(tenantId)) ? tenantId : "lgcns" );
		inquiry.setBotId(botId);
		inquiry.setReqUser(reqUser);
		
		//Action Param 처리 (직전 요청이 SLOT FILLING, Parameter 중복이었을 경우)
		inquiry.setReqActionParams(activity.getActionParams());
		
		//Inquiry Type 별로 실행할 Process 분기
		switch (activityType) {
			case CommonCode.ACTIVITY_TYPE_MESSAGE :
				
				//직전 의도분석이 SLOT Filling 인지 검사
				IntentBase intentBase = intentContext.getLastIntent(tenantId, reqUser.getUserId());
				boolean isPostSlotFilling = ( (intentBase != null) && (Status.SLOT_FILLING == intentBase.getStatus()) ) ? true : false;
				
				//SLOT Filling, Parameter Duplication 이 아닐 경우만 불용어 전처리 검사 수행
				if ( (!isPostSlotFilling) && (activity.getActionParams() == null) ) {
					//일반 질의 처리
					//관용어구(불용어) 인지 검사
					dialog = (VpaDialog) context.getBean("StopWordDialog");
					activityResult = dialog.action(inquiry, true);
					
					if ( activityResult != null ) {
						isStopWordAction = true;//불용어 처리 여부 표시
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:["+inquiry.getInquiryData()+"],STATUS:[불용어 처리됨],Message:["+activityResult.getMessage()+"]");
					}
					else {
						long startPreIntentTime = System.currentTimeMillis();
						
						//TenantId 별 전처리 수행 
						activityResult = preProcessService.preProcessExcute(inquiry, tenantId);
						
						//전처리 소요 시간
						spentTiemPreIntent = System.currentTimeMillis() - startPreIntentTime;
						
					}//if-else 불용어 결과가 없으면
				}//if 직전 의도분석이 SLOT Filling 또는 Parameter 중복이 아니면
				
			case CommonCode.ACTIVITY_TYPE_LGEFAQ :
				if (activityType.equals(CommonCode.ACTIVITY_TYPE_LGEFAQ)) {
					LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:["+inquiry.getInquiryData()+"],STATUS:[LGEFAQ 처리시작]");
				}
				//LGE FAQ 처리
			default :
				//불용어 결과가 없을 경우 의도분석 시작
				if ( activityResult == null ) {
					//의도 분석
					//- 후속 Action이 필요 없는 경우
					//- 후속 Action이 필요한 경우
					//- 의도가 없어 통합 검색이 필요한 경우 
					intentProcess(inquiry, reqUser);
					
					switch (inquiry.getProcessStatus()) {
						//후속 Action 진행
						case CommonCode.INQUIRY_STATE_INTENT_COMPLETE :
							//Action MetaData 조회
							//- Action MetaData가 없을 경우
							//- Action MetaData가 있을 경우
							//getActionMetadata(inquiry);
							
							if ( !(inquiry.getProcessStatus() != CommonCode.INQUIRY_STATE_ACTION_COMPLETE) || 
								 (inquiry.getAction() == null) ) {
								//의도와 Mapping 된 Action MetaData가 없을 경우
								activityResult = this.commonResponeService.cannotUnderstand(inquiry);
								
								LOG.info("inquiryId:["+inquiry.getInquiryId()+"],intentId:["+inquiry.getIntentId()+"],STATUS:[ACTION 정보 없음],MESSAGE:["+activityResult.getMessage()+"]");
							}
							else {
								
								Action action = inquiry.getAction();
								//Dialog Object 생성
								//Action MetaData 에서 처리 Dialog 정보에 따라 처리
								try {
									
									long actionStartTime = System.currentTimeMillis();
									
									if ( !StringUtils.hasText(action.getActionDialogName()) ) {
										dialog = (VpaDialog) context.getBean("CommonDialog");
										LOG.info("inquiryId:["+inquiry.getInquiryId()+"],intentId:["+inquiry.getIntentId()+"],actionId:["+inquiry.getAction().getActionId()+"],Default Dialog:[CommonDialog]");
										
										activityResult = dialog.action(inquiry, false);
									}
									else {
										dialog = (VpaDialog) context.getBean(action.getActionDialogName());
										LOG.info("inquiryId:["+inquiry.getInquiryId()+"],intentId:["+inquiry.getIntentId()+"],actionId:["+inquiry.getAction().getActionId()+"],Dialog:["+action.getActionDialogName()+"]");
										
										activityResult = dialog.action(inquiry, false);
									}
									
									LOG.info("inquiryId:["+inquiry.getInquiryId()+"],intentId:["+inquiry.getIntentId()+"],actionId:["+inquiry.getAction().getActionId()+"],ACTION 수행시간:["+(System.currentTimeMillis()-actionStartTime)+"ms]");
								}
								catch (Exception e) {
									activityResult = this.commonResponeService.errorWarning(inquiry);
									LOG.info("inquiryId:["+inquiry.getInquiryId()+"],intentId:["+inquiry.getIntentId()+"],actionId:["+inquiry.getAction().getActionId()+"],STATUS:[Dialog Instance 생성 오류],exception:"+e.toString());
								}
							}
							
							break;
						//후속 Action 필요 없음 (Multi Intetn, 단순 질의, Slot filling, 의도중복, 파라미터 중복)
						case CommonCode.INQUIRY_STATE_INTENT_MULTI :
							inquiry.setActionResult(this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_INTENT_LOW));
						case CommonCode.INQUIRY_STATE_INTENT_ACTIONEND :
						case CommonCode.INQUIRY_STATE_INTENT_SLOT :
						case CommonCode.INQUIRY_STATE_INTENT_DUPPARAM :
							activityResult = this.commonResponeService.createSimpleResponse (inquiry.getActionResult(), reqActivityId, botId, reqUserId, reqIp, reqDeviceType);
							
							//중복된 사용자가 의도에서 파악된 경우 통합검색, 그룹사 인원 조회버튼 처리를 하기 위한 구분
							boolean isTotalSearchInGroup = false;
							
							//Action Parameter 처리
							if (inquiry.getIntentParam() != null) {
								activityResult.setActionParams(inquiry.getIntentParam());
							}
							
							//Element 처리 (Multi Intent, Parameter 중복일 경우)
							if (inquiry.getParamElements() != null) {
								
								List<Attachment> attachments = activityResult.getAttachments();
								Attachment attachment = null;
								
								boolean isUserList = false;
								List<Element> elements = inquiry.getParamElements();
								Element elem = elements.get(0);
								
								if ( elem != null ) {
									isUserList = ( CommonCode.ELEMENT_TYPE_PEOPLE.equals(elem.getType()) ) ? true : false;
									
									int paramCount = elements.size();
									
									//Activity Result Message  변경
									//사용자 목록이 중복 되었을 경우 "총 N명의 사용자가 조회되었습니다. 질의하실 대상을 선택해주세요." 로 출력함
									//비 사용자 목록이 중복 되었을 경우 "총 N건의 데이터가 조회되었습니다. 질의하실 대상을 선택해주세요." 로 출력함
									//TODO  향 후 의도분석에서 메세지 출력 시 대체함
									if ( paramCount > 1 ) {
										
										String paramDupMessage = (isUserList ) ? 
												String.format(this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_MULTI_USER), paramCount) :
												String.format(this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_MULTI_RESULT), paramCount);
												
										activityResult.setMessage(paramDupMessage.toString());
									}
								}
								
								if (attachments == null) {
									attachment = new Attachment();
									attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
									
									if (isUserList) {//사용자 목록 처리
										attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_PEOPLE_LIST);
										isTotalSearchInGroup = true;
									}
									else {//비 사용자 목록 처리
										attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
									}
									attachment.setElements(inquiry.getParamElements());
									
									attachments = new ArrayList<Attachment>();
									attachments.add(attachment);
									
									activityResult.setAttachments(attachments);
								}
								else {
									attachment = attachments.get(0);
									attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
									
									if (isUserList) {//사용자 목록 처리
										attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_PEOPLE_LIST);
									}
									else {//비 사용자 목록 처리
										attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
									}
									attachment.setElements(inquiry.getParamElements());
								}
							}// if (inquiry.getParamElements() != null) 
							
							//버튼이 있으면 처리
							if ( (inquiry.getIntentButtons() != null) && (!inquiry.getIntentButtons().isEmpty()) ) {
								List<RelatedButton> intentButtons = inquiry.getIntentButtons();
								List<Button> activityButtonList = DialogUtil.makeActivityButtonList(intentButtons);
																
								if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
									activityResult.setButtons(activityButtonList);
								}
							}
							//사용자 목록이 파라미터 중복으로 처리된 경우
							//통합 검색 버튼, 그룹사 인원 검색 추가
							else if (isTotalSearchInGroup) {
								activityResult.addButton(0, this.commonResponeService.makeSearchButton(StringUtils.removeSpecialChar(activity.getPreSynonymMessage()), tenantId));
								activityResult.addButton(1, this.commonResponeService.makeSearchInGroupButton(StringUtils.removeSpecialChar(activity.getPreSynonymMessage()), tenantId));
							}
							
							// Dialog를 수행하지 않는 경우 Intent Animation 처리
							if ( !StringUtils.isEmpty(inquiry.getIntentAnimation()) && StringUtils.isEmpty(activityResult.getAnimation()) ) {
								activityResult.setAnimation(inquiry.getIntentAnimation());
							}
							
							break;
						//오류 처리
						case CommonCode.INQUIRY_STATE_INTENT_ERR_CALL : 	/* 의도분석 중 의도분석 서버연결 오류 발생 */
							activityResult = this.commonResponeService.intentErrorWarning(inquiry, CommonCode.INQUIRY_STATE_INTENT_ERR_CALL);
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"],STATUS:[의도분석 서버연결 오류 발생],MESSAGE:["+activityResult.getMessage()+"]");
							break;
						case CommonCode.INQUIRY_STATE_INTENT_ERR_SERVER :	/* 의도분석 중 의도분석 서버처리 오류 발생 */
							activityResult = this.commonResponeService.intentErrorWarning(inquiry, CommonCode.INQUIRY_STATE_INTENT_ERR_SERVER);
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"],STATUS:[의도분석 서버처리 결과 오류 발생],MESSAGE:["+activityResult.getMessage()+"]");
							break;
						case CommonCode.INQUIRY_STATE_INTENT_ERR :			/* 의도분석 중 기타 오류 발생 */
							activityResult = this.commonResponeService.intentErrorWarning(inquiry);
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"],STATUS:[의도분석 시 오류 발생],MESSAGE:["+activityResult.getMessage()+"]");
							break;
						case CommonCode.INQUIRY_STATE_INTENT_PARAM_ERR :	/* 의도분석 중 파라미터 변환 관련 에러 발생 */
							activityResult = this.commonResponeService.intentErrorWarning(inquiry);
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"],STATUS:[의도분석 시 파라미터 변환관련 오류 발생],MESSAGE:["+activityResult.getMessage()+"]");
						default :
							activityResult = this.commonResponeService.cannotUnderstand(inquiry);
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"],STATUS:[분류되지 않는 상황 발생],MESSAGE:["+activityResult.getMessage()+"]");
					}
				}
				
			break;
		}
		
		//TODO 개발 완료 시 제거
		if ( (inquiry != null) && (activityResult != null) ) {
			activityResult.setIntentLog(inquiry.getIntentLog());
			activityResult.setIntentId(inquiry.getIntentId());  //좋아요/싫어요 intent벌로 파악하기 위해
			activityResult.setIntentType(inquiry.getIntentType());
		}
		
		if (activityResult == null) {
			activityResult = this.commonResponeService.cannotUnderstand(inquiry);
		}
		else {
			//BotId, ReplyToId 설정 확인
			if ( StringUtils.isEmpty(activityResult.getBotId()) ) {
				activityResult.setBotId(botId);
			}
			
			if ( StringUtils.isEmpty(activityResult.getReplyToId()) ) {
				activityResult.setReplyToId(reqActivityId);
			}
		}
		
		//좋아요/싫어요 버튼 추가, 불용어 처리를 제외하고 모든 응답에 추가함
		if ( !isStopWordAction && (activityResult != null) ) {
			List<Button> newButtons = this.addLikeButton(activityResult.getButtons());
			if (newButtons != null) {
				activityResult.setButtons(newButtons);
			}
		}
		
		long spentTime = System.currentTimeMillis()-startTime;
		if ( activityResult != null ) {
			activityResult.setSpentTime(spentTime);
			activityResult.setSpentTimeIntent(inquiry.getSpentTimeIntent());
			activityResult.setSpentTimeProxy(inquiry.getSpentTimeProxy());
			activityResult.setSpentTimePreIntent(spentTiemPreIntent);
			
			//사용자 질의 중 유의어 치환 전 메세지 처리
			activityResult.setPreSynonymMessage(activity.getPreSynonymMessage());
			
			//사용자 질의 중 유의어 치환 된 메세지 처리
			activityResult.setRequestMessage(inquiry.getInquiryData());
			
			//통합 검색 버튼 추가, Intent 가 도출되지 않은 결과에 추가됨, 불용어 처리 제외, 전처리 중 1명의 user_profile일 경우 제외
			if ( !isStopWordAction && StringUtils.isEmpty(activityResult.getIntentId()) ) {
				
				Attachment attm = activityResult.findAttachmentFirst();
				boolean isAddTotalSearchButton = true;
				if ( (attm != null) && 
					 ( ActivityCode.TEMPLATE_TYPE_CUSTOM_USRE_PROFILE.equals(attm.getTemplateType())) && 
					 (CommonCode.SUBTYPE_PREINTENT.equals(activityResult.getSubtype())) ) {
					isAddTotalSearchButton = false;
				}
				
				if (isAddTotalSearchButton) {
					activityResult.addButton(0, this.commonResponeService.makeSearchButton(StringUtils.removeSpecialChar(activity.getPreSynonymMessage()), tenantId));
				}
			}
			
			//사용자 자동 실행 설정 버튼 추가
			//자동 실행이 가능한 의도일경우 버튼 추가
			//의도 분석이 완료되어 의도가 있고 (MULTI_INTENT, SLOT_FILLING, MULTI_PARAM 상태가 아니어야 함)
			//사용자 자동 실행 설정 버튼 설정 시간이고 
			if ( inquiry.getIntentAutoRunYn() &&
				 this.userAutoRunConfigService.isDisplayAutoRunButton(botId) && 
				 !StringUtils.isEmpty(activityResult.getIntentId()) ) {
				
				Map<String, Object> actionParams = new HashMap<String, Object>();
				actionParams.put("intentId", activityResult.getIntentId());
				actionParams.put("inquiry", activityResult.getRequestMessage());
				
				activityResult.addButton(this.commonResponeService.makeAutoRunButton(actionParams));
			}
		}
		LOG.info("syncInquiry() FINISHED inquiryId:["+inquiry.getInquiryId()+"],소요시간:["+(spentTime)+"ms],ACTIVITY JSON=======" + JsonUtil.toJson(activityResult)+"=======");
		
		return activityResult;
	}//syncInquiry end
	
	
	
	/**
	 * 의도분석
	 * @param inquiry
	 * @param reqUser
	 */
	private void intentProcess (InquiryVO inquiry, User reqUser) {
		//의도 분석 Parameter Setting
		//의도 분석 실행
		//결과 처리
		//- 의도 분석 결과가 없음
		//- 의도 결과 있음
		//-    파라미터 중복 (Action 없이 응답)
		//-    Slot filling (Action 없이 응답)
		//-    단순 질의 (Action 없이 응답)
		//-	     일반 질의
		//- 오류 발생
		long startTime = System.currentTimeMillis();
 		long intnetFinishTime = 0;
		try {
			//진행 상태 Update
			inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_REQ);
			
			//의도분석 요청
			IntentAnalysisResult result = null;
			IntentBase intentBase = null;
			Map <String, Object> reqActionParams = inquiry.getReqActionParams();
			
			//일반질의 일 경우 의도분석 요청
			if ( reqActionParams == null ) {
				
				LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:[" +inquiry.getInquiryData()+"],의도분석 요청 구분[일반질의]");
				
				result = this.intentService.reasonIntent(inquiry.getTenantId(), inquiry.getBotId(), reqUser.getUserId(), inquiry.getInquiryData());
				intentBase = result.getIntent();
			}
			else {
				
				String inquiryType = null;
				String reqIntentId = null;
				String reqEntity = null;
				String reqValue = null;
				
				//SLOT FILLING 일 경우
				//PARAMETER 중복 일 경우
				for (String key : reqActionParams.keySet()) {
					
					if ("inquiryType".equalsIgnoreCase(key)) {
						inquiryType = (String) reqActionParams.get(key);
					}
					else if ("intentId".equalsIgnoreCase(key)) {
						reqIntentId = (String) reqActionParams.get(key);
					}
					else {
						reqEntity = key;
						reqValue = (String) reqActionParams.get(key);
					}
				}
				
				//의도분석 요청
				if ( !StringUtils.isEmpty(inquiryType) && !StringUtils.isEmpty(reqEntity) && !StringUtils.isEmpty(reqIntentId) ) {
					switch (inquiryType) {
					//SLOT Filling
					case CommonCode.INQUIRY_TYPE_SLOTFILLING :
						
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:["+inquiry.getInquiryData()+"],의도분석 요청 구분[SLOT FILLING],intentId:["+reqIntentId+
								 "],entity:["+reqEntity+"],value:["+inquiry.getInquiryData()+"]");
						
						//SLOT FILLING 시 입력된 질의문으로 처리
						result = this.intentService.fillIntent(inquiry.getTenantId(), inquiry.getBotId(), reqUser.getUserId(), reqIntentId, reqEntity, inquiry.getInquiryData());
						intentBase = result.getIntent();
						break;
					//Parameter Duplication
					case CommonCode.INQUIRY_TYPE_MULTIPARAM :
						
						//JsonData 를 Map으로 변환
						Map<String, Object> reqActionParamMap = null;
						if ( !StringUtils.isEmpty(reqValue) ) {
							reqActionParamMap = JsonConverter.jsonToMap(reqValue);
						}
						
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:["+inquiry.getInquiryData()+"],의도분석 요청 구분[파라미터 중복],intentId:["+reqIntentId+
								 "],entity:["+reqEntity+"],valueMap:["+reqActionParamMap+"]");
						
						//파라미터 중복 시 선택된 값의 파라미터를 질의문으로 처리
						result = this.intentService.fillIntent(inquiry.getTenantId(), inquiry.getBotId(), reqUser.getUserId(), reqIntentId, reqEntity, reqActionParamMap);
						intentBase = result.getIntent();
						break;
					//자동 완성에서 의도처리 요청
					case CommonCode.INQUIRY_TYPE_AUTO_SUGGFEST :
						
						//JsonData 를 Map으로 변환
						Map<String, Object> autoActionParamMap = null;
						if ( !StringUtils.isEmpty(reqValue) ) {
							autoActionParamMap = JsonConverter.jsonToMap(reqValue);
						}
						
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:["+inquiry.getInquiryData()+"],의도분석 요청 구분[자동완성 의도 처리 요청],intentId:["+reqIntentId+
								 "],entity:["+reqEntity+"],valueMap:["+autoActionParamMap+"]");
						
						//파라미터 중복 시 선택된 값의 파라미터를 질의문으로 처리
						result = this.intentService.transIntent(inquiry.getTenantId(), inquiry.getBotId(), reqUser.getUserId(), reqIntentId, reqEntity, autoActionParamMap);
						intentBase = result.getIntent();
						break;
					//일반 질의 처리
					case CommonCode.INQUIRY_TYPE_GENERAL :
					default :
						
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:[" +inquiry.getInquiryData()+"],의도분석 요청 구분[일반질의]");
						
						result = this.intentService.reasonIntent(inquiry.getTenantId(), inquiry.getBotId(), reqUser.getUserId(), inquiry.getInquiryData());
						intentBase = result.getIntent();
					}
				}
				else {//일반 질의 처리
					
					LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:[" +inquiry.getInquiryData()+"],의도분석 요청 구분[일반질의]");
					
					result = this.intentService.reasonIntent(inquiry.getTenantId(), inquiry.getBotId(), reqUser.getUserId(), inquiry.getInquiryData());
					intentBase = result.getIntent();
				}
			}
			
			
			//TODO 개발 완료 시 의도 분석 로그 제거
			//의도 분석 결과 로그 개발 시만 표시됨
			inquiry.setIntentLog(this.getIntentScore(result));
			
			intnetFinishTime = System.currentTimeMillis();
			LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:[" +inquiry.getInquiryData()+"],의도분석 소요시간:["+(intnetFinishTime-startTime)+"ms], "
					+ "result:["+this.getIntentScore(result)+"],"
					+ "intentBase:["+((intentBase != null)?intentBase.toString():null)+"]");
			
			//- 의도분석 결과가 없음 (Multi Intent일 경우는 IntentId 가 없음, 그 이외의 경우는 IntentId 가없으면 Error 처리)
			if ( (result == null) || (result.getStatus() == Status.NOT_UNDERSTAND) || (intentBase == null) || 
				 ((!StringUtils.hasText(intentBase.getIntentId())) && (!Status.MULTI_INTENTS.equals(intentBase.getStatus())) ) ) {
				inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_NONE);
			}
			//- 의도분석 결과가 있음
			else {
				//- 파라미터 중복 처리 : Intent.status == Status.DUP_PARAMETER (Intent.subIntent 에서 Data 생성)
				//- Slot filling 처리 : Intent.status == Status.SLOT_FILLING
				//- 단순 질의(추가 Action 필요 없음) : Intent.status == Status.COMPLETED
				//- 일반 질의 : Intent.status == Status.COMPLETED
				
				//Multi Intent 처리
				if (Status.MULTI_INTENTS.equals(intentBase.getStatus())) {
				
					SimilarIntentSet sIntentSet = (SimilarIntentSet) intentBase;
					String messageTmp = ( !StringUtils.isEmpty(sIntentSet.getMessage()) ) ? sIntentSet.getMessage() : "MULTI INTENT";
					
					inquiry.setIntentId(sIntentSet.getIntentId());
					inquiry.setIntentMessage(messageTmp);
					inquiry.setActionResult(messageTmp);
					inquiry.setIntentAnimation(sIntentSet.getAnimation());
					inquiry.setIntentType(sIntentSet.getIntentType());
					
					List<Element> paramElements = new ArrayList<Element>();
					Element elem = null;
					Map<String, Object>param = null;
					
					List<IntentBase> intentBaseList = sIntentSet.getIntents();
					
					if ( (intentBaseList == null) || (intentBaseList.isEmpty()) ) {
						inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_NONE);
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:[" +inquiry.getInquiryData()+"],Status:[Multi Intent, Intent 없음],intentId:["+intentBase.getIntentId()+"],intent Name:["+intentBase.getIntentName()+"]");
					}
					else {
						
						inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_MULTI);
						
						//MULTI INTENT 인 경우 intentId가 없음
						if ( StringUtils.isEmpty(sIntentSet.getIntentId()) ) {
							inquiry.setIntentId(messageTmp);
							inquiry.setIntentType(null);
						}
						
						String text = null, action = null;
						for (IntentBase intentBaseTmp : intentBaseList) {
							if (intentBaseTmp != null) {
								text = intentBaseTmp.getUtterance().getText();
								action = intentBaseTmp.getUtterance().getText();
								
								Element element = new Element();
								element.setType(CommonCode.ELEMENT_TYPE_TEXT);
								element.setTitle(text);
			    				element.setAction(action);
			    				element.setActionType(ActivityCode.ACTION_TYPE_INQUIRY);
			    				element.setCorpCode(inquiry.getCompanyCode());
			    				
			    				paramElements.add(element);
							}
						}//for
						
						if ( (paramElements != null) && (!paramElements.isEmpty()) ) {
							inquiry.setParamElements(paramElements);
						}
						
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], Status:[Multi Intent], intent Count:["+intentBaseList.size()+"],"
								+ "Intent List:["+paramElements.toString()+"]");
					}
				
				}
				//Slot filling 처리
				else if (Status.SLOT_FILLING.equals(intentBase.getStatus())) {
					
					//Intent intent = (Intent) intentBase;
					inquiry.setIntentId(intentBase.getIntentId());
					inquiry.setIntentAnimation(intentBase.getAnimation());
					inquiry.setIntentType(intentBase.getIntentType());
					
					//Intent 에서 분석된 Parameter 정보 가져오기
					Map<String, Parameter> paramList = intentBase.getParameters();
					
					if ( (paramList == null) || (paramList.isEmpty()) ) {
						inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_NONE);
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:[" +inquiry.getInquiryData()+"],Status:[SLOT FILLING, 파라미터 없음],intentId:["+intentBase.getIntentId()+"],intent Name:["+intentBase.getIntentName()+"]");
					}
					else {
						
						String message = null;
						
						//Intent 에서 Message 추출
						message = intentBase.getMessage();
						
						//Slot filling 처리인데 메세지가 없으면
						if ( !StringUtils.hasText(message) ) {
							inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_NONE);
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:[" +inquiry.getInquiryData()+"],Status:[SLOT FILLING, 메세지 없음],intentId:["+intentBase.getIntentId()+"],intent Name:["+intentBase.getIntentName()+"]");
						}
						else {
							inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_SLOT);
							
							//TODO Intent 에서 새로운 메세지르 넘겨 주기 전까지 뜻이 보강된 SLOT Filling 시 메세지 처리
							StringBuffer slotMessage = new StringBuffer(this.botService.getBotMessage(inquiry.getBotId(), BotCode.BOT_MESSAGE_TYPE_SLOT_FILLING));
							slotMessage.append(message);
							
							inquiry.setActionResult(slotMessage.toString());
							
							Map<String, Object> param = new HashMap<String, Object>();
							param.put("inquiryType", CommonCode.INQUIRY_TYPE_SLOTFILLING); 
							param.put("intentId", intentBase.getIntentId());
							
							Map<String, Parameter> paramTmp = intentBase.getParameters();
							if ( (paramTmp != null) && (!paramTmp.isEmpty()) ) {
								
								Parameter parameter = null;
								
								for( String key : intentBase.getParameters().keySet() ) {
									parameter = intentBase.getParameter(key);
									
									if (parameter != null) {
										param.put(key, intentBase.getParameter(key).getValue());
									}
								}
							}
							//응답메세지 생성 시 ActionParameter 항목에 Mapping
							inquiry.setIntentParam(param);
							
							//2018.01.03 slot filling일때도 문자발송 버튼이 보이도록 해당 intent의 연관의도 조회
							//문자 발송 버튼 시작 
						
							for(String intentId: smsSendIntentIdList){
								//LOG.info("#################smsSendIntentIdList intentId:"+intentId);
								if(intentBase.getIntentId().equals(intentId)){
									//LOG.info("#############sms 발송 intent에 버튼 추가");
									IntentMongo intentMongo=intentService.getIntent(intentBase.getIntentId());
									@SuppressWarnings("rawtypes")
									List<RelatedButton> buttons=  new ArrayList<>();
									for( com.lgcns.vpa.intent.model.IntentMongo.Action action : intentMongo.getActions() ) {
										@SuppressWarnings("rawtypes")
										RelatedButton button = null;
										String name = messageTranslator.translateText(intentBase.getParameters(), action.getName());
										switch(action.getType()) {
										case "Link" : 
										case "Call" : 
											button = new RelatedButton<String>();
											button.setName(name);
											button.setType(action.getType());
											button.setAction(messageTranslator.translateLink(intentBase.getParameters(), action.getAction()));
											button.setParams(messageTranslator.translateText(intentBase.getParameters(), action.getParams()));
											break;
										case "InQuiry" : 
											button = new RelatedButton<IntentBase>();
											button.setName(name);
											button.setType(action.getType());
											
											/*IntentMongo relData = getIntent(action.getIntentId());
											if( relData != null ) {
												continue;
											}

											IntentBase relIntent = propagateIntent(relData, entityParams);*/
											
											button.setAction(messageTranslator.translateText(intentBase.getParameters(), action.getAction()));
											
											
											break;
										}
										
										buttons.add(button);
										
									}
									//버튼 정보가 있으면 처리
									if ( buttons.size()>0) {
										inquiry.setIntentButtons(buttons);
									}
								}
							}
							//문자 발송 버튼 끝
							
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"],질의어:[" +inquiry.getInquiryData()+"],Status:[SLOT FILLING],intentId:["+intentBase.getIntentId()+
									 "],intent Name:["+intentBase.getIntentName()+"],SLOT FILLING MESSAAGE:["+message+"],parameter:["+param.toString()+"]");
						}
					}	
				}
				//파라미터 중복 처리
				else if (Status.DUP_PARAMETER.equals(intentBase.getStatus())) {
					
					inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_DUPPARAM);
					
					IntentSet intentSet = (IntentSet)intentBase;
					Iterator<IntentBase> iter = intentSet.iterator();
					
					inquiry.setIntentId(intentSet.getIntentId());
					inquiry.setIntentMessage(intentSet.getMessage());
					inquiry.setActionResult(intentSet.getMessage());
					inquiry.setIntentAnimation(intentSet.getAnimation());
					inquiry.setIntentType(intentSet.getIntentType());
					
					List<Element> paramElements = new ArrayList<Element>();
					Element elem = null;
					Map<String, Object>param = null;
					StringBuffer sbLog = new StringBuffer("");
					
					boolean isUserType = false;
					String pId = null, pName = null, pTitle = null, pMail = null, pGroupName = null, pGroupId = null, pImageUrl = null, pLeader = null;
					String pGroupFullName = null, pMobile = null, pOfficePhoneNo = null, pCorpCode = null, pUserStatus = null, pUserType = null;
				
					String titleNmEp=null;
					Map<String, Object> additionalProperties = null; 
					StringBuffer descBuf = null;
					
					//User Profile Image Url을 Properties 에서 읽어온다.
		        	String userProfileUrl = this.dialogConfig.getDialogInfo(inquiry.getTenantId(), "url", "userProfileImage");
					
					while(iter.hasNext()) {
						IntentBase child = iter.next();
						
						param = new HashMap<String, Object>();
						param.put("inquiryType", CommonCode.INQUIRY_TYPE_MULTIPARAM); 
						param.put("intentId", child.getIntentId());
						
						Map<String, Parameter> paramTmp =child.getParameters();
						if ( (paramTmp != null) && (!paramTmp.isEmpty()) ) {
							
							Parameter parameter = null;
							
							for( String key : paramTmp.keySet() ) {
								parameter = paramTmp.get(key);
								
								if (parameter != null) {
									param.put(key, parameter.getValue());
									
									if ("P".equals(parameter.getDataType())) {
										isUserType = true;
										
										Map <String, Object> pMap = JsonConverter.jsonToMap(String.valueOf(paramTmp.get(key).getValue()));
										
										
					        			
										boolean pmapHasData = (pMap != null) && (!pMap.isEmpty()) ? true : false;
										
										pId = ( pmapHasData && pMap.get("id") != null ) ? String.valueOf(pMap.get("id")) : "";
										pName = ( pmapHasData && pMap.get("name") != null ) ? String.valueOf(pMap.get("name")) : "";
										pTitle = ( pmapHasData && pMap.get("title") != null ) ? String.valueOf(pMap.get("title")) : "";
										pMail = ( pmapHasData && pMap.get("mail") != null ) ? String.valueOf(pMap.get("mail")) : "";
										pGroupName = ( pmapHasData && pMap.get("groupName") != null ) ? String.valueOf(pMap.get("groupName")) : "";
										pGroupFullName = ( pmapHasData && pMap.get("groupFullName") != null ) ? String.valueOf(pMap.get("groupFullName")) : "";
										pMobile = ( pmapHasData && pMap.get("mobile") != null ) ? String.valueOf(pMap.get("mobile")) : "";
										pOfficePhoneNo = ( pmapHasData && pMap.get("officePhoneNo") != null ) ? String.valueOf(pMap.get("officePhoneNo")) : "";
										pCorpCode = ( pmapHasData && pMap.get("corpCode") != null ) ? String.valueOf(pMap.get("corpCode")) : "";
										pUserStatus = ( pmapHasData && pMap.get("userStatus") != null ) ? String.valueOf(pMap.get("userStatus")) : "";
										pUserType = ( pmapHasData && pMap.get("userType") != null ) ? String.valueOf(pMap.get("userType")) : "";
										pLeader = ( pmapHasData && pMap.get("leader") != null ) ? String.valueOf(pMap.get("leader")) : "";
										pGroupId = ( pmapHasData && pMap.get("groupId") != null ) ? String.valueOf(pMap.get("groupId")) : "";
										titleNmEp= ( pmapHasData && pMap.get("titleNmEp") != null ) ? String.valueOf(pMap.get("titleNmEp")) : "";
										
										
										descBuf = new StringBuffer();
										if ( !StringUtils.isEmpty(pMail) ) {
											descBuf.append(pMail);
										}
										
										if ( !StringUtils.isEmpty(pMobile) ) {
											if ( !StringUtils.isEmpty(pMail) ) {
												descBuf.append(" | ");
											}
											
											descBuf.append(pMobile);
										}
										
									}
									else {
										isUserType = false;
									}
								}
							}//for
						}//if
						
						elem = new Element();
						if (isUserType) {//UserList Type으로 처리
							
							if ( !StringUtils.isEmpty(pId) ) {
								elem.setType(CommonCode.ELEMENT_TYPE_PEOPLE);
								//elem.setUserId(pId);
								//elem.setCorpCode(inquiry.getCompanyCode());
								elem.setId(pId);
								elem.setAction(child.getMessage());
								if ( !"H".equalsIgnoreCase(pUserStatus) ) {
									elem.setTitle(pName+" "+titleNmEp);
									//elem.setTitle(pName+" "+pTitle);
								}
								else {
									elem.setTitle("(휴직) "+pName+" "+titleNmEp);
									//elem.setTitle("(휴직) "+pName+" "+pTitle);
								}
								elem.setText(pGroupFullName);
								elem.setDescriptions(descBuf.toString());
								elem.setActionType(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);
								elem.setActionParams(param);
								
								if ( !StringUtils.isEmpty(userProfileUrl) ) {
									elem.setImageUrl( String.format(userProfileUrl, pCorpCode, pId) );
								}
								
								additionalProperties = new HashMap<String, Object>();
								additionalProperties.put("jobTitleEnglishName", pTitle);
								additionalProperties.put("empType", pUserType);
								additionalProperties.put("mobile", pMobile);
								//additionalProperties.put("corpType", );
								
								// 직급을 titleNmEp에서 읽어옴(2018.01.08)
								//additionalProperties.put("jobTitleName", pTitle);
								
								additionalProperties.put("jobTitleName", titleNmEp);
								
								additionalProperties.put("leader", pLeader);
								additionalProperties.put("groupName", pGroupName);
								additionalProperties.put("officePhoneNo", pOfficePhoneNo);
								additionalProperties.put("userName", pName);
								additionalProperties.put("userStatus", pUserStatus);
								additionalProperties.put("mail", pMail);
								additionalProperties.put("groupId", pGroupId);
								//additionalProperties.put("jobDutyName", pTitle);
								additionalProperties.put("jobDutyName", titleNmEp);
								additionalProperties.put("fullPathName", pGroupFullName);
								
								elem.setAdditionalProperties(additionalProperties);
							}
							else {
								//Data에 오류가 있는 경우 Element 를 추가하지 않기 위하여 null 설정함
								elem = null;
							}
						}
						else {//Text Type으로 처리
							elem.setType(CommonCode.ELEMENT_TYPE_TEXT);
							elem.setAction(child.getMessage());
							elem.setTitle(child.getMessage());
							elem.setActionType(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);
							elem.setActionParams(param);
						}
						
						if ( elem != null ) {
							//Log 용 메세지 생성
							sbLog.append(elem.toStringForDialogHandler());
							paramElements.add(elem);
						}
						else {
							//Log 용 메세지 생성
							sbLog.append("Element Data 오류로 Null 처리됨");
						}
					}
					
					
					//중복 Parameter 목록이 있으면
					if ( (paramElements != null) && (!paramElements.isEmpty()) ) {
						inquiry.setParamElements(paramElements);
					}
					
					LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], Status:[파라미터 중복], intentId:["+intentSet.getIntentId()+
							 "],intent Name:["+intentSet.getIntentName()+"],paramElements:["+sbLog.toString()+"]");
				}
				//단순질의 : Mapping 된 Action 이 없음, 일반 질의 : Mapping 된 Actino 이 있음
				else if (Status.COMPLETED.equals(intentBase.getStatus())) {
					
					Intent intent = (Intent) intentBase;
					
					inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_COMPLETE);
					inquiry.setIntentId(intent.getIntentId());
					inquiry.setIntentAnimation(intent.getAnimation());
					inquiry.setIntentType(intent.getIntentType());
					inquiry.setIntentAutoRunYn(intent.isAutorun());
					
					//버튼 정보가 있으면 처리
					if ( (intent.getButtons() != null) && (!intent.getButtons().isEmpty()) ) {
						inquiry.setIntentButtons(intent.getButtons());
						
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"],intentId:["+intent.getIntentId()+"],intent Name:["+intent.getIntentName()+"],intentButton:["+intent.getButtons()+"]");
					}
					else {
						LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"],intentId:["+intent.getIntentId()+"],intent Name:["+intent.getIntentName()+"],intentButton:[NONE]");
					}
					
					//Action 정보 조회
					this.getAction(inquiry);
					
					//Action 정보가 없으면 단순 질의로 처리함
					if (inquiry.getProcessStatus() == CommonCode.INQUIRY_STATE_ACTION_NONE) {
						inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_ACTIONEND);
						
						//Intent 에서 Message 추출
						String message = intent.getMessage();
						
						if ( StringUtils.hasText(message) ) {
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], Status:[단순질의,Action 없음], intentId:["+intent.getIntentId()+"],intent Name:["+intent.getIntentName()+"]");
							inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_ACTIONEND);
							inquiry.setActionResult(message);
						}
						//단순질의 처리인데 Message 가 없음 
						else {
							LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], Status:[단순질의,Action 없음,Intent Message 없음], intentId:["+intent.getIntentId()+"],intent Name:["+intent.getIntentName()+"]");
							inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_NONE);
						}
					}
					//Action 정보가 있음, 일반 질의 처리
					else {
						 LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], Status:[일반질의], intentId:["+intent.getIntentId()+"],intent Name:["+intent.getIntentName()+"],actionId:["+inquiry.getAction().getActionId()+"]");
						inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_COMPLETE);
						inquiry.setIntentId(intent.getIntentId());
						inquiry.setIntentMessage(intent.getMessage());
						inquiry.setIntentType(intent.getIntentType());
						
						Map<String, Object> paramMap = new HashMap<String, Object>();
						
						Map<String, Parameter> paramTmp = intentBase.getParameters();
						if ( (paramTmp != null) && (!paramTmp.isEmpty()) ) {
							
							Parameter parameter = null;
							
							for( String key : intentBase.getParameters().keySet() ) {
								parameter = intentBase.getParameter(key);
								
								if (parameter != null) {
									paramMap.put(key, intentBase.getParameter(key).getValue());
								}
							}
						}
						
						//Parameter 기본 정보 Setting
						paramMap.put("companyCode", inquiry.getCompanyCode());
						paramMap.put("langSet", (StringUtils.hasText(reqUser.getLocaleCode())) ? reqUser.getLocaleCode() : "ko");

						if (!paramMap.containsKey("loginUserId")) {
							paramMap.put("loginUserId", reqUser.getUserId());
						}
						//Parameter 처리
						inquiry.setIntentParam(paramMap);
					}
				}
			}
		} catch (IntentException e) {
			e.printStackTrace();
			String errCode = e.getErrorCode();
			
			// 의도분석 중 의도분석 서버처리 오류 발생
			if ( IntentException.ERROR_NLU_SERVER.equals(errCode) ) {
				inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_ERR_SERVER);
			}
			// 의도분석 중 의도분석 서버연결 오류 발생
			else if ( IntentException.ERROR_NLU_CALL.equals(errCode) ) {
				inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_ERR_CALL);
			}
			// 의도분석 중 파라미터 변환 관련 오류 발생
			else if ( IntentException.ERROR_ENTITY_TRAN.equals(errCode) ) {
				inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_PARAM_ERR);
			}
			// 의도분석 중 기타 오류 발생
			else {
				inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_ERR);
			}
			
			intnetFinishTime = System.currentTimeMillis();
			LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], Status:[의도분석 시 오류 발생], errorCode:["+errCode+"], Exception:"+e.toString());
			
		} catch (Exception e) {
			e.printStackTrace();
			
			intnetFinishTime = System.currentTimeMillis();
			//- 오류 발생 처리
			inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_ERR);
			LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], Status:[의도분석 시 오류 발생], Exception:"+e.toString());
		}
		
		//의도분석 서버와 연동에 소요된 시간
		inquiry.setSpentTimeIntent(intnetFinishTime-startTime);
		
		if (inquiry.getAction() != null) {
			LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], 의도분석 후 분류 소요시간:["+inquiry.getSpentTimeIntent()+"]ms, intentId:["+inquiry.getIntentId()+"],actionId:["+inquiry.getAction().getActionId()+"]");
		}
		else {
			LOG.info("inquiryId:["+inquiry.getInquiryId()+"], 질의어:[" +inquiry.getInquiryData()+"], 의도분석 후 분류 소요시간:["+inquiry.getSpentTimeIntent()+"]ms, intentId:["+inquiry.getIntentId()+"],actionId:[]");
		}
	}//intentProcess
	
	/**
	 * Intent(의도)와 Mapping 되어 있는 Action MetaData 조회
	 * @param inquiry
	 */
	private void getAction(InquiryVO inquiry) {
		if (inquiry == null) {
			return;
		}
		else {
			//Action Data 조회 중
			inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_ACTION_REQ);
		}
		
		if ( StringUtils.hasText(inquiry.getIntentId()) ) {
			Action action = this.actionService.getActionByIntentId(inquiry.getIntentId());
			
			if (action == null) {
				//Action Data 없음
				inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_ACTION_NONE);
				
				LOG.info("inquiryId:["+inquiry.getInquiryId()+"],intentId:["+inquiry.getIntentId()+"],STATUS:[ACTION DATA 없음]");
			}
			else {
				
				//Action 질의문의 개행문자, 탭문자를 공백문자로 치환
				action.setActionUri( DialogUtil.makeActionUriForRun(action.getActionUri()) );
				
				inquiry.setAction(action);
				//Action Data 조회 완료
				inquiry.setProcessStatus(CommonCode.INQUIRY_STATE_ACTION_COMPLETE);
				
				LOG.info("inquiryId:["+inquiry.getInquiryId()+"],intentId:["+inquiry.getIntentId()+"],actionId:["+inquiry.getAction().getActionId()+"]");
			}
		}
	}//getActionMetadata
	
	/**
	 * 개발 시 사용되는 의도분석 결과 개발 로그
	 * @param result
	 * @return
	 */
	private String getIntentScore (IntentAnalysisResult result) {
		if (result == null) {
			return "IntentAnalysisResult is null.";
		}

		StringBuffer sb = new StringBuffer();
		
		Status status = result.getStatus();
		if ( status == Status.COMPLETED ) {
			sb.append("의도분석이 완료되었습니다. \r\n");
		}
		else if ( status == Status.NOT_UNDERSTAND ) {
			sb.append("의도분석이 실패하였습니다. \r\n");
		}
		else if ( status == Status.DUP_PARAMETER ) {
			sb.append("의도의 파라미터 중 중복된 데이터가 있습니다. \r\n");
		}
		else if ( status == Status.SLOT_FILLING ) {
			sb.append("의도의 파라미터가 부족하여 SLOT Filling 이 필요합니다. \r\n");
		}
		
		if (result.getScore() != null) {
			sb.append("의도분석 결과 : <<"+result.getScore()+">>");
		}
		
		sb.append("]");
		return sb.toString();
	}
	
	/**
	 * 좋아요/싫어요 버튼 추가 (맨뒤에)
	 * @param activityButtonList
	 */
	private List<Button> addLikeButton (List<Button> activityButtonList) {
		
		List<Button> resultList = new ArrayList<Button>();
		
		if ( (activityButtonList != null) && (!activityButtonList.isEmpty()) ) {
			
			for (Button button : activityButtonList) {
				resultList.add(button);
			}
		}
		
		Button likeButton = new Button();
		likeButton.setType(CommonCode.BUTTON_TYPE_FEEDBACK);
		likeButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_FUNCTION);
		likeButton.setAction(CommonCode.BUTTON_LIKE_ACTION);
		
		resultList.add(likeButton);
		
		Button dislikeButton = new Button();
		dislikeButton.setType(CommonCode.BUTTON_TYPE_FEEDBACK);
		dislikeButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_FUNCTION);
		dislikeButton.setAction(CommonCode.BUTTON_DISLIKE_ACTION);
		
		resultList.add(dislikeButton);
		
		return resultList;
	}
	
	/**
	 * 질의문 중 직급명, 직급명+님, 팀장, 팀장님의 단어 앞/뒤에 공백 추가 
	 * @param inquiry
	 * @param botId
	 * @return
	 */
	private String spaceCheckJobTitle (String inquiry, String botId) {
		
		String result = null;
		
		try {
			//직급목록 조회
			List<JobTitle> jobTitleList = jobTitleService.selectAllJobTitle(botId);
			jobTitleList = ( (jobTitleList == null) ) ? new ArrayList<JobTitle>() : jobTitleList;
			
			//직급에 팀장 추가
			jobTitleList.add(new JobTitle("", "팀장", ""));
			
			String jobTitleName = null;
			
			//직급명 앞뒤로 " " 추가
			for ( JobTitle jobTitle : jobTitleList ) {
				jobTitleName = jobTitle.getJobTitleName();
				
				if ( result == null ) {
					result = inquiry.replaceAll(jobTitleName, " "+jobTitleName+" ");
				}
				else {
					result = result.replaceAll(jobTitleName, " "+jobTitleName+" ");
				}
			}
			
			if ( result != null ) {
				//직급명 뒤에 있는 "님" 뒤에 " " 추가
				result = result.replaceAll("님", "님 ");
				
				//문장 사이의 연속된 공백을 " "으로 변환
				result = StringUtils.removeDoubleSpace(result);
				
				//직급명과 "님" 사이의 공백 제거
				result = result.replaceAll("\\s님", "님");
				
				result = result.replaceAll("부\\s사장", "부사장");
				result = result.replaceAll("부\\s회장", "부회장");
			}
			
		} catch (Exception e) {
			return null;
		}
		
		return result;
	}
	
}
