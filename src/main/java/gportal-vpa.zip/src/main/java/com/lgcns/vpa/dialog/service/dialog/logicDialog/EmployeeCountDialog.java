/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SearchContactDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.dialog.util.ParameterChecker;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * 업무담당자 목록 조회 처리를 위한 Dialog 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 8.
 */
@Component("EmployeeCountDialog")
public class EmployeeCountDialog extends LogicDialog {
	
	private static final Logger LOG = LoggerFactory.getLogger(EmployeeCountDialog.class);

	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private BotService botService;
	
	@Override
	protected boolean validator(InquiryVO data) {
		Action action = data.getAction();
		boolean isValid = false;
		
		//Parameter validator
		if (action != null) {
			if ( !StringUtils.hasText(action.getActionUri()) ) {
				isValid = true;
			}
			else {
				isValid = true;
				
				/*Map<String, Object> newIntentParam = null;
				
				if ( action.getActionUri().startsWith("sql-stored") ) {
					//Intent Parameter 에서 누락된 Parameter 는 각 Type 의 기본 값으로 Parameter 값을 설정함
					newIntentParam = ParameterChecker.parameterValidator(action.getActionUri(), data.getIntentParam());
					data.setIntentParam(newIntentParam);
				}
				
				newIntentParam = ( newIntentParam == null ) ? new HashMap<String, Object>() : newIntentParam;*/
								
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
						 "], actionUri:["+action.getActionUri()+"], Intent Param:["+data.getIntentParam()+"]");
			}
		}
		else {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+"], Validation을 수행할 action 정보가 없음");
		}
		
		return isValid;
	}
	
	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet =  null;
			
			TransferSyncVO responseVO =  new  TransferSyncVO();
			ObjectMapper mapper = new ObjectMapper();
			responseVO =  mapper.readValue(proxyResponseJsonData, TransferSyncVO.class);
			
			if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
				proxyResultSet = responseVO.getActionResult();
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
					//Proxy에서 조회된 결과(JsonData)에서 Attachment 를 구함
					attachments = this.getAttachment(data, proxyResultSet);
					
					if ( (attachments != null) && (!attachments.isEmpty()) ) {
						
						StringBuffer activityMessage = new StringBuffer(); 
						
			        	Map<String, Object> intentParam = data.getIntentParam();
			        	if ( intentParam != null ) {
			        		activityMessage.append( String.valueOf(intentParam.get("teamName")) );
			        		activityMessage.append( " 소속 임직원 수를 조회한 결과입니다.\n");
			        		activityMessage.append( "(조직별 인원수도 알려드릴 수 있어요! \n 예:하이테크사업부 인원수, 우리팀 인원수)"); 
			        	}
			        	
			        	resultActivity.setMessage(activityMessage.toString());
						resultActivity.setAttachments(attachments);
						
					}
					else {
						LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
						
						//Data 가 없음
			        	resultActivity = this.commonResponeService.simpleResponseMessage(
								data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
								this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
					}
					
					//의도분석의 Button이 있는 경우 처리
					if ( data.getIntentButtons() != null ) {
						List<RelatedButton> buttons = data.getIntentButtons();
						List<Button> activityButtonList = super.makeActivityButtonList(buttons);
						
						if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
							resultActivity.setButtons(activityButtonList);
						}
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	@Override
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        // 조회된 임직원 수 정보가 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("조회된 소속 임직원 수에 대한 정보가 없습니다.");
	        }
	        // 조회된 임직원 수 정보가 존재하는 경우    
	        else {
	        	
	        	Map<String, Object> intentParamMap = inquiryData.getIntentParam();
	        	
	        	String title =  ( (intentParamMap != null) && (intentParamMap.get("teamName") != null) ) ? String.valueOf(intentParamMap.get("teamName")) : "";
	        	String descriptions =  ( (intentParamMap != null) && (intentParamMap.get("teamFullName") != null) ) ? String.valueOf(intentParamMap.get("teamFullName")) : "";
	        	String amount = null, id = null;
	        	String unit = "명";
	        	
	        	// | 로 시작하면 제거
	        	if ( !StringUtils.isEmpty(descriptions) ) {
	        		
	        		descriptions = descriptions.trim();
	        		
	        		if ( descriptions.startsWith("||")) {
	        			descriptions = descriptions.substring(2);
	        		}
	        		else if ( descriptions.startsWith("|")) {
	        			descriptions = descriptions.substring(1);
	        		}
	        	}
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
        			
	        			amount = ( (proxyResult.get("VALUE") != null) ) ? String.valueOf(proxyResult.get("VALUE")) : null;
	        			id = ( (proxyResult.get("DEPT_CD") != null) ) ? String.valueOf(proxyResult.get("DEPT_CD")) : null;
	        			
	        			if ( !StringUtils.isEmpty(amount) ) {
	        				amount = StringUtils.addComma(amount);
	        			}
	        			
	    				Element element = new Element();
	    				element.setId(id);
	    				element.setTitle(title);
	    				element.setDescriptions(descriptions);
	    				element.setAmount(amount);
	    				element.setUnit(unit);
	    				//element.setAction(action.toString());
	    				//element.setActionType(ActivityCode.ACTION_TYPE_INQUIRY);
	    				
	    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	    				
	    				attachment.addElement(element);
	        		}
	        	}//for
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
}
