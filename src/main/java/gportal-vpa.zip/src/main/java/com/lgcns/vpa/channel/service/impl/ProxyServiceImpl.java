/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.text.WordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.channel.model.config.LegacyConfig;
import com.lgcns.vpa.channel.service.AbstractProxyService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.channel.service.ProxyService;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 포탈 서비스
 * </pre>
 * @author
 */
@Service("multi.proxyService")
public class ProxyServiceImpl extends AbstractProxyService implements ProxyService {

	@Autowired
	ConfigService configService;
	
   
    /**
     * 사용자의 축하합니다 정보 조회 (메인 포탈) 
     * @param user
     * @param tenantId
     * @return
     */
    @Override
    public List<Map<String, String>> retrieveMyCongratulation(User user, String tenantId) {
     
        String localeCode = user.getLocaleCode();

        String legacyCode="PORTAL";
        String legacyTypeCode="MY_CONGRATULATIONS";
        
        LegacyConfig legacy=configService.retrieveLegacyConfig(legacyCode, legacyTypeCode);
       // System.out.println("##############retrieveMyCongratulation MY_CONGRATULATIONS_ACTION_URI:"+MY_CONGRATULATIONS_ACTION_URI);
       // System.out.println("##############retrieveMyCongratulation actionUri:"+legacy.getActionUri());
        
        TransferSyncVO transferSyncVO = new TransferSyncVO();
        transferSyncVO.setActionUri(legacy.getActionUri());
        transferSyncVO.setTenantId(tenantId);
        
        // 파라미터 설정
        Map<String, Object> actionParam = new HashMap<>();
        
        // 사용자 정보
        actionParam.put("LOGIN_USER_ID", user.getUserId());
        actionParam.put("LOCALE", localeCode);
        transferSyncVO.setActionParam(actionParam);
        
        List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
        List<Map<String, String>> congratulations = null;
        
        if (!CollectionUtils.isEmpty(proxyResultSet)) {
            congratulations = proxyResultSet.stream().map(data -> new HashMap<String, String>() {
                private static final long serialVersionUID = -4803937536892622504L;
                {                   
                    for (Map.Entry<String, Object> entry : data.entrySet()) {
                        String camelCaseKey = WordUtils.capitalizeFully(entry.getKey(), new char[]{'_'}).replaceAll("_", "");
                        camelCaseKey = camelCaseKey.substring(0, 1).toLowerCase() + camelCaseKey.substring(1);
                        this.put(camelCaseKey, String.valueOf(entry.getValue()));
                    }
                }
            }).collect(Collectors.toList());
        }

        return congratulations;
    }
    
    /**
     * 시스템 및 메뉴 검색
     * @param user
     * @param tenantId
     * @param searchWord
     * @return
     */
    @Override
    public List<Map<String, String>> searchSystemMenu(User user, String tenantId, String searchWord) {
    	
    	String legacyCode="PORTAL";
        String legacyTypeCode="SYSMAP_SEARCH_LIST";
         
        LegacyConfig legacy=configService.retrieveLegacyConfig(legacyCode, legacyTypeCode);
       // System.out.println("##############searchSystemMenu SYSTEM_MAP_ACTION_URI:"+SYSTEM_MAP_ACTION_URI);
       // System.out.println("##############searchSystemMenu actionUri:"+legacy.getActionUri());
         
        TransferSyncVO transferSyncVO = new TransferSyncVO();
        transferSyncVO.setActionUri(legacy.getActionUri());
        transferSyncVO.setTenantId(tenantId);
        
        // 파라미터 설정
        Map<String, Object> actionParam = new HashMap<>();
        
        // 검색 정보
        actionParam.put("USER_ID", user.getUserId());
        actionParam.put("SEARCH_WORD", searchWord);
        transferSyncVO.setActionParam(actionParam);
        
        List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
        List<Map<String, String>> results = null;
        
        if (!CollectionUtils.isEmpty(proxyResultSet)) {
            results = proxyResultSet.stream().map(data -> new HashMap<String, String>() {
                private static final long serialVersionUID = -4803937536892622504L;
                {                   
                    for (Map.Entry<String, Object> entry : data.entrySet()) {
                        String camelCaseKey = WordUtils.capitalizeFully(entry.getKey(), new char[]{'_'}).replaceAll("_", "");
                        camelCaseKey = camelCaseKey.substring(0, 1).toLowerCase() + camelCaseKey.substring(1);
                        this.put(camelCaseKey, String.valueOf(entry.getValue()));
                    }
                }
            }).collect(Collectors.toList());
        }

        return results;
    }    
    
    /**
     * 즐겨찾기 시스템 및 메뉴 검색
     * @param user
     * @param tenantId
     * @return
     */
    @Override
    public List<Map<String, String>> searchFavoriteSystemMenu(User user, String tenantId) {
    	
    	String legacyCode="PORTAL";
        String legacyTypeCode="SYSMAP_FAV_LIST";
         
        LegacyConfig legacy=configService.retrieveLegacyConfig(legacyCode, legacyTypeCode);
       // System.out.println("##############searchFavoriteSystemMenu SYSTEM_MAP_FAVORITE_ACTION_URI:"+SYSTEM_MAP_FAVORITE_ACTION_URI);
       // System.out.println("##############searchFavoriteSystemMenu actionUri:"+legacy.getActionUri());
        
        TransferSyncVO transferSyncVO = new TransferSyncVO();
        transferSyncVO.setActionUri(legacy.getActionUri());
        transferSyncVO.setTenantId(tenantId);
        
        // 파라미터 설정
        Map<String, Object> actionParam = new HashMap<>();
        
        // 검색 정보
        actionParam.put("USER_ID", user.getUserId());
        transferSyncVO.setActionParam(actionParam);
        
        List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
        List<Map<String, String>> results = null;
        
        if (!CollectionUtils.isEmpty(proxyResultSet)) {
            results = proxyResultSet.stream().map(data -> new HashMap<String, String>() {
                private static final long serialVersionUID = -4803937536892622504L;
                {                   
                    for (Map.Entry<String, Object> entry : data.entrySet()) {
                        String camelCaseKey = WordUtils.capitalizeFully(entry.getKey(), new char[]{'_'}).replaceAll("_", "");
                        camelCaseKey = camelCaseKey.substring(0, 1).toLowerCase() + camelCaseKey.substring(1);
                        this.put(camelCaseKey, String.valueOf(entry.getValue()));
                    }
                }
            }).collect(Collectors.toList());
        }

        return results;
    }       
}
