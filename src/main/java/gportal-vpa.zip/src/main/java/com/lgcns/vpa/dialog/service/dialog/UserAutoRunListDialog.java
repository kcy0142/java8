/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserAutoRunListDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.push.model.UserAutoRun;

/**
 * <PRE>
 * 사용자별 자동알림 설정 목록 조회를 처리하는 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 12. 8.
 */
@Component("UserAutoRunListDialog")
public class UserAutoRunListDialog extends VpaDialog {

private static final Logger LOG = LoggerFactory.getLogger(UserAutoRunListDialog.class);
	
	static final String[] DAY_KR = {"월","화","수","목","금","토","일"};
	static final String[] DAY_EN = {"MON","TUE","WED","THU","FRI","SAT","SUN"};
	static final String DELIMETER = ",", TIME_DELIMETER = ":", SPACE = " ";
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private DialogConfig dialogConfig;
	
	@Autowired
	private BotService botService;
	
	@Override
	protected boolean validator(InquiryVO data) {
		if ( (data == null) || (!StringUtils.hasText(data.getInquiryData())) ) {
			return false;
		}
		
		return true;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		return true;
	}

	@Override
	protected String processor(InquiryVO data) {
		return "Inquiry USerAutoRun";
	}
	
	@Override
	protected Activity afterWork(InquiryVO data, String stopWordReponseMessage) {
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		String userId = data.getReqUserId();
		String botId = data.getBotId();
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
			
			//사용자 자동알림 목록 조회
			List<UserAutoRun> userAutoRunList = this.commonResponeService.getUserAutoRunList(botId, userId);
	        
			List<Attachment> attachments = null;
			
			if ( (userAutoRunList != null) && (!userAutoRunList.isEmpty()) ) {
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],userAutoRunList size:["+userAutoRunList.size()+"]");
				
				//통합 검색에서 조회된 결과로 Attachment 를 구함
				attachments = this.getAttachment(data, userAutoRunList);
				
				if ( (attachments != null) && (!attachments.isEmpty()) ) {
					
					//Activity Message
					StringBuffer activityMessage = new StringBuffer();
					activityMessage.append("총 ").append(userAutoRunList.size()).append("건의 사용자 자동 알림 정보가 있습니다.");
					activityMessage.append("\n\n\"삭제\"를 클릭하여 설정된 사용자 자동알림 정보를 삭제하실 수 있습니다.");
										
					resultActivity.setMessage(activityMessage.toString());
					resultActivity.setAttachments(attachments);
					
				}
				else {
					LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
					
					//Data 가 없음
		        	resultActivity = this.commonResponeService.simpleResponseMessage(
							data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
							this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
				}
				
				//의도분석의 Button이 있는 경우 처리
				if ( data.getIntentButtons() != null ) {
					List<RelatedButton> buttons = data.getIntentButtons();
					List<Button> activityButtonList = super.makeActivityButtonList(buttons);
					
					if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
						resultActivity.setButtons(activityButtonList);
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 사용자 자동알림 조회 결과가 없음");
				
				//Activity Message
				StringBuffer activityMessage = new StringBuffer();
				activityMessage.append(data.getInquiryData()).append(" ");
				activityMessage.append(this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						activityMessage.toString());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param userAutoRunList
	 * @return
	 */
	private List<Attachment> getAttachment (InquiryVO inquiryData, List<UserAutoRun> userAutoRunList) throws Exception {
		
		if ( (inquiryData == null) || (userAutoRunList == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_AUTORUN_LIST);
	        
			String title = null;
			StringBuffer desciptions = new StringBuffer();
			String actionUrl = null;
			
			String inquiry = null, userAutoRunId = null, repeatDay = null, repeatTime = null;
			
			for (UserAutoRun uar : userAutoRunList) {
				
				desciptions.setLength(0);
				
				if ( uar != null ) {
					
					inquiry = uar.getInquiry();
					userAutoRunId = uar.getUserAutoRunId();
					
					//요일 정보를 MON,TUE,THU 에서 월,화,목요일 형식으로 변환
					repeatDay = this.getDisplayRepeatDay(uar.getRepeatDay());
					desciptions.append(repeatDay).append(SPACE);
					
					//시간 정보를 0900 ==> 09:00 형식으로 변환
					repeatTime = uar.getRepeatTime();
					if ( !StringUtils.isEmpty(repeatTime) ) {
						if ( repeatTime.length() == 3 ) {
							desciptions.append(repeatTime.substring(0, 1)).append(TIME_DELIMETER).append(repeatTime.substring(1));
						}
						else if ( repeatTime.length() >= 4  ) {
							desciptions.append(repeatTime.substring(0, 2)).append(TIME_DELIMETER).append(repeatTime.substring(2));
						}
					}
					
					//사용자 자동알림 정보 삭제 Url
					String deleteUrl = this.dialogConfig.getDialogInfo(inquiryData.getTenantId(), "url", "deleteUserAutoRun");
					
					if ( !StringUtils.isEmpty(deleteUrl) ) {
						actionUrl = String.format(deleteUrl, inquiryData.getBotId(), userAutoRunId);
					}
					
					title = uar.getInquiry();
    				
    				Element element = new Element();
    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
    				element.setTitle(title);
    				//element.setDescriptions(desciptions.toString());
    				element.setAmount(desciptions.toString());
    				element.setUnit("삭제");
    				element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
    				element.setAction(actionUrl);
    				
    				attachment.addElement(element);
    				
        		}
			}
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
	
	/**
	 * "MON,TUE,WED,THU,FRI,SAT,SUN" 형식의 요일 정보를 "월,화,수,목,금,토,일 + 요일" 의 표시 형식으로 반환 
	 * @param repeatDay
	 * @return
	 */
	private String getDisplayRepeatDay ( String repeatDay ) {
		
		if ( StringUtils.isEmpty(repeatDay) ) {
			return null;
		}
		
		StringBuffer displayDay = new StringBuffer();
		
		for ( int i = 0; i < 7; i++) {
			if ( repeatDay.contains(DAY_EN[i]) ) {
				if (displayDay.length() > 0) {
					displayDay.append(DELIMETER).append(DAY_KR[i]);
				}
				else {
					displayDay.append(DAY_KR[i]);
				}
			}
		}
				
		return (displayDay.length() > 0) ? displayDay.append("요일").toString() : null;
	}
}
