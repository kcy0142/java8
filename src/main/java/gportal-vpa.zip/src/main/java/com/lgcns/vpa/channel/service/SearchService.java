/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : SearchService.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.channel.service;

import java.util.List;
import java.util.Map;

public interface SearchService {
	/**
	 * 통합 검색
	 * @param tenantId
	 * @param query
	 * @param options
	 * @return
	 */
	List<Map<String, Object>> search(String tenantId, String query, Map<String, String> options);
	
	/**
	 * collection 지정 검색
	 * @param tenantId
	 * @param query
	 * @param collection
	 * @param options
	 * @return
	 */
	List<Map<String, Object>> search(String tenantId, String query, String collection, Map<String, String> options);
	

}
