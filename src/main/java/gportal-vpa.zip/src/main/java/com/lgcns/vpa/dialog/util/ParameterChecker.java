/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ParameterChecker.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.util.StringUtils;

/**
 * <PRE>
 * Intent 에서 분석된 Parameter 와 Action uri 의 파라미터의 Matching Validation을 처리하는 Util
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 6. 9.
 */
public class ParameterChecker {
	
	private static final String 
		VARCHAR_TYPE		= "VARCHAR",
		NVARCHAR_TYPE		= "NVARCHAR",
		CHAR_TYPE			= "CHAR";
	
	public static Map<String, Object> parameterValidator (final String uriData, Map<String, Object> params) {
		
		if (StringUtils.isEmpty(uriData)) {
			return params;
		}
		
		Map<String, Object> newParams = new HashMap<String, Object>();
		boolean isExistParams = ( (params == null) || (params.isEmpty()) ) ? false : true; 

		//uriData 에서 변수명과 Type을 추출한다.
		int startPos = uriData.indexOf("(");
		int endPos = uriData.lastIndexOf(")"); 
		String data = uriData.substring(startPos+1, endPos);
		
		//System.out.println(data);
		
		String [] dataArr = data.split(",");
		int size = dataArr.length;
		String tmp = null;
		Object objTmp = null;
		
		String [] paramTypes = new String [size];
		String [] paramNames = new String [size];
		int typeEnd = -1, paramEnd = -1;
		
		for (int i = 0; i < size; i++) {
			tmp = dataArr[i];
			tmp = tmp.trim();//공백 제거
			
			typeEnd = tmp.indexOf("${");
			paramEnd = tmp.lastIndexOf("}");
			
			if ( (typeEnd > -1) && (paramEnd > -1) ) {
				paramTypes[i] = tmp.substring(0, typeEnd);
				paramNames[i] = tmp.substring(typeEnd+2, paramEnd);
				
				paramTypes[i] = ( StringUtils.isEmpty(paramTypes[i]) ) ? null : paramTypes[i].trim();
				paramNames[i] = ( StringUtils.isEmpty(paramNames[i]) ) ? null : paramNames[i].trim();
			}
			
			//System.out.println("==>["+tmp+"]["+paramTypes[i]+"]["+paramNames[i]+"]");
			
			//변수명에 해당하는 parameter 가 있는지 조회하여 없으면 해당 Type의 기본값을 parameter에 설정한다.
			if ( !StringUtils.isEmpty(paramNames[i]) && !StringUtils.isEmpty(paramNames[i])) {
				
				objTmp = params.get(paramNames[i]);
				
				if ( isExistParams && (objTmp != null) ) {
					newParams.put(paramNames[i], params.get(paramNames[i]));
				}
				else {
					if ( VARCHAR_TYPE.equalsIgnoreCase(paramTypes[i]) || NVARCHAR_TYPE.equalsIgnoreCase(paramTypes[i]) ) {
						newParams.put(paramNames[i], "");
					}
					else if ( CHAR_TYPE.equalsIgnoreCase(paramTypes[i])) {
						newParams.put(paramNames[i], new String("").charAt(0));
					}
					else {
						newParams.put(paramNames[i], 0);
					}
				}
			}
		}
		
		//System.out.println(newParams);
		return newParams;
		
	}//getParameter
	
	/**
	 * UriData에서 파라미터를 추출함
	 * @param uriData
	 * @return
	 */
	/*
	 * Usage
	 * String uriData = "sql-stored:WINDB.ep_user.WINBLP_MAIN_SCHEDULE_LIST_SEL (NVARCHAR ${  empNo   }, NVARCHAR ${date})?dataSource=mssqlDataSource";
	 * result : {"empNo", "date"}
	 */
	public static String[] getParameter (final String uriData) {
		
		Pattern pattern = Pattern.compile("(\\$\\{)(.+?)(\\})");
		Matcher m = pattern.matcher(uriData);
		
		List<String> paramNames = new ArrayList<String>();
		
		while(m.find()) {
			//System.out.println("["+m.group(0)+"]["+m.group(1)+"]["+m.group(2)+"]["+m.group(3)+"]");
			//System.out.println("==> ["+m.group(2).trim()+"]");
			paramNames.add(m.group(2).trim());
		}
		
		if (paramNames.isEmpty()) {
			return null;
		}
		else {
			String [] paramArray = new String[paramNames.size()];
			paramNames.toArray(paramArray);
			
			return paramArray;
		}
	}//getParameter
	
	/**
	 * uriData 에서 추출한 파라미터 명칭과 Intent에서 추출한 파라미터를 비교하여 <br/>
	 * 파라미터가 없거나 값이 없으면 유효하지 않음
	 * @param uriData
	 * @param params
	 * @return
	 */
	/* Usage
	 	Parameter [] params = new Parameter[2];
		params[0] = new Parameter("empNo", "A12345", null);
		params[1] = new Parameter("date", "", null);
		
		String uriData = "sql-stored:WINDB.ep_user.WINBLP_MAIN_SCHEDULE_LIST_SEL (NVARCHAR ${  headers.empNo   }, NVARCHAR ${headers.date})?dataSource=mssqlDataSource";
		System.out.println(StringUtil.parameterValidator(uriData, params)); 	//true
		System.out.println(StringUtil.parameterValidator(uriData, null));		//false
		
		String uriData_1 = "123123123123123123";
		System.out.println(StringUtil.parameterValidator(uriData_1, params));	//true
		System.out.println(StringUtil.parameterValidator(uriData_1, null));		//true
		
		String uriData_2 = "sql-stored:WINDB.ep_user.WINBLP_MAIN_SCHEDULE_LIST_SEL (NVARCHAR ${  headers.groupId }, NVARCHAR ${  headers.empNo   }, NVARCHAR ${headers.date})?dataSource=mssqlDataSource";
		System.out.println(StringUtil.parameterValidator(uriData_2, params));	//false
		
		String uriData_3 = "";
		System.out.println(StringUtil.parameterValidator(uriData_3, params));	//false
		System.out.println(StringUtil.parameterValidator(null, params));		//false
		System.out.println(StringUtil.parameterValidator(null, null));			//false
	*/
	/*public static boolean parameterValidator (final String uriData, final Map<String, Object> params) {
		
		boolean isValid = true;
		
		// uriData가 없으면 무조건 유효하지 않음
		if ( !StringUtils.hasText(uriData) ) {
			return false;
		}
		
		String [] paramNames = ParameterChecker.getParameter(uriData);
		
		// uriData에서 추출된 파라미터가 없으면 무조건 유효함
		if ( (paramNames == null) || (paramNames.length <= 0) ) {
			return true;
		}
		// uriData에서 추출된 파라미터가 있고, Intent에서 분석된 파라미터가 없으면 무조건 유효하지 않음
		else if ( (params == null) || (params.isEmpty()) ) {
			return false;
		}
		
		//파라미터명이 일치하는 것이 하나라도 없거나 
		//일치하는 파라미터의 명중에서 값이 하나라도 없으면 유효하지 않음
		for (String paramName : paramNames) {
			
			boolean hasVlaue = false;
			
			for (String key : params.keySet()) {
				//파라미터 명이 일치하는 것이 있나?
				if ( paramName.endsWith(key) ) {
					//동일한 파라미터 명의 값이 있나?
					if ( params.get(key) instanceof String ) {
						hasVlaue = ( params.get(key)!=null &&
								     StringUtils.hasText((String)params.get(key)) ) ? true : false;
					}
					else {
						hasVlaue = ( params.get(key)!=null ) ? true : false;
					}
					
					break;
				}
			}
			
			if ( !hasVlaue ) {
				isValid = hasVlaue;
			}
		}
		
		return isValid;
	}//parameterValidator
*/	
	/**
	 * uriData 에서 추출한 파라미터 명칭과 Intent에서 추출한 파라미터를 비교하여 <br/>
	 * 파라미터가 없거나 값이 없으면 유효하지 않음
	 * @param uriData
	 * @param params
	 * @return
	 */
	/* Usage
	 	Map <String, Object> params = new HashMap<String, Object>();
		params.put("empNo", "A12345");
		params.put("date",  new Date(System.currentTimeMillis()));
		
		String uriData = "sql-stored:WINDB.ep_user.WINBLP_MAIN_SCHEDULE_LIST_SEL (NVARCHAR ${  headers.empNo   }, NVARCHAR ${headers.date})?dataSource=mssqlDataSource";
		System.out.println(StringUtil.parameterValidator(uriData, params)); 	//true
		System.out.println(StringUtil.parameterValidator(uriData, null));		//false
		
		String uriData_1 = "123123123123123123";
		System.out.println(StringUtil.parameterValidator(uriData_1, params));	//true
		System.out.println(StringUtil.parameterValidator(uriData_1, null));		//true
		
		String uriData_2 = "sql-stored:WINDB.ep_user.WINBLP_MAIN_SCHEDULE_LIST_SEL (NVARCHAR ${  headers.groupId }, NVARCHAR ${  headers.empNo   }, NVARCHAR ${headers.date})?dataSource=mssqlDataSource";
		System.out.println(StringUtil.parameterValidator(uriData_2, params));	//false
		
		String uriData_3 = "";
		System.out.println(StringUtil.parameterValidator(uriData_3, params));	//false
		System.out.println(StringUtil.parameterValidator(null, params));		//false
		System.out.println(StringUtil.parameterValidator(null, null));			//false
	*/
	public static boolean parameterValidatorOld (final String uriData, final Map<String, Object> params) {
		
		boolean isValid = true;
		
		// uriData가 없으면 무조건 유효하지 않음
		if ( !StringUtils.hasText(uriData) ) {
			return false;
		}
		
		String [] paramNames = ParameterChecker.getParameter(uriData);
		
		// uriData에서 추출된 파라미터가 없으면 무조건 유효함
		if ( (paramNames == null) || (paramNames.length <= 0) ) {
			return true;
		}
		// uriData에서 추출된 파라미터가 있고, Intent에서 분석된 파라미터가 없으면 무조건 유효하지 않음
		else if ( params == null ) {
			return false;
		}
		
		//파라미터명이 일치하는 것이 하나라도 없거나 
		//일치하는 파라미터의 명중에서 값이 하나라도 없으면 유효하지 않음
		for (String paramName : paramNames) {
			
			boolean hasVlaue = false;
			Object value = params.get(paramName); 
			//파라미터 명이 일치하는 것이 있나?
			if ( value != null ) {
				//동일한 파라미터 명의 값이 있나?
				if ( value instanceof String ) {
					hasVlaue = ( StringUtils.hasText((String)value) ) ? true : false;
				}
				else {
					hasVlaue = true;
				}
			}
			else {//파라미터 값이 없으면 false
				isValid = false;
				break;
			}
			
			if ( !hasVlaue ) {
				isValid = hasVlaue;
				break;
			}
		}
		
		return isValid;
	}
	
}//class
