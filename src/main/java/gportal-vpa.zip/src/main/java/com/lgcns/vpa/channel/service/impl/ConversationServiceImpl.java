/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import com.lgcns.vpa.base.util.I18nUtils;
import com.lgcns.vpa.channel.dao.BotDao;
import com.lgcns.vpa.channel.model.config.ConfigCode;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.channel.service.ConversationService;
import com.lgcns.vpa.channel.service.EventService;
import com.lgcns.vpa.channel.web.BotController;
import com.lgcns.vpa.push.dao.WeatherDao;
import com.lgcns.vpa.push.model.City;
import com.lgcns.vpa.push.model.Weather;
import com.lgcns.vpa.push.service.ConversationDailyPushService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.BotMessage;
import com.lgcns.vpa.channel.model.Conversation;
import com.lgcns.vpa.channel.model.Event;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 봇 대화관리 Service
 * </pre>
 * @author
 */
@Service("multi.conversationService")
public class ConversationServiceImpl implements ConversationService {
    final Logger logger = LoggerFactory.getLogger(BotController.class);

    @Autowired
    private ConfigService configService;

    @Autowired
    private ActivityService activityService;
    
    @Autowired
    private ConversationDailyPushService conversationDailyPushService;
    
    @Autowired
    private EventService eventService;

    @Autowired
    private BotDao botDao;
   
    @Autowired
    private WeatherDao weatherDao;
    
    @Autowired
    private MongoTemplate mongoTemplate;    
        
    @Autowired
    private MessageSource messageSource;
    
    private static final int DEFAULT_ACTIVITIES_OFFSET_COUNT = 10;
    
    /**
     * 기본 로케이션 코드 (서울시 영등포구: 1156000000, 마곡 이전하면 변경필요)
     */
    private static String DEFAULT_CITY_CODE;
    
    @Value("${weather.default-city-code}")
    public void setDefaultCityCode(String cityCode) {
        DEFAULT_CITY_CODE = cityCode;
    }

    /**
     * Conversation 초기화 (대화정보 생성 및 대화일시 갱신)
     * @param botId
     * @param user
     * @param tenantId
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Conversation initialize(String botId, User user, String tenantId) {
        LocalDateTime now = LocalDateTime.now();
        Date date = Date.from(now.atZone(ZoneId.systemDefault()).toInstant());
        
        // 1 봇 조회
        Bot bot = StringUtils.isEmpty(botId) ? botDao.selectDefaultBotDetail() : botDao.selectBotDetail(botId);
        
        if (!I18nUtils.isDefaultLocaleCode(user.getLocaleCode())) {
            bot.setBotName(bot.getBotEnglishName());
        }
        
        // 2. Conversation 조회
        Query findQuery = new Query()
                .addCriteria(Criteria.where("userId").is(user.getUserId()).and("botId").is(bot.getBotId()));

        Conversation conversation = mongoTemplate.findOne(findQuery, Conversation.class, "conversations");
        
        // 2-1. 대화 데이터 생성
        // 봇 과 사용자의 대화정보 조회 및 대화일시 갱신, 존재하지 않는 경우 신규대화 생성
        boolean fristTodayConversation = false;
        
        if (conversation == null) {
            conversation = new Conversation();
            
            // 최초 로그인 여부
            conversation.setFirstLogin(true);
            
            // 당일 최초 로그인 여부
            fristTodayConversation = true;
            conversation.setFirstTodayConversation(fristTodayConversation);
            
            conversation.setUserId(user.getUserId());
            conversation.setBotId(bot.getBotId());
            conversation.setEnterDate(date);
            conversation.setRegisterId(user.getUserId());
            conversation.setRegisterName(user.getUserName());
            conversation.setRegistDate(date);
            conversation.setUpdaterId(user.getUserId());
            conversation.setUpdaterName(user.getUserName());
            conversation.setUpdateDate(date);
                        
            mongoTemplate.save(conversation, "conversations");
        } 
        // 2-2. 대화 입장 일시 갱신
        else {
            //  최초 로그인 여부
            conversation.setFirstLogin(false);
            
            //  당일 최초 로그인 여부
            fristTodayConversation = this.isFristTodayConversation(conversation.getEnterDate());
            conversation.setFirstTodayConversation(fristTodayConversation);
            
            conversation.setEnterDate(date);
            conversation.setUpdaterId(user.getUserId());
            conversation.setUpdaterName(user.getUserName());
            conversation.setUpdateDate(date);
            
            mongoTemplate.save(conversation);
        }
        
        // 봇 정보 세팅
        conversation.setBot(bot);
        
        // 3. 알림 설정정보 생성
        try {
            // 알림정보 기본 설정이 필요한 경우
            if (configService.isUserCreatePushConfig(botId, user.getUserId())) {
                configService.createPushConfig(botId, user.getUserId());
            }
        } catch (Exception e) {
            logger.debug(e.getMessage(), e);
        }
                
        // 4. 데일리 푸시 표시 여부
        // 데일리 푸시 미사용 여부 확인
        boolean hasUserTodayDailyPush = false;
        
        try {
            if (!configService.isUserNotUsedPushByPushTypeCode(botId, user.getUserId(), ConfigCode.PUSH_TYPE_CODE_DAILY)) {            
                hasUserTodayDailyPush = this.isFristDailyPush(conversation.getDailyPushDate());
                conversation.setHasUserTodayDailyPush(hasUserTodayDailyPush);
            }
        } catch (Exception e) {
            logger.debug(e.getMessage(), e);
        }   
        logger.info("### initialize conversation userId:"+conversation.getUserId()+",getEnterDate:"+conversation.getEnterDate()+", getDailyPushDate:"+conversation.getDailyPushDate()+",firstTodayConversation:"+fristTodayConversation+",hasUserTodayDailyPush:"+hasUserTodayDailyPush);
        
        
        // 5. 데일리 푸시 시점이 아닌 경우 과거 메시지 ${DEFAULT_ACTIVITIES_OFFSET_COUNT} 건을 조회한다.
        try {       
            if (!fristTodayConversation && !hasUserTodayDailyPush) {
                List<Activity> activities = activityService.retrieveRecentActivityList(botId, DEFAULT_ACTIVITIES_OFFSET_COUNT, user, false);
                conversation.setActivities(activities);
            }
            
        } catch (Exception e) {
            logger.debug(e.getMessage(), e);
        }          
        
        // 6. (오늘 최초 로그인인 경우) 오늘의 이벤트 조회
        try {       
            if (fristTodayConversation) {
                conversation.setEvent(eventService.retrieveTodayEvent(botId, tenantId, user));
            }
        } catch (Exception e) {
            logger.debug(e.getMessage(), e);
        }  
        
        // 7. 메시지 건수 조회
        // 메시지 카운트 조회하지 않음, 이전 대화 보기 버튼을 위하여 1로 무조건 세팅
        conversation.setActivityCount(1);   
        
        //	8. 푸쉬 읽음 처리
        
    	
    	//이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다.2018.01.09
    	//james
       // System.out.println("######action.getUserId():"+conversation.getUserId());
        logger.info("###########################initialize 이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다##########################");
    	Query findPushQuery = new Query();
    	Criteria criteriaPush = Criteria.where("subtype").is("push");
    	criteriaPush.and("userId").is(conversation.getUserId());
    	criteriaPush.and("readDate").exists(false);
    	

    	findPushQuery.addCriteria(criteriaPush);

    	Update update = new Update();
    	update.set("readDate", new Date());
    	mongoTemplate.updateMulti(findPushQuery, update, Activity.class, "activities");
        
        return conversation;
    }
    
    /**
     * 사용자의 진행중인 Conversation 및 Bot 목록 조회
     * @param userId
     * @return
     */
    @Override
    public List<Conversation> retrieveUserConversationAndBotList(User user) {
        List<Conversation> botAndconversations = new ArrayList<>();

        List<Conversation> conversations = 
                mongoTemplate.find(new Query().addCriteria(Criteria.where("userId").is(user.getUserId())), Conversation.class, "conversations");

        for (Conversation conversation : conversations) {
            conversation.setBot(botDao.selectBotDetail(conversation.getBotId()));
            conversation.setLastActivity(activityService.retrieveLastActivity(conversation.getBotId(), user));
            botAndconversations.add(conversation);
        }

        List<Bot> bots = botDao.selectBotList();
        boolean hasUserConversation;
        for (Bot bot : bots) {
            hasUserConversation = false;
            for (Conversation conversation : botAndconversations) {
                if (!StringUtils.isEmpty(bot.getBotId()) && bot.getBotId().equals(conversation.getBotId())) {
                    hasUserConversation = true;
                    break;
                }
            }
            if (!hasUserConversation) {
                Conversation conversation = new Conversation();
                conversation.setBot(bot);
                botAndconversations.add(conversation);
            }
        }

        return botAndconversations;
    }
    
    /**
     * bot의 대화목록을 조회
     * @param botId
     * @return
     */
    @Override
    public List<Conversation> retrieveConversationList(String botId) {
    	
    	Query query = new Query();
    	
    	if( !StringUtils.isEmpty(botId)) {
    		query.addCriteria(Criteria.where("botId").is(botId));
    	} 
    	List<Conversation> conversations = mongoTemplate.find(query, Conversation.class, "conversations");
    	
    	return conversations;

    }


    /**
     * 접속시 인사말
     * @param botId
     * @param isEventMessage
     * @param tenantId
     * @param user
     * @return
     */
    @Override
    public List<Activity> retrieveGreeting(String botId, boolean isEventMessage, String tenantId, User user) {
        List<Activity> greetings = new ArrayList<>();
        
        String localeCode = user.getLocaleCode();        
        LocalDateTime now = LocalDateTime.now();

        // 1. 봇 정보 조회
        Bot bot = botDao.selectBotDetail(botId);

        // 1.1 기본 봇 인사 메시지 조회
        BotMessage params = new BotMessage();
        params.setBotId(bot.getBotId());
        params.setMessageType(BotCode.BOT_MESSAGE_TYPE_GREETING);
       
        StringBuffer message = new StringBuffer();
        
        // 2. 메시지 조회
        
        // 2.2. 이벤트 메시지 조회
        if (isEventMessage) {
            // 표시유형 (1: 메시지, 2: 애니메이션, 3: 애니메이션 + 메시지)
            Event event = eventService.retrieveTodayEvent(botId, tenantId, user);
            
            if (event != null && (ActivityCode.EVENT_DISPLAY_TYPE_MESSAGE.equals(event.getDisplayType()) || 
                    ActivityCode.EVENT_DISPLAY_TYPE_ALL.equals(event.getDisplayType()))) {
                
                String messageString = I18nUtils.isDefaultLocaleCode(localeCode) ? event.getMessage() : event.getEnglishMessage();

                DateTimeFormatter formatter = Locale.KOREAN.toString().equals(localeCode) ? 
                        DateTimeFormatter.ofPattern("yyyy년 M월 d일 E요일").withLocale(Locale.KOREAN) : 
                        DateTimeFormatter.ofPattern("eee, d M yyyy").withLocale(Locale.ENGLISH);

                messageString = messageString.replaceAll("[$]\\{userName\\}",
                        I18nUtils.isDefaultLocaleCode(localeCode) ? user.getUserName() : user.getUserEnglishName());
                
                messageString = messageString.replaceAll("[$]\\{jobTitleName\\}",
                        I18nUtils.isDefaultLocaleCode(localeCode) ? user.getJobTitleName() : user.getJobTitleName());
                
                messageString = messageString.replaceAll("[$]\\{today\\}", formatter.format(now));

                message.append(messageString);
            }
        }
        
        // 2.1. 금일의 랜덤 메시지 조회
        if (!isEventMessage || StringUtils.isEmpty(message)) {
            BotMessage greetingMessage = botDao.selectRandomBotMessageByType(params);
            
            // 2.1.1. 인사말 (Greeting Message) 생성
            if (greetingMessage != null && !StringUtils.isEmpty(greetingMessage.getMessage())) {
                String messageString = I18nUtils.isDefaultLocaleCode(localeCode) ? 
                        greetingMessage.getMessage() : greetingMessage.getEnglishMessage();

                DateTimeFormatter formatter = Locale.KOREAN.toString().equals(localeCode) ? 
                        DateTimeFormatter.ofPattern("yyyy년 M월 d일 E요일").withLocale(Locale.KOREAN) :
                        DateTimeFormatter.ofPattern("eee, d M yyyy").withLocale(Locale.ENGLISH);

                messageString = messageString.replaceAll("[$]\\{userName\\}",
                        I18nUtils.isDefaultLocaleCode(localeCode) ? user.getUserName() : user.getUserEnglishName());
                
                messageString = messageString.replaceAll("[$]\\{jobTitleName\\}",
                        I18nUtils.isDefaultLocaleCode(localeCode) ? user.getJobTitleName() : user.getJobTitleName());
                
                messageString = messageString.replaceAll("[$]\\{today\\}", formatter.format(now));

                message.append(messageString);
            }

            // 2.1.2. 금일 날씨 정보 조회
            Weather weatherCondition = new Weather();
            String cityCode = DEFAULT_CITY_CODE;
            
            if (!StringUtils.isEmpty(user.getOfficeBasicAddress())) {
                City officeLocation = weatherDao.selectCityByOfficeAddress(user.getOfficeBasicAddress());
                
                if (officeLocation != null && !StringUtils.isEmpty(officeLocation.getCityCode())) {
                    cityCode = officeLocation.getCityCode();
                }
            }
            
            weatherCondition.setSearchCityCode(cityCode);
        
            // 날씨(0: 맑음, 1: 흐림, 2: 비, 3: 눈)에 따른 메시지 조회
            Weather weather = weatherDao.selectWeatherByCityCode(weatherCondition);
            
            if (weather != null) {
                params = new BotMessage();
                params.setBotId(bot.getBotId());
                params.setMessageType(BotCode.BOT_MESSAGE_TYPE_WEATHER);
                params.setWeatherType(weather.getSkyType());
                
                BotMessage weatherMessage = botDao.selectRandomBotMessageByType(params);
                
                if (weatherMessage != null && !StringUtils.isEmpty(weatherMessage.getMessage())) {
                    message
                        .append("\n\r")
                        .append(I18nUtils.isDefaultLocaleCode(localeCode) ? weatherMessage.getMessage() : weatherMessage.getEnglishMessage());   
                }
            }
        }
        
        // 3. 인사말(메시지) 생성
        if (!StringUtils.isEmpty(message)) {
            Activity greeting = Activity.createBotMessage(bot.getBotId(), user.getUserId());
            greeting.setMessage(message.toString());
            greeting.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_GREETING);
            
            try {
                greeting = activityService.insertActivity(greeting);
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
            
            greetings.add(greeting);    
        }
        
        return greetings;
    }

    /**
     * 일 최초 접속시 데일리 푸시 조회
     * @param botId
     * @param user
     * @param tenantId
     * @param reload
     * @return
     */
    @Override
    public List<Activity> retrieveDailyPush(String botId, User user, String tenantId, boolean reload) {
        List<Activity> activities = new ArrayList<>();
        StringBuilder msg = new StringBuilder();
        // 1. 봇 정보 조회
        Bot bot = botDao.selectBotDetail(botId);

        if (bot == null) {
            throw new RuntimeException("봇 정보가 올바르지 않습니다.");
        }
        
        // 데일리 푸시 미사용 여부
        boolean isUserNotUsedDailyPush = configService.isUserNotUsedPushByPushTypeCode(botId, user.getUserId(), ConfigCode.PUSH_TYPE_CODE_DAILY);
        msg.append("userId:"+user.getUserId()+",");
        msg.append("reload:"+reload+",");
        msg.append("isUserNotUsedDailyPush:"+isUserNotUsedDailyPush+",");  
        
        logger.info("### retrieveDailyPush init data:"+"userId:"+user.getUserId()+",reload:"+reload+",isUserNotUsedDailyPush:"+isUserNotUsedDailyPush);
        // 1.1. 데일리 푸시 미사용인 경우 종료
        if (isUserNotUsedDailyPush) {
            // 당일 최초 로그인 경우 무시
            if (!reload) {
                return activities;
            } 
            // 리로드인 경우 설정없음 메시지 표시
            // [설정된 데일리 알림이 없습니다.]
            else {
                Activity activity = Activity.createBotMessage(botId, user.getUserId());
                activity.setMessage(messageSource.getMessage("meesage.push.daily.noSetting", null, new Locale(user.getLocaleCode())));
                activity.addButton(new Button() {{
                    this.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
                    this.setAction("setting");
                    this.setIcon("fa-bell");
                    this.setTitle(messageSource.getMessage("meesage.push.setting", null, new Locale(user.getLocaleCode())));
                }});
                
                activities.add(activity);
                
                return activities;
            }
        } 

        // 2. 데일리 푸시        
        // A. 당일 최초 로그인 시, 데일리 알림 reload = false        
        // B. 명시적 데일리 알림 리로드 reload = true

        // A. 당일 최초 로그인
        if (!reload) {
            // 2.2. 대화정보 조회
            Query findQuery = new Query().addCriteria(Criteria.where("userId").is(user.getUserId()).and("botId").is(bot.getBotId()));
            Conversation conversation = mongoTemplate.findOne(findQuery, Conversation.class, "conversations");
            
            // 3. 데일리 푸시 처리
            // 3.1. 데일리 푸시 조건 확인
            // 날짜가 다르고 8시간이 지났다면 푸시 (8시간은 보통 취침후 다시 출근하는 최소 시간을 대략적으로 추정)
            // 일자가 다르거나, 최종 푸시 이후 8시간이 경과된 경우 푸시                  
            boolean isFristDailyPush = this.isFristDailyPush(conversation.getDailyPushDate());
            msg.append("getDailyPushDate:"+conversation.getDailyPushDate()+",");
            msg.append("isFristDailyPush:"+isFristDailyPush+",");
            // 3.2. 당일 데일리 푸시가 아닌 경우 종료
            if (!isFristDailyPush) {
                return activities;
            }
            
            // 3.3. 데일리 알림 일시 수정 (발신 처리)
            Update update = new Update()
                    .set("dailyPushDate", Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()));
            msg.append("dailyPushDate:"+ Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant())+",");
            mongoTemplate.updateFirst(new Query().addCriteria(Criteria.where("userId").is(user.getUserId()).and("botId").is(bot.getBotId())), 
                    update, Conversation.class, "conversations");            
        }
        
        // 3.3.2. 데일리 알림 조회
        Activity activity = conversationDailyPushService.executeDailyPush(bot, user, tenantId);

        // 데일리 알림 결과가 있는 경우
        if (activity != null) {
            // 설정 버튼
        	msg.append("==activity result is existed===,");
            activity.setId(UUID.randomUUID().toString());
            activity.addButton(new Button() {{
                this.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
                this.setAction("setting");
                this.setIcon("fa-bell");
                this.setTitle(messageSource.getMessage("meesage.push.setting", null, new Locale(user.getLocaleCode())));
            }});         
            
            
            // FIXME: 철수 전에 꼭 삭제
            // 애네메이션 테스트 용도로 사용
            if (!"app".equals(System.getProperty("spring.profiles.active"))) {
                activity.addButton(new Button() {{
                    this.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
                    this.setType("development");
                    this.setAction("animate");
                    this.setActionParams(new HashMap<String, Object>() {
                        private static final long serialVersionUID = 6370202000208121379L;
                        {
                            this.put("animation", new HashMap<String, Object>() {
                                private static final long serialVersionUID = 6370202000208121379L;
                                {
                                    this.put("animation", "Congratulation");
                                    // 0; 공용 컴포넌트, 1: 전용 컴포넌트
                                    this.put("animationType", ActivityCode.ANIMATION_TYPE_DEDICATED);
                                    this.put("animationTimeout", ActivityCode.ANIMATION_NO_TIMEOUT);
                                    this.put("congratulationType", "BIRTHDAY");
                                }
                            });
                        }
                    });
                    this.setIcon("fa-birthday-cake");
                }});                 
                    
                activity.addButton(new Button() {{
                    this.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
                    this.setType("development");
                    this.setAction("animate");
                    this.setActionParams(new HashMap<String, Object>() {
                        private static final long serialVersionUID = 6370202000208121379L;
                        {
                            this.put("animation", new HashMap<String, Object>() {
                                private static final long serialVersionUID = 6370202000208121379L;
                                {
                                    this.put("animation", "HeartBackground");
                                    this.put("animationType", ActivityCode.ANIMATION_TYPE_DEDICATED);                                
                                }
                            });
                        }
                    });
                    this.setIcon("fa-heart");
                }});
                
                activity.addButton(new Button() {{
                    this.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
                    this.setType("development");
                    this.setAction("animate");
                    this.setActionParams(new HashMap<String, Object>() {
                        private static final long serialVersionUID = 6370202000208121379L;
                        {
                            this.put("animation", new HashMap<String, Object>() {
                                private static final long serialVersionUID = 6370202000208121379L;
                                {
                                    this.put("animation", "Heart");
                                    this.put("animationType", ActivityCode.ANIMATION_TYPE_DEDICATED);                                
                                }
                            });
                        }
                    });
                    this.setIcon("fa-heart-o");
                }});
                
                activity.addButton(new Button() {{
                    this.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
                    this.setType("development");
                    this.setAction("animate");
                    this.setActionParams(new HashMap<String, Object>() {
                        private static final long serialVersionUID = 6370202000208121379L;
                        {
                            this.put("animation", new HashMap<String, Object>() {
                                private static final long serialVersionUID = 6370202000208121379L;
                                {
                                    this.put("animation", "Kiss");
                                    this.put("animationType", ActivityCode.ANIMATION_TYPE_DEDICATED);                                
                                }
                            });
                        }
                    });
                    this.setIcon("fa-heartbeat");
                }});
                
                activity.addButton(new Button() {{
                    this.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
                    this.setType("development");
                    this.setAction("animate");
                    this.setActionParams(new HashMap<String, Object>() {
                        private static final long serialVersionUID = 6370202000208121379L;
                        {
                            this.put("animation", new HashMap<String, Object>() {
                                private static final long serialVersionUID = 6370202000208121379L;
                                {
                                    // this.put("animation", "http://localhost:8000/assets/images/animation/Sample.gif");
                                    this.put("animation", "/assets/images/animation/Sample.gif");
                                    this.put("animationType", ActivityCode.ANIMATION_TYPE_COMMON);
                                    this.put("animationTitle", "ANIMATION_TITLE");
                                    this.put("animationContent", "ANIMATION_CONTENT : IKEP4_VA_EVENT_CONFIG 테이블");
                                    this.put("animationButton", "ANIMATION_BUTTON");
                                    this.put("animationButtonUrl", "http://www.google.com");
                                    this.put("animationTimeout", -1);                                
                                }
                            });
                        }
                    });
                    this.setIcon("fa-film");
                }});                 
            }
            

            // 2017.08.31 데일리 푸시 이력에서 제외함
            // activity = activityService.insertActivity(activity);
            
            // 리로드인 경우 간단한 메시지 추가
            if (reload) {
                String localeCode = user.getLocaleCode();
                
                DateTimeFormatter formatter = Locale.KOREAN.toString().equals(localeCode) ? 
                    DateTimeFormatter.ofPattern("yyyy년 M월 d일 E요일").withLocale(Locale.KOREAN) : 
                    DateTimeFormatter.ofPattern("eee, d M yyyy").withLocale(Locale.ENGLISH);
                       
                String userName = I18nUtils.isDefaultLocaleCode(localeCode) ? user.getUserName() : user.getUserEnglishName();
                String jobTitleName = I18nUtils.isDefaultLocaleCode(localeCode) ? user.getJobTitleName() : user.getJobTitleName();
                
                StringBuffer userNameBuffer = new StringBuffer()
                    .append(userName)
                    .append(" ")
                    .append(jobTitleName);

                String message = messageSource.getMessage("meesage.push.daily.today",
                    new String[] {
                        userNameBuffer.toString(),
                        formatter.format(LocalDateTime.now())
                    },
                    new Locale(user.getLocaleCode()));
                
                activity.setMessage(message);
            }
            
            activity.setFirstDailyPush(!reload);
            activities.add(activity);
            msg.append("reload:"+ !reload+",");
            msg.append("activity:"+activity.isFirstDailyPush() +" ");
            msg.append("###");
        } 
        // 데일리 알림 결과가 없는 경우
        // 최소 날씨는 하나 걸리기 때문에 거의 걸릴 확률 없음
        else {
            // 리로드인 경우 간단한 메시지 추가
            if (reload) {
                
            }
        }
        logger.info("### retrieveDailyPush data:"+msg.toString());
        return activities;
    }
    
    /**
     * 데일리 알림 일시 수정
     * @param botId
     * @param user
     * @return
     */
    @Override    
    public void updateDailyPushDate(String botId, User user) {
	
	  // 3.3. 데일리 알림 일시 수정 (발신 처리)
            Update update = new Update()
                    .set("dailyPushDate", Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()));
            mongoTemplate.updateFirst(new Query().addCriteria(Criteria.where("userId").is(user.getUserId()).and("botId").is(botId)), 
                    update, Conversation.class, "conversations");
					
    };
    
    /**
     * 최근 대화이력 조회
     * @param botId
     * @param user
     * @param limit
     * @param tenantId
     * @return
     */
    @Override    
    public List<Activity> retrieveRecentActivityList(String botId, User user, int limit, String tenantId) {
        return activityService.retrieveRecentActivityList(botId, limit, user, false);
    };
    
    /**
     * 이전 대화이력 조회
     * @param botId
     * @param user
     * @param cursorId
     * @param limit
     * @param tenantId
     * @return
     */
    @Override    
    public List<Activity> retrieveBeforeActivityList(String botId, User user, String cursorId, int limit, String tenantId) {
        return activityService.retrieveBeforeActivityList(botId, cursorId, limit, user, false);
    };
            
    /**
     * 사용자의 금일 Daily Push 여부를 확인
     * @return
     */ 
    private boolean isFristDailyPush(Date dailyPushDate) {
        boolean isFristDailyPush = false;
        LocalDate today = LocalDate.now();    
        
        try {
            if (dailyPushDate == null) {
                isFristDailyPush = true;
            } else {
                LocalDate dailyPushDateTime = dailyPushDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                isFristDailyPush = today.compareTo(dailyPushDateTime) > 0;
            }
            
        } catch (Exception e) {
            logger.debug(e.getMessage(), e);
            isFristDailyPush = false;
        }
        
        return isFristDailyPush;
    }
        
    /**
     * 금일 최초 대화 여부를 확인
     * @param enterDate
     * @return
     */
    private boolean isFristTodayConversation(Date enterDate) {
        try {    
            LocalDate now = LocalDate.now();    
            LocalDate enterLocalDate = enterDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            return enterLocalDate.compareTo(now) < 0;
            
        } catch (Exception e) {
            return false;
        }
    }
}
