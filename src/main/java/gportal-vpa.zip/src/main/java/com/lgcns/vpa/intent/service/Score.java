/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : Score.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.service;

public class Score {
	private String name;
	private double score;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	
	public String toString() {
		return name + "=" + score;
	}
	
	public static Score ZERO() {
		Score score = new Score();
		score.name  = "";
		score.score = 0.0;
		return score;
	}
	
	public static Score PERFECT() {
		Score score = new Score();
		score.name  = "";
		score.score = 100;
		return score;
	}
}
