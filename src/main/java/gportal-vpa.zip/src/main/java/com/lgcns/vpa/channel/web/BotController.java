package com.lgcns.vpa.channel.web;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.Keyword;
import com.lgcns.vpa.channel.model.Recommand;
import com.lgcns.vpa.channel.model.RecommandUserExcept;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.channel.service.RecommandService;
import com.lgcns.vpa.channel.service.RecommandUserExceptService;
import com.lgcns.vpa.security.user.model.User;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * <pre>
 * 봇 관리 Controller
 * </pre>
 * @author
 */
@RequestMapping(value = "/api/bots")
@CrossOrigin(value = "*")
@RestController
public class BotController extends BaseController {
    private final Logger logger = LoggerFactory.getLogger(BotController.class);

    @Autowired
    private BotService botService;
    
    @Autowired
    private RecommandService recommandService;
    
    @Autowired
    private RecommandUserExceptService recommandUserExceptService;

    /**
     * 봇 정보 조회	
     * @param botId
     * @return
     */
    @RequestMapping(value = "/{botId}", method = RequestMethod.GET)
    public ResponseEntity<Bot> retrieveBot(@PathVariable String botId, Map<String, String> params) {
        return new ResponseEntity<>(botService.retrieveBot(botId), HttpStatus.OK);
    }

    /**
     * 키워드 버튼 조회
     * @param botId
     * @return
     */
    @RequestMapping(value = "/{botId}/keywords", method = RequestMethod.GET)
    public ResponseEntity<List<Keyword>> retrieveButtons(@PathVariable String botId) {
        User user = getUser();
        List<Keyword> keywords = null;
        
        if (user != null) {
        	// 1. 사용자별 제외 키워드 조회
    		// 2. 관리자 추천 키워드를 조회
    		// 3. 사용자별 자주쓰는 키워드 조회
    		// 4. 사용자별 최근 키워드 조회 (6개월)
    		// 5. (2 + 3 + 4)에서 제외 키워드 제외함
    		// 6. 결과 : 관리자 추천키워드 + 자주쓰는 키워드(최대 5개) + 최근 키워드(최대 5개)
    		
        	// 관리자 키워드 조회
			List<Recommand> userRecomList = this.recommandService.getAdminRecommand(botId, user.getLeader());
			// 사용자 키워드 조회
    		userRecomList.addAll(this.recommandService.getUserRecommand(user.getUserId(), botId, 10));
    		
    		// 사용자별 제외 키워드 조회
    		List<RecommandUserExcept> userExceptList = this.recommandUserExceptService.listRecommandUserExcept(user.getUserId(), botId);
    		if( userExceptList == null ) {
    			userExceptList = Collections.emptyList();
    		}
    		
    		// 반환할 추천 Keyword 목록
    		// 메뉴 Keyword 생성
    		keywords = new ArrayList<Keyword>();
    		//2018.1.4 관리자 추천 키워드에서 해당 버튼을 생성하게 수정됨. 김가원
    		/*keywords.add(new Keyword("function", "", "dailyPush", "dailyPush") {{
    		    this.setId(UUID.randomUUID().toString());
    		    this.setType("dailyPush");
    		    this.setIcon("fa-bell");
    		}});
    		
    		keywords.add(new Keyword("function", "", "deleteActivities", "deleteActivities") {{
                this.setId(UUID.randomUUID().toString());
                this.setType("deleteActivities");
    		    this.setIcon("fa-trash-o");
            }});
    		
    		keywords.add(new Keyword("function", "연말정산봇", "newChangeBotWindow", "연말정산봇") {{
                this.setId(UUID.randomUUID().toString());
                this.setType("changeBot");    		    
            }});
    		
    		keywords.add(new Keyword("function", "@조직도", "organizationTree", "조직도") {{
                this.setId(UUID.randomUUID().toString());
                this.setType("fixed");
            }});
    		
    		keywords.add(new Keyword("function", "@메모", "memo", "메모") {{
                this.setId(UUID.randomUUID().toString());
                this.setType("fixed");
                
            }});
    		
    		
    		
    		keywords.add(new Keyword("function", "새창", "newWindow", "새창") {{
                this.setId(UUID.randomUUID().toString());
                this.setType("fixed");
            }});
    		
    		keywords.add(new Keyword("function", "To.엘비", "feedback", "의견") {{
                this.setId(UUID.randomUUID().toString());

            }});*/
    		
    		String keyword = null;
    		
    		for( Recommand recommand : userRecomList ) {
    			keyword = recommand.getRecommandName();
    			
    			if ( !StringUtils.hasText(keyword)  ) {
					continue;
				}
    			
				if( !userExceptList.contains(new RecommandUserExcept(keyword))) {
					keywords.add(new Keyword(recommand));
				}
    		}
        } // if (user != null)
        
        return new ResponseEntity<>(keywords, HttpStatus.OK);
    }
    
    /**
     * 키워드 버튼 삭제 (사용자 제외 키워드에 추가)
     * @param botId
     * @param keywordId
     * @return
     */
    @RequestMapping(value = "/{botId}/keywords", method = RequestMethod.DELETE)
    public ResponseEntity<String> deleteButton(@PathVariable String botId, @RequestBody Keyword keyword) {
    	logger.info("BotId:[" + botId + "], except keyword:[" + keyword + "]");
    	User user = getUser();
    	
    	if (keyword != null && !StringUtils.isEmpty(keyword.getTitle()) && (user != null)) {
    		// 사용자 제외 키워드 생성
    		this.recommandUserExceptService.createRecommandUserExcept(keyword.getTitle(), user.getUserId(), user.getUserName(), botId);
    	}
    	
        return new ResponseEntity<>(keyword.getId(), HttpStatus.OK);
    }
}
