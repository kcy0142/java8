/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.security.authentication.web;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.security.authentication.service.EndpointAuthenticationService;
import com.lgcns.vpa.security.authentication.util.IpAddressUtils;
import com.lgcns.vpa.security.authentication.util.JWTUtils;

import io.jsonwebtoken.Claims;

/**
 * <pre>
 * 인증처리 Controller
 * </pre>
 * @author
 */
@CrossOrigin(value="*")
@Controller
public class AuthenticationController extends BaseController {
    final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);
        
    @Autowired
    private EndpointAuthenticationService endpointAuthenticationService;
        
    /**
     * 엔드포인트 인증 처리
     * G-Portal 본체와의 인증 초기화시 이용
     * @param authorizationCode
     * @param popup
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value={"/authorize"}, method= RequestMethod.GET)
    public String authorize(@RequestParam(name = "authorization_code", required = true) String authorizationCode, 
            @RequestParam(name = "popup", required = false) String popup, 
            HttpServletRequest request, 
            RedirectAttributes redirectAttributes) {
        
        String tenantId = this.getTenantId();
        String ipaddress = IpAddressUtils.getClientIpAddress(request);

        logger.info("===================================================");
        logger.info("[AUTHORIZE]");
        logger.info("===================================================");
        logger.info(" - tenant_id: " + tenantId);
        logger.info(" - ip_address: " + ipaddress);
        logger.info(" - authorization_code: " + authorizationCode);
 
        Enumeration<String> headerNames = request.getHeaderNames();
        while(headerNames.hasMoreElements()){
            String name = (String)headerNames.nextElement();
            String value = request.getHeader(name);
            logger.info(String.format(" - [header] %s : %s", name, value));
        }
                
        endpointAuthenticationService.authorize(request, authorizationCode, ipaddress);
        
        redirectAttributes.addAttribute("popup", popup);
        return "redirect:/client";
    }
    
    /**
     * 인증실패 처리
     * @return
     */
    @RequestMapping("/unauthorized") 
    public String unauthorized() { 
        return "redirect:/error"; 
    }
    
    /**
     * 인증여부 조회
     * @param request
     * @return
     */
    @RequestMapping(value = "/auth", method= RequestMethod.GET)
    @ResponseBody
    public boolean getSession(HttpServletRequest request) {
        return true;
    }    

    /**
     * 로그인 (개발에서만 사용)
     * @param authorizationCode
     * @param request
     * @return
     */
    @RequestMapping(value = "/auth/login", method= RequestMethod.POST)
    @ResponseBody
    public void login(@RequestBody(required = false) ModelMap model, HttpServletRequest request) {
        if ("app".equals(System.getProperty("spring.profiles.active"))) {
            throw new IllegalStateException("올바르지 않은 인증입니다.");
        }
        
        String userId = (String) model.get("authorization_code");
        String password = (String) model.get("password");
        endpointAuthenticationService.login(new UsernamePasswordAuthenticationToken(userId, password));
    } 
    
    /**
     * 로그아웃 (개발에서만 사용)
     * @param request
     */
    @RequestMapping(value = "/auth/logout", method= RequestMethod.POST)
    @ResponseBody
    public void logout(HttpServletRequest request) {
        if ("app".equals(System.getProperty("spring.profiles.active"))) {
            throw new IllegalStateException("올바르지 않은 인증입니다.");
        }
        
        HttpSession session = request.getSession(false);
        if (session != null) {            
            try {
                session.invalidate();
            } catch (Exception ignored) {}
        }
    }
        
    /**
     * JWT 테스트 (개발에서만 사용)
     * @param request
     * @return
     */
    @RequestMapping(value="/security/jwt", method= RequestMethod.GET)
    public String token(HttpServletRequest request, @RequestParam(required = false) String userId, ModelMap model) {
        // @FIXME: 백도어 로그인이 불필요한 시점이 되면 꼭 이 소스 막으세요.
        String token = JWTUtils.generateToken(userId, IpAddressUtils.getClientIpAddress(request));
        Claims claims = JWTUtils.getClaimsFromToken(token);
        
        logger.info(claims.getExpiration().toString());
        logger.info(claims.getId());
        logger.info(claims.getIssuedAt().toString());
        logger.info(claims.getSubject());
        logger.info(claims.get("ipaddress").toString());
        
        model.addAttribute("token", token);
        model.addAttribute("claims", claims);
        model.addAttribute("validated", JWTUtils.validateToken(token, IpAddressUtils.getClientIpAddress(request)));
        
        return "authentication";
    }
    
    /**
     * JWT Demo 테스트 (개발에서만 사용)
     * @param request
     * @return
     */
    @RequestMapping(value="/demo", method= RequestMethod.GET)
    public String tokenDemo(HttpServletRequest request, RedirectAttributes redirectAttributes, @RequestParam(required = false) String userId, ModelMap model) {
        // @FIXME: 백도어 로그인이 불필요한 시점이 되면 꼭 이 소스 막으세요.
    	String tempUserId="demo";
        String token = JWTUtils.generateToken(tempUserId, IpAddressUtils.getClientIpAddress(request));
        Claims claims = JWTUtils.getClaimsFromToken(token);
        
        logger.info(claims.getExpiration().toString());
        logger.info(claims.getId());
        logger.info(claims.getIssuedAt().toString());
        logger.info(claims.getSubject());
        logger.info(claims.get("ipaddress").toString());
        
       // model.addAttribute("token", token);
       // model.addAttribute("claims", claims);
       // model.addAttribute("validated", JWTUtils.validateToken(token, IpAddressUtils.getClientIpAddress(request)));
        
        String popup="";
        String authorizationCode=token;
        String tenantId = this.getTenantId();
        String ipaddress = IpAddressUtils.getClientIpAddress(request);

        logger.info("===================================================");
        logger.info("[DEMO AUTHORIZE]");
        logger.info("===================================================");
        logger.info(" - demo tenant_id: " + tenantId);
        logger.info(" - demo ip_address: " + ipaddress);
        logger.info(" - demo authorization_code: " + authorizationCode);
        
 
        Enumeration<String> headerNames = request.getHeaderNames();
        while(headerNames.hasMoreElements()){
            String name = (String)headerNames.nextElement();
            String value = request.getHeader(name);
            logger.info(String.format(" - [header] %s : %s", name, value));
        }
                
        endpointAuthenticationService.authorize(request, authorizationCode, ipaddress);
        
       // redirectAttributes.addAttribute("popup", popup);
        return "redirect:/client";
        
        
       // return "authentication";
    }
}