/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : StopWordService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.dialog.model.StopWord;
import com.lgcns.vpa.framework.multidata.annotation.MultiDataSource;


/**
 * <PRE>
 * 불용어를 Mongo Db에서 조회할 business logic 처리용 Service
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 7. 12.
 */
@Service("multi.stopWordService")
public class StopWordService {
	
	private static final String [] REMOVE_CHAR_ARRAY = {"은", "는", "이", "가", "을", "를", "의", "에서", "부터", "도", "으로","요", "니다", "오", "께요", "네요", "하네", "해", "야", "아", "님"};
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	/**
	 * 불용어를 검색, 불용어 Type 별로 검색 함
	 * @param stopWordName
	 * @param botId
	 * @return
	 */
	@MultiDataSource
	public StopWord getStopWordData(String stopWordName, String botId) {
		
		if ( (stopWordName == null) || (!StringUtils.hasText(stopWordName)) ) {
			return null;
		}
		
		StopWord resultSw = null;
		
		//조회할 문장의 모든 공백을 제거하고 단일 문장으로 검색
		resultSw = searchStopWord(this.removeSpecialChar(stopWordName), botId, false);
		
		//조회할 문장의 모든 공백을 제거하고 특정 접미어를 제외한 단일 문장으로 검색
		resultSw = ( resultSw == null ) ? searchStopWord(this.removeEndChar(stopWordName), botId, false) : resultSw;
		
		//조회할 문장을 공백으로 구분하여 단어 단위로 검색
		if ( resultSw == null ) {
			String [] splitData = stopWordName.split(" ");
			if ( splitData != null ) {
				
				//조회할 단어가 2개 이상인 경우만 검색 함
				if ( splitData.length > 1) {
					for (String data : splitData) {
						
						if ( StringUtils.isEmpty(data) ) {
							continue;
						}
						
						//조회할 단어로 검색
						resultSw = searchStopWord(this.removeSpecialChar(data), botId, true);
						
						//특정 접미어를 제외한 단어로 검색
						resultSw = ( resultSw == null ) ? this.searchStopWord(this.removeEndChar(data), botId, true) : resultSw;
						
						//앞쪽의 단어가 불용어에 해당하면 그 값을 리턴함 
						if (resultSw != null) {
							break;
						}
					}//for
				}
			}
		}
		
		return resultSw;
	}//getStopWordData
	
	/**
	 * 불용어 검색
	 * @param stopWordName
	 * @param botId
	 * @return
	 */
	private StopWord searchStopWord (String stopWordName, String botId, boolean onlyInType) {
		
		StopWord resultSw = null;
		String target = stopWordName.replace(" ", "");
		
		if ( (target == null) || (target.length() <= 0) ) {
			return null;
		}
		
		try {
			Criteria criteria = new Criteria();
			Query query = new Query();
			
			if (botId != null) {
				criteria.andOperator(Criteria.where("botId").is(botId), Criteria.where("stopWordName").is(target));
				//query.addCriteria(Criteria.where("stopWordName").is(target).andOperator(Criteria.where("botId").regex(botId)));
				
			}
			else {
				criteria.andOperator(Criteria.where("stopWordName").is(target));
				//query.addCriteria(Criteria.where("stopWordName").regex(target));
			}
			
			query.addCriteria(criteria);
			StopWord stopWord = this.mongoTemplate.findOne(query, StopWord.class);
			
			//불용어 조건이 포함일 경우 처리
			if ( "IN".equals(stopWord.getStopWordType()) ) {
				resultSw = stopWord;
			}
			//불용어 조건이 일치일 경우 처리 
			else if ( !onlyInType ) {
				if (target.equalsIgnoreCase(stopWord.getStopWordName())) {
					resultSw = stopWord;
				}
			}
		} catch (Exception e) {
			return null;
		}
		
		return resultSw;
	}
	
	
	@MultiDataSource
	public String getStopWordDataOne(String stopWordName, String botId) {
		
		if ( (stopWordName == null) || (!StringUtils.hasText(stopWordName)) ) {
			return null;
		}
		
		//조회할 문장의 모든 공백을 제거
		String target = stopWordName.replace(" ", "");
		
		if ( (target == null) || (target.length() <= 0) ) {
			return null;
		}
		
		try {
			Query query = new Query();
			
			if (botId != null) {
				query.addCriteria(Criteria.where("stopWordName").is(target).andOperator(Criteria.where("botId").is(botId)));
			}
			else {
				query.addCriteria(Criteria.where("stopWordName").is(target));
			}
			
			StopWord stopWord = this.mongoTemplate.findOne(query, StopWord.class);
			
			return (stopWord != null) ? stopWord.getResponseMessage() : null;
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 특정 접미어 제거
	 * @param word
	 * @return
	 */
	public String removeEndChar (String word) {
		
		if ( StringUtils.isEmpty(word) ) {
			return null;
		}
		final String emptyStr = "";
		
		//String result = new String(word);
		String result = this.removeSpecialChar(word);
		 
		for (String removeChar : REMOVE_CHAR_ARRAY) {
			if ( result.endsWith(removeChar) ) {
				result = result.replace(removeChar, emptyStr);
				break;
			}
		}
		
		return result;
	}
	
	/**
	 * 특수문자 제거
	 * @param str
	 * @return
	 */
	public String removeSpecialChar (String str) {
		
		if ( StringUtils.isEmpty(str) ) {
			return null;
		}
		
		String match = "[^a-zA-Z0-9ㄱ-ㅎㅏ-ㅣ가-힣\\-/()@^\\s+]";
	    String nstr = str.replaceAll(match, "");
	    
	    return nstr;
	}
}
