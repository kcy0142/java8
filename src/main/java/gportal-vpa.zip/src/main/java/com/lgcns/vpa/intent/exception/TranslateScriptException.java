/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : DuplicateEntityException.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.exception;

public class TranslateScriptException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TranslateScriptException(String msg) {
		super(msg);
	}

}
