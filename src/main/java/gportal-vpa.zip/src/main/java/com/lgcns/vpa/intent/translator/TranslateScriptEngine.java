package com.lgcns.vpa.intent.translator;

import java.io.InputStreamReader;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;

import com.lgcns.vpa.intent.entity.EntityDictionary;
import com.lgcns.vpa.intent.exception.TranslateScriptException;

public class TranslateScriptEngine {
	
	private static final Logger LOG = LoggerFactory.getLogger(EntityDictionary.class);

	private ScriptEngine engine;
	
	public TranslateScriptEngine(Resource resource) {
		engine = new ScriptEngineManager().getEngineByName("nashorn");
		
		try {
			engine.eval(new InputStreamReader(resource.getInputStream()));
		} catch (Exception e) {
			LOG.error("translator script is null " + resource.getDescription());
			e.printStackTrace();
			throw new IllegalStateException();
		}
	}
	public Object invokeFunction(String funcName, Object ...params) {
		Invocable invocable = (Invocable) engine;
		
		try {
			return invocable.invokeFunction(funcName, params);
		} catch ( Exception e) {
			throw new TranslateScriptException(e.getLocalizedMessage());
		}
	}
	public Object evalFunction(String evalString, String funcName, Object ... params) {

		try {
			engine.eval(evalString);
			Invocable invocable = (Invocable) engine;
	        return invocable.invokeFunction(funcName, params);
		} catch (Exception e) {
			throw new TranslateScriptException(e.getLocalizedMessage());
		}
	}
}
