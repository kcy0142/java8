/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : DuplicateEntityException.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.exception;

public class DuplicateEntityException extends EntityException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DuplicateEntityException(String field, String msg) {
		super(field, msg);
	}

}
