/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : CommonDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.service.dialog;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.service.NettyPoolClientService;
import com.lgcns.vpa.dialog.util.ActivityResultMapper;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.dialog.util.JsonUtil;
import com.lgcns.vpa.dialog.util.ParameterChecker;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.security.user.service.UserRoleService;



/**
 * <PRE>
 * 일반 질의문 처리를 위한 Dialog 정의
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Component("CommonDialog")
public class CommonDialog extends VpaDialog {
	
	private static final Logger LOG = LoggerFactory.getLogger(CommonDialog.class); 
	
	@Autowired
	private NettyPoolClientService nettyPoolClientService;  
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Override
	protected boolean validator(InquiryVO data) {
		
		Action action = data.getAction();
		boolean isValid = false;
		
		//Parameter validator
		if (action != null) {
			if ( !StringUtils.hasText(action.getActionUri()) ) {
				isValid = true;
			}
			else {
				isValid = true;
				
				if ( action.getActionUri().startsWith("sql-stored") ) {
					//Intent Parameter 에서 누락된 Parameter 는 각 Type 의 기본 값으로 Parameter 값을 설정함
					Map<String, Object> newIntentParam = ParameterChecker.parameterValidator(action.getActionUri(), data.getIntentParam());
					data.setIntentParam(newIntentParam);
				}
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
						 "], actionUri:["+action.getActionUri()+"], Intent Param:["+data.getIntentParam()+"]");
			}
		}
		else {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+"], Validation을 수행할 action 정보가 없음");
		}
		
		return isValid;
	}
	
	@Override
	protected boolean hasActionRight(InquiryVO data) {
		
		boolean hasRight = false;
		
		if ( data.getReqUser() == null ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한을 검사할 Req User 정보가 없음");
			return false;
		}
		
		//인텐트별 사용자의 사용 권한 조회
		hasRight = this.userRoleService.validateUserRole(data.getReqUser(), data.getIntentId());
		
		if (!hasRight) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한 없음");
		}
		return hasRight;
	}

	@Override
	protected String processor(InquiryVO data) {
		
		if ( (data == null) || (data.getAction() == null) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 정보가 부정확함");
			return null;
		}
		
		//Backend Proxy 에 Data 요청 (동기식 처리)
		TransferSyncVO transferVO = null;
		String resultJsonData = null;
		long currentTime = System.currentTimeMillis();
		
		try {
			transferVO = new TransferSyncVO(data);
			
			//ActionUri가 있는 경우 Proxy 서버에 질의
			//ActionUri가 없는 경우 Template 정보으로 응답 생성
			if ( StringUtils.hasText(transferVO.getActionUri()) ) {
				
				resultJsonData = this.nettyPoolClientService.sendToBnpSync(transferVO);
				data.setSpentTimeProxy(System.currentTimeMillis() - currentTime);
				
				if ( (resultJsonData == null) || (!StringUtils.hasText(resultJsonData)) ) {
					//결과가 없음
					resultJsonData = CommonCode.ACTION_RESULT_NONE;
					LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음, spentTimeProxy:["+data.getSpentTimeProxy()+"]");
				}
			}
			else {
				//Template 정보으로 응답 생성
				resultJsonData = CommonCode.ACTION_URI_NONE;
				data.setSpentTimeProxy(System.currentTimeMillis() - currentTime);
			}
			
		} catch (Exception e) {
			
			data.setSpentTimeProxy(System.currentTimeMillis() - currentTime);
			
			//오류 발생
			resultJsonData = CommonCode.ACTION_RESULT_ERROR;
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], spentTimeProxy:["+data.getSpentTimeProxy()+"], Proxy 정보 조회 중 오류 발생, Exception : " + e.toString());
		}
		
		return resultJsonData;
	}

	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		Activity resultActivity = null;
		
		try {
			
			//proxy에 data 조회를 하지 않은 경우는 Template data로만 응답 생성
			if ( proxyResponseJsonData == null ) {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성할 정보가 없음");
				resultActivity = createResponceActivityForNoneUri (data);
			}
			//proxy에 data 조회하여 결과를 받은 경우 처리
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResponseJsonData:======="+proxyResponseJsonData+"=======");
				
				TransferSyncVO transferSyncVO = null;
				
				if ( StringUtils.hasText(proxyResponseJsonData) ) {
					//응답 메세지가 성공인지 결과는 있는지 검사
					ObjectMapper mapper = new ObjectMapper();
			        JsonNode root = mapper.readTree(proxyResponseJsonData);
			        
			        String successYn = root.path("successYn").asText();
			        
			        if ( !"Y".equalsIgnoreCase(successYn) ) {
			        	//조회 실패
			        	resultActivity = this.commonResponeService.errorWarning(data);
			        }
			        if (root.path("actionResult").isNull() || root.path("actionResult").isTextual()) {
			        	//Data 가 없음
			        	resultActivity = this.commonResponeService.noDataInLegacy(data);
			        }
			        else {
			        	if (root.path("actionResult").isArray()) {
			        		
			        		//Data를 Class로 변환, 동기식 응답 Object 생성
							JsonConverter<TransferSyncVO> transferMapper = new JsonConverter<TransferSyncVO>(); 
							transferSyncVO = transferMapper.jasonStringToObject(proxyResponseJsonData, TransferSyncVO.class);
							
							List<Map<String, Object>> proxyResultSet = transferSyncVO.getActionResult();
							
							if ( (proxyResultSet == null) || (proxyResultSet.isEmpty()) ) {
								//Data 가 없음
					        	resultActivity = this.commonResponeService.noDataInLegacy(data);
							}
							else {
								Action action = data.getAction();
								resultActivity = this.createResponseActivity( data, proxyResultSet, action.getMapper()); //응답용 Activity 생성
							}
			        	}
			        }
				}
				
				//응답 Transfer Object 가 없거나 응답내용이 실패 또는 응답 내용이 없을 경우
				if ( (resultActivity == null) && (transferSyncVO == null) ) {
					resultActivity = this.commonResponeService.cannotUnderstand(data);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	private Activity createResponseActivity (InquiryVO data, List<Map<String, Object>> proxyResultSet, String mappingData) {
		if ( data == null ) {
			return null;
		}
		
		Activity resultActivity = null;
		
		try {
			Action action = data.getAction();
			
			// Template 정보가 있는 경우 Activity Object 생성
			if (StringUtils.hasText(action.getResponseTemplate())) {
				
				JsonConverter<Activity> jc = new JsonConverter<Activity>();
				resultActivity = jc.jasonStringToObject(action.getResponseTemplate(), Activity.class);
			}
			//Template 정보가 없는 경우 Activity Object 생성
			else {
				resultActivity = new Activity();
			}
			
			//Return 을 위한 Activity 설정, Template 값에 우선함.
			Activity reqActivity = data.getRequestActivity();
			
			//resultActivity.setConversationId(reqActivity.getConversationId());
			resultActivity.setReplyToId(reqActivity.getReplyToId());
			resultActivity.setType(CommonCode.ACTIVITY_TYPE_MESSAGE);
			resultActivity.setMessage(data.getIntentMessage());
			resultActivity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
			
			resultActivity.setUserIp(reqActivity.getUserIp());
			resultActivity.setDeviceType(reqActivity.getDeviceType());
			resultActivity.setBotId(data.getBotId());
			resultActivity.setSentDate(new Date(System.currentTimeMillis()));
			resultActivity.setUserId(reqActivity.getUserId());
			
			//의도분석의 Button이 있는 경우 처리
			if ( data.getIntentButtons() != null ) {
				List<RelatedButton> buttons = data.getIntentButtons();
				List<Button> activityButtonList = super.makeActivityButtonList(buttons);
				
				if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
					resultActivity.setButtons(activityButtonList);
				}
			}
			
			//TODO Attachment List 처리
			//TODO Element 처리 (Action Mapper Data 가 있을 경우 치환 처리)
			//TODO Button 처리 (Parameter 있을 Proxy Result 에서 치환 처리)
			new ActivityResultMapper().setMappingData(resultActivity, proxyResultSet, mappingData, action.getMapperType(), action.getAttachmentTemplateType());
			
			List<Attachment> attachments = resultActivity.getAttachments();
			if ( (attachments != null) && (!attachments.isEmpty()) ) {
				for (Attachment attm : attachments) {
					if (attm != null) {
						attm.setType(action.getAttachmentType());
						attm.setTemplateType(action.getAttachmentTemplateType());
						attm.setSubtype(action.getAttachmentTemplateType());
					}
				}
			}
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Activity : " + JsonUtil.toJson(resultActivity));
		} catch (Exception e) {
			resultActivity = null;
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답Activity 생성하는 중 오류 발생, Exception : " + e.toString());
		}
		
		return resultActivity;
	}//createResponceActivity

	/**
	 * Action URI 가 없어 Template 으로만 응답 내용 생성
	 * @param data
	 * @return
	 */
	private Activity createResponceActivityForNoneUri (InquiryVO data) {
		Activity resultActivity = null;
		
		try {
			Action action = data.getAction();
			
			// Template 정보가 있는 경우 Activity Object 생성
			if (StringUtils.hasText(action.getResponseTemplate())) {
				
				JsonConverter<Activity> jc = new JsonConverter<Activity>();
				resultActivity = jc.jasonStringToObject(action.getResponseTemplate(), Activity.class);
				
				if (resultActivity != null) {
					
					resultActivity.setType(action.getActivityType());
					List<Attachment> attachments = resultActivity.getAttachments();
					Attachment attachment = null;
					
					if ( (attachments != null) && (!attachments.isEmpty()) ) {
						attachment = attachments.get(0);
						attachment.setTemplateType(action.getAttachmentTemplateType());
						attachment.setType(action.getAttachmentType());
					}
					
					if ( !StringUtils.isEmpty(data.getIntentMessage()) ) {
						resultActivity.setMessage(data.getIntentMessage());
					}
					
					//의도분석의 Button이 있는 경우 처리
					if ( data.getIntentButtons() != null ) {
						List<RelatedButton> buttons = data.getIntentButtons();
						List<Button> activityButtonList = super.makeActivityButtonList(buttons);
						
						if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
							resultActivity.setButtons(activityButtonList);
						}
					}
				}
				else {// Template 정보가 있는데 파싱오류가 발생함
					LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 연동 없이 Template 정보로 Activity 생성중 Template Parsing 오류");
				}
			}
			// Template 정보가 없는 경우 잘 모르겠음 응답
			else {
				resultActivity = this.commonResponeService.cannotUnderstand(data);
			}
			
			if ( resultActivity != null ) {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 연동 없이 Template 정보로 Activity 생성 : " + JsonUtil.toJson(resultActivity));
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 연동 없이 Template 정보로 Activity 생성 : NULL");
			}
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 연동 없이 Template 정보로 Activity 생성중 오류 발생 : " + e.toString());
			
			resultActivity = null;
		}
		
		return resultActivity;
		
	}//createResponceActivityForNoneUri
}
