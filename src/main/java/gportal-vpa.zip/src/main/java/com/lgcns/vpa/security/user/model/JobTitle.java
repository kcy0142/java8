/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : JobTitle.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.security.user.model;

/**
 * <PRE>
 * JOB Title Model
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 10. 17.
 */
public class JobTitle {
	
	/**
	 * JOB TITLE Code
	 */
	private String jobTitleCode;
	
	/**
	 * JOB TITLE Name
	 */
	private String jobTitleName;
	
	/**
	 * JOB TITLE English Name
	 */
	private String jobTitleEnglishName;

	public JobTitle() {}
	
	public JobTitle(String jobTitleCode, String jobTitleName, String jobTitleEnglishName) {
		super();
		this.jobTitleCode = jobTitleCode;
		this.jobTitleName = jobTitleName;
		this.jobTitleEnglishName = jobTitleEnglishName;
	}

	public String getJobTitleCode() {
		return jobTitleCode;
	}

	public void setJobTitleCode(String jobTitleCode) {
		this.jobTitleCode = jobTitleCode;
	}

	public String getJobTitleName() {
		return jobTitleName;
	}

	public void setJobTitleName(String jobTitleName) {
		this.jobTitleName = jobTitleName;
	}

	public String getJobTitleEnglishName() {
		return jobTitleEnglishName;
	}

	public void setJobTitleEnglishName(String jobTitleEnglishName) {
		this.jobTitleEnglishName = jobTitleEnglishName;
	}
	
}
