/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : GroupSearchDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.model.InquiryVO;

/**
 * <PRE>
 * 조직 정보를 검색(LIKE 검색) 결과를 처리하는 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 18.
 */
@Component("GroupSearchDialog")
public class GroupSearchDialog extends LogicDialog {
	
	//private static final Logger LOG = LoggerFactory.getLogger(GroupSearchDialog.class);
	
	@Autowired
	private DialogConfig dialogConfig;
	
	@Override
	protected List<Attachment> getAttachment(InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet)
			throws Exception {
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        // 부서 정보가 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	        	attachment.setDescriptions("조회된 부서 정보가 없숩니다.");
	        }
	        else {
	        	
	        	/*
	        	1 GROUP_ID string 그룹ID 그룹ID 98906 
				2 GROUP_NAME string 그룹명 그룹명 정보전략팀   
				3 GROUP_ENGLISH_NAME string 그룹명문명 그룹명문명     Information Strategy Team 
				4 CORP_CODE string 법인코드 법인코드 LG01   
				5 CORP_NAME string 법인명 법인명 LG CNS   
				6 CORP_ENG_NAME string 법인영문명 법인영문명     LG CNS   
				7 GROUP_ALL_NAME string 그룹전체명 그룹전체명 CFO 정보전략팀   
				8 GROUP_ALL_ENG_NAME string 그룹전체영문명 그룹전체영문명     CFO Information Strategy Team 
				9 EMP_NO string 팀리더 사번 팀리더 사번 44051 
				10 USER_NAME string 팀리더 성명 팀리더 성명 김혜정 
				11 USER_ENGLISH_NAME string 팀리더 영문성명 팀리더 영문성명     HYE JOUNG KIM 
				12 JOB_TITLE string 팀리더 호칭 팀리더 호칭 부장 
				13 JOB_ENGLISH_TITLE string 팀리더 영문호칭 팀리더 영문호칭         
				14 OFFICE_PHONE_NO string 사무실 전화번호 사무실 전화번호 02-2099-1140 
				15 MOBILE string 휴대폰번호 휴대폰번호 010-2258-6089 
				16 MAIL string 이메일 이메일 
	        	*/
	        	
	        	String groupId = null;
	        	StringBuffer descriptions = new StringBuffer();
	        	String groupName = null, groupAllName = null, userName = null, jobTitle = null, officePhoneNo = null, mobile = null;
	        	
	        	//Group Blog Url 정보를 Properties 파닐에서 읽어온다.
	        	String groupBlogUrl = this.dialogConfig.getDialogInfo(inquiryData.getTenantId(), "url", "groupBlog");
	        	
	        	// 부서 항목 처리
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		
	        		descriptions.setLength(0);
	        		
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
	        			
	        			groupName = ( proxyResult.get("GROUP_NAME") != null ) ? String.valueOf(proxyResult.get("GROUP_NAME")) : "";
	        			groupAllName = ( proxyResult.get("GROUP_ALL_NAME") != null ) ? String.valueOf(proxyResult.get("GROUP_ALL_NAME")) : "";
	        			groupId = ( proxyResult.get("GROUP_ID") != null ) ? String.valueOf(proxyResult.get("GROUP_ID")) : "";
	        			
	        			userName = ( proxyResult.get("USER_NAME") != null ) ? String.valueOf(proxyResult.get("USER_NAME")) : "";
	        			jobTitle = ( proxyResult.get("JOB_TITLE") != null ) ? String.valueOf(proxyResult.get("JOB_TITLE")) : "";
	        			officePhoneNo = ( proxyResult.get("OFFICE_PHONE_NO") != null ) ? String.valueOf(proxyResult.get("OFFICE_PHONE_NO")) : "";
	        			mobile = ( proxyResult.get("MOBILE") != null ) ? String.valueOf(proxyResult.get("MOBILE")) : "";
	        			
	        			if ( !StringUtils.isEmpty(userName) ) {
	        				descriptions.append("Leader : ");
	                        descriptions.append(userName);
	                    }
	        			
	        			if ( !StringUtils.isEmpty(jobTitle) ) {
	        				if ( !StringUtils.isEmpty(userName) ) {
	        					descriptions.append(" ");
	        				}
	                        descriptions.append(jobTitle);
	                    }
	        			
	        			if ( !StringUtils.isEmpty(officePhoneNo) ) {
	        				if ( !StringUtils.isEmpty(userName) ) {
	        					descriptions.append(" | ");
	        				}
	                        descriptions.append(officePhoneNo);
	                    }
	        			
	        			if ( !StringUtils.isEmpty(mobile) ) {
	        				if ( !StringUtils.isEmpty(officePhoneNo) ) {
	        					descriptions.append(" / ");
	        				}
	                        descriptions.append(mobile);
	                    }
	        			
	        			Element element = new Element();
	        			element.setTitle(groupName);
	        			element.setText(groupAllName);
	        			element.setDescriptions(descriptions.toString());
	        			
	        			if ( !StringUtils.isEmpty(groupBlogUrl) && !StringUtils.isEmpty(groupId) ) {
		        			element.setAction(String.format(groupBlogUrl, groupId));
		        			element.setActionType(ActivityCode.ACTION_TYPE_LINK);
	        			}
	        			
	        			attachment.addElement(element);
	        		}
	        	}
	        }
	        
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}

}
