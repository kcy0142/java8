/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service;

import com.lgcns.vpa.channel.model.Event;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 사용자 이벤트 관리 Service
 * </pre>
 * @author
 */
public interface EventService {
    
    /**
     * 오늘의 이벤트 조회
     * @param botId
     * @param tenantId
     * @param user
     * @return
     */
    Event retrieveTodayEvent(String botId, String tenantId, User user);
}
