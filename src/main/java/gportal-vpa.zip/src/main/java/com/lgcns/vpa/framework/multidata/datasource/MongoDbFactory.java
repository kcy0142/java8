/* ------------------------------------------------------------------------------
 * Project       : NextEP Project
 * Source        : MultiMongoDbFactory.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.framework.multidata.datasource;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.authentication.UserCredentials;
import org.springframework.data.mongodb.core.MongoDbUtils;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.base.config.MongoConfig.MongoDataSourceProperty;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.framework.multidata.aspect.MultiDataSourceAspect;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;

/**
 * DataSourceKeyHolder에 설정된 key로 mongodb database명을 설정함
 * @author 70399
 *
 */
public class MongoDbFactory extends SimpleMongoDbFactory {
	private static final Logger LOG = LoggerFactory.getLogger(MongoDbFactory.class);
	
	@Autowired
	MongoDataSourceProperty mongoDataSourceProperty;
	
	private MongoClient mongoClient;
	private String defaultDatabaseName;
	
	public MongoDbFactory(MongoClient mongoClient, String databaseName) {
		super(mongoClient, databaseName);
		this.mongoClient = mongoClient;
		this.defaultDatabaseName = databaseName;
	}

	@Override
	public DB getDb() throws DataAccessException {
		
		String database = DataSourceKeyHolder.getDataSourceKey();
		
		if( StringUtils.isEmpty(database)) {
		    LOG.info("mongodb routing database is cleared...........................");
			database = defaultDatabaseName;
		}
		
		LOG.info(String.format("mongodb routing database name %s", database));
		
		UserCredentials credential;
		
		if( mongoDataSourceProperty.getMongodb().containsKey(database) ) {
			Map<Object, Object> account = mongoDataSourceProperty.getMongodb().get(database);
			credential = new UserCredentials((String)account.get("username"), (String)account.get("password"));
		} else {
			MongoCredential mongoCredential = mongoClient.getCredentialsList().get(0);
			credential = new UserCredentials(mongoCredential.getUserName(), String.valueOf(mongoCredential.getPassword()));
		}
		DB db = MongoDbUtils.getDB(mongoClient, database,credential, database); 

		return db;

	}
	
}
