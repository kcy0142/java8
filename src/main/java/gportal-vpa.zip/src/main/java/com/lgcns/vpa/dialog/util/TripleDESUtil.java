/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : TripleDESUtil.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
 
/**
 * <PRE>
 * test
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 6. 21.
 */
package com.lgcns.vpa.dialog.util;
 

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.springframework.util.StringUtils;


/**
 * 
 * <PRE>
 * Simple TripleDES Encrypt/Decrypt
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 6. 22.
 */
public class TripleDESUtil {


	/**
	 * 기본 암호화키(프락시에서 넘어온 키값 암/복호회)
	 */
	private static String defaultSecretKey="vpaSystem";
	
	  
  
	/**
	 * 
	 * 인코딩
	 *
	 * @param message 인코딩 대상,secretKey 암호화키
	 * @return String 인코딩값
	 */
	public static String encrypt(String message, String secretKey)  {
		if( StringUtils.isEmpty(secretKey)) {
			return message;
		}
		
		if( !StringUtils.hasText(message) ) {
			return message;
		}
		
		String base64EncryptedString =null;
		try {
			byte[] bytes = secretKey.getBytes();
			SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
			sr.setSeed(bytes);
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			kgen.init(128, sr);
			
			SecretKey skey = kgen.generateKey();
			SecretKeySpec skeySpec = new SecretKeySpec(skey.getEncoded(), "AES");
			Cipher c = Cipher.getInstance("AES");
			c.init(Cipher.ENCRYPT_MODE, skeySpec);
			
			byte[] encrypted = c.doFinal(message.getBytes("UTF-8"));
			base64EncryptedString=Hex.encodeHexString(encrypted);
		    
			//System.out.println("============== encrypt base64EncryptedString:"+base64EncryptedString);
		} catch (Exception e) {
            e.printStackTrace();
        }

	    return base64EncryptedString;
	}
	
	/**
	 * 
	 * 인코딩
	 *
	 * @param message 인코딩 대상
	 * @return String 인코딩값
	 */
	public static String encrypt(String message)  {
		return encrypt(message, defaultSecretKey);
	}

	/**
	 * 
	 * 디코딩
	 *
	 * @param encryptedText 대코딩 대상,secretKey 암호화키
	 * @return String 디코딩값
	 */
	public static String decrypt(String encryptedText, String secretKey) {
		if( StringUtils.isEmpty(secretKey)) {
			return encryptedText;
		}
		
		if( !StringUtils.hasText(encryptedText) ) {
			return encryptedText;
		}
		
		String decryptedText=null;
		try {
			byte[] bytes = secretKey.getBytes();
			SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
			sr.setSeed(bytes);
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			kgen.init(128, sr);
			
			SecretKey skey = kgen.generateKey();
			SecretKeySpec skeySpec = new SecretKeySpec(skey.getEncoded(), "AES");
			
			Cipher c = Cipher.getInstance("AES");
			c.init(Cipher.DECRYPT_MODE, skeySpec);
			byte[] decrypted = c.doFinal(Hex.decodeHex(encryptedText.toCharArray()));
			decryptedText= new String(decrypted,"UTF-8");
		} catch (Exception e) {
            e.printStackTrace();
        }
		return decryptedText;
	}
	
	/**
	 * 
	 * 디코딩
	 *
	 * @param encryptedText 대코딩 대상
	 * @return String 디코딩값
	 */
	public static String decrypt(String encryptedText) {
		return decrypt(encryptedText, defaultSecretKey);

	}
}