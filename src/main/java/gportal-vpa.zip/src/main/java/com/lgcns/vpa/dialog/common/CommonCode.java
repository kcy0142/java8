/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : CommonCode.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.common;

/**
 * <PRE>
 * Dialog Package에 사용되는 공통 코드 정의
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
public class CommonCode {
	
	/* Dialog Handler에서 사용되는  공통 코드 */
	public static final String 
		ACTIVITY_TYPE_MESSAGE 				= "message", 	/* 일반 질의 */
		ACTIVITY_TYPE_SEARCH 				= "seaarch", 	/* 검색 질의 */
		ACTIVITY_TYPE_TYPEAHEAD 			= "typeahead", 	/* 자동완성 질의 */
		ACTIVITY_TYPE_POLLING 				= "polling", 	/* POLLING MESSAGE */
		ACTIVITY_TYPE_GREETING 				= "greeting", 	/* LOGIN 시 환영 메세지 */
		ACTIVITY_TYPE_LGEFAQ 				= "lgefaq"; 	/* LGE FAQ */
	
	public static final String
		ACTIVITY_SUBTYPE_BASIC				= "message",	/* 일반 질의 */
		ACTIVITY_SUBTYPE_SEARCH				= "search",		/* 전체 검색 */
		ACTIVITY_SUBTYPE_USER				= "user",		/* 사용자 검색 */
		ACTIVITY_SUBTYPE_PROJECT			= "project",	/* 프로젝트 검색 */
		ACTIVITY_SUBTYPE_CHOICE				= "choice",		/* 리스트 결과 중 선택 */
		ACTIVITY_SUBTYPE_BUTTON				= "button";		/* 버튼 선택 */
	
	public static final int
		INQUIRY_STATE_INTENT_REQ 			= 1, /* 의도분석 요청 */
		INQUIRY_STATE_INTENT_ERR 			= 2, /* 의도분석 중 오류 발생 */ 
		INQUIRY_STATE_INTENT_NONE 			= 3, /* 의도분석 결과 의도 없음 */
		INQUIRY_STATE_INTENT_COMPLETE		= 4, /* 의도분석 의도 분석완료 다음 진행 */
		INQUIRY_STATE_INTENT_SLOT			= 5, /* 의도분석 결과 SLOT FILLING */
		INQUIRY_STATE_INTENT_DUPINT 		= 6, /* 의도분석 결과 의도가 중복됨 */
		INQUIRY_STATE_INTENT_DUPPARAM		= 7, /* 의도분석 결과 파라미터가 중복됨 */
		INQUIRY_STATE_INTENT_ACTIONEND		= 8, /* 의도분석 결과단순 질의로 Action 필요 없음 */
		INQUIRY_STATE_INTENT_ERR_CALL 		= 9, /* 의도분석 중 의도분석 서버연결 오류 발생 */ 
		INQUIRY_STATE_INTENT_ERR_SERVER		= 10,/* 의도분석 중 의도분석 서버처리 오류 발생 */
		INQUIRY_STATE_INTENT_SHORTWORD_ERR	= 11,/* 질의어의 길이가 너무 짦아서 의도분석을 할 수 없음*/
		INQUIRY_STATE_INTENT_PARAM_ERR		= 12,/* 의도분석 중 파라미터 변환 관련 에러*/
		INQUIRY_STATE_INTENT_MULTI			= 13;/* 의도분석 중 결과로 MULTI Intent 발생*/
	
	public static final int
		INQUIRY_STATE_ACTION_REQ			= 21, /* Action 정보 조회요청 */
		INQUIRY_STATE_ACTION_ERR			= 22, /* Action 정보 요청 중 오류 발생 */
		INQUIRY_STATE_ACTION_NONE			= 23, /* Action 정보 없음 */
		INQUIRY_STATE_ACTION_COMPLETE		= 24; /* Action 정보 조회 완료 */
	
	public static final int
		INQUIRY_STATE_BNP_REQ				= 31, /* BACKEND PROXY 정보 조회/처리 요청 */
		INQUIRY_STATE_BNP_ERR				= 32, /* BACKEND PROXY 정보 조회/처리 중 오류 발생 */
		INQUIRY_STATE_BNP_NONE				= 33, /* BACKEND PROXY 정보 조회/처리 요청 중 결과 없음 */
		INQUIRY_STATE_BNP_COMOLETE			= 34; /* BACKEND PROXY 정보 조회/처리 완료 */
	
	public static final String
		ACTION_RESULT_ERROR					= "ERROR", /* BACKEND PROXY 정보조회 시 오류 발생 */
		ACTION_RESULT_NONE					= "NONE",  /* BACKEND PROXY 정보조회 결과 없음 */
		ACTION_PARAM_INVALID				= "INVALID_PARAM", 	/* 파라미터 매핑 오류 */
		ACTION_NONE_RIGHT					= "NONE_RIGHT", 	/* 권한 없음 */
		ACTION_URI_NONE						= "NONE_URI";		/* Proxy에 질의할 필요없이 Template 정보만으로 응답 생성*/
	
	public static final String 	
		ELEMENT_TYPE 						= "type",
		ELEMENT_TITLE 						= "title",
		ELEMENT_SUBTITLE 					= "subtitle",
		ELEMENT_DESCRIPTION 				= "descriptions",
		ELEMENT_TEXT 						= "text",
		ELEMENT_AMOUNT 						= "amount",
		ELEMENT_VALUE 						= "value",
		ELEMENT_CLASSNAMES					= "classNames",
		ELEMENT_UNIT 						= "unit",
		ELEMENT_IMAGEURL 					= "imageUrl",
		ELEMENT_ACTION						= "action",
		ELEMENT_ACTION_PARAMS				= "actionParams",
		ELEMENT_ACTION_TYPE					= "actionType",
		ELEMENT_ID							= "id",
		ELEMENT_ADDITIONAL					= "additionalProperties",
		ELEMENT_POPUPWIDTH					= "popupWidth",
		ELEMENT_POPUPHEIGHT					= "popupHeight";

	public static final int 	
		SINGLE_ELEMENT_INROW				= 1,
		MULTI_ELEMENT_INROW					= 2;

	public final static String
		ELEMENT_TYPE_TEXT 					= "text",
		ELEMENT_TYPE_PLANNER 				= "planner",
		ELEMENT_TYPE_PEOPLE 				= "people";
	
	public final static String
		INTENT_BUTTON_TYPE_LINK				= "link",
		INTENT_BUTTON_TYPE_INQUIRY			= "inquiry",
		INTENT_BUTTON_TYPE_FUNCTION			= "function",
		INTENT_BUTTON_TYPE_CALL				= "Call";
	
	public final static String
		BUTTON_TYPE_FEEDBACK				= "feedback",
		BUTTON_TYPE_HELP					= "help",
		BUTTON_TYPE_SEARCH					= "search",
		BUTTON_TYPE_AUTORUN					= "autorun",
		BUTTON_LIKE_ACTION					= "like",
		BUTTON_DISLIKE_ACTION				= "dislike";
	
	public final static String
		INQUIRY_TYPE_SLOTFILLING			= "slot",
		INQUIRY_TYPE_MULTIPARAM				= "dupparam",
		INQUIRY_TYPE_GENERAL				= "general",
		INQUIRY_TYPE_AUTO_SUGGFEST			= "autosuggest";
	
	public final static String
		PREINQUERY_INTENT_ONLYONE			= "ONLY_ONE_CONTEXT";
	
	public final static String
	    SUBTYPE_STOPWORD					= "stop",
	    SUBTYPE_PREINTENT					= "pre";
}
