/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : UserServiceImpl.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.entity;


import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.io.Resource;
import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.framework.multidata.annotation.MultiDataSource;
import com.lgcns.vpa.intent.exception.IntentException;
import com.lgcns.vpa.intent.model.Entity;
import com.lgcns.vpa.intent.translator.TranslateScriptEngine;

import jdk.nashorn.api.scripting.ScriptObjectMirror;
import jdk.nashorn.internal.runtime.Undefined;


/**
 * <pre>
 * redis에 캐슁된 사용자 정보를 검색한다.
 * 이름으로 개체명 사전에 저장된 userid를 검색, 검색된 userId의 사용자 정보를 리턴한다.
 * </pre>
 * @author 최환준
 * @see ${basedir}/main/resources/mapper/datatrans.js
 */
@SuppressWarnings("restriction")
@Component("dictionary")
public class EntityDictionary {
	
	private static final Logger LOG = LoggerFactory.getLogger(EntityDictionary.class);
	
	//private ScriptEngine engine;
	
	/**
	 * redistemplate
	 */
	@Autowired
	RedisTemplate redisTemplate;
	
	@Autowired
	TranslateScriptEngine engine;
	
	public EntityDictionary() {
/*		engine = new ScriptEngineManager().getEngineByName("nashorn");
		
		try {
			engine.eval(new InputStreamReader(resource.getInputStream()));
		} catch (Exception e) {
			LOG.error("translator script is null " + resource.getDescription());
			e.printStackTrace();
			throw new IllegalStateException();
		}
*/	}

	@SuppressWarnings("unchecked")
	public Map<String, Object> findUser(String tenantId, String userId) {
		return redisTemplate.opsForHash().entries(UserContracts.getKey(tenantId, userId));
	}
	
	/**
	 * 
	 * @param tenantId
	 * @param params username, deptname, title, session team
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> findUsers(String tenantId, String sGroupCode, String ... params) {
			
		//부서명이 없으면
		SetOperations<String, String> setOper = redisTemplate.opsForSet();
		HashOperations<String, String, Object> hasOper = redisTemplate.opsForHash();
		
		List<Map<String, Object>> userList;
		Set<String> userIds;
		final String groupId;
		final String groupName;
		Map<String, Object> groupInfo;
		int type = UserContracts.getType(params);
		LOG.info(String.format("**find user params : %s  type : %d", Arrays.toString(params), type));
		
		String title;
		switch(type) {
		
		case UserContracts.USER_NAME : //사용자 이름
			userIds = setOper.members(UserContracts.getSynonymKey(tenantId, params[0]));
			userList = getUserList(tenantId, userIds);
			break;
			
		case UserContracts.DEPT : //조직명이 왔을 때는 팀의 리더
			groupId = findGroupCode(tenantId, params[1], sGroupCode);
			groupInfo = hasOper.entries(GroupContracts.getKey(tenantId, groupId));
			userList = new ArrayList<>();
			userList.add(hasOper.entries(UserContracts.getKey(tenantId, groupInfo.get(GroupContracts.Columns.GROUP_LEADER))));
			break;
			
		case UserContracts.USER_NAME_DEPT : //사용자 부서경로가 입력된 부서를 포함하는 지 확인
			
			groupName = findGroupName(tenantId, params[1], sGroupCode);
			
			if(StringUtils.isEmpty(groupName)) {
				userList = new ArrayList<>();
				break;
			}
			userIds = setOper.members(UserContracts.getSynonymKey(tenantId, params[0]));
			userList = getUserList(tenantId, userIds).stream().filter(new Predicate<Map<String, Object>>() {
				@Override
				public boolean test(Map<String, Object> userInfo) {
					
					//사용자 정보의 그룹경로내 입력된 그룹이 존재하는 지 확인한다.
					String ugroup = (String)userInfo.get(GroupContracts.Columns.GROUP_FULL_NAME);
					
					if( StringUtils.hasText(ugroup) && ugroup.contains(groupName)) {
						return true;
					} else {
						return false;
					}
					
				}
			}).collect(Collectors.toList());
			
			break;
			
		case UserContracts.USER_NAME_TITLE : //사용자 이름의 임직원 TITLE비교
			//TODO TITLE도 사전으로 정의
			userIds = setOper.members(UserContracts.getSynonymKey(tenantId, params[0]));
			//동의어가 있는 지 비교
			title = (String)hasOper.get(EntityContracts.getSynonymKey(tenantId, null, "J"), params[2]);
			
			//동의어가 있다면 동의어로 치환
			if( !StringUtils.isEmpty(title) ) {
				params[2] = title;
			}
			
			userList = getUserList(tenantId, userIds).stream().filter(new Predicate<Map<String, Object>>(){
				@Override
				public boolean test(Map<String, Object> userInfo) {
					String title = (String)userInfo.get(UserContracts.Columns.USER_TITLE);
					if( Pattern.matches("\\d+", params[2]) ) {
						return params[2].equals(userInfo.get(UserContracts.Columns.LEADER).toString());
						//return !userInfo.get(UserContracts.Columns.LEADER).equals("0");
					} else {
						return StringUtils.isEmpty(title) || equalsTitle(title, params[2]);
					}
				}
			}).collect(Collectors.toList());
			break;
			
		case UserContracts.USER_NAME_DEPT_TITLE :
			
			groupName = findGroupName(tenantId, params[1], sGroupCode);
			
			if( StringUtils.isEmpty(groupName) ) {
				userList = new ArrayList<>();
				break;
			}
			userIds = setOper.members(UserContracts.getSynonymKey(tenantId, params[0]));
			
			title = (String)hasOper.get(EntityContracts.getSynonymKey(tenantId, null, "J"), params[2]);
			
			//직급이 숫자인 경우는 level
			if( !StringUtils.isEmpty(title) ) {
				params[2] = title;
			}
			
			userList = getUserList(tenantId, userIds).stream().filter(new Predicate<Map<String, Object>>() {
				@Override
				public boolean test(Map<String, Object> userInfo) {
					String ugroup = (String)userInfo.get(GroupContracts.Columns.GROUP_FULL_NAME);
					
					if( ugroup.contains(groupName)) {
						if( Pattern.matches("\\d+", params[2]) ) {
							return params[2].equals(userInfo.get(UserContracts.Columns.LEADER).toString());
							//return !userInfo.get(UserContracts.Columns.LEADER).equals("0");

						} else {
							String title = (String)userInfo.get(UserContracts.Columns.USER_TITLE);
							return StringUtils.isEmpty(title) || equalsTitle(title, params[2]);
						}
					} else {
						return false;
					}
				}
			}).collect(Collectors.toList());
			
			break;
			
		case UserContracts.DEPT_TITLE : //입력 조직의 상위 조직 title은 무시하고, 팀명과 title이 오면 팀장을 찾아줌.. 
			userList = new ArrayList<>();
			//TODO TITLE도 사전으로 정의. 내용에는 레벨을 포함하도록 함. 
			groupId = findGroupCode(tenantId, params[1], sGroupCode);
			
			if( StringUtils.isEmpty(groupId) ) {
				break;
			}
			groupInfo = hasOper.entries(GroupContracts.getKey(tenantId, groupId));

			//직급 유사어 사전을 뒤진다.
			title = (String)hasOper.get(EntityContracts.getKey(tenantId, null, "J"), params[2]);
			if( !StringUtils.isEmpty(title) ) {
				params[2] = title;
			}

			Object groupLevel = groupInfo.get(GroupContracts.Columns.GROUP_LEVEL);
			Object leader 	  = groupInfo.get(GroupContracts.Columns.GROUP_LEADER);

			//level이면, 그룹의 level과 동일하면 그룹의 리더를 리턴
			if( Pattern.matches("\\d+", params[2]) ) {
				//if( params[2].equals("" + groupLevel) ) {
				userList.add(hasOper.entries(UserContracts.getKey(tenantId, leader)));
				//}
			} else {
				Map<String, Object> userInfo = hasOper.entries(UserContracts.getKey(tenantId, leader));
				if( userInfo != null ) {
					title = (String)userInfo.get(UserContracts.Columns.USER_TITLE);
					if( equalsTitle(title, params[2])) {
						userList.add(hasOper.entries(UserContracts.getKey(tenantId, leader)));
					}
				}
			}
						
			break;
			
		case UserContracts.TITLE :
			//TODO 사람이 입력한 타이틀로 개체명 사전에 타이틀과 비교할 수 있을 까?
			//예를 들어 담당님  --> 부장
			
			//직급 유사어 사전을 뒤진다.
			title = (String)hasOper.get(EntityContracts.getKey(tenantId, null, "J"), params[2]);
			if( !StringUtils.isEmpty(title) ) {
				params[2] = title;
			}
			
			//직급에 사번이 매핑된 경우가 존재할 수 있음. CEO, CHO, CFO 등
			userList = new ArrayList<>();
			Map<String, Object> user = findUser(tenantId, params[2]);
			
			if(  (user == null) || (user.isEmpty()) ) {
				user = findApprovalUser(tenantId, sGroupCode, params[2]);
			}
			
			if( user != null ) {
				userList.add(user);
			}
			
			break;
			
		default :
			return Collections.EMPTY_LIST;
		}
		
		Collections.sort(userList, new UserComparator());
		return userList;
	}
	
	/**
	 * 결재 라인에서 직급으로 사용자를 찾는 재귀함수
	 * @param tenantId
	 * @param groupId
	 * @param title
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String, Object> findApprovalUser(String tenantId, String groupId, String title) {
		
		HashOperations<String, String, Object> hasOper = redisTemplate.opsForHash();
		Map<String, Object> groupInfo = hasOper.entries(GroupContracts.getKey(tenantId, groupId));
		
		if( groupInfo == null ) {
			return null;
		}
		
		Object leader = groupInfo.get(GroupContracts.Columns.GROUP_LEADER);
		if( StringUtils.isEmpty(leader)) {
			return null;
		}
		Map<String, Object> userInfo = hasOper.entries(UserContracts.getKey(tenantId, leader));
		if( equalsTitle(title,(String)userInfo.get(UserContracts.Columns.USER_TITLE))) {
			return userInfo;
		} else if( Pattern.matches("\\d+", title)){
			int compare = title.compareTo(groupInfo.get("groupLevel").toString());
			if( compare < 2 ) {//같으면, 팀인 경우 3, 4레벨임..
				return userInfo;
			}
		}
		String parent = (String)groupInfo.get(GroupContracts.Columns.PARENT_GROUP_ID);
		if( StringUtils.isEmpty(parent) || parent.equals(groupId)) {
			return null;
		}
		
		return findApprovalUser(tenantId, parent, title);
	}
	
	@SuppressWarnings("unchecked")
	private List<Map<String, Object>> getUserList(String tenantId, Set<String> userIds) {
		
		if( userIds == null || userIds.isEmpty() ) {
			return Collections.EMPTY_LIST;
		}
		
		HashOperations<String, String, Object> userHashOper = redisTemplate.opsForHash();
		List<Map<String, Object>> userList = new ArrayList<>();
		for( String userId : userIds ) {
			userList.add(userHashOper.entries(UserContracts.getKey(tenantId, userId)));
		}
		return userList;
	}
	
	/**
	 * 조직명으로 조직 코드를 반환한다.
	 * @param tenantId
	 * @param groupName
	 * @return
	 */
	public String findGroupCode(String tenantId, String groupName, String sGroupCode) {
		
		if( StringUtils.isEmpty(groupName) ) {
			return null;
		}
		
		HashOperations<String, String, String> hasOp = redisTemplate.opsForHash();
		
		String groupCode = (String)hasOp.get(GroupContracts.getSynonymKey(tenantId), groupName);
		if( StringUtils.hasText(groupCode) && groupCode.startsWith("$SESSION") ) {
			groupCode = sGroupCode;
		}
		
		return groupCode;
	}
	
	/**
	 * 
	 * @param tenantId
	 * @param groupName
	 * @param sGroupCode
	 * @return
	 */
	public String findGroupName(String tenantId, String groupName, String sGroupCode) {
		
		if( StringUtils.isEmpty(groupName) ) {
			return null;
		}
		
		HashOperations<String, String, String> hasOp = redisTemplate.opsForHash();

		String groupCode = (String)hasOp.get(GroupContracts.getSynonymKey(tenantId), groupName);
		if( StringUtils.isEmpty(groupCode ) ) {
			return null;
		} else {
			if( groupCode.startsWith("$SESSION") ) {
				return hasOp.get(GroupContracts.getKey(tenantId, sGroupCode), GroupContracts.Columns.GROUP_NAME);
			} else {
				return hasOp.get(GroupContracts.getKey(tenantId, groupCode), GroupContracts.Columns.GROUP_NAME);
			}
		}
	}
	
	/**
	 * 입력된 그룹의 그룹 정보를 반환한다.
	 * @param tenantId
	 * @param groupName
	 * @param sGroupName  groupName으로 동의어 사전을 뒤졌을 때, session인 경우, 세션의 그룹이름을 사용
	 * @return
	 */
	public Map<String, Object> findGroup(String tenantId, String groupName, String sGroupName) {
		if( StringUtils.isEmpty(groupName) ) {
			return null;
		}
		
		HashOperations<String, String, Object> hasOper = redisTemplate.opsForHash();
		
		String groupCode = (String)hasOper.get(GroupContracts.getSynonymKey(tenantId), groupName);
		
		//그룹 코드가 있다면. 그룹 코드의 그룹 정보를 리턴하고, 
		//없으면, 사용자 입력값을 그대로 리턴한다.
		Map<String, Object> groupInfo;
		if( StringUtils.hasText(groupCode) ) {
			if( groupCode.startsWith("$SESSION")) {
				groupCode = (String)hasOper.get(GroupContracts.getSynonymKey(tenantId), sGroupName.toLowerCase());
				groupName = sGroupName;
			}
			groupInfo = hasOper.entries(GroupContracts.getKey(tenantId, groupCode));
			groupInfo.put("text", groupName);
		} else {
			groupInfo = new HashMap<>();
			groupInfo.put("value", groupCode);
			groupInfo.put("text", groupName);
		}
		return groupInfo;
	}
	
	public Map<String, Object> findEntity(String tenantId, String botId, String entity, String input) throws Exception {
		return findEntity(tenantId, botId, entity, input, null);
	}
	
	/**
	 * 사용자 입력값인 entity를 치환한다.
	 * 1. 정규표현식이 없는 경우, 동의어사전으로 
	 * 2. 정규표현식이 있는 경우, 정규표현식 처리
	 * 3. 정규표현식 처리결과 동의어 사전으로 갈경우, 동의어 처리
	 * 
	 * 기타 파라미터가 필요한 경우가 있어 파라미터를 받는다.
	 * 예를 들어, 내일 오전 1시 인 경우, 내일의 Date 파라미터로 받는다.
	 * @param tenantId
	 * @param botId
	 * @param entity
	 * @param input	사용자 입력값
	 * @param param	인자값
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "restriction" })
	public Map<String, Object> findEntity(String tenantId, String botId, String entity, String input, Object param) 
			throws Exception {
		
		if( !StringUtils.hasText(input) ) {
			return null;
		}
		HashOperations<String, String, Object> hasOp = redisTemplate.opsForHash();
		
		//정규식이 있다면 먼저 수행한다.
		String exp = (String)hasOp.get(
				entityKey(tenantId, botId, entity), 
				EntityContracts.Columns.PHRASE_REXP);
		
		Map<String, Object> map = new HashMap<String, Object>();
		if( !StringUtils.hasText(exp) ) {
			Object synonym = synonym(tenantId, botId, entity, input, param, null);
			
			if( synonym instanceof Map ) {
				map.putAll((Map)synonym);
			} else {
				map.put("value", synonym);
			}
			
			map.put("text", input);
			return map;
		}
		//정규식을 수행한 결과
		Object obj = engine.evalFunction(String.format("function %s(input, param){ %s }", entity, exp), entity, input, param);
		
/*		Invocable invocable = (Invocable) engine;
        Object obj = invocable.invokeFunction(entity, input, param);
*/        if( obj instanceof ScriptObjectMirror) {
        	ScriptObjectMirror scriptObj = (ScriptObjectMirror)obj;
        	
        	//동의어사전을 돌릴 값.
        	Object name = scriptObj.getMember(entity);
        	if( name instanceof Undefined ) {//동의어 사전을 돌리지 않아도 된다면. 그대로 반환
        		for( Entry<String, Object> members : scriptObj.entrySet() ) {
        			map.put(members.getKey(), members.getValue());
        		}
        	} else {
        		Object data  = scriptObj.getMember("data");
        		Object synonym = synonym(tenantId, botId, entity, name, param, data);
        		if( synonym instanceof Map ) {
					map.putAll((Map)synonym);
				} else {
					map.put("value", synonym);
				}
        	}
        	map.put("text", input);
        	return map;
        } else {
        	map.put("value", obj);
        	map.put("text", input);
        	return map;
        }

	}
	
	/**
	 * 동의어 사전을 찾고, 만약 동의어 사전에 정의된 낱말이 스크립트 형이면 ..
	 * 즉, 스크립트 참조를 가지고 있다면, 스크립트를 수행시킨다.
	 * @param tenantId
	 * @param botId
	 * @param entity
	 * @param name
	 * @param param findEntity에서 넘겨받은 값
	 * @param data  findEntity처리 결과 값
	 * @return
	 * @throws ScriptException
	 * @throws NoSuchMethodException
	 */
	@SuppressWarnings({ "unchecked" })
	private Object synonym(String tenantId, String botId, String entity, Object name, Object param, Object data) 
			throws ScriptException, NoSuchMethodException {

		HashOperations<String, String, Object> hasOp = redisTemplate.opsForHash(); 
		String key = entityKey(tenantId, botId, entity);
		String val = (String)hasOp.get(key, name);
		
		if( StringUtils.isEmpty(val) ) {//치환 값이 없으면, 입력값으로 대체
			return name;
		} 
		if ( !EntityContracts.isScriptRef(val)) {//치환값이 상수이면 
			return val;
		} //치환값이 스크립트이면,
    	String script = (String)hasOp.get(key, val);
    	
    	if( StringUtils.isEmpty(script)) {
    		return val;
    	} 
		Object obj = engine.evalFunction(String.format("function %s(data, param){ %s }", entity, script), entity, data, param);
		//Invocable invocable = (Invocable) engine;
        //Object obj = invocable.invokeFunction(entity, data, param);
        if( obj instanceof ScriptObjectMirror) {
        	ScriptObjectMirror scriptObj = (ScriptObjectMirror)obj;
        	Map<String, Object> map = new HashMap<String, Object>();
    		for( String member : scriptObj.keySet()) {
    			map.put(member, scriptObj.get(member));
    		}
    		return map;
        } else {
        	return obj;
        }
	}	
	
	@SuppressWarnings("unchecked")
	public String entityKey(String tenantId, String botId, String entity) {
		
		String key = EntityContracts.getKey(tenantId, botId, entity);
		if( !redisTemplate.hasKey(key) ) {
			key = EntityContracts.getKey(tenantId, null, entity);
		}
		
		return key;
	}
	
	/**
	 * TODO get entity type from entityName ex) FROM_DATE ==> DATE
	 * @param entityName
	 * @return
	 */
	public String getEntityType(String entityName) {
		return entityName;
	}
	
	private boolean equalsTitle(String src, String tgt) {
		if( src == null || tgt == null ) {
			return false;
		}
		
		boolean equals = src.replaceAll("\\s+", "").equalsIgnoreCase(tgt.replaceAll("\\s+", ""));
		
		if( !equals ) {
			return src.startsWith(tgt);
		} else {
			return equals;
		}
	}
	
	public interface UserContracts {
		/**
		 * 이름 hash key --> 사번 set
		 */
		public static final String DIC_USER_SYN_KEY = "%s:dictionary:entity:user:name:%s";
		
		
		/**
		 * 사번 key --> 상세
		 */
		public static final String DIC_USER_KEY = "%s:dictionary:entity:user:%s";
		
		public static Collection<String> SELECTION = Arrays.asList(new String[]{Columns.USER_ID, Columns.USER_NAME, Columns.MAIL, GroupContracts.Columns.GROUP_ID});

		//bit수.. name:dept:title:mail
		public static final int USER_NAME 		= 1;
		
		public static final int DEPT			= 2;
		
		public static final int USER_NAME_DEPT 	= 3;
		
		public static final int TITLE 			= 4;
		
		public static final int USER_NAME_TITLE = 5;
		
		public static final int USER_NAME_DEPT_TITLE = 7;
		
		public static final int DEPT_TITLE 		= 6;
		
		public static final int USER_NAME_TITLE_MAIL = 15;
		
		public static int getType(String...params) {
			int type = 0;
			for( int i = 0; i < params.length; i++ ) {
				if( StringUtils.hasText(params[i]))
					type += 1<<i;
			}
			return type;
		}
		public static String getSynonymKey(String tenantId, Object name ) {
			return String.format(DIC_USER_SYN_KEY,tenantId, name);
		}
		
		public static String getKey(String tenantId, Object id) {
			return String.format(DIC_USER_KEY, tenantId, id);
		}
		
		public interface Columns {
			public static final String USER_ID 		= "id";		
			public static final String EMP_NO 		= "empNo";
			public static final String USER_NAME 	= "name";			
			public static final String MAIL 		= "mail";			
			public static final String USER_TITLE 	= "title";			
			public static final String TITLE_SORT_ORDER = "titleSortOrder";			
			public static final String MOBILE 		= "mobile";			
			public static final String OFFICE_PHONE_NO = "officePhoneNo";	
			public static final String LEADER		= "leader";
			public static final String USER_TYPE 	= "userType";			
			public static final String USER_STATUS 	= "userStatus";			
			public static final String CORP_CODE 	= "corpCode";			
			public static final String CORP_NAME 	= "corpName";
			public static final String TITLE_NM_EP 	= "titleNmEp";
			
		}
	}
	
	public interface GroupContracts {
		
		/**
		 * 이름 hash key --> 조직 set
		 */ 
		public static final String DIC_DEPT_SYN_KEY = "%s:dictionary:entity:O";
		
		/**
		 * 조직 코드 key --> 상세 (리더, 상위조직)
		 */ 
		public static final String DIC_DEPT_KEY = "%s:dictionary:entity:O:%s";
		
		public static Collection<String> SELECTION = Arrays.asList(new String[]{Columns.GROUP_ID, Columns.GROUP_NAME, Columns.GROUP_LEVEL, Columns.PARENT_GROUP_ID, Columns.GROUP_PATH, Columns.GROUP_LEADER});
		
		public static String getSynonymKey(String tenantId) {
			return String.format(DIC_DEPT_SYN_KEY,tenantId);
		}
		
		public static String getKey(String tenantId, String id) {
			return String.format(DIC_DEPT_KEY, tenantId, id);
		}
		public interface Columns {
			public static final String GROUP_ID = "groupId";
			public static final String GROUP_NAME = "groupName";
			public static final String GROUP_FULL_NAME = "groupFullName";
			public static final String GROUP_LEVEL = "groupLevel";
			public static final String PARENT_GROUP_ID = "parentGroupId";
			public static final String GROUP_PATH = "groupPath";
			public static final String GROUP_LEADER = "groupLeader";
		}
	}
	
	public interface EntityContracts {
		
		
		/**
		 * 정규식 / 유사어
		 */ 
		public static final String DIC_ENTITY_SYN_KEY = "%s:dictionary:entity:%s";
		
		/**
		 * 처리규칙
		 */ 
		public static final String DIC_ENTITY_KEY = "%s:dictionary:entity:%s";
		
		/**
		 * 동의어 스크립트 키 패턴
		 */
		public static final Pattern SYN_SCRIPT_KEY = Pattern.compile("SY\\d+$");
		
		public static String getSynonymKey(String tenantId, String botId, String entity) {
			return String.format(DIC_ENTITY_SYN_KEY,tenantId, StringUtils.isEmpty(botId)? entity: botId + ":" + entity);
		}
		
		public static String getKey(String tenantId, String botId, String id) {
			return String.format(DIC_ENTITY_KEY, tenantId, StringUtils.isEmpty(botId)? id: botId + ":" + id);
		}
		
		public static boolean isScriptRef(String value) {
			Matcher matcher = SYN_SCRIPT_KEY.matcher(value);
			return matcher.matches();
		}
		public interface Columns {
			public static final String PHRASE_REXP = "rexp";
		}
		
		public interface ReservedEntity {
			public static final String PERSON 		 = "P";
			public static final String ORGANIZATION  = "O";
			public static final String DATE 		 = "D";
			public static final String DATETIME		 = "DT";
			public static final String LOCATION      = "L";
			public static final String TITLE     	 = "J";
			public static final String MAIL 		 = "MA";
			public static final String KEYWORD       = "KE";
			public static final String SESSION 		 = "SESSION";
		}
	}
	
	public class UserComparator implements Comparator<Map<String, Object>> {
		private final int ORDER = 1;
		private final String I = "I";//정직원
		private final String E = "E";//촉탁
		private final String O = "O";//협력업체
		
		/**
		 * 직급정렬 코드가 낮은 게 먼저 나와야 함
		 */
		@Override
		public int compare(Map<String, Object> o1, Map<String, Object> o2) {
			/**
			 * 회사 (소속사 우선)
			   이름 ( 가나다 순 )
			   직급 
			   팀 ( 가나다 순 )
			   사번
			 */
			int corp = ((String)o1.getOrDefault(UserContracts.Columns.CORP_CODE ,"ZZZZ")).compareToIgnoreCase(
					(String)o2.getOrDefault(UserContracts.Columns.CORP_CODE ,"ZZZZ"));
			
			if( corp != 0 ) {
				return corp * ORDER;
			}
			
			int type = toType((String)o1.get(UserContracts.Columns.USER_TYPE)) - 
					toType((String)o2.get(UserContracts.Columns.USER_TYPE));
			
			if( type != 0 ) {
				return type * ORDER;
			}
			
			int name = ((String)o1.getOrDefault(UserContracts.Columns.USER_NAME ,"ZZZZ")).compareToIgnoreCase(
					(String)o2.getOrDefault(UserContracts.Columns.USER_NAME ,"ZZZZ"));
			
			if( name != 0 ) {
				return name * ORDER;
			}
			
			int title = toInt(o2.get(UserContracts.Columns.TITLE_SORT_ORDER)) - 
					toInt(o1.get(UserContracts.Columns.TITLE_SORT_ORDER));
			
			if( title != 0 ) {
				return title * ORDER;
			}
			
			int group = ((String)o1.getOrDefault(GroupContracts.Columns.GROUP_FULL_NAME ,"ZZZZ")).compareToIgnoreCase(
					(String)o2.getOrDefault(GroupContracts.Columns.GROUP_FULL_NAME ,"ZZZZ"));
			
			if( group != 0 ) {
				return group * ORDER;
			}
			
			int empNo = ((String)o1.getOrDefault(UserContracts.Columns.USER_ID ,"ZZZZ")).compareToIgnoreCase(
					(String)o2.getOrDefault(UserContracts.Columns.USER_ID ,"ZZZZ"));
			
			return empNo * ORDER;
		}
		
		int toInt(Object obj) {
			if( obj instanceof Integer ) {
				return (Integer)obj;
			} 
			
			if( obj instanceof String ) {
				try {
					return Integer.parseInt((String)obj);
				}catch(NumberFormatException e) {
					return Integer.MAX_VALUE;
				}
			}
			
			return Integer.MAX_VALUE;
		}
		
		int toType(String userType) {
			if ( userType == null ) {
				return 3;
			}
			
			switch(userType) {
			case I : 
				return 0;
			case O : 
				return 1;
			case E : 
				return 2;
			}
			
			return 3;
		}
		
	}
	private static final int SCAN_COUNT = 10;

	public class KeyScanRedisCallback implements RedisCallback<List<String>> {
		
		private String keyPattern;
		public KeyScanRedisCallback(String keyPattern) {
			this.keyPattern = keyPattern;
		}
		@Override
		public List<String> doInRedis(RedisConnection connection) throws DataAccessException {
			
			StringRedisSerializer serializer = new StringRedisSerializer();
			
			ScanOptions options = ScanOptions.scanOptions().match(keyPattern).count(SCAN_COUNT).build();

			List<String> list = new ArrayList<String>();
			Cursor<byte[]> c = connection.scan(options);
			try {
			  
				while (c.hasNext()) {
					list.add(serializer.deserialize(c.next()));
				}
			} catch (NoSuchElementException nse) {
				nse.printStackTrace();
			}
			return list;
		}
	}
	
	public class SScanRedisCallback implements RedisCallback<List<String>> {
		private String pattern;
		
		public SScanRedisCallback(String pattern) {
			this.pattern = pattern;
		}
		@Override
		public List<String> doInRedis(RedisConnection connection) throws DataAccessException {
			return null;
		}
	}
}
