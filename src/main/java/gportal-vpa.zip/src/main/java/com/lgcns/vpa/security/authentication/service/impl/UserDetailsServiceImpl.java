package com.lgcns.vpa.security.authentication.service.impl;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.lgcns.vpa.security.authentication.dao.AuthenticationDao;
import com.lgcns.vpa.security.authentication.model.UserDetailsImpl;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 사용자 인증 정보 조회
 * </pre>
 * @author
 */
@Service("multi.userDetailsService")
public class UserDetailsServiceImpl implements UserDetailsService {
	   
    @Autowired
	Environment env;
    
    @Autowired
    private AuthenticationDao authenticationDao;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = authenticationDao.selectUserDetails(username);
        
        if (user == null) {
            throw new UsernameNotFoundException(String.format("No user found with username '%s'.", username));
        } else {
            // 테넌트 ID 추출
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            String tenantId = env.getProperty(request.getServerName());
            
            if (StringUtils.isEmpty(tenantId)) tenantId = "lgcns";
            
        	user.setTenantId(tenantId);
        	
            // List<GrantedAuthority> grantedAuths = new ArrayList<>();
            // grantedAuths.add(new SimpleGrantedAuthority("ROLE_" + user.getType()));
            return new UserDetailsImpl(user, Arrays.asList(new SimpleGrantedAuthority("ROLE_USER")), tenantId);
        }
    }
}
