package com.lgcns.vpa.security.authentication.dao;

import com.lgcns.vpa.security.user.model.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * <pre>
 * 사용자 인증 정보 조회 Dao
 * </pre>
 * @author
 */
@Mapper
@Repository
public interface AuthenticationDao {
    
    /**
     * 사용자 정보 조회
     * @param userId
     * @return
     */
    User selectUserDetails(String userId);
    
    /**
     * 인가 가능한 IP 주소 조회 (테스트 기간동안 사용)
     * @param ipaddress
     * @return
     */
    String selectIpaddress(@Param("ipaddress") String ipaddress);
}