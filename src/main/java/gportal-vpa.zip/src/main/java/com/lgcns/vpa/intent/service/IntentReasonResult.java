/* ------------------------------------------------------------------------------
 * Project       : NextEP Project
 * Source        : IntentResult.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.service;

/**
 * R&D 의도api 응답 결과 binding bean
 * @author 70399
 *
 * @param <T>
 */
public class IntentReasonResult {
	private boolean result;
	
	private ReasonData data;
	
	public void setResult(boolean result) {
		this.result = result;
	}
	
	public boolean getResult() {
		return this.result;
	}
	
	public void setData(ReasonData data) {
		this.data = data;
	}
	
	public ReasonData getData() {
		return this.data;
	}
	
	public String toString() {
		return " result : " + this.result + " data : " + this.data;
	}
}
