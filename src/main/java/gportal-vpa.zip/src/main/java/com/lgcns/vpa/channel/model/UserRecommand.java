/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : UserRecommand.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.channel.model;

import java.util.List;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;

@Document(collection="userRecommands")
@CompoundIndexes({
    @CompoundIndex(name = "userRecommands_idx", def = "{'botId':1, 'userId': 1}")
})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserRecommand {
	
	private String botId;
	
	private String userId;
	
	private List<String> intents;

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getIntents() {
		return intents;
	}

	public void setIntents(List<String> intents) {
		this.intents = intents;
	}
	
	public String toString() {
		return String.format("botId : %s, userId : %s, intents : %s", botId, userId, intents);
	}
}
