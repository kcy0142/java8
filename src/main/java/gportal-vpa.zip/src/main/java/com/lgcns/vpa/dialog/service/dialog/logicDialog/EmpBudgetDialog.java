/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : EmpBudgetDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * 통제경비 조회 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 25.
 */
@Component("EmpBudgetDialog")
public class EmpBudgetDialog extends LogicDialog {

	private static final Logger LOG = LoggerFactory.getLogger(EmpBudgetDialog.class);
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet =  null;
			
			TransferSyncVO responseVO =  new  TransferSyncVO();
			ObjectMapper mapper = new ObjectMapper();
			responseVO =  mapper.readValue(proxyResponseJsonData, TransferSyncVO.class);
			
			if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
				proxyResultSet = responseVO.getActionResult();
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				
				if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
					//Proxy에서 조회된 결과(JsonData)에서 Attachment 를 구함
					attachments = this.getAttachment(data, proxyResultSet);
					
					if ( (attachments != null) && (!attachments.isEmpty()) ) {
						
						int count = proxyResultSet.size();
						
						//Activity Message
						StringBuffer activityMessage = new StringBuffer();
						activityMessage.append(data.getInquiryData()).append(" 질의 결과 ");
						//통제경비는 항목에 TOTAL 이 있어서 전체 개수에서 1개를 제외함
						activityMessage.append("총 ").append(count-1).append("건의 경비가 조회되었습니다.");
						//resultActivity.setMessage(data.getIntentMessage());
						resultActivity.setMessage(activityMessage.toString());
						resultActivity.setAttachments(attachments);
						
					}
					else {
						LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
						
						//Data 가 없음
			        	resultActivity = this.commonResponeService.simpleResponseMessage(
								data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
								" 질의 결과 조회된 정보가 없습니다.");
					}
					
					//의도분석의 Button이 있는 경우 처리
					if ( data.getIntentButtons() != null ) {
						List<RelatedButton> buttons = data.getIntentButtons();
						List<Button> activityButtonList = super.makeActivityButtonList(buttons);
												
						if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
							resultActivity.setButtons(activityButtonList);
						}
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						"조회된 정보가 없습니다.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	@Override
	protected List<Attachment> getAttachment(InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet)
			throws Exception {
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        //attachment.setTitle(inquiryData.getIntentMessage());
	        
	        // 통제경비 현황이 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("등록된 SI 주요 수주현황이 없습니다.");
	            
	        }
	        // 통제경비 현황이 존재하는 경우    
	        else {
	        	
	        	String title = null;
	        	String setSubtitle = null;
	        	String setDescriptions = null;
	        	String setAmount = null;
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
	    				title = (proxyResult.get("ZUONR_NM") != null) ? proxyResult.get("ZUONR_NM").toString() : "";
	    				setSubtitle = (proxyResult.get("ZUONR") != null) ? proxyResult.get("ZUONR").toString() : "";
	    				setDescriptions = (proxyResult.get("ACG_NM") != null) ? proxyResult.get("ACG_NM").toString() : "";
	    				setAmount = (proxyResult.get("PLAN_AVAILABLE_AMT") != null) ? this.getAmount(proxyResult.get("PLAN_AVAILABLE_AMT").toString()) : "";
	    				
	    				Element element = new Element();
	    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	    				element.setTitle(title);
	    				element.setSubtitle(setSubtitle);
	    				element.setDescriptions(setDescriptions);
	    				element.setAmount(setAmount);
	    				element.setUnit("만원");
	    				
	    				attachment.addElement(element);
	        		}
	        	}//for
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
	
	/**
	 * 만원담위로 변경
	 * @param amount
	 * @return
	 */
	private String getAmount (String amount) {
		
		String resultAmount = "0";
		
		if ( (amount == null) || StringUtils.isEmpty(amount.trim()) ) {
			return resultAmount;
		}

		String tempAmount = amount.trim();
		try {
			Double amtDouble = Double.valueOf(tempAmount);
			
			if (amtDouble != null) {
				int amountInt = amtDouble.intValue()/10000;
				
				//통화 형식으로 천단위 "," 구분
				NumberFormat nf = NumberFormat.getNumberInstance();
				resultAmount = nf.format(amountInt);
			}
		}
		catch (Exception e) {
			return resultAmount;
		}
		
		 return resultAmount;
	}

}
