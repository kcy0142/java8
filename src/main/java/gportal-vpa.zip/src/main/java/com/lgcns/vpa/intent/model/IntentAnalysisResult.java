/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentAnalysisResult.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.model;

import java.util.HashMap;
import java.util.Map;

import com.lgcns.vpa.intent.model.IntentAnalysisResult.Status;
import com.lgcns.vpa.intent.service.Score;

public class IntentAnalysisResult {
	
	private IntentBase intent;
	private Status status;
	private Score score;
	
	public IntentAnalysisResult(Status status, Score score) {
		this.status = status;
		this.score = score;
	}
	
	public IntentAnalysisResult(IntentBase intent, Score score) {
		this.status = intent.getStatus();
		this.intent = intent;
		this.score  = score;
	}
	
	public Status getStatus() {
		return status;
	}
	
	public Score getScore() {
		return score;
	}
	
	public IntentBase getIntent() {
		return intent;
	}
	
	public void setIntent(IntentBase intent) {
		this.intent = intent;
	}
	
	public enum Status {
		COMPLETED("OK"),
		NOT_UNDERSTAND("Not-Understand"),
		MULTI_INTENTS("Multi-Intents"),
		DUP_PARAMETER("Duplicate-Parameter"),
		SLOT_FILLING("Slot-Filling");
		
		private String status;
		private String field;
		
		Status(String status) {
			this.status = status;
		}
		
		public String getField() {
			return this.field;
		}
		
		public void setField(String field) {
			this.field = field;
		}
	}
}
