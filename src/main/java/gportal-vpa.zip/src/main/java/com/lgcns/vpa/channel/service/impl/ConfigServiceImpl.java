/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.base.util.I18nUtils;
import com.lgcns.vpa.channel.dao.BotDao;
import com.lgcns.vpa.channel.dao.ConfigDao;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.config.Config;
import com.lgcns.vpa.channel.model.config.ConfigCode;
import com.lgcns.vpa.channel.model.config.LegacyConfig;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.model.config.PushConfigProperty;
import com.lgcns.vpa.channel.model.config.PushConfigPropertyValue;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 사용자 및 봇 설정 Service
 * </pre>
 * @author
 */
@Service("multi.configService")
public class ConfigServiceImpl implements ConfigService {

    @Autowired
    private BotDao botDao;

    @Autowired
    private ConfigDao configDao;
    
    /**
     * 사용자의 봇 설정 조회 (알림 설정 포함)
     * @param botId
     * @param user
     * @return
     */
    @Override
    public Config retrieveBotConfig(String botId, User user) {
        Bot bot = botDao.selectBotDetail(botId);
        
        if (bot == null) {
            throw new RuntimeException("봇 정보가 유효하지 않습니다.");
        }
        
        Config config = new Config();
        config.setBot(bot);
        
    	// 푸시 목록 조회
    	// 설정창에서는 표시여부가 'Y'인 건만 조회 (강유경C 요청)
        PushConfig searchCondition = new PushConfig();
        searchCondition.setBotId(botId);
        searchCondition.setUserId(user.getUserId());
        searchCondition.setDisplayYn("Y");
        searchCondition.setPushTypeCode(ConfigCode.PUSH_TYPE_CODE_ALL);
        
        List<PushConfig> pushConfigs = configDao.selectPushConfigList(searchCondition);
        
        if (!CollectionUtils.isEmpty(pushConfigs)) {
            pushConfigs = pushConfigs.stream().map(pushConfig -> {
                if (!I18nUtils.isDefaultLocaleCode(user.getLocaleCode())) {
                    pushConfig.setPushName(pushConfig.getPushEnglishName());
                    pushConfig.setDisplayDescription(pushConfig.getDisplayEnglishDescription());
                }

                // 푸시 설정 속성 조회
                List<PushConfigProperty> properties = configDao.selectPushConfigPropertyList(user.getUserId(), pushConfig.getPushId());
                
                for (PushConfigProperty property : properties) {
                    if (!I18nUtils.isDefaultLocaleCode(user.getLocaleCode())) {
                        property.setPropertyLabel(property.getPropertyEnglishLabel());
                    }
                    
                    // 푸시 설정 속성 값 정보 조회
                    List<PushConfigPropertyValue> proertyValues = configDao.selectPushPropertyValueList(pushConfig.getPushId(), property.getPropertyId());
                    
                    if (!CollectionUtils.isEmpty(proertyValues)) {
                        proertyValues = proertyValues.stream().map(value -> {
                            if (!I18nUtils.isDefaultLocaleCode(user.getLocaleCode()))
                                value.setLabel(value.getEnglishLabel());
                            
                            return value;
                            
                        }).collect(Collectors.toList());   
                    }        
                    property.setPropertyValues(proertyValues);   
                }
                
                pushConfig.setPushConfigProperties(properties);
                
                return pushConfig;
                
            }).collect(Collectors.toList());
        }

        config.setPushConfigs(pushConfigs);
        
        return config;
    }
    
    /**
     * 사용자의 봇 설정 저장
     * @param config
     * @param user
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateBotConfig(Config config, User user) {
        Bot bot = botDao.selectBotDetail(config.getBotId());
        
        if (bot == null) {
            throw new RuntimeException("봇 정보가 유효하지 않습니다.");
        }
        
        // 기 등록 알림 설정 삭제
        configDao.deletePushConfigsByBotId(config.getBotId(), user.getUserId());
        
        // 알림 속성 전체 삭제
        configDao.deletePushConfigPropertyByUserId(user.getUserId());
        
        // 알림 설정 저장
        if (!CollectionUtils.isEmpty(config.getPushConfigs())) {
            for (PushConfig pushConfig : config.getPushConfigs()) {
                pushConfig.setUserId(user.getUserId());
                pushConfig.setRegisterId(user.getUserId());
                pushConfig.setRegisterName(user.getUserName());
                pushConfig.setUpdaterId(user.getUserId());
                pushConfig.setUpdaterName(user.getUserName());
                
                // 알림 설정 저장
                configDao.insertPushConfig(pushConfig);
                
                // 알림 속성 전체 삭제
               // configDao.deletePushConfigPropertyByPushId(user.getUserId(), pushConfig.getPushId());

                // 알림 속성 저장
                List<PushConfigProperty> properties = pushConfig.getPushConfigProperties();
                if (!CollectionUtils.isEmpty(properties)) {
                    for (PushConfigProperty property : properties) {
                        if (!"GROUP".equals(property.getFormTypeCode())) {
                            property.setUserId(user.getUserId());
                            property.setRegisterId(user.getUserId());
                            property.setRegisterName(user.getUserName());
                            property.setUpdaterId(user.getUserId());
                            property.setUpdaterName(user.getUserName());
                            configDao.insertPushConfigProperty(property);
                        }
                    }
                } 
            }   
        }
    }
    
    /**
     * 사용자의 알림 설정 조회
     * @param botId
     * @param userId
     * @param pushTypeCode
     * @return
     */
    @Override
    public PushConfig retrievePushConfig(String pushId, String userId) {
        return configDao.selectPushConfig(pushId, userId);
    }
    
    /**
     * 사용자의 알림 설정(리스트) 조회
     * @param botId
     * @param pushTypeCode
     * @param user
     * @return
     */
    @Override
    public List<PushConfig> retrievePushConfigList(PushConfig searchCondition, User user) {        
        List<PushConfig> pushConfigs = configDao.selectPushConfigList(searchCondition);
        
        if (!CollectionUtils.isEmpty(pushConfigs)) {
            pushConfigs = pushConfigs.stream().map(pushConfig -> {
                if (!I18nUtils.isDefaultLocaleCode(user.getLocaleCode())) {
                    pushConfig.setPushName(pushConfig.getPushEnglishName());
                    pushConfig.setDisplayDescription(pushConfig.getDisplayEnglishDescription());
                }
                
                // 푸시 설정 속성 조회
                List<PushConfigProperty> properties = configDao.selectPushConfigPropertyList(user.getUserId(), pushConfig.getPushId());
                
                for (PushConfigProperty property : properties) {
                    if (!I18nUtils.isDefaultLocaleCode(user.getLocaleCode())) {
                        property.setPropertyLabel(property.getPropertyEnglishLabel());
                    }
                    
                    // 푸시 설정 속성 값 정보 조회
                    List<PushConfigPropertyValue> proertyValues = configDao.selectPushPropertyValueList(pushConfig.getPushId(), property.getPropertyId());
                    
                    if (!CollectionUtils.isEmpty(proertyValues)) {
                        proertyValues = proertyValues.stream().map(value -> {
                            if (!I18nUtils.isDefaultLocaleCode(user.getLocaleCode()))
                                value.setLabel(value.getEnglishLabel());
                            
                            return value;
                            
                        }).collect(Collectors.toList());   
                    }        
                    property.setPropertyValues(proertyValues);   
                }
                
                pushConfig.setPushConfigProperties(properties);
                
                return pushConfig;
                
            }).collect(Collectors.toList());
        }

        return pushConfigs;
    }
        
    /**
     * 봇 알림 설정 생성 필요 여부 확인
     * true 인 경우, 기본 설정 정보를 생성한다.
     * @param botId
     * @param userId
     * @return
     */
    @Override    
    public boolean isUserCreatePushConfig(String botId, String userId) {
        return configDao.isUserNeedToCreatePushConfig(botId, userId);
    }
    
    /**
     * 봇 알림 미사용 여부
     * @param botId
     * @param userId
     * @param pushTypeCode
     * @return
     */
    @Override    
    public boolean isUserNotUsedPushByPushTypeCode(String botId, String userId, String pushTypeCode) {
        return configDao.selectNotUsedByPushTypeCode(botId, userId, pushTypeCode);
    }
    
    /**
     * 봇 알림 기본 설정 생성
     * @param botId
     * @param userId
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createPushConfig(String botId, String userId) {
        configDao.createPushConfig(botId, userId);
        configDao.createPushConfigProperty(botId, userId);
    }
        
    /**
     * 알림 상세 정보 조회
     * @param pushId
     * @param ip
     * @return
     */
    public PushConfig retrievePushDetail(String pushId, String ip) {
        return configDao.selectPushDetail(pushId, ip);
    }
    
    /**
     * 알림 사용자 목록 조회
     * @param params
     * @return
     */
    public List<PushConfig>retrievePushConfigAllUserList(String pushId, String userId){
        return configDao.selectPushConfigAllUserList(pushId, userId);
    }
    
    /**
     * 알림 설정 사용자 목록 조회
     * @param params
     * @return
     */
    public List<PushConfigProperty>retrievePushConfigPropertyAllUserList(String pushId, String userId, String propertyId){
        return configDao.selectPushConfigPropertyAllUserList(pushId, userId, propertyId);
    }
    
    
    /**
     * 레가시 조회
     * @param botId
     * @param legacyCode
     * @param legacyTypeCode
     * @return
     */
    @Override
    public LegacyConfig retrieveLegacyConfig(String legacyCode, String legacyTypeCode) {
        return configDao.selectLegacyConfig(legacyCode, legacyTypeCode);
    }
    
    /**
     * 레가시 정보(리스트) 조회
     * @param legacyCode
     * @return
     */
    @Override
    public List<LegacyConfig> retrieveLegacyConfigList(String legacyCode) {        
        List<LegacyConfig> legacyConfigs = configDao.selectLegacyConfigList(legacyCode);
        return legacyConfigs;
    }
    
}
