/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SmsSendService.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service;

import java.util.Map;

import com.lgcns.vpa.channel.model.config.PushConfig;

/**
 * <pre>
 *  SMS Send Service
 * </pre>
 * @author
 */
public interface SmsSendService {

	/**
	 * SMS Send Service
	 * @param params
	 * @param tenantId
	 */
	public Map<String, String>  execute(Map<String, Object> params, String tenantId);
	
}
