/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : TargetInfoDao.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.lgcns.vpa.push.model.TargetInfo;
import com.lgcns.vpa.security.user.model.User;

@Repository
@Mapper
public interface TargetInfoDao {
	
	/**
	 * TargetGroup에 해당하는 TargetInfo 정보 조회
	 * @param botId
	 * @param targetGroupId
	 * @return
	 */
	public List<TargetInfo> listTargetInfo(@Param("botId") String botId, @Param("targetGroupId") String targetGroupId);
	
	/**
	 * Target Group에 해당하는 임직원의 사용자 Id 조회
	 * @param params
	 * @return
	 */
	public String isAllEmployee(Map<String, Object> params);
	
	/**
	 * Target Group에 해당하는 임직원 정보 조회
	 * @param params
	 * @return
	 */
	public List<User> getTargetUserList(Map<String, Object> params);
	
	/**
	 * 전체 직원의 정보를 조회
	 * @return
	 */
	public List<User> getAllTargetUserList();
}
