/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : UserSessionListener.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.base.config;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.lgcns.vpa.intent.service.impl.IntentContext;
import com.lgcns.vpa.security.authentication.model.UserDetailsImpl;

public class UserSessionListener implements HttpSessionListener {
	
	final Logger logger = LoggerFactory.getLogger(UserSessionListener.class);
	
	@Autowired
	IntentContext intentContext;
	
	@Override
	public void sessionCreated(HttpSessionEvent event) {

	}

	/**
	 * 인증 세션이 만료되었을 때, 임시로 보관되는 사용자의 최근대화를 삭제한다.
	 */
	@Override
	public void sessionDestroyed(HttpSessionEvent event) {
		//HttpSession session = event.getSession();
		logger.debug("user session was destroyed");
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		if( auth == null ) {
			return;
		}
		Object principal = auth.getPrincipal();
		
		if( principal != null && principal instanceof UserDetailsImpl ) {
			UserDetailsImpl user = (UserDetailsImpl)principal;
			intentContext.expireIntent(user.getTenantId(), user.getUser().getUserId());
		}
	}

}
