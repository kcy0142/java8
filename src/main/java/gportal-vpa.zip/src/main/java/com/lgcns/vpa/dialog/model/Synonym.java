/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : IntentFilter.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.query.Update;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <PRE>
 * 질의문 중 유의어 대상 단어 Modeling Object
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 9. 19.
 */
@Document(collection="synonyms")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Synonym {
	
	@Id
	private String id;
	
	/**
	 * 필터링 대상어 Id
	 */
	private String synonymId;
	
	/**
	 * 필터링 대상어
	 */
	private String synonymTargetData;
	
	/**
	 * 필터링 대상어의 결과
	 */
	private String synonymData;
	
	/**
	 * StopWord 을 사용하는 챗봇 구분 id
	 */
	private String botId;
	
	/**
	 * 생성자 userId
	 */
	private String registerId;
	
	/**
	 * 생성자 명
	 */
	private String registerName;
	
	/**
	 * 생성일자
	 */
	private Date registDate;
	
	/**
	 * 수정자 userId
	 */
	private String updaterId;
	
	/**
	 * 수정자 명
	 */
	private String updaterName;
	
	/**
	 * 수정일자
	 */
	private Date updateDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSynonymId() {
		return synonymId;
	}

	public void setSynonymId(String synonymId) {
		this.synonymId = synonymId;
	}

	public String getSynonymTargetData() {
		return synonymTargetData;
	}

	public void setSynonymTargetData(String synonymTargetData) {
		this.synonymTargetData = synonymTargetData;
	}

	public String getSynonymData() {
		return synonymData;
	}

	public void setSynonymData(String synonymData) {
		this.synonymData = synonymData;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getRegisterName() {
		return registerName;
	}

	public void setRegisterName(String registerName) {
		this.registerName = registerName;
	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}

	public String getUpdaterId() {
		return updaterId;
	}

	public void setUpdaterId(String updaterId) {
		this.updaterId = updaterId;
	}

	public String getUpdaterName() {
		return updaterName;
	}

	public void setUpdaterName(String updaterName) {
		this.updaterName = updaterName;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getSynonymTargetDataToUpperCase() {
		
		return ( this.synonymTargetData != null ) ? synonymTargetData.toUpperCase() : "";
	}
	
	/**
	 * 수정용 Parameter 인 Update Object 생성
	 * @return
	 */
	public Update getUpdateObject () {
		
		Update update = new Update();
		
		update.set("synonymTargetData", this.synonymTargetData);
		update.set("synonymData", this.synonymData);
		update.set("updaterId", this.updaterId);
		update.set("updaterName", this.updaterName);
		update.set("updateDate", new Date(System.currentTimeMillis()));
		
		return update;
	}

	/**
	 * Json Data 생성
	 * @return
	 */
	public String toJson () {
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(this);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}
}
