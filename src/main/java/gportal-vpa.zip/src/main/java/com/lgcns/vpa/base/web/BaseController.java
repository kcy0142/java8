/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.base.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.lgcns.vpa.security.authentication.model.UserDetailsImpl;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * Base Controller
 * <pre>
 * @author
 */
public abstract class BaseController {

    @Autowired
    Environment environment;

    /**
     * 인증정보 조회
     * @return
     */
    public Authentication getAuthentication() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    /**
     * 세션 사용자 정보 조회
     * @return
     */
    public User getSessionUser() {
        return this.getUser();
    }

    /**
     * Security Context 의 사용자 정보 반환
     * @return
     */
    public User getUser() {
        Authentication authentication = this.getAuthentication();
        Object principal = authentication.getPrincipal();
        try {
            if (principal != null && principal instanceof UserDetailsImpl) {
                UserDetailsImpl userDetails = (UserDetailsImpl) principal;    
                return userDetails.getUser();
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }	

    /**
     * 테넌트 ID 조회
     * @return
     */
    public String getTenantId() {
        String tenantId = null;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails){
            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
            tenantId = userDetails.getTenantId();
        } else {
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            tenantId = request.getAttribute("vpa.tenantId") != null ?  request.getAttribute("vpa.tenantId").toString() : environment.getProperty(request.getServerName());
        }
        return tenantId;
    }
}