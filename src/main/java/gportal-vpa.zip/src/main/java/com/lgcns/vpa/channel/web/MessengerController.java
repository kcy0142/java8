package com.lgcns.vpa.channel.web;

import java.util.Date;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.util.StringUtils;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.MessengerActivity;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.service.DialogHandlerService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 메신저 FAQ 파일럿 api 컨트롤러
 * </pre>
 * @author
 */
@RestController
@CrossOrigin(value="*")
@RequestMapping(value="/api/messenger")
public class MessengerController extends BaseController {
    final Logger logger = LoggerFactory.getLogger(MessengerController.class);
    
    @Autowired
    DialogHandlerService dialogHandlerService;
    
    @Autowired
    private MessageSource messageSource;

    @RequestMapping(value="/faq", method= RequestMethod.POST)
    public ResponseEntity<Activity> messengerFaq(@RequestBody (required=false) Map<String, String> params, HttpServletRequest request) throws Exception {
    	
    	Activity outbound = null;
    	request.setAttribute("vpa.tenantId", "lge");
    	User user = new User();
    	user.setUserId(params.get("senderId"));
    	
    	try {
	    	if (params != null) {
	    		
	    		Activity inbound = new Activity();
	    		inbound.setType(CommonCode.ACTIVITY_TYPE_LGEFAQ);
	    		inbound.setSenderType(ActivityCode.SENDER_TYPE_USER);
	    		inbound.setBotId(params.get("receiverId"));
	    		inbound.setUserId(params.get("senderId"));
	    		inbound.setMessage(params.get("text"));
	    		inbound.setUserIp(params.get("userIp"));
	    		inbound.setDeviceType(params.get("deviceType"));
	    		
	    		outbound = dialogHandlerService.syncInquiry(inbound, user, "lge");
	    		
	    		if (outbound == null) {
	    			outbound = new Activity();
	        		outbound.setMessage("문의하신 질문을 이해하지 못하였습니다.");
	    		}
	    	}
    	} catch (Exception e) {
    		outbound = new Activity();
    		outbound.setMessage("문의하신 질문을 처리하는 중 오류가 발생하였습니다.");
    	}
    	
        return new ResponseEntity<>(outbound, new HttpHeaders(), HttpStatus.OK);
    }
    
    @RequestMapping(value="/message", method= RequestMethod.POST)
    public ResponseEntity<Activity> message(@RequestBody MessengerActivity activityRequest) throws Exception {

    	Activity activityResponse;
    	
    	//필수: userId,companyCode,tenantId,botId,message
    	User user = activityRequest.getUser();
    	String tenantId = StringUtils.isEmpty(activityRequest.getTenantId()) ? getTenantId() : activityRequest.getTenantId();
    	
    	if(StringUtils.isEmpty(activityRequest.getBotId()) || StringUtils.isEmpty(user.getUserId()) || StringUtils.isEmpty(tenantId)){
    		activityResponse = new Activity();
    		activityResponse.setMessage(messageSource.getMessage("error.title", null, Locale.KOREA));
    	}else{
    		activityResponse = dialogHandlerService.syncInquiry(activityRequest, activityRequest.getUser(), tenantId);
    		
    		activityResponse.setUserId(user.getUserId());
    		activityResponse.setSentDate(new Date());
    		activityResponse.setReplyToId(activityRequest.getId());
    	}
    	
    	return new ResponseEntity<>(activityResponse, new HttpHeaders(), HttpStatus.OK);
    }
}