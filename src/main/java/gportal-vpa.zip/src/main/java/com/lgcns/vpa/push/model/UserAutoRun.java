/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserAutoRun.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.scheduling.support.SimpleTriggerContext;

/**
 * <PRE>
 * 사용자별 자동실행을 위한 모델
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 11. 27.
 */
public class UserAutoRun {
	
	/**
	 * 자동 실행 구분 아이디
	 */
	private String userAutoRunId;
	
	/**
	 * 자동실행 사용자 아이디
	 */
	private String userId;

	/**
	 * 자동 실행 봇 아이디
	 */
	private String botId;

	/**
	 * 자동실행 의도 아이디
	 */
	private String intentId;

	/**
	 * 자동실행 질의문
	 */
	private String inquiry;

	/**
	 * 자동실행 의도 파라미터
	 */
	private String parameter;

	/**
	 * 크론표현식, 자동 실행 Cron 표현식 ("0 30 10 ? 2,4,5 ?" ==> 월수목요일 오전 10시 30분)
	 */
	private String cronExpression;

	/**
	 * 반복 요일, MON,TUE,WED,THU,FRI,SAT,SUN (MON,WED,THU ==> 월요일,수요일,목요일)
	 */
	private String repeatDay;

	/**
	 * 반복 시간, hhjmm (1330 ==> 오후 1시 30분, 0030 ==> 오전 0시 30분)
	 */
	private String repeatTime;

	/**
	 * 마지막 실행 상태 (0:WAIT, 1:SUCCESS, 2:FAILURE) 
	 */
	private int resultStatus;
	
	/**
	 * 실행 상태,  인접된 실행 시간에 종료가 안된 경우 중복 실행이 되지 않게 하기 위함 (0:WAIT, 1:RUNNING)
	 */
	private int processStatus;

	/**
	 * 다음 실행 시간 (Next Fire Time)
	 */
	private long nextRunTime;

	/**
	 * 마지막 실행 시간 (마지막 Fire Time) 
	 */
	private Date lastRunDate;

	/**
	 * 생성자 사용자 아이디
	 */
	private String registerId;

	/**
	 * 생성자 명
	 */
	private String registerName;

	/**
	 * 생성일
	 */
	private Date registDate;;

	/**
	 * 수정자 아이디
	 */
	private String updaterId;

	/**
	 * 수정자 명
	 */
	private String updaterName;

	/**
	 * 수정일
	 */
	private Date updateDate;

	public UserAutoRun () {}
	
	public UserAutoRun (String repeatDay, String repeatTime) {
		this.repeatDay = repeatDay;
		this.repeatTime = repeatTime;
		this.cronExpression = this.makeCronExpression();
	}
	
	public UserAutoRun (String userId, String repeatDay, String repeatTime) {
		this.userId = userId;
		this.repeatDay = repeatDay;
		this.repeatTime = repeatTime;
		this.cronExpression = this.makeCronExpression();
	}
	
	public UserAutoRun(String userAutoRunId, String userId, String botId, String repeatDay, String repeatTime) {
		super();
		this.userAutoRunId = userAutoRunId;
		this.userId = userId;
		this.botId = botId;
		this.repeatDay = repeatDay;
		this.repeatTime = repeatTime;
	}
	
	public String getUserAutoRunId() {
		return userAutoRunId;
	}

	public void setUserAutoRunId(String userAutoRunId) {
		this.userAutoRunId = userAutoRunId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}

	public String getInquiry() {
		return inquiry;
	}

	public void setInquiry(String inquiry) {
		this.inquiry = inquiry;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public String getCronExpression() {
		return cronExpression;
	}

	public void setCronExpression(String cronExpression) {
		this.cronExpression = cronExpression;
	}

	public String getRepeatDay() {
		return repeatDay;
	}

	public void setRepeatDay(String repeatDay) {
		this.repeatDay = repeatDay;
	}

	public String getRepeatTime() {
		return repeatTime;
	}

	public void setRepeatTime(String repeatTime) {
		this.repeatTime = repeatTime;
	}

	public int getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(int resultStatus) {
		this.resultStatus = resultStatus;
	}

	public int getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(int processStatus) {
		this.processStatus = processStatus;
	}

	public long getNextRunTime() {
		return nextRunTime;
	}

	public void setNextRunTime(long nextRunTime) {
		this.nextRunTime = nextRunTime;
	}

	public Date getLastRunDate() {
		return lastRunDate;
	}

	public void setLastRunDate(Date lastRunDate) {
		this.lastRunDate = lastRunDate;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getRegisterName() {
		return registerName;
	}

	public void setRegisterName(String registerName) {
		this.registerName = registerName;
	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}

	public String getUpdaterId() {
		return updaterId;
	}

	public void setUpdaterId(String updaterId) {
		this.updaterId = updaterId;
	}

	public String getUpdaterName() {
		return updaterName;
	}

	public void setUpdaterName(String updaterName) {
		this.updaterName = updaterName;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * 반복 요일과 시간을 Cron Expression 으로 변경
	 * @return
	 */
	public String makeCronExpression () {
		
		if ( StringUtils.isEmpty(this.repeatDay) || 
			 StringUtils.isEmpty(this.repeatTime) ||
			 !(this.repeatTime.length() >= 3) ) {
			return null;
		}
		
		final String SPACE = " ";
		//("0 30 10 ? * 2,4,5 ?" ==> 매주 월,수,목요일 오전 10시 30분)
		StringBuffer expBuf = new StringBuffer("0");
		String minute = null, hour = null;
		
		if (this.repeatTime.length() >= 4) {
			minute = this.repeatTime.substring(2, 4);
			minute = (minute.equals("00")) ? "0" : minute;
			
			hour = this.repeatTime.substring(0, 2);
			hour = (hour.startsWith("0")) ? this.repeatTime.substring(1, 2) : hour;
		}
		else {
			minute = this.repeatTime.substring(1, 3);
			minute = (minute.equals("00")) ? "0" : minute;
			
			hour = this.repeatTime.substring(0, 1);
		}
		
		expBuf.append(SPACE).append(minute);
		expBuf.append(SPACE).append(hour);
		expBuf.append(SPACE).append("? *");
		
		if ( this.repeatDay.endsWith(",") ) {
			expBuf.append(SPACE).append(this.repeatDay.substring(0, this.repeatDay.length()-1));
		}
		else {
			expBuf.append(SPACE).append(this.repeatDay);
		}
		
		//expBuf.append(SPACE).append("*");
		
		return expBuf.toString();
	}
	
	/**
	 * 다은 실행 시간을 Long 형으로 반환 
	 * @return
	 */
	public long nextExcutionTimeLong () {
		
		Date nextExcutionTime = this.nextExcutionTime();
		return ( nextExcutionTime == null ) ? 0L : nextExcutionTime.getTime();
	}
	
	/**
	 * 다음 실행 시간을 String 형으로 반환
	 * @return
	 */
	public String nextExcutionTimeString () {
		
		if ( StringUtils.isEmpty(this.repeatDay) || StringUtils.isEmpty(this.repeatTime) ) {
			return null;
		}
		
		if ( StringUtils.isEmpty(this.cronExpression) ) {
			this.cronExpression = this.makeCronExpression();
		}
		
		Date excutionDate = this.nextExcutionTime();
		String nextDateStr = null;
		
		if (excutionDate != null) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
			nextDateStr = sdf.format(excutionDate);
		}
		
		return nextDateStr;
	}
	
	/**
	 * 다음 실행 시간을 Date 형으로 반환
	 * @return
	 */
	public Date nextExcutionTime () {
		
		if ( StringUtils.isEmpty(this.repeatDay) || StringUtils.isEmpty(this.repeatTime) ) {
			return null;
		}
		
		if ( StringUtils.isEmpty(this.cronExpression) ) {
			this.cronExpression = this.makeCronExpression();
		}
		
		CronTrigger cronTrigger = new CronTrigger(this.cronExpression);
		SimpleTriggerContext context = new SimpleTriggerContext();
		context.update(null, null, new Date());
		
		return cronTrigger.nextExecutionTime(context);
	}

	@Override
	public String toString() {
		return "UserAutoRun [userAutoRunId=" + userAutoRunId + ", userId=" + userId + ", botId=" + botId + ", intentId="
				+ intentId + ", inquiry=" + inquiry + ", parameter=" + parameter + ", cronExpression=" + cronExpression
				+ ", repeatDay=" + repeatDay + ", repeatTime=" + repeatTime + ", resultStatus=" + resultStatus
				+ ", processStatus=" + processStatus + ", nextRunTime=" + nextRunTime + ", lastRunDate=" + lastRunDate
				+ ", registerId=" + registerId + ", registerName=" + registerName + ", registDate=" + registDate
				+ ", updaterId=" + updaterId + ", updaterName=" + updaterName + ", updateDate=" + updateDate + "]";
	}

}
