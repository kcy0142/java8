package com.lgcns.vpa.base.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.web.socket.messaging.SessionConnectEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

public class WebSocketEventListener {
    final Logger logger = LoggerFactory.getLogger(WebSocketEventListener.class);

    public WebSocketEventListener() {
    }

    @EventListener
    private void handleSessionConnected(SessionConnectEvent event) {
        logger.info("- handleSessionConnected()");
        logger.info(event != null ? event.toString() : "");
    }

    @EventListener
    private void handleSessionDisconnect(SessionDisconnectEvent event) {
        logger.info("- handleSessionDisconnect()");
        logger.info(event != null ? event.toString() : "");
    }
}
