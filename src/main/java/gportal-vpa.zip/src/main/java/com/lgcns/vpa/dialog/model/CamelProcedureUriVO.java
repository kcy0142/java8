/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : CamelProcedureUriVO.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.model;

import java.util.Map;

public class CamelProcedureUriVO {
	private String query;
	private Map<String, Object> parameters;
	
	public CamelProcedureUriVO(){}
	
	public CamelProcedureUriVO(String query, Map<String, Object> parameters) {
		super();
		this.query = query;
		this.parameters = parameters;
	}
	
	public String getQuery() {
		return query;
	}
	
	public void setQuery(String query) {
		this.query = query;
	}
	
	public Map<String, Object> getParameters() {
		return parameters;
	}
	
	public void setParameters(Map<String, Object> parameters) {
		this.parameters = parameters;
	}

	@Override
	public String toString() {
		return "CamelProcedureUriVO [query=[" + query + "], parameters=" + parameters + "]";
	}
}
