/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.activity;

/**
 * <pre>
 * 액티비티 도메인 Code
 * 액티비티 도메인의 공통코드 정의
 * </pre>
 * @author
 */
public interface ActivityCode {
    
    // SENDER_TYPE: 발신자 유형
    
    /**
     * 사용자
     */
    String SENDER_TYPE_USER = "user";
    
    /**
     * 봇
     */
    String SENDER_TYPE_BOT = "bot";
    
    /**
     * 시스템 (장애 공지 등)
     */
    String SENDER_TYPE_SYSTEM = "system";
    
    // ACTIVITY_TYPE: 액티비티 유형
    
    /**
     * 메시지
     */
    String ACTIVITY_TYPE_MESSAGE = "message";
    
    /**
     * 검색
     */
    String ACTIVITY_TYPE_SEARCH = "search";

    /**
     * 폴링
     */
    String ACTIVITY_TYPE_POLLING = "polling";
    
    /**
     * 자동완성
     */
    String ACTIVITY_TYPE_AUTOSUGGEST = "autosuggest";
    
    // ACTIVITY_SUBTYPE: 액티비티 세부 유형
    
    /**
     * 푸시
     */
    String ACTIVITY_SUBTYPE_MESSAGE_PUSH = "push";
    
    /**
     *  인사말
     */
    String ACTIVITY_SUBTYPE_MESSAGE_GREETING = "greeting";
    
    /**
     * 데일리 푸시
     */
    String ACTIVITY_SUBTYPE_MESSAGE_DAILY_PUSH = "daily_push";
    
    /**
     * 결과가 없는 경우
     */
    String ACTIVITY_SUBTYPE_MESSAGE_NOT_FOUND = "notfound";
    
    /**
     * 에러
     */
    String ACTIVITY_SUBTYPE_MESSAGE_ERROR = "error";
    
    /**
     * 검색
     */
    String ACTIVITY_SUBTYPE_SEARCH_ALL = "search_all";
    
    String ACTIVITY_SUBTYPE_SEARCH_USER = "search_user";
    
    String ACTIVITY_SUBTYPE_SEARCH_PROJECT = "search_project";

    // ATTACHMENT_LAYOUT_TYPE: 첨부가 복수인 경우 레이아웃을 정의
    
    // 기본값
    String ATTACHMENT_LAYOUT_TYPE_DEFAULT = "default";
    
    String ATTACHMENT_LAYOUT_TYPE_CAROUSEL = "carousel";
        
    String ATTACHMENT_LAYOUT_TYPE_ACCORDION = "accordion";
    
    // ATTACHMENT_TYPE

    String ATTACHMENT_TYPE_TEMPLATE = "template";
    
    String ATTACHMENT_TYPE_POPUP = "popup";
    
    String ATTACHMENT_TYPE_FUNCTION = "function";
    
    String ATTACHMENT_TYPE_IMAGE = "image";
    
    String ATTACHMENT_TYPE_VIDEO = "video";
    
    String ATTACHMENT_TYPE_AUDIO = "audio";
    
    // TEMPLATE_TYPE: 템플릿 유형
    
    String TEMPLATE_TYPE_LIST = "list";
        
    String TEMPLATE_TYPE_TEXT = "text";
    
    String TEMPLATE_TYPE_CARD = "card";
    
    String TEMPLATE_TYPE_DETAIL = "detail";
    
    String TEMPLATE_TYPE_TABLE = "table";
        
    String TEMPLATE_TYPE_COLLAPSE = "collapse";
    
    String TEMPLATE_TYPE_CAROUSEL = "carousel";
    
    String TEMPLATE_TYPE_THUMB_LIST = "thumb_list";
    
    String TEMPLATE_TYPE_CUSTOM_WEATHER = "weather";
    
    String TEMPLATE_TYPE_CUSTOM_WORLDTIME = "worldtime";
    
    String TEMPLATE_TYPE_CUSTOM_PEOPLE_LIST = "people_list";
    
    String TEMPLATE_TYPE_CUSTOM_PLANNER = "planner_list";
    
    String TEMPLATE_TYPE_CUSTOM_PLANNER_DETAIL = "planner_detail";
    
    String TEMPLATE_TYPE_CUSTOM_USRE_PROFILE = "user_profile";
    
    String TEMPLATE_TYPE_CUSTOM_CONGRATULATION = "congratulation";
    
    String TEMPLATE_TYPE_CUSTOM_MEMO = "memo";
    
    String TEMPLATE_TYPE_AUTORUN_LIST = "autorun_list";
    
    
    String TEMPLATE_TYPE_SMSSEND = "smsSend";
    
    String TEMPLATE_TYPE_VACATIONAPPLY = "vacationApply";
    
    String TEMPLATE_TYPE_IMAGE_LIST = "img_list";
    
    // ELEMENT_TYPE: 템플릿 엘리먼트 유형을 정의, 동일 템플릿내에서 세부 렌더링을 조정할 경우 사용
        
    // ACTION_TYPE: 액션 유형
    
    /**
     * 단순링크
     */
    String ACTION_TYPE_LINK = "link";
    
    /**
     * 인텐트 처리
     */
    String ACTION_TYPE_INQUIRY = "inquiry";
    
    /**
     * 함수형 액션
     */
    String ACTION_TYPE_FUNCTION = "function";
    
    // ACTION_FUNCTION: 함수형 액션
    
    /**
     * 좋아요
     */
    String ACTION_FUNCTION_LIKE = "like";
    
    /**
     * 너무 싫어요
     */
    String ACTION_FUNCTION_DISLIKE = "dislike";
   
    /**
     * 메모
     */
    String ACTION_FUNCTION_MEMO = "memo";
    
    /**
     * 조직도
     */
    String ACTION_FUNCTION_ORG_TREE = "organizationTree";

    // BLOCK_DATA_TYPE: Element 페이지 블럭의 데이터 유형을 정의
    
    /**
     * 일자 (currentBlock 에서 1일씩 가감)
     */
    String BLOCK_DATA_TYPE_DATE = "date";
    
    /**
     * 시간 (currentBlock 에서 1시간씩 가감)
     */
    String BLOCK_DATA_TYPE_HOUR = "hour";
    
    /**
     * 숫자 (currentBlock 에서 1씩 가감)
     */
    String BLOCK_DATA_TYPE_NUMBER = "number";
    
    /**
     * locale
     */
    String DEFAULT_LOCALE_CODE = "ko";
    
    // PAGING_TYPE: Element 항목의 페이징 유형을 정의
    
    /**
     * 페이저 (다음, 이전 스타일) 
     */
    String PAGING_TYPE_PAGER = "pager";
    
    /**
     * 페이징 (페이지 번호)
     */
    String PAGING_TYPE_PAGINATION = "pagination";
    
    /**
     * 페이징 (더보기)
     */
    String PAGING_TYPE_MORE = "more";
        
    // 페이징 사이즈 
    
    int PAGING_DEFAULT_LIST_SIZE = 5;
    
    int PAGING_DEFAULT_MAX_LIST_SIZE = 100;
    
    int PAGING_DEFAULT_OFFSET_SIZE = 5;
    
    int PAGING_NO_LIMIT = -1;
    
    // 이벤트, 애니메이션
    
    /**
     * 메시지
     */
    String EVENT_DISPLAY_TYPE_MESSAGE = "1";
    
    /**
     * 애니메이션
     */
    String EVENT_DISPLAY_TYPE_ANIMATION = "2";
    
    /**
     * 메시지, 애니메이션
     */
    String EVENT_DISPLAY_TYPE_ALL = "3";
    
    // 애니메이션 컴포넌트 유형 (1: 공용 컴포넌트, 2: 전용 컴포넌트)
    
    /**
     * 공통 컴포넌트
     */
    String ANIMATION_TYPE_COMMON = "1";
    
    /**
     * 전용 컴포넌트 (기념일, 하트, 추석 등)
     */
    String ANIMATION_TYPE_DEDICATED = "2";
    
    // 애니메이션 타임아웃
    
    int ANIMATION_DEFAULT_TIMEOUT = 3000;
    
    int ANIMATION_NO_TIMEOUT = -1;
    
    // 축하합니다. 유형
    
    /**
     * 생일
     */
    String CONGRATULATION_TYPE_BIRTHDAY = "BIRTHDAY";
    
    /**
     * 결혼 기념일
     */
    String CONGRATULATION_WEDDING_ANNIV = "WEDDING_ANNIV";
    
    /**
     * 장기 근속
     */
    String CONGRATULATION_TYPE_LONG_SERVICE = "LONG_SERVICE";
}
