/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : TargetInfoDao.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.lgcns.vpa.push.model.UserAutoRun;
import com.lgcns.vpa.push.model.UserAutoRunConfig;

@Repository
@Mapper
public interface UserAutoRunDao {
	
	/**
	 * 개인별 설정된 자동 실행 목록 조회
	 * @param botId
	 * @param userId
	 * @return
	 */
	public List<UserAutoRun> list(@Param("botId") String botId, @Param("userId") String userId);
	
	/**
	 * 실행 중인 개인 자동 실행 목록 조회
	 * @param botId
	 * @return
	 */
	public List<UserAutoRun> listAllRunning(@Param("botId") String botId);
	
	/**
	 * 개인별 자동실행 내역 상세 조회
	 * @param botId
	 * @param userAutoRunId
	 * @return
	 */
	public UserAutoRun retrieve(@Param("botId") String botId, @Param("userAutoRunId") String userAutoRunId);
	
	/**
	 * 개인별 자동실행 내역 생성
	 * @param userAutoRun
	 */
	public void create(UserAutoRun userAutoRun);
	
	/**
	 * 개인별 자동실행 내역 삭제
	 * @param botId
	 * @param userAutoRunId
	 */
	public void delete(@Param("botId") String botId, @Param("userAutoRunId") String userAutoRunId);
	
	/**
	 * 정해진 시간대의 자동 실행해야하는 개인별 자동 실행 내역 목록 조회 
	 * @param params
	 * @return
	 */
	public List<UserAutoRun> listFireTarget(Map<String, Object> params);
	
	/**
	 * 자동 실행중인 개인별 자동 실행 내역의 실행 상태 변경
	 * @param params
	 */
	public void updateProcessStatusFireTarget(Map<String, Object> params);
	
	/**
	 * 자동 실행을 완료한 개인별 자동 실행 내역의 상태 변경
	 * @param userAutoRun
	 */
	public void updateResultStatus(UserAutoRun userAutoRun);
	
	/**
	 * 자동 실행 등록 버튼의 표시 시간설정 정보를 조회 
	 * @param botId
	 * @return
	 */
	public List<UserAutoRunConfig> listUserAutoRunConfig(@Param("botId") String botId);
	
}
