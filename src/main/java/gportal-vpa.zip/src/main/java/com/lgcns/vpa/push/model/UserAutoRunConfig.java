/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserAutoRunConfig.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.model;

import java.util.Date;

public class UserAutoRunConfig {
	/**
	 * 자동 실행 시간 설정 구분 아이디
	 */
	private String autoRunConfigId;
	
	/**
	 * 자동 실행 시간 설정 봇 아이디
	 */
	private String botId;

	/**
	 * 자동 실행 시간 설정 사용여부(0:사용, 1:미사용)
	 */
	private int useYn;
	
	/**
	 * 자동 실행 시간 설정 시작 시간(mmss Type)
	 */
	private int startTime;
	
	/**
	 * 자동 실행 시간 설정 종료 시간(mmss Type)
	 */
	private int endTime;

	/**
	 * 생성자 사용자 아이디
	 */
	private String registerId;

	/**
	 * 생성자 명
	 */
	private String registerName;

	/**
	 * 생성일
	 */
	private Date registDate;;

	/**
	 * 수정자 아이디
	 */
	private String updaterId;

	/**
	 * 수정자 명
	 */
	private String updaterName;

	/**
	 * 수정일
	 */
	private Date updateDate;

	public String getAutoRunConfigId() {
		return autoRunConfigId;
	}

	public void setAutoRunConfigId(String autoRunConfigId) {
		this.autoRunConfigId = autoRunConfigId;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public int getUseYn() {
		return useYn;
	}

	public void setUseYn(int useYn) {
		this.useYn = useYn;
	}

	public int getStartTime() {
		return startTime;
	}

	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}

	public int getEndTime() {
		return endTime;
	}

	public void setEndTime(int endTime) {
		this.endTime = endTime;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getRegisterName() {
		return registerName;
	}

	public void setRegisterName(String registerName) {
		this.registerName = registerName;
	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}

	public String getUpdaterId() {
		return updaterId;
	}

	public void setUpdaterId(String updaterId) {
		this.updaterId = updaterId;
	}

	public String getUpdaterName() {
		return updaterName;
	}

	public void setUpdaterName(String updaterName) {
		this.updaterName = updaterName;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
}
