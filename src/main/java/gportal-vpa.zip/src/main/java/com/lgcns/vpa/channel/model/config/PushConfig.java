/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.config;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseModel;

/**
 * <pre>
 * 사용자 알림 (Notification) 설정 Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PushConfig extends BaseModel {

    /**
     * 사용자 ID
     */
    private String userId;
    
    /**
     * 봇 ID
     */
    private String botId;

    /**
     * 알림 항목 ID
     */
    private String pushId;

    /**
     * 알림 항목명
     */
    private String pushName;
    
    /**
     * 알림 영문명
     */
    private String pushEnglishName;
    
    /**
     * 알림 사용 여부
     */
    private String useYn;
    
    /**
     * 기본 사용 여부
     */
    private String defaultUseYn;
    
    /**
     * 표시 여부
     */
    private String displayYn;
    
    /**
     * 알림 유형 코드 (DAILY: 데일리, PUSH: 푸시, SYSTEM: 시스템 푸시)
     * @see com.lgcns.vpa.channel.model.config.ConfigCode
     */
    private String pushTypeCode;
        
    /**
     * 시스템 코드
     */
    private String systemCode;
    
    /**
     * 실제 수행되는 클래스/메소드/어노테이션 명
     */
    private String workerName;
    
    /**
     * 액션ID (다이얼로그 핸들러 액션 ID)
     */
    private String actionId;
    
    /**
     * 액션명
     */
    private String actionName;
    
    /**
     * 정렬 순서
     */
    private String sortOrder;
       
    /**
     * 설명
     */
    private String description;
    
    /**
     * 표시되는 설명
     */
    private String displayDescription;
    
    /**
     * 표시되는 영문 설명
     */
    private String displayEnglishDescription;
    
    /**
     * 상세 속성 설정 목록
     */
    List<PushConfigProperty> pushConfigProperties;
    
    /**
     * 사용자 로케일
     */
    private String localeCode;
    
    /**
     * 액션수행URI
     */
    private String actionUri;
    
    /**
     * IP 체크 여부
     */
    private String ipCheckYn;
    
    /**
     * IP 체크 결과
     */
    private boolean ipCheckResult;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public String getPushId() {
        return pushId;
    }

    public void setPushId(String pushId) {
        this.pushId = pushId;
    }

    public String getPushName() {
        return pushName;
    }

    public void setPushName(String pushName) {
        this.pushName = pushName;
    }

    public String getPushEnglishName() {
        return pushEnglishName;
    }

    public void setPushEnglishName(String pushEnglishName) {
        this.pushEnglishName = pushEnglishName;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getDefaultUseYn() {
        return defaultUseYn;
    }

    public void setDefaultUseYn(String defaultUseYn) {
        this.defaultUseYn = defaultUseYn;
    }

    public String getDisplayYn() {
        return displayYn;
    }

    public void setDisplayYn(String displayYn) {
        this.displayYn = displayYn;
    }

    public String getPushTypeCode() {
        return pushTypeCode;
    }

    public void setPushTypeCode(String pushTypeCode) {
        this.pushTypeCode = pushTypeCode;
    }

    public String getSystemCode() {
        return systemCode;
    }

    public void setSystemCode(String systemCode) {
        this.systemCode = systemCode;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public String getActionId() {
        return actionId;
    }

    public void setActionId(String actionId) {
        this.actionId = actionId;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDisplayDescription() {
        return displayDescription;
    }

    public void setDisplayDescription(String displayDescription) {
        this.displayDescription = displayDescription;
    }

    public String getDisplayEnglishDescription() {
        return displayEnglishDescription;
    }

    public void setDisplayEnglishDescription(String displayEnglishDescription) {
        this.displayEnglishDescription = displayEnglishDescription;
    }

    public List<PushConfigProperty> getPushConfigProperties() {
        return pushConfigProperties;
    }

    public void setPushConfigProperties(List<PushConfigProperty> pushConfigProperties) {
        this.pushConfigProperties = pushConfigProperties;
    }

	public String getLocaleCode() {
		return localeCode;
	}

	public void setLocaleCode(String localeCode) {
		this.localeCode = localeCode;
	}

	public String getActionUri() {
		return actionUri;
	}

	public void setActionUri(String actionUri) {
		this.actionUri = actionUri;
	}

	public String getIpCheckYn() {
		return ipCheckYn;
	}

	public void setIpCheckYn(String ipCheckYn) {
		this.ipCheckYn = ipCheckYn;
	}

	public boolean isIpCheckResult() {
		return ipCheckResult;
	}

	public void setIpCheckResult(boolean ipCheckResult) {
		this.ipCheckResult = ipCheckResult;
	}
    
    
}
