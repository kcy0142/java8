/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserAutoRunService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service;

/**
 * <PRE>
 * 개인별 자동 실행 설정버튼 표시 시간 설정 정보 조회 Service
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 12. 7.
 */
public interface UserAutoRunConfigService {
	
	/**
	 * 실행이 완료된 질의문의 응답에 사용자별 자동실행의 등록을 위한 버튼을 보여주는 시간인지 아닌지 조회   
	 * @param botId
	 * @return
	 */
	public boolean isDisplayAutoRunButton(String botId);
	
}
