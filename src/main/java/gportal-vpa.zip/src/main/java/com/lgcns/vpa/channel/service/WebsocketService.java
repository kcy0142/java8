/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : WebsocketService.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.channel.service;

import com.lgcns.vpa.channel.model.activity.Activity;

/**
 * <pre>
 * Websocket 서비스 Interface
 * <pre>
 * @author
 */
public interface WebsocketService {
	
	/**
	 * Websocket push 알림
	 * @param activity
	 */
	public void push(Activity activity);
	
	/**
	 * Websocket 전체 push 알림
	 * @param activity
	 */
	public void pushAll(Activity activity);
	
}
