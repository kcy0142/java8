/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ActionMongo.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <PRE>
 * Mongodb Test Model 정의
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Document(collection="actions")
public class ActionMongo extends BaseMongo {
	/*@Id
	private String id;*/
	
	private String intentId;		/* 의도 아이디 */
	private String actionId;		/* 액션 아이디 */
	private int actionType;			/* 액션 타입 */
	private int reqEmpNo;			/* 요청자 아이디 */
	private String reqEmpName;		/* 요청자 명 */
	private String reqDeptNo;		/* 요청자 부서아이디 */
	private String reqDeptName;		/* 요청자 부서명 */
	private String actionQuery;		/* 액션 쿼리*/
	private String[] parameterName;	/* 파라미터 명 */
	private String[] parameterValue;/* 파라미터 값 */
	
	@DateTimeFormat(iso=ISO.DATE_TIME)
	private Date registDate;
	
	@DateTimeFormat(iso=ISO.DATE_TIME)
	private Date updateDate;
	
	public ActionMongo(){}
	
	public ActionMongo(String messageId, String messageGroupId) {
		super(messageId, messageGroupId);
	}
	
	public ActionMongo(String messageId, String messageGroupId, String intentId, String actionId, int actionType, int reqEmpNo, String reqEmpName,
			String reqDeptNo, String reqDeptName, String actionQuery, String[] parameterName, String[] parameterValue) {
		super(messageId, messageGroupId);
		this.intentId = intentId;
		this.actionId = actionId;
		this.actionType = actionType;
		this.reqEmpNo = reqEmpNo;
		this.reqEmpName = reqEmpName;
		this.reqDeptNo = reqDeptNo;
		this.reqDeptName = reqDeptName;
		this.actionQuery = actionQuery;
		this.parameterName = parameterName;
		this.parameterValue = parameterValue;
		this.registDate = new Date();
		this.updateDate = registDate;
	}
	
	public ActionMongo(String messageId, String messageGroupId, String intentId, String actionId, int actionType, int reqEmpNo, String reqEmpName,
			String reqDeptNo, String reqDeptName, String actionQuery, String[] parameterName, String[] parameterValue,
			Date registDate, Date updateDate) {
		super(messageId, messageGroupId);
		this.intentId = intentId;
		this.actionId = actionId;
		this.actionType = actionType;
		this.reqEmpNo = reqEmpNo;
		this.reqEmpName = reqEmpName;
		this.reqDeptNo = reqDeptNo;
		this.reqDeptName = reqDeptName;
		this.actionQuery = actionQuery;
		this.parameterName = parameterName;
		this.parameterValue = parameterValue;
		this.registDate = registDate;
		this.updateDate = updateDate;
	}

	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public int getActionType() {
		return actionType;
	}

	public void setActionType(int actionType) {
		this.actionType = actionType;
	}

	public int getReqEmpNo() {
		return reqEmpNo;
	}

	public void setReqEmpNo(int reqEmpNo) {
		this.reqEmpNo = reqEmpNo;
	}

	public String getReqEmpName() {
		return reqEmpName;
	}

	public void setReqEmpName(String reqEmpName) {
		this.reqEmpName = reqEmpName;
	}

	public String getReqDeptNo() {
		return reqDeptNo;
	}

	public void setReqDeptNo(String reqDeptNo) {
		this.reqDeptNo = reqDeptNo;
	}

	public String getReqDeptName() {
		return reqDeptName;
	}

	public void setReqDeptName(String reqDeptName) {
		this.reqDeptName = reqDeptName;
	}

	public String getActionQuery() {
		return actionQuery;
	}

	public void setActionQuery(String actionQuery) {
		this.actionQuery = actionQuery;
	}

	public String[] getParameterName() {
		return parameterName;
	}

	public void setParameterName(String[] parameterName) {
		this.parameterName = parameterName;
	}

	public String[] getParameterValue() {
		return parameterValue;
	}

	public void setParameterValue(String[] parameterValue) {
		this.parameterValue = parameterValue;
	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	@Override
	public String toString() {
		/*return "ActionMongo [getId()=" + getId()+"getMessageId()=" + getMessageId() + ", getMessageGroupId()=" + getMessageGroupId()
				+ ", intentId=" + intentId + ", actionId=" + actionId + ", actionType=" + actionType
				+ ", reqEmpNo=" + reqEmpNo + ", reqEmpName=" + reqEmpName + ", reqDeptNo=" + reqDeptNo
				+ ", reqDeptName=" + reqDeptName + ", actionQuery=" + actionQuery + ", parameterName="
				+ Arrays.toString(parameterName) + ", parameterValue=" + Arrays.toString(parameterValue)
				+ ", registDate=" + registDate + ", updateDate=" + updateDate + "]";*/
		
		return this.toJson();
	}

	public String toJson () {
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(this);
		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}
}
