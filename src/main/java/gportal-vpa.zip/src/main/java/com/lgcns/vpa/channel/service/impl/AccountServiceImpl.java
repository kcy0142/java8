/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service.impl;

import com.lgcns.vpa.channel.dao.BotDao;
import com.lgcns.vpa.channel.dao.ConfigDao;
import com.lgcns.vpa.channel.model.Account;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.service.AccountService;
import com.lgcns.vpa.security.user.dao.UserDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * <pre>
 * 사용자 계정 관리 Service
 * </pre>
 * @author
 */
@Service("multi.accountService")
public class AccountServiceImpl implements AccountService {
    final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

    @Autowired
    MongoOperations mongoOperations;

    @Autowired
    UserDao userDao;

    @Autowired
    ConfigDao configDao;

    @Autowired
    private BotDao botDao;

	/**
	 * 사용자 계정 정보 조회
	 * @param userId
	 * @return
	 */
    @Override
    public Account retrieveAccount(String userId) {
        Account account = new Account();
        account.setUser(userDao.selectUser(userId));
        //Demo 사용자는 DEMO 봇을 고정으로 불어온다.
        String tenantId="";
        Bot userBot=botDao.selectUserBotDetail(tenantId, userId);
        
        
        if(userId.equals("demo")){
        	 account.setDefaultBot(botDao.selectDemoBotDetail());
        }else{
        	if (userBot==null) {
        		account.setDefaultBot(botDao.selectDefaultBotDetail());
        	}else{
        		account.setDefaultBot(userBot);
        	}
        	 
        }
       
        
        account.setBotList(botDao.selectBotList());
        return account;
    }
}
