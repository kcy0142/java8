/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ServiceLog;
import com.lgcns.vpa.security.user.model.User;

import java.util.List;

/**
 * <pre>
 * 액티비티 관리 Service
 * </pre>
 * @author
 */
public interface ActivityService {

    /**
     * 액티비티 저장
     * @param activity
     * @return
     */
    Activity insertActivity(Activity activity);
    
    /**
     * 특정 bot에서 발생된 activity를 모든 사용자 대화이력 기록
     * @param activity
     * @return
     */
    Activity insertAllActivity(Activity activity);
    
    /**
     * 액티비티 저장
     * @param activity
     * @return
     */
    Activity insertAllActivity(Activity requestActivity,Activity responseActivity);

    /**
     * 최근 액티비티 조회
     * @param botId
     * @param limit
     * @param user
     * @param includeDailyPush
     * @return
     */
    List<Activity> retrieveRecentActivityList(String botId, int limit, User user, boolean includeDailyPush);

    /**
     * 이전 액티비티 조회
     * @param botId
     * @param cursorId
     * @param limit
     * @param user
     * @param includeDailyPush
     * @return
     */
    List<Activity> retrieveBeforeActivityList(String botId, String cursorId, int limit, User user, boolean includeDailyPush);

    /**
     * 액티비티 카운트 조회
     * @param botId
     * @param user
     * @return
     */
    Integer retrieveActivityCount(String botId, User user);
    
    /**
     * 마지막 액티비티 조회
     * @param botId
     * @param user
     * @return
     */
    Activity retrieveLastActivity(String botId, User user);

    /**
     * 현 대화의 전체 액티비티 삭제
     * @param botId
     * @param user
     */
    void deleteAllActivities(String botId, User user);
    
    /**
     * 액티비티의 좋아요 및 피드백 저장
     * @param activity
     * @param user
     * @return
     */
    Activity updateFeedback(Activity activity, User user);
    
    /**
     * 사용자의 피드백 저장
     * @param activity
     * @param user
     * @return
     */
    Activity updateUserFeedback(Activity activity, User user);
    
    /**
     * 액티비티의 좋아요 및 피드백 조회
     * @param activityId
     * @param botId
     * @param user
     * @return
     */
    Activity retrieveFeedback(String activityId, String botId, User user);
    
    
    /**
     * 외부 서비스 저장
     * @param activity
     * @param user
     * @return
     */
    ServiceLog insertServiceLog(ServiceLog serviceLog, User user);
    
  
    /**
     * 메시지 읽음 상태 변경
     * @param activityId
     */
    void updateMessageRead(String botId, String userId, String activityId, String tempId);
    
    
    /**
     * 안읽음 메시지 갯수
     * @param userId
     * @return
     */
    long getUnreadCount(String botId, String userId);
    
    
    /**
     *readDate 업데이트
     * @param botId
     * @param userId
     */
    void updateReadDate(String botId, String userId);
    
    
    /**
     * 안읽은 push 메시지
     * @param botId
     * @param userId
     * @return
     */
    List<Activity> getUnreadPush(String botId,String userId);
    
    
    /**
     * 세션 조회
     * @param userId
     * @return
     */
    String  getRedisSession(String userId);
    
    
    /**
     * 세션삭제
     * @param userId
     * @return
     */
    String  removeSession(String userId);
    
    /**
     * 세션Id 조회
     * @param userId
     * @return
     */
    String  getRedisSessionId(String webSocketSessionId);
    
    /**
     * 배치관련 세션 조회
     * @return
     */
    List<Activity>  getRedisAllSession(String botId);
    
    /**
     * 배치관련 세션 조회
     * @return
     */
    List<Activity>  getRedisAllSessionTest(String botId);
}