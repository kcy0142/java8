package com.lgcns.vpa.push.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.config.ConfigCode;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.push.service.ConversationDailyPushService;
import com.lgcns.vpa.push.service.DailyPushService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 데일리 알림 Common Service
 * 등록된 액션 메타 데이터 기반으로 푸시 데이터를 조회
 * </pre>
 * @author
 */
@Service("multi.conversationDailyPushService")
public class ConversationDailyPushServiceImpl implements ConversationDailyPushService {
    
    final Logger logger = LoggerFactory.getLogger(ConversationDailyPushServiceImpl.class);
    
    @Autowired
    ConfigService configService;
    
    @Autowired
    private ApplicationContext context;
        
    /**
     * 데일리 알림 항목 조회
     * @param greetings
     * @param conversation
     * @param bot
     * @param user
     * @param tenantId
     */
    @Override
    public Activity executeDailyPush(Bot bot, User user, String tenantId) {
        Activity activity = null;

        // 데일리 알림 항목 조회
        PushConfig searchCondition = new PushConfig();
        searchCondition.setBotId(bot.getBotId());
        searchCondition.setUserId(user.getUserId());
        searchCondition.setPushTypeCode(ConfigCode.PUSH_TYPE_CODE_DAILY);

        List<PushConfig> dailyPushConfigs = configService.retrievePushConfigList(searchCondition,user);

        if (!CollectionUtils.isEmpty(dailyPushConfigs)) {
            activity = Activity.createBotMessage(bot.getBotId(), user.getUserId());
            
            activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_DAILY_PUSH);
            activity.setAttachmentLayout(ActivityCode.ATTACHMENT_LAYOUT_TYPE_ACCORDION);

            for (PushConfig pushConfig : dailyPushConfigs) {
                if ("Y".equals(pushConfig.getUseYn()) && !StringUtils.isEmpty(pushConfig.getWorkerName())) {
                    try {
                        DailyPushService dailyPushService = context.getBean(pushConfig.getWorkerName(), DailyPushService.class);
                        
                        List<Attachment> attachments = dailyPushService.execute(null, pushConfig, bot, user, tenantId);
                        if (!CollectionUtils.isEmpty(attachments)) {
                            activity.addAttachments(attachments.stream().filter(attachment -> attachment != null).collect(Collectors.toList()));
                        }

                    } catch (Exception e) {
                        logger.info(e.getMessage(), e);
                    }
                }
            }
        }

        return activity;
    }
}
