/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : AsyncConfig.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.base.config;

import java.util.concurrent.Executor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
public class AsyncConfig {

	@Bean(name = "threadPoolTaskExecutor")
    public Executor threadPoolTaskExecutor() {
		
		ThreadPoolTaskExecutor excutor = new ThreadPoolTaskExecutor();
		/*excutor.setCorePoolSize(10);
		excutor.setMaxPoolSize(20);
		excutor.setQueueCapacity(500);
		excutor.initialize();*/
		
		return excutor;
	}
}
