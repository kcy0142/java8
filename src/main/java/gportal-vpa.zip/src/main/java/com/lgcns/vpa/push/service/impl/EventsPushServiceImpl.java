package com.lgcns.vpa.push.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.model.config.PushConfigProperty;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.PushService;
import com.lgcns.vpa.security.user.model.Group;
import com.lgcns.vpa.security.user.service.GroupService;

/**
 * <pre>
 * 경조사 Push 알림 Service
 * </pre>
 * @author
 */
@Service("multi.eventsPushService")
public class EventsPushServiceImpl extends PushAbstractService implements PushService{
    
    @Autowired
	ActivityService activityService;
    
    @Autowired
    private ConfigService configService;
    
    @Autowired
    private GroupService groupService;
    
    @Autowired
    RedisMessagePublisher redisMessagePublisher;
	
    @Override
	public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig){
    	
    	String botId = params.get("botId");
    	String targetUserId =params.get("targetUserId");
    	String message = params.get("message");
    	String action = params.get("action");
    	String title = params.get("title");
    	String registName = params.get("registName");
    	String registDate = params.get("registDate");
    	
    	
    	checkBotId(botId);
		
		List<PushConfigProperty> pushConfigPropertyList = configService.retrievePushConfigPropertyAllUserList(pushConfig.getPushId(), null, null);
		List<Group> targetUserGroupList = groupService.selectParentGroupListByUser(targetUserId);
		
		for(PushConfigProperty pushUser:pushConfigPropertyList){
			boolean isSend = false;

			List<Group> pushUserGroupList = groupService.selectParentGroupListByUser(pushUser.getUserId());
			
			for(Group targetUserGroup:targetUserGroupList){
				for(Group pushUserGroup:pushUserGroupList){
					if(targetUserGroup.getGroupId().equals(pushUserGroup.getGroupId()) && StringUtils.isNotEmpty(targetUserGroup.getGroupLevel())){
						if(
								(pushUser.getPropertyValue().equals("TEAM") && targetUserGroup.getGroupLevel().equals("40"))||
								(pushUser.getPropertyValue().equals("UNIT") && (targetUserGroup.getGroupLevel().equals("30") || targetUserGroup.getGroupLevel().equals("20")))||
								(pushUser.getPropertyValue().equals("BUSINESS") && targetUserGroup.getGroupLevel().equals("10"))
							){
							isSend = true;
							//System.out.println("=====EventsPushServiceImpl========pushUser.getUserId:"+pushUser.getUserId()+",pushUser.getLocaleCode():"+pushUser.getLocaleCode());
							break;
						}
					}
				}
			}

			if(isSend){
				
				String localeCode = pushConfigPropertyList.stream()
		                .filter(x -> pushUser.getUserId().equals(x.getUserId()))
		                .map(PushConfigProperty::getLocaleCode)
		                .findAny()
		                .orElse("");
				
				Activity activity = createPushActivity(botId, pushUser.getUserId(), localeCode, message);
				
				Attachment attachment = new Attachment();
				
				attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
				attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
				
				Element element = new Element();
				element.setActionType(ActivityCode.ACTION_TYPE_LINK);
				element.setAction(action);
				element.setTitle(title);
				element.setDescriptions("등록자:"+registName);
				
				activity.addAdditionalProperty("title", message);
				activity.addAdditionalProperty("content", title);
				activity.addAdditionalProperty("url", action);
				
				attachment.addElement(element);
				activity.addAttachment(attachment);
				
				redisMessagePublisher.publish(activity);
			}
		}
    	
	}
	
}
