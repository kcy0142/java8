package com.lgcns.vpa.security.user.service;

import java.util.List;
import com.lgcns.vpa.security.user.model.User;

public interface UserService {
    /**
     * 사용자 조회
     * @param userId
     * @return
     * @throws Exception
     */
    User selectUser(String userId);

    /**
     * 사용자 목록 조회
     * @return
     * @throws Exception
     */
    List<User> selectUserList();
}
