/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : DialogueContext.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.lgcns.vpa.intent.entity.ParameterMap;
import com.lgcns.vpa.intent.exception.DialogueInvalidException;
import com.lgcns.vpa.intent.model.IntentBase;
import com.lgcns.vpa.intent.service.impl.IntentContext.DialogueContracts.Columns;
import com.lgcns.vpa.intent.util.JacksonUtils;
import com.lgcns.vpa.intent.model.IntentAnalysisResult.Status;

@Component("intentContext")
public class IntentContext {
	
	@Value("${intent.context.ttlminutes}")
	public long DIALOGUE_TTL;

	@Value("${intent.context.maxfail}")
	public int DIALOGUE_MAX_FAIL;
	
	@Autowired
	RedisTemplate redisTemplate;
	
	public void saveLastIntent(String tenantId, String userId, IntentBase intent) {
		
		//실패인 경우, 동일 의도인 경우 실패횟수를 기록하며, 
		//실패횟수가 임계치를 넘으면 문맥을 삭제한다.
		//동일 항목을 실패한 경우, 오류 메시지
		int failCnt = 0;
		if( (failCnt = failCount(intent, tenantId, userId)) > DIALOGUE_MAX_FAIL ) {
			expireIntent(tenantId, userId);
			throw new DialogueInvalidException("dialogue max");
		} 
		
		String key = DialogueContracts.dialogueKey(tenantId, userId);
		
		HashOperations<String, String, Object> hasOp = redisTemplate.opsForHash();
		
		hasOp.put(key, Columns.FAIL_CNT, failCnt);
		hasOp.put(key, Columns.BOT_ID, intent.getBotId());
		hasOp.put(key, Columns.INTENT_ID, intent.getIntentId());
		hasOp.put(key, Columns.INTENT_TYPE, intent.getIntentType());
		hasOp.put(key, Columns.STATUS, intent.getStatus());
		hasOp.put(key, Columns.ERROR_FIELD, intent.getStatus().getField());
		hasOp.put(key, Columns.CONTEXTS, intent.getContexts());
		hasOp.put(key, Columns.ENTITIES, intent.getEntities().toString());
		hasOp.put(key, Columns.AUTO_RUN, intent.isAutorun());

		redisTemplate.expire(key, DIALOGUE_TTL, TimeUnit.MINUTES);
	}
	
	/**
	 * 실패한 의도에 대해서 의도와 최근 대화의 실패여부와 횟수를 
	 * @param newIntent
	 * @param tenantId
	 * @param userId
	 * @return
	 */
	private int failCount(IntentBase newIntent, String tenantId, String userId) {
		
		if( newIntent.getStatus() == Status.COMPLETED || newIntent.getStatus() == Status.DUP_PARAMETER) {
			return 0;
		}
		
		HashOperations<String, String, Object> hasOp = redisTemplate.opsForHash();
		
		String key = DialogueContracts.dialogueKey(tenantId, userId);

		if( hasOp.hasKey(key, Columns.INTENT_ID) ) {
			Object intentId = hasOp.get(key, Columns.INTENT_ID);
			int failCnt = (Integer)hasOp.get(key, Columns.FAIL_CNT);
			Object errorField = hasOp.get(key, Columns.ERROR_FIELD);
			
			//만일 동일 의도에 항목에 대한 실패라면, fail count를 늘리고, 그렇지 않다면, return 0;
			if( newIntent.getIntentId().equals(intentId) && 
				newIntent.getStatus().getField().equals(errorField) ){
				return failCnt + 1;
			}
		} 
		return 1;
	}
	
	public IntentBase getLastIntent(String tenantId, String userId) {
		HashOperations<String, String, Object> hasOp = redisTemplate.opsForHash();
		Map<String, Object> message = hasOp.entries(DialogueContracts.dialogueKey(tenantId, userId));
		if( message.isEmpty()) {
			return null;
		}
		IntentBase recent = new IntentBase();
		recent.setBotId((String)message.get(Columns.BOT_ID));
		recent.setIntentId((String)message.get(Columns.INTENT_ID));
		recent.setIntentType((String)message.get(Columns.INTENT_TYPE));
		Status status = Status.valueOf((String)message.get(Columns.STATUS));
		status.setField((String)message.get(Columns.ERROR_FIELD));
		recent.setStatus(status);
		recent.setContexts((List)message.get(Columns.CONTEXTS));
		recent.setEntities(new ParameterMap((ObjectNode)JacksonUtils.read((String)message.get(Columns.ENTITIES))));
		recent.setAutorun((Boolean)message.get(Columns.AUTO_RUN));
		return recent;
	}
	
	public void expireIntent(String tenantId, String userId) {
		/*HashOperations<String, String, Object> hasOp = redisTemplate.opsForHash();
		hasOp.delete(DialogueContracts.dialogueKey(tenantId, userId), DialogueContracts.DIALOGUE_CONTEXT_FIELDS);*/
		String key = DialogueContracts.dialogueKey(tenantId, userId);
		//redisTemplate.expire(key, 0, TimeUnit.MINUTES);
		redisTemplate.delete(key);
	}
	
	
	interface DialogueContracts {
		public static final String DIALOGUE_CONTEXT_KEY = "%s:dialog:user:%s";
		
		public static final Object DIALOGUE_CONTEXT_FIELDS[] = new String[]{Columns.BOT_ID, Columns.INTENT_ID, Columns.STATUS, Columns.CONTEXTS, Columns.ENTITIES};
		public static String dialogueKey(String tenantId, String userId) {
			return String.format(DIALOGUE_CONTEXT_KEY, tenantId, userId);
		}
		
		public interface Columns {
			public static final String BOT_ID 		= "botId";
			public static final String INTENT_ID	= "intentId";
			public static final String INTENT_TYPE	= "intentType";
			public static final String STATUS 		= "status";
			public static final String ERROR_FIELD  = "errorField";
			public static final String CONTEXTS 	= "contexts";
			public static final String ENTITIES 	= "entities";
			public static final String FAIL_CNT 	= "failCount";
			public static final String AUTO_RUN     = "autorun";
		}
	}
}
