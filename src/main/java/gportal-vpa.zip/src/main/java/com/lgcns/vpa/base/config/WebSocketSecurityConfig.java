/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.base.config;

import java.net.InetAddress;
import java.security.Principal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

//import java.net.InetAddress;
//import java.security.Principal;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptorAdapter;
import org.springframework.messaging.support.MessageHeaderAccessor;
//import org.springframework.messaging.Message;
//import org.springframework.messaging.MessageChannel;
//import org.springframework.messaging.simp.config.ChannelRegistration;
//import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
//import org.springframework.messaging.support.ChannelInterceptorAdapter;
//import org.springframework.messaging.support.MessageHeaderAccessor;
//import org.springframework.data.redis.core.HashOperations;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.messaging.Message;
//import org.springframework.messaging.MessageChannel;
//import org.springframework.messaging.simp.config.ChannelRegistration;
//import org.springframework.messaging.simp.stomp.StompCommand;
//import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
//import org.springframework.messaging.support.ChannelInterceptorAdapter;
//import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.security.config.annotation.web.messaging.MessageSecurityMetadataSourceRegistry;
import org.springframework.security.config.annotation.web.socket.AbstractSecurityWebSocketMessageBrokerConfigurer;

/**
 * <pre>
 * WebSocket Security 설정
 * </pre>
 * @author
 */
@Configuration
public class WebSocketSecurityConfig extends AbstractSecurityWebSocketMessageBrokerConfigurer {
    final Logger logger = LoggerFactory.getLogger(WebSocketSecurityConfig.class);

    @Autowired
    RedisTemplate<String, Object> redisTemplate;
    
    @Override
    protected void configureInbound(MessageSecurityMetadataSourceRegistry messages) {
        messages
            .nullDestMatcher().authenticated()
            .simpMessageDestMatchers("/topic/chat.messages", "/topic/chat.notifications").authenticated()
            .anyMessage().authenticated();
    }

    /**
     * 인바운드 채널 커스터마이징
     * @param registration
     */
//    @Override
//    public void customizeClientInboundChannel(ChannelRegistration registration) {
//        registration.setInterceptors(new ChannelInterceptorAdapter() {
//            @Override
//            public Message<?> preSend(Message<?> message, MessageChannel channel) {
//                StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
//                
//                logger.info("=========================================================================================");
//                logger.info("[" + accessor.getCommand() + "] - " + message.toString());
//                logger.info("=========================================================================================");          
//                
//                return message;
//            }
//        });
//    }
    

    /**
     * FIXME: 운영서비스 시 삭제 할 것, 웹소켓 커넥션 확인을 위한 임시 코드
     */
    @Override
    public void customizeClientInboundChannel(ChannelRegistration registration) {
        registration.setInterceptors(new ChannelInterceptorAdapter() {
            @Override
            public Message<?> preSend(Message<?> message, MessageChannel channel) {
                StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
                
                logger.info("===============================WebSocketSecurityConfig===================================");
                logger.info("[" + accessor.getCommand() + "] ["+accessor.getUser().getName()+"]- " + message.toString());
                logger.info("=========================================================================================");

                try {
                    // CONNECT
                    if (StompCommand.CONNECT.equals(accessor.getCommand())) {
                        Principal user = accessor.getUser();
                        String sessionId = accessor.getSessionId();
                        
                        String port = System.getProperty("server.port");
                        
                        // SPRING.SESSION.ID=1e8c726e-a065-4bb5-ab9e-c2ceaa00c725
                        // WebSocket SessionId=rvjjydn1
                        InetAddress inetAddress = null;
                        try {
                            inetAddress = InetAddress.getLocalHost();
                        } catch (Exception e) {
                            
                        }
                                                
                        // 웹소켓 연결정보를 REDIS에 저장한다.
                        HashOperations<String, String, Object> hashOperation = redisTemplate.opsForHash();
                        Map<String, Object> data = new HashMap<>();
                        data.put("sessionId", String.valueOf(accessor.getSessionAttributes().get("SPRING.SESSION.ID")));
                        data.put("webSocketSessionId", sessionId);
                        data.put("port", port);
                        data.put("userId", user.getName());  
                        
                        if (inetAddress != null) {
                            data.put("hostName", inetAddress.getHostName());
                            data.put("hostAddress", inetAddress.getHostAddress());
                            data.put("canonicalHostName", inetAddress.getCanonicalHostName());
                        }
                        
                        data.put("creation", DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss").format(LocalDateTime.now()));
                        data.put("message", message);
                        data.put("accessor", accessor);                     
                        
                        String key = String.format("webscoket:%s", user.getName());

                        // 웹소켓 연결정보를 REDIS에 저장한다.
                        // TODO: 서버 노드 정보까지 빼올것 (-Dserver.node, -Dserver.port)
                        hashOperation.putAll(key, data); 
                        redisTemplate.expire(key, 1, TimeUnit.HOURS);
                        
                        // 웹소켓 기록
                        hashOperation = redisTemplate.opsForHash();
                        data = new HashMap<>();
                        data.put("sessionId", String.valueOf(accessor.getSessionAttributes().get("SPRING.SESSION.ID")));
                        data.put("webSocketSessionId", sessionId);
                        data.put("creation", DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss").format(LocalDateTime.now()));
                        data.put("message", message);
                        data.put("accessor", accessor);
                        data.put("port", port);
                        data.put("userId", user.getName());  
                        
                        if (inetAddress != null) {
                            data.put("hostName", inetAddress.getHostName());
                            data.put("hostAddress", inetAddress.getHostAddress());
                            data.put("canonicalHostName", inetAddress.getCanonicalHostName());
                        }                        
                        
                        key = String.format("webscoketsession:%s", sessionId);
                        
                        hashOperation.putAll(key, data); 
                        redisTemplate.expire(key, 1, TimeUnit.HOURS);
                        
                        // logger.info(data.toString());
                    }
                    // DISCONNECT                
                    else if (StompCommand.DISCONNECT.equals(accessor.getCommand())) {
                        Principal user = accessor.getUser();
                        String sessionId = accessor.getSessionId();
                        
                        logger.info(String.format("%s %s DISCONEECT", sessionId, user.getName()));
                        
                        // 웹소켓 연결정보를 REDIS에서 삭제한다.
                        String key = String.format("webscoket:%s", user.getName());
                        redisTemplate.expire(key, 0, TimeUnit.HOURS);
                        
                        key = String.format("webscoketsession:%s", sessionId);
                        redisTemplate.expire(key, 0, TimeUnit.HOURS);      
                    }                   
                } catch (Exception e) {
                    logger.info(e.getMessage(), e);
                }
                
                return message;
            }
        });
    }

    @Override
    protected boolean sameOriginDisabled() {
        return true;
    }
}