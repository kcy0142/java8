package com.lgcns.vpa.security.user.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.util.I18nUtils;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class User implements Serializable {
    private static final long serialVersionUID = -34383874856499169L;

    /**
     * 사용자 ID
     */
    private String userId;

    /**
     * 포탈 ID
     */
    private String portalId;

    /**
     * 사용자 Password(암호화됨)
     */
    private String userPassword;

    /**
     * 사용자의 재직구분(C:재직, H:휴직, T:퇴직)
     */
    private String userStatus;

    /**
     * 사용자의 사원번호
     */
    private String empNo;

    /**
     * 사용자의 이메일 주소
     */
    private String mail;

    /**
     * 사용자의 메일 패스워드
     */
    private String mailPassword;

    /**
     * 사용자의 이름
     */
    private String userName;

    /**
     * 사용자의 이름(읽기)
     */
    private String userNameRead;

    /**
     * 사용자의 영문 이름
     */
    private String userEnglishName;

    /**
     * 이 사용자가 해당된 부서(그룹) 이름
     */
    private String teamName;

    /**
     * 이 사용자가 해당된 부서(그룹) 영어 이름
     */
    private String teamEnglishName;

    /**
     * 사용자의 TIMEZONE ID(등록/업데이트시의 TIMEZONE ID)
     */
    private String timezoneId;

    /**
     * 사용자의 모바일폰 번호
     */
    private String mobile;

    /**
     * 사용자의 사무실 전화번호
     */
    private String officePhoneNo;

    /**
     * 사용자의 집 전화번호
     */
    private String homePhoneNo;

    /**
     * 사용자의 사무실 주소(기본)
     */
    private String officeBasicAddress;

    /**
     * 사용자의 사무실 주소(상세)
     */
    private String officeDetailAddress;

    /**
     * 사용자의 사무실 우편번호
     */
    private String officeZipcode;

    /**
     * 사용자의 집 주소(기본)
     */
    private String homeBasicAddress;

    /**
     * 사용자의 집 주소(상세)
     */
    private String homeDetailAddress;

    /**
     * 사용자의 집 우편번호
     */
    private String homeZipcode;

    /**
     * 사용자의 생일
     */
    private String birthday;

    /**
     * 사용자의 결혼 기념일
     */
    private String weddingAnniv;

    /**
     * 사용자의 사진 ID
     */
    private String pictureId;

    /**
     * 사용자의 프로필 사진 ID
     */
    private String profilePictureId;

    /**
     * 사용자의 프로필 사진 경로 (큰이미지)
     */
    private String picturePath;

    /**
     * 사용자의 프로필 사진 경로(작은이미지)
     */
    private String profilePicturePath;

    /**
     * 사용자의 팀장 여부(0: 팀장아님, 1: 팀장)
     */
    private int leader;

    /**
     * 사용자의 직군 코드
     */
    private String jobClassCode;

    /**
     * 해당 직군의 이름
     */
    private String jobClassName;

    /**
     * 사용자의 직급코드
     */
    private String jobRankCode;

    /**
     * 해당 직급코드의 이름
     */
    private String jobRankName;

    /**
     * 사용자의 직책코드
     */
    private String jobDutyCode;

    /**
     * 해당 직책코드의 이름
     */
    private String jobDutyName;

    /**
     * 사용자의 직위코드
     */
    private String jobPositionCode;

    /**
     * 해당 직위코드의 이름
     */
    private String jobPositionName;

    /**
     * 사용자의 호칭코드
     */
    private String jobTitleCode;

    /**
     * 해당 호칭코드의 이름
     */
    private String jobTitleName;

    /**
     * 사용자의 로케일코드
     */
    private String localeCode;

    /**
     * 해당 로케일코드의 이름
     */
    private String localeName;

    /**
     * 사용자의 트위터 계정
     */
    private String twitterAccount;

    /**
     * 트위터 인증 코드
     */
    private String twitterAuthCode;

    /**
     * 사용자의 페이스북 계정
     */
    private String facebookAccount;

    /**
     * 페이스북 인증 코드
     */
    private String facebookAuthCode;

    /**
     * 프로필 상태
     */
    private String profileStatus;

    /**
     * 현재 직무
     */
    private String currentJob;

    /**
     * 전문분야
     */
    private String expertField;

    /**
     * 이 사용자를 등록한 자의 ID
     */
    private String registerId;

    /**
     * 이 사용자를 등록한 자의 이름
     */
    private String registerName;

    /**
     * 이 사용자를 등록한 날짜
     */
    private Date registToDate;

    /**
     * 이 사용자의 정보를 업데이트한 자의 ID
     */
    private String updaterId;

    /**
     * 이 사용자의 정보를 업데이트한 자의 이름
     */
    private String updaterName;

    /**
     * 이 사용자의 정보를 업데이트한 날짜
     */
    private Date updateToDate;

    /**
     * 사용자의 국가 코드
     */
    private String nationCode;

    /**
     * 결재 비밀번호
     */
    private String approvalPassword;

    /**
     * 구글 연동 여부 : 1 - 연동
     */
    private int isGoogle;

    /**
     * 사용자 팩스번호
     */
    private String officeFaxNo;	

    /**
     * Mail Server 정보 (물리 서버)
     */
    private String mailServer;

    /**
     * Mail Domain 정보 (도메인 정보)
     */
    private String mailDomain;

    /**
     * Mail Server Domain 정보 (LG 화학의 경우, Exchange 서버 정보)
     */
    private String mailDomainServer;

    /**
     * 국가 지역번호
     */
    private String phoneLocationNo;

    /**
     * Domino Mail 사용자 Path
     */
    private String mailPath;

    /**
     * Attribute1
     */
    private String attr1;

    /**
     * Attribute2
     */
    private String attr2;

    /**
     * Attribute3
     */
    private String attr3;

    /**
     * Attribute4
     */
    private String attr4;

    /**
     * Attribute5
     */
    private String attr5;

    private String tenantId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPortalId() {
        return portalId;
    }

    public void setPortalId(String portalId) {
        this.portalId = portalId;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public String getEmpNo() {
        return empNo;
    }

    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getMailPassword() {
        return mailPassword;
    }

    public void setMailPassword(String mailPassword) {
        this.mailPassword = mailPassword;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserNameRead() {
        return userNameRead;
    }

    public void setUserNameRead(String userNameRead) {
        this.userNameRead = userNameRead;
    }

    public String getUserEnglishName() {
        return userEnglishName;
    }

    public void setUserEnglishName(String userEnglishName) {
        this.userEnglishName = userEnglishName;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getTeamEnglishName() {
        return teamEnglishName;
    }

    public void setTeamEnglishName(String teamEnglishName) {
        this.teamEnglishName = teamEnglishName;
    }

    public String getTimezoneId() {
        return timezoneId;
    }

    public void setTimezoneId(String timezoneId) {
        this.timezoneId = timezoneId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getOfficePhoneNo() {
        return officePhoneNo;
    }

    public void setOfficePhoneNo(String officePhoneNo) {
        this.officePhoneNo = officePhoneNo;
    }

    public String getHomePhoneNo() {
        return homePhoneNo;
    }

    public void setHomePhoneNo(String homePhoneNo) {
        this.homePhoneNo = homePhoneNo;
    }

    public String getOfficeBasicAddress() {
        return officeBasicAddress;
    }

    public void setOfficeBasicAddress(String officeBasicAddress) {
        this.officeBasicAddress = officeBasicAddress;
    }

    public String getOfficeDetailAddress() {
        return officeDetailAddress;
    }

    public void setOfficeDetailAddress(String officeDetailAddress) {
        this.officeDetailAddress = officeDetailAddress;
    }

    public String getOfficeZipcode() {
        return officeZipcode;
    }

    public void setOfficeZipcode(String officeZipcode) {
        this.officeZipcode = officeZipcode;
    }

    public String getHomeBasicAddress() {
        return homeBasicAddress;
    }

    public void setHomeBasicAddress(String homeBasicAddress) {
        this.homeBasicAddress = homeBasicAddress;
    }

    public String getHomeDetailAddress() {
        return homeDetailAddress;
    }

    public void setHomeDetailAddress(String homeDetailAddress) {
        this.homeDetailAddress = homeDetailAddress;
    }

    public String getHomeZipcode() {
        return homeZipcode;
    }

    public void setHomeZipcode(String homeZipcode) {
        this.homeZipcode = homeZipcode;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getWeddingAnniv() {
        return weddingAnniv;
    }

    public void setWeddingAnniv(String weddingAnniv) {
        this.weddingAnniv = weddingAnniv;
    }

    public String getPictureId() {
        return pictureId;
    }

    public void setPictureId(String pictureId) {
        this.pictureId = pictureId;
    }

    public String getProfilePictureId() {
        return profilePictureId;
    }

    public void setProfilePictureId(String profilePictureId) {
        this.profilePictureId = profilePictureId;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public void setPicturePath(String picturePath) {
        this.picturePath = picturePath;
    }

    public String getProfilePicturePath() {
        return profilePicturePath;
    }

    public void setProfilePicturePath(String profilePicturePath) {
        this.profilePicturePath = profilePicturePath;
    }

    public int getLeader() {
        return leader;
    }

    public void setLeader(int leader) {
        this.leader = leader;
    }

    public String getJobClassCode() {
        return jobClassCode;
    }

    public void setJobClassCode(String jobClassCode) {
        this.jobClassCode = jobClassCode;
    }

    public String getJobClassName() {
        return jobClassName;
    }

    public void setJobClassName(String jobClassName) {
        this.jobClassName = jobClassName;
    }

    public String getJobRankCode() {
        return jobRankCode;
    }

    public void setJobRankCode(String jobRankCode) {
        this.jobRankCode = jobRankCode;
    }

    public String getJobRankName() {
        return jobRankName;
    }

    public void setJobRankName(String jobRankName) {
        this.jobRankName = jobRankName;
    }

    public String getJobDutyCode() {
        return jobDutyCode;
    }

    public void setJobDutyCode(String jobDutyCode) {
        this.jobDutyCode = jobDutyCode;
    }

    public String getJobDutyName() {
        return jobDutyName;
    }

    public void setJobDutyName(String jobDutyName) {
        this.jobDutyName = jobDutyName;
    }

    public String getJobPositionCode() {
        return jobPositionCode;
    }

    public void setJobPositionCode(String jobPositionCode) {
        this.jobPositionCode = jobPositionCode;
    }

    public String getJobPositionName() {
        return jobPositionName;
    }

    public void setJobPositionName(String jobPositionName) {
        this.jobPositionName = jobPositionName;
    }

    public String getJobTitleCode() {
        return jobTitleCode;
    }

    public void setJobTitleCode(String jobTitleCode) {
        this.jobTitleCode = jobTitleCode;
    }

    public String getJobTitleName() {
        return jobTitleName;
    }

    public void setJobTitleName(String jobTitleName) {
        this.jobTitleName = jobTitleName;
    }

    public String getLocaleCode() {
        // if (localeCode == null || "".equals(localeCode)) return I18nUtils.DEFAULT_LOCALE_CODE;
        // else return localeCode;
        // 다 필요없고 무조건 한국어로 리턴 (번역 등 글로벌 환경 세팅되면 사용할 것)
        return I18nUtils.DEFAULT_LOCALE_CODE;
    }

    public void setLocaleCode(String localeCode) {
        this.localeCode = localeCode;
    }

    public String getLocaleName() {
        return localeName;
    }

    public void setLocaleName(String localeName) {
        this.localeName = localeName;
    }

    public String getTwitterAccount() {
        return twitterAccount;
    }

    public void setTwitterAccount(String twitterAccount) {
        this.twitterAccount = twitterAccount;
    }

    public String getTwitterAuthCode() {
        return twitterAuthCode;
    }

    public void setTwitterAuthCode(String twitterAuthCode) {
        this.twitterAuthCode = twitterAuthCode;
    }

    public String getFacebookAccount() {
        return facebookAccount;
    }

    public void setFacebookAccount(String facebookAccount) {
        this.facebookAccount = facebookAccount;
    }

    public String getFacebookAuthCode() {
        return facebookAuthCode;
    }

    public void setFacebookAuthCode(String facebookAuthCode) {
        this.facebookAuthCode = facebookAuthCode;
    }

    public String getProfileStatus() {
        return profileStatus;
    }

    public void setProfileStatus(String profileStatus) {
        this.profileStatus = profileStatus;
    }

    public String getCurrentJob() {
        return currentJob;
    }

    public void setCurrentJob(String currentJob) {
        this.currentJob = currentJob;
    }

    public String getExpertField() {
        return expertField;
    }

    public void setExpertField(String expertField) {
        this.expertField = expertField;
    }

    public String getRegisterId() {
        return registerId;
    }

    public void setRegisterId(String registerId) {
        this.registerId = registerId;
    }

    public String getRegisterName() {
        return registerName;
    }

    public void setRegisterName(String registerName) {
        this.registerName = registerName;
    }

    public Date getRegistToDate() {
        return registToDate;
    }

    public void setRegistToDate(Date registToDate) {
        this.registToDate = registToDate;
    }

    public String getUpdaterId() {
        return updaterId;
    }

    public void setUpdaterId(String updaterId) {
        this.updaterId = updaterId;
    }

    public String getUpdaterName() {
        return updaterName;
    }

    public void setUpdaterName(String updaterName) {
        this.updaterName = updaterName;
    }

    public Date getUpdateToDate() {
        return updateToDate;
    }

    public void setUpdateToDate(Date updateToDate) {
        this.updateToDate = updateToDate;
    }

    public String getNationCode() {
        return nationCode;
    }

    public void setNationCode(String nationCode) {
        this.nationCode = nationCode;
    }

    public String getApprovalPassword() {
        return approvalPassword;
    }

    public void setApprovalPassword(String approvalPassword) {
        this.approvalPassword = approvalPassword;
    }

    public int getIsGoogle() {
        return isGoogle;
    }

    public void setIsGoogle(int isGoogle) {
        this.isGoogle = isGoogle;
    }

    public String getOfficeFaxNo() {
        return officeFaxNo;
    }

    public void setOfficeFaxNo(String officeFaxNo) {
        this.officeFaxNo = officeFaxNo;
    }

    public String getMailServer() {
        return mailServer;
    }

    public void setMailServer(String mailServer) {
        this.mailServer = mailServer;
    }

    public String getMailDomain() {
        return mailDomain;
    }

    public void setMailDomain(String mailDomain) {
        this.mailDomain = mailDomain;
    }

    public String getMailDomainServer() {
        return mailDomainServer;
    }

    public void setMailDomainServer(String mailDomainServer) {
        this.mailDomainServer = mailDomainServer;
    }

    public String getPhoneLocationNo() {
        return phoneLocationNo;
    }

    public void setPhoneLocationNo(String phoneLocationNo) {
        this.phoneLocationNo = phoneLocationNo;
    }

    public String getMailPath() {
        return mailPath;
    }

    public void setMailPath(String mailPath) {
        this.mailPath = mailPath;
    }

    public String getAttr1() {
        return attr1;
    }

    public void setAttr1(String attr1) {
        this.attr1 = attr1;
    }

    public String getAttr2() {
        return attr2;
    }

    public void setAttr2(String attr2) {
        this.attr2 = attr2;
    }

    public String getAttr3() {
        return attr3;
    }

    public void setAttr3(String attr3) {
        this.attr3 = attr3;
    }

    public String getAttr4() {
        return attr4;
    }

    public void setAttr4(String attr4) {
        this.attr4 = attr4;
    }

    public String getAttr5() {
        return attr5;
    }

    public void setAttr5(String attr5) {
        this.attr5 = attr5;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }



}
