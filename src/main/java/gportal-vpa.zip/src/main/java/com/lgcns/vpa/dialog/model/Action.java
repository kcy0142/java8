/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : Action.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.query.Update;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <PRE>
 * Action Data 를 MongoDB에서 관리할 VO
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 6. 9.
 */
@Document(collection="actions")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Action {
	@Id
	private String id;
	
	/**
	 * 연결된 intent id
	 */
	@Indexed
	private String intentId;
	
	/**
	 * Log 추적용 inquiry id
	 */
	private String inquiryId;
	
	/**
	 * Action 고유의 아이디
	 */
	@Indexed
	private String actionId;
	
	/**
	 * Action 별 실행 Dialog 명
	 */
	private String actionDialogName;
	
	/**
	 * Action Type ( ex) sql-sp, sql, rest 등)
	 */
	private String actionType;
	
	/**
	 * Backend Proxy 에서 실행될 from uri
	 */
	private String actionUri;
	
	/**
	 * Action 실행된 후의 응답 Template
	 */
	private String responseTemplate;
	
	/**
	 * 응답 Template 의 Activity Type 
	 * ex) message, search 등
	 */
	private String activityType;
	
	/**
	 * 응답 Template 의 Ativity.Attachment Type 
	 * ex) template, image, audio, video
	 */
	private String attachmentType;
	
	/**
	 * 응답 Template 의 Ativity.Attachment Template Type
	 * ex) list, table, planner_list, user_profile, text, congratulation, detail_list
	 */
	private String attachmentTemplateType;
	
	/**
	 * 응답 Template 의 Ativity.Attachment.Element Type
	 * ex) text, people
	 */
	private String elementType;
	
	/**
	 * 응답 Template 와 Data Resultset 의 컬럼명의 Mapping Data, JsonType
	 * ex) [{\"positionInRow\":0, \"classNames\":\"noti\", \"vpaField\":\"title\", \"dataFields\":[\"subject\", \"subject2\"]}, {\"positionInRow\":0, ....}]
	 */
	private String mapper;
	
	/**
	 * 응답 Template 와 Data Resultset 의 컬럼명의 Mapping Type
	 * @see com.lgcns.vpa.dialog.common.SINGLE_ELEMENT_INROW, com.lgcns.vpa.dialog.common.MULTI_ELEMENT_INROW
	 */
	private int mapperType;
	
	/**
	 * Action 을 사용하는 회사코드
	 */
	private String companyCode;
	
	/**
	 * Action 을 사용하는 챗봇 구분 id
	 */
	private String botId;
	
	/* 여기서부터 하위로는 공통임. 
	 * 추후에 공통 Parent 에서 상속하는 것으로 처리*/
	
	/**
	 * 생성자 userId
	 */
	private String registerId;
	
	/**
	 * 생성자 명
	 */
	private String registerName;
	
	/**
	 * 생성일자
	 */
	private Date registDate;
	
	/**
	 * 수정자 userId
	 */
	private String updaterId;
	
	/**
	 * 수정자 명
	 */
	private String updaterName;
	
	/**
	 * 수정일자
	 */
	private Date updateDate;

	public Action() {}
	
	public Action(String companyCode, String botId) {
		this.companyCode = companyCode;
		this.botId = botId;
	}
		
	public Action(String intentId, String inquiryId, String actionId, String actionDialogName,
			String actionType, String actionUri, String activityType, String attachmentType, String attachmentTemplateType, 
			String elementType, String responseTemplate, String companyCode, String botId, String registerId,
			String registerName, String updaterId, String updaterName) {
		super();
		this.intentId = intentId;
		this.inquiryId = inquiryId;
		this.actionId = actionId;
		this.actionDialogName = actionDialogName;
		this.actionType = actionType;
		this.actionUri = actionUri;
		this.responseTemplate = responseTemplate;
		this.activityType = activityType;
		this.attachmentType = attachmentType;
		this.attachmentTemplateType = attachmentTemplateType;
		this.elementType = elementType;
		this.companyCode = companyCode;
		this.botId = botId;
		this.registerId = registerId;
		this.registerName = registerName;
		this.updaterId = updaterId;
		this.updaterName = updaterName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}

	public String getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(String inquiryId) {
		this.inquiryId = inquiryId;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public String getActionDialogName() {
		return actionDialogName;
	}

	public void setActionDialogName(String actionDialogName) {
		this.actionDialogName = actionDialogName;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getActionUri() {
		return actionUri;
	}

	public void setActionUri(String actionUri) {
		this.actionUri = actionUri;
	}

	public String getResponseTemplate() {
		return responseTemplate;
	}

	public void setResponseTemplate(String responseTemplate) {
		this.responseTemplate = responseTemplate;
	}

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public String getAttachmentTemplateType() {
		return attachmentTemplateType;
	}

	public void setAttachmentTemplateType(String attachmentTemplateType) {
		this.attachmentTemplateType = attachmentTemplateType;
	}

	public String getElementType() {
		return elementType;
	}

	public void setElementType(String elementType) {
		this.elementType = elementType;
	}
	
	public String getMapper() {
		return mapper;
	}

	public void setMapper(String mapper) {
		this.mapper = mapper;
	}
	
	public int getMapperType() {
		return mapperType;
	}

	public void setMapperType(int mapperType) {
		this.mapperType = mapperType;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getRegisterName() {
		return registerName;
	}

	public void setRegisterName(String registerName) {
		this.registerName = registerName;
	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}

	public String getUpdaterId() {
		return updaterId;
	}

	public void setUpdaterId(String updaterId) {
		this.updaterId = updaterId;
	}

	public String getUpdaterName() {
		return updaterName;
	}

	public void setUpdaterName(String updaterName) {
		this.updaterName = updaterName;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * 수정용 Parameter 인 Update Object 생성
	 * @return
	 */
	public Update getUpdateObject () {
		
		Update update = new Update();
		update.set("intentId", this.intentId);
		update.set("inquiryId", this.inquiryId);
		update.set("actionId", this.actionId);
		update.set("actionDialogName", this.actionDialogName);
		update.set("actionType", this.actionType);
		update.set("actionUri", this.actionUri);
		update.set("activityType", this.activityType);
		update.set("attachmentType", this.attachmentType);
		update.set("attachmentTemplateType", this.attachmentTemplateType);
		update.set("elementType", this.elementType);
		update.set("mapper", this.mapper);
		update.set("mapperType", this.mapperType);
		update.set("responseTemplate", this.responseTemplate);
		update.set("companyCode", this.companyCode);
		update.set("botId", this.botId);
		update.set("updaterId", this.updaterId);
		update.set("updaterName", this.updaterName);
		update.set("updateDate", new Date(System.currentTimeMillis()));
		
		return update;
	}

	/**
	 * Json Data 생성
	 * @return
	 */
	public String toJson () {
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(this);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}

	@Override
	public String toString() {
		return "Action [id=" + id + ", intentId=" + intentId + ", inquiryId=" + inquiryId + ", actionId=" + actionId
				+ ", actionDialogName=" + actionDialogName + ", actionType=" + actionType + ", actionUri=" + actionUri
				+ ", responseTemplate=" + responseTemplate + ", activityType=" + activityType + ", attachmentType="
				+ attachmentType + ", attachmentTemplateType=" + attachmentTemplateType + ", elementType=" + elementType
				+ ", mapper=" + mapper + ", mapperType=" + mapperType + ", companyCode=" + companyCode + ", botId="
				+ botId + ", registerId=" + registerId + ", registerName=" + registerName + ", registDate=" + registDate
				+ ", updaterId=" + updaterId + ", updaterName=" + updaterName + ", updateDate=" + updateDate + "]";
	}
	
}
