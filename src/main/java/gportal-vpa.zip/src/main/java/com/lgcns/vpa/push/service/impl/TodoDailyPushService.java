/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.push.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.model.config.PushConfigProperty;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.push.service.DailyPushService;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.ActivityCode;

/**
 * <pre>
 * 마감 To-Do Push Service
 * </pre>
 * @author
 */
@Service("multi.todoDailyPushService")
public class TodoDailyPushService extends PushAbstractService implements DailyPushService {

    final Logger logger = LoggerFactory.getLogger(TodoDailyPushService.class);
    
    /**
     * LG CNS To-Do 조회 SQL
     * 실행예시: EXEC APPRDB.appr_user.IAMWP_TODO_LIST '70976', 'N', 'N', 'N', 'N', 'N', '20170806', '20170906', '', '', '', 'V', '70976'
     */
    
    private static final String TODO_CALL_FG = "V";
    
    @Autowired
    private MessageSource messageSource;
    
    @Override
    public List<Attachment> execute(Map<String, String> param, PushConfig pushConfig, Bot bot, User user, String tenantId) {
                
       
         
         TransferSyncVO transferSyncVO = new TransferSyncVO();
         transferSyncVO.setActionUri(pushConfig.getActionUri());
         transferSyncVO.setTenantId(tenantId);
        
        Map<String, Object> actionParam = new HashMap<>();
        actionParam.put("EmpNo", user.getUserId());
        actionParam.put("IncludeWork", "N");
        actionParam.put("IncludeAfter", "N");
        actionParam.put("IncludeRef", "N");
        actionParam.put("IncludeMdt", "N");
        actionParam.put("State", "N");
        
        LocalDate now = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd").withLocale(Locale.KOREAN);

        // 지연 건 포함여부
        // 지연 알림 포함여부 (Y:포함, N:미포함)
        boolean includeDelay = false;
        List<PushConfigProperty> pushConfigProperties = pushConfig.getPushConfigProperties();
        PushConfigProperty configProperty = pushConfigProperties.stream()
                .filter(property -> "TODO_DELAYED_YN".equals(property.getPropertyCode()))
                .findFirst().orElse(null);
        
        if (configProperty != null) {
            String value = StringUtils.isEmpty(configProperty.getPropertyValue()) ? 
                    configProperty.getDefaultPropertyValue() : configProperty.getPropertyValue();
            
            // 지연건 포함인 경우, 한달 내 지연 건 조회
            if ("Y".equals(value)) {
                includeDelay = true;
                actionParam.put("FromDT", formatter.format(now.minusMonths(1)));
            } 
            // 지연건 미포함인 경우, 금일 종료 건 조회
            else {
                actionParam.put("FromDT", formatter.format(now));
            }
        } else {
            actionParam.put("FromDT", formatter.format(now));
        }
                
        actionParam.put("EndDT", formatter.format(now));
        actionParam.put("KeyType", "");
        actionParam.put("Keyword", "");
        actionParam.put("SysCd", "");
        actionParam.put("CallFg", TODO_CALL_FG);
        actionParam.put("LoginEmpNo", user.getUserId());
        
        transferSyncVO.setActionParam(actionParam);
        
        List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
        List<Attachment> attachments = null;

        if (!CollectionUtils.isEmpty(proxyResultSet)) {
            Attachment attachment = new Attachment();
            attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
            attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
            attachment.setTitle(pushConfig.getPushName());
            
            // 타이틀 처리
            // 데이터가 있는 경우
            if (proxyResultSet != null && proxyResultSet.size() > 0) {
                // 금일 마감 또는 지연된 건이 {0}개 있습니다.
                if (includeDelay) {
                    attachment.setDescriptions(
                            messageSource.getMessage("meesage.push.daily.todo.descriptions1", 
                                    new String[]{StringUtils.toString(proxyResultSet.size())},
                                    new Locale(user.getLocaleCode())));
                } 
                // 금일 마감 건이 {0}개 있습니다.
                else {
                    attachment.setDescriptions(
                            messageSource.getMessage("meesage.push.daily.todo.descriptions2",
                                    new String[]{StringUtils.toString(proxyResultSet.size())},
                                    new Locale(user.getLocaleCode())));
                }
            }
            // 데이터가 없는 경우
            else {
                // 금일 마감 또는 지연된 건이 없습니다.
                if (includeDelay) {
                    attachment.setDescriptions(
                            messageSource.getMessage("meesage.push.daily.todo.nodata1",
                                    null,
                                    new Locale(user.getLocaleCode()))); 
                } 
                // 금일 마감 건이 없습니다.
                else {
                    attachment.setDescriptions(
                            messageSource.getMessage("meesage.push.daily.todo.nodata2",
                                    null,
                                    new Locale(user.getLocaleCode())));
                }
            }

            DateTimeFormatter resultFormatter = DateTimeFormatter.ofPattern("yyyy.MM.dd").withLocale(Locale.KOREAN);
            String today = resultFormatter.format(now);
            
            List<Element> elements = proxyResultSet.stream().map(data -> new Element() {
                
                private static final long serialVersionUID = -4803937536892622504L;
                {
                    this.setSubtitle(StringUtils.toString(data.get("TODO_TYPE_NM")));
                    this.setTitle(StringUtils.toString(data.get("TODO_REQ_NM")));
                    
                    StringBuffer descriptions = new StringBuffer();
                    
                    if (!StringUtils.isEmpty(data.get("APPR_SYS_NM"))) {
                        descriptions.append(data.get("APPR_SYS_NM"));
                    }
                    
                    if (!StringUtils.isEmpty(data.get("EMP_NM"))) {
                        if (!StringUtils.isEmpty(data.get("APPR_SYS_NM"))) {
                            descriptions.append(" | ");
                        }
                        descriptions.append(data.get("EMP_NM"));
                    }
                    
                    if (!StringUtils.isEmpty(data.get("TODO_END_DT"))) {
                        if (!StringUtils.isEmpty(data.get("EMP_NM"))) {
                            descriptions.append(" | ");
                        }
                        descriptions.append(data.get("TODO_END_DT"));
                    }
                    
                    this.setDescriptions(descriptions.toString());
                    this.setActionType(ActivityCode.ACTION_TYPE_LINK);
                    this.setAction(StringUtils.toString(data.get("TODO_LINK")));
                    
                    // To-Do 상태 표시
                    this.setValue(StringUtils.toString(data.get("TODO_STATUS")));
                    try {
                        String endDateString = StringUtils.toString(data.get("TODO_END_DT"));
       
                        // 지연: 지연 {0}일
                        if ("1".equals(StringUtils.toString(data.get("DELAY_FLAG")))) {
                            this.setClassNames("warning");
                            
                            if (!StringUtils.isEmpty(endDateString)) {
                                long days = ChronoUnit.DAYS.between(LocalDate.parse(endDateString, resultFormatter), now);
                                
                                if (days > 0) {
                                    this.setValue(messageSource.getMessage("meesage.push.daily.todo.delayDay", new String[] {StringUtils.toString(days)}, new Locale(user.getLocaleCode())));
                                }
                            }
                        } 
                        // 금일 마감
                        else if (today.equals(endDateString)) {
                            this.setValue(messageSource.getMessage("meesage.push.daily.todo.today", null, new Locale(user.getLocaleCode())));   
                        }
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                }
            }).collect(Collectors.toList());
            
            attachment.setElements(elements);
            attachments = Arrays.asList(attachment);
        }
        
        return attachments;
    }
}
