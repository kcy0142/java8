/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : TeamInputRateDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.LegacyConfig;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.service.NettyPoolClientService;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * 팀투입률조회 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 12. 19.
 */
@Component("TeamInputRateDialog")
public class TeamInputRateDialog extends LogicDialog {

	private static final Logger LOG = LoggerFactory.getLogger(TeamInputRateDialog.class);

	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private NettyPoolClientService nettyPoolClientService;
	
	@Autowired
	private BotService botService;
	
	@Autowired
	ConfigService configService;
	
	
	
	
	@Override
	protected String processor(InquiryVO data) {
		
		if ( (data == null) || (data.getAction() == null) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 정보가 부정확함");
			return null;
		}
		
			
		return "TeamInputRateDialog Process Result";
	}

	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
		
		String legacyCode="TEAM";
    	List<LegacyConfig> teamLegacyList=configService.retrieveLegacyConfigList(legacyCode);
    	
    	//System.out.println("############## teamLegacyList.size():"+teamLegacyList.size());
		
		//Backend Proxy 에 Data 요청 (동기식 처리)
		TransferSyncVO transferVO = null;
		String [] resultJsonData = new String[teamLegacyList.size()];
		long currentTime = System.currentTimeMillis();
		
		//Legacy 질의 요청
		try {
			transferVO = new TransferSyncVO(data);
			
			//1.팀투입률 전월/당월/누계 각항목 서비스 조회
			//2.팀 Effort 입력자 목록 조회
			//3.팀투입 O/L variance 인원 명단 조회
			int i = 0;
			for( LegacyConfig legacyConfig : teamLegacyList ) {
				//System.out.println("######## legacyConfig getDescription:"+legacyConfig.getDescription()+",getActionUri:"+legacyConfig.getActionUri());
				transferVO.setActionUri(legacyConfig.getActionUri());
				
				resultJsonData[i] = this.nettyPoolClientService.sendToBnpSync(transferVO);
				i=i+1;
			}
			
			/*
			for ( int i = 0; i < ACTION_URI.length; i++) {
				transferVO.setActionUri(ACTION_URI[i]);
				
				resultJsonData[i] = this.nettyPoolClientService.sendToBnpSync(transferVO);
			}
			*/
			
			
			data.setSpentTimeProxy(System.currentTimeMillis() - currentTime);
						
		} catch (Exception e) {
			
			data.setSpentTimeProxy(System.currentTimeMillis() - currentTime);
			
			//오류 발생
			resultJsonData[0] = CommonCode.ACTION_RESULT_ERROR;
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], spentTimeProxy:["+data.getSpentTimeProxy()+"], Proxy 정보 조회 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
			
			return resultActivity;
		}
		
		//Legacy 질의 결과 처리
		try {
			
			if ( resultJsonData.length > 0 ) {
				
				resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
				
				List<Attachment> attachments = null;
				List<Map<String, Object>> proxyResultSet1 =  null;
				List<Map<String, Object>> proxyResultSet2 =  null;
				List<Map<String, Object>> proxyResultSet3 =  null;
				
				TransferSyncVO responseVO = null;
				ObjectMapper mapper = new ObjectMapper();
				
				for (int i = 0; i < resultJsonData.length; i++) {
					if ( StringUtils.isEmpty(resultJsonData[i] ) ) {
						continue;
					}
					
					responseVO = mapper.readValue(resultJsonData[i], TransferSyncVO.class);
					
					//1.팀투입률 전월/당월/누계 각항목 서비스 조회
					//2.팀 Effort 입력자 목록 조회
					//3.팀투입 O/L variance 인원 명단 조회
					if (responseVO != null) {
						switch (i) {
						case 0:
							proxyResultSet1 = responseVO.getActionResult();
							break;
						case 1:
							proxyResultSet2 = responseVO.getActionResult();
							break;
						case 2:
							proxyResultSet3 = responseVO.getActionResult();
							break;
						}
					}
				}//for
				
				attachments = this.getAttachment(data, proxyResultSet1, proxyResultSet2, proxyResultSet3);
				
				if ( (attachments != null) && (!attachments.isEmpty()) ) {
					resultActivity.setAttachments(attachments);
					resultActivity.setMessage(data.getIntentMessage());
				}
				else {
					LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
					
					//Data 가 없음
		        	resultActivity = this.commonResponeService.simpleResponseMessage(
							data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
							this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
				}
				
				//의도분석의 Button이 있는 경우 처리
				if ( data.getIntentButtons() != null ) {
					List<RelatedButton> buttons = data.getIntentButtons();
					List<Button> activityButtonList = super.makeActivityButtonList(buttons);
					
					if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
						resultActivity.setButtons(activityButtonList);
					}
				}
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}

	@Override
	protected List<Attachment> getAttachment(InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet)
			throws Exception {
		return null;
	}
	
	private List<Attachment> getAttachment(InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet1, List<Map<String, Object>> proxyResultSet2, List<Map<String, Object>> proxyResultSet3)
			throws Exception {

		if ( (inquiryData == null) || ( (proxyResultSet1 == null) && (proxyResultSet2 == null) && (proxyResultSet3 == null) ) ) {
			return null;
		}
		
		Attachment attachment = null;
		final String SPACE = " ", COMMA = ",";
		
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        /* 팀투입률 전월/당월/누계 각항목 서비스 조회 결과
	        CD_NM	누적	당월	전월
	        계약	82.34	78.05	86.12
	        순계약	92.09	80.00	88.28
	        유상	93.37	82.93	91.00
	        유상(간접계약)	93.37	82.93	91.00
	        프로젝트	93.37	82.93	91.00 */
	        if ( proxyResultSet1 != null ) {
	        	
	        	String cdNm = null, accMonth = null, preMonth = null, curMonth = null;
	        	StringBuffer buf = new StringBuffer();
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet1) {
	        		buf.setLength(0);
	        		cdNm = ( proxyResult.get("CD_NM") != null ) ? String.valueOf(proxyResult.get("CD_NM")) : "";
	        		
	        		if ("프로젝트".equals(cdNm)) {
	        			accMonth = ( proxyResult.get("누적") != null ) ? String.valueOf(proxyResult.get("누적")) : ""; 
		        		preMonth = ( proxyResult.get("전월") != null ) ? String.valueOf(proxyResult.get("전월")) : ""; 
		        		curMonth = ( proxyResult.get("당월") != null ) ? String.valueOf(proxyResult.get("당월")) : "";
		        		
		        		buf.append("투입률(누적) : ").append(accMonth).append("%, ");
		        		buf.append("투입률(당월) : ").append(curMonth).append("%, ");
		        		buf.append("투입률(전월) : ").append(preMonth).append("% 입니다.");
		        		
		        		Element element = new Element();
	    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	    				element.setSubtitle("[팀투입률]\n");
	    				element.setTitle(buf.toString());
	    				element.setActionType(ActivityCode.ACTION_TYPE_INQUIRY);
	    				
	    				attachment.addElement(element);
	        		}
	        	}
	        }
	        /*팀 Effort 입력자 목록 조회 결과
	        emp_no	emp_nm	title_nm	EMP_MOBILE_NO	CNT	ARR_INPUT_DATE
	        53815	남진우	부장	010-8294-6931	20	 12/01, 12/04, 12/05, 12/06, 12/07, 12/08, 12/11, 12/12, 12/13, 12/14, 12/15, 12/18, 12/19, 12/20, 12/21, 12/22, 12/26, 12/27, 12/28, 12/29
	        30061	박수경	부장	010-8482-5262	20	 12/01, 12/04, 12/05, 12/06, 12/07, 12/08, 12/11, 12/12, 12/13, 12/14, 12/15, 12/18, 12/19, 12/20, 12/21, 12/22, 12/26, 12/27, 12/28, 12/29
	        61113	조혁상	부장	010-2241-8172	20	 12/01, 12/04, 12/05, 12/06, 12/07, 12/08, 12/11, 12/12, 12/13, 12/14, 12/15, 12/18, 12/19, 12/20, 12/21, 12/22, 12/26, 12/27, 12/28, 12/29
	        62435	박한성	부장	010-8995-5771	20	 12/01, 12/04, 12/05, 12/06, 12/07, 12/08, 12/11, 12/12, 12/13, 12/14, 12/15, 12/18, 12/19, 12/20, 12/21, 12/22, 12/26, 12/27, 12/28, 12/29
	        69878	김정철	부장	010-3622-0006	20	 12/01, 12/04, 12/05, 12/06, 12/07, 12/08, 12/11, 12/12, 12/13, 12/14, 12/15, 12/18, 12/19, 12/20, 12/21, 12/22, 12/26, 12/27, 12/28, 12/29
	        50496	이은정	차장	010-2634-6461	20	 12/01, 12/04, 12/05, 12/06, 12/07, 12/08, 12/11, 12/12, 12/13, 12/14, 12/15, 12/18, 12/19, 12/20, 12/21, 12/22, 12/26, 12/27, 12/28, 12/29
	        60413	이영우	차장	010-8228-7173	20	 12/01, 12/04, 12/05, 12/06, 12/07, 12/08, 12/11, 12/12, 12/13, 12/14, 12/15, 12/18, 12/19, 12/20, 12/21, 12/22, 12/26, 12/27, 12/28, 12/29*/
	        if ( proxyResultSet2 != null ) {
	        	
	        	int size = proxyResultSet2.size(), pos = 0;
	        	
	        	StringBuffer titleBuf = new StringBuffer();
	        	StringBuffer userInfoBuf = new StringBuffer(); 
	        	StringBuffer mobileBuf = new StringBuffer();
	        	StringBuffer empNoBuf = new StringBuffer(); 
	        	
	        	String empNo = null, empNm = null, titleNm = null, empMobileNo = null;
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet2) {
	        		empNo = ( proxyResult.get("emp_no") != null ) ? String.valueOf(proxyResult.get("emp_no")) : "";
	        		empNm = ( proxyResult.get("emp_nm") != null ) ? String.valueOf(proxyResult.get("emp_nm")) : "";
	        		titleNm = ( proxyResult.get("title_nm") != null ) ? String.valueOf(proxyResult.get("title_nm")) : "";
	        		empMobileNo = ( proxyResult.get("EMP_MOBILE_NO") != null ) ? String.valueOf(proxyResult.get("EMP_MOBILE_NO")) : "";
	        		
	        		userInfoBuf.append(empNm).append(SPACE).append(titleNm);
	        		mobileBuf.append(empMobileNo);
	        		empNoBuf.append(empNo);
	        		
	        		if (pos < size-1) {
	        			userInfoBuf.append(COMMA);
	        			mobileBuf.append(COMMA);
	        			empNoBuf.append(COMMA);
	        		}
	        		
	        		pos++;
	        	}
	        	
	        	titleBuf.append("Effort 미입력자는 총 ").append(size).append("명 입니다.");
	        		        	
	        	Element element = new Element();
				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
				element.setSubtitle("[Effort 미입력]\n");
				element.setTitle(titleBuf.toString());
				element.setDescriptions(userInfoBuf.toString());
				element.setActionType(ActivityCode.ACTION_TYPE_INQUIRY);
				
				Map<String, Object> addProp = new HashMap<String, Object>();
				addProp.put("userIds", empNoBuf.toString());
				addProp.put("mobiles", mobileBuf.toString()); 
				
				element.setAdditionalProperties(addProp); 
				
				attachment.addElement(element);
	        }
	        
	        /* 3.팀투입 O/L variance 인원 명단 조회 결과
	        EMP_NO	EMP_NM	TITLE_NM	DEPT_NM	(열 이름 없음)
	        75053	태미선	대리	CNS운영팀	-47.60
	        75053	태미선	대리	CNS운영팀	-47.60
	        75053	태미선	대리	CNS운영팀	-47.60 */
	        if ( proxyResultSet3 != null ) {
	        	
	        	int size = proxyResultSet3.size(), pos = 0;
	        	
	        	StringBuffer titleBuf = new StringBuffer();
	        	StringBuffer userInfoBuf = new StringBuffer(); 
	        	
	        	String empNm = null, titleNm = null;
	        			
	        	for (Map<String, Object> proxyResult : proxyResultSet3) {
	        		empNm = ( proxyResult.get("EMP_NM") != null ) ? String.valueOf(proxyResult.get("EMP_NM")) : "";
	        		titleNm = ( proxyResult.get("TITLE_NM") != null ) ? String.valueOf(proxyResult.get("TITLE_NM")) : "";
	        		
	        		userInfoBuf.append(empNm).append(SPACE).append(titleNm);
	        		
	        		if (pos < size-1) {
	        			userInfoBuf.append(COMMA);
	        		}
	        		
	        		pos++;
	        	}
	        	
	        	titleBuf.append("투입 O/L Variance 발생 총 ").append(size).append("명 입니다.");
	        	
	        	Element element = new Element();
				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
				element.setSubtitle("[투입 O/L Variance]\n");
				element.setTitle(titleBuf.toString());
				element.setDescriptions(userInfoBuf.toString());
				element.setActionType(ActivityCode.ACTION_TYPE_INQUIRY);
				
				attachment.addElement(element);
	        }
	        
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
	
}
