/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.config;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseModel;

/**
 * <pre>
 * 사용자 알림 (Notification) 설정 Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LegacyConfig extends BaseModel {



/**
* 레가시 코드
*/
private String legacyCode;
/**
* 레가시 타입 코드
*/
private String legacyTypeCode;
/**
* 레가시 이름
*/
private String legacyName;
/**
* 레가시 설명
*/
private String description;
/**
* 봇 id
*/
private String botId;
/**
* 사용여부
*/
private String useYn;
/**
* 액션 uri
*/
private String actionUri;
/**
* ip체크
*/
private String ipCheckYn;
/**
* 순서
*/
private int ord;
public String getLegacyCode() {
	return legacyCode;
}
public void setLegacyCode(String legacyCode) {
	this.legacyCode = legacyCode;
}
public String getLegacyTypeCode() {
	return legacyTypeCode;
}
public void setLegacyTypeCode(String legacyTypeCode) {
	this.legacyTypeCode = legacyTypeCode;
}
public String getLegacyName() {
	return legacyName;
}
public void setLegacyName(String legacyName) {
	this.legacyName = legacyName;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getBotId() {
	return botId;
}
public void setBotId(String botId) {
	this.botId = botId;
}
public String getUseYn() {
	return useYn;
}
public void setUseYn(String useYn) {
	this.useYn = useYn;
}
public String getActionUri() {
	return actionUri;
}
public void setActionUri(String actionUri) {
	this.actionUri = actionUri;
}
public String getIpCheckYn() {
	return ipCheckYn;
}
public void setIpCheckYn(String ipCheckYn) {
	this.ipCheckYn = ipCheckYn;
}
public int getOrd() {
	return ord;
}
public void setOrd(int ord) {
	this.ord = ord;
}
    
}
