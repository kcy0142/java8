/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : Keyword.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.channel.model;

import java.util.Map;

public class Keyword {
    /**
     * 키워드 ID
     */
    private String id;
	
	/**
	 * 표시 순서
	 */
	private String displayOrder;
	
	/**
     * 버튼유형
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String type;

    /**
     * 버튼 제목
     */
    private String title;

    // 액션정보
    
    /**
     * 액션 유형 (link: 링크, inquiry: 인텐트처리)
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String actionType;
    
    /**
     * 액션
     */
    private String action;
        
    /**
     * 액션 파라미터
     */
    private Map<String, Object> actionParams;
    
    /**
     * 아이콘 (Font Awesome class)
     */
    private String icon;
    
	public Keyword() {
	}
	
	public Keyword(Recommand recommand) {
	    // ID 추가 (화면에서 렌더링시 필수 값)
	    this.id = recommand.getId();
		this.displayOrder = recommand.getDisplayOrder();
		
		//RecommandName으로 Keyword 버튼명을 표시할 지, 아이콘만 표시할 지 설정
		if ( "N".equals(recommand.getDisplayYn()) ) {
			this.title = "";
		}
		else {
			this.title = recommand.getRecommandName();
		}
		this.actionType = recommand.getActionType();
		this.action = recommand.getAction();
		
		this.type = recommand.getType();
		this.icon = recommand.getIconName();
	}
	
	public Keyword(String actionType, String title, String action, String actionMessage) {
		
		this.actionType = actionType;
		this.title = title;
		this.action = action;
	}
	
	public Keyword(String displayOrder, String type, String title, String actionType, String action,
			String actionMessage, Map<String, Object> actionParams, String icon) {
		this.displayOrder = displayOrder;
		this.type = type;
		this.title = title;
		this.actionType = actionType;
		this.action = action;
		this.actionParams = actionParams;
		this.icon = icon;
	}
	
	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Map<String, Object> getActionParams() {
		return actionParams;
	}

	public void setActionParams(Map<String, Object> actionParams) {
		this.actionParams = actionParams;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}
	
}
