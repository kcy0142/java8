/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : Intent.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.model;

import java.util.ArrayList;
import java.util.List;

import com.lgcns.vpa.intent.model.IntentMongo.Utterance;

public class Intent extends IntentBase {
	/**
	 * 연관 버튼
	 */
	private List<RelatedButton> buttons;
	
	public Intent() {
		super();
		buttons = new ArrayList<>(); 
	}
	
	public Intent(IntentMongo mongo) {
		super(mongo);
		buttons = new ArrayList<>(); 
	}
	public Intent(String id, String botId, String intentId, String intentName, String intentType, List<String> contexts, boolean autorun, Utterance utterance) {
		super(id, botId, intentId, intentName, intentType, contexts, autorun, utterance);
		buttons = new ArrayList<>();
	}
	
	public List<RelatedButton> getButtons() {
		return buttons;
	}

	public void addButton(RelatedButton button) {
		this.buttons.add(button);
	}
	
	public String toString() {
		String str = super.toString();
		str += "    button[";
		for( RelatedButton button : buttons ) {
			if( button != null ) {
				str += button.toString();
			}
		}
		str += "]";
		return str;
	}
	public static class RelatedButton<T> {
		private String name;
		
		private String type;
		
		private T action;
		
		private String params;
		
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public T getAction() {
			return action;
		}

		public void setAction(T action) {
			this.action = action;
		}
		
		public String getParams() {
			return params;
		}

		public void setParams(String params) {
			this.params = params;
		}
		
		public String toString() {
			return String.format(
					"name : %s "
					+ "type : %s "
					+ "action : %s "
					+ "params : %s\n", 
					this.name, this.type, this.action, this.params);
		}

		
	}
}
