/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : BaseMongo.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.model;

import org.springframework.data.annotation.Id;

/**
 * <PRE>
 * Mongodb Model Parent 정의
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
public class BaseMongo {
	
	@Id
	private String id;
	private String messageId;
	private String messageGroupId;
	
	public BaseMongo() {}
	
	public BaseMongo(String messageId, String messageGroupId) {
		super();
		this.messageId = messageId;
		this.messageGroupId = messageGroupId;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public String getMessageGroupId() {
		return messageGroupId;
	}
	public void setMessageGroupId(String messageGroupId) {
		this.messageGroupId = messageGroupId;
	}
	
}
