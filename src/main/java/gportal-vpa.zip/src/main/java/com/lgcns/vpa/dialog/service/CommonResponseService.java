/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : CommonResponseService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.channel.dao.BotDao;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.push.dao.UserAutoRunDao;
import com.lgcns.vpa.push.model.UserAutoRun;

/**
 * <PRE>
 * 관용적으로 사용되는 읍답메세지를 처리하는 Class
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Service("multi.commonResponseService")
public class CommonResponseService {
	
	private final String MAPPER_PATH = "mappers", MESSAGE_PATH = "noResultMessage";
	
	@Autowired
	BotService botService; 
	
	@Autowired
	BotDao botDao; 
	
	@Autowired
	private DialogConfig dialogConfig;
	
	@Autowired
	private UserAutoRunDao userAutoRunDao;
	
	/**
	 * 통합검색 시 그룸 탭 검색 Option
	 */
	private final String TOTAL_SEARCH_GROUP_TAB = "&collection=employee_group";
	
	/**
	 * 단순 Text 응답 메세지를 생성함
	 * @param message
	 * @param replyToId
	 * @param botId
	 * @param userId
	 * @return
	 */
	public Activity createSimpleResponse (String message, String replyToId, String botId, String userId, String reqIp, String reqDeviceType) {
		
		if ( !StringUtils.hasText(message) || !StringUtils.hasText(userId) ) {
			return null;
		}
		
		Activity activity = new Activity();
		activity.setReplyToId(replyToId);
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype("");
		activity.setMessage(message);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(botId);
		activity.setUserId(userId);
		activity.setUserIp(reqIp);
		activity.setDeviceType(reqDeviceType);
		
		return activity;		
	}
	
	/**
	 * 글자 수가 적어 질의어를 처리하지 않음 메세지 생성함
	 * @param data
	 * @return
	 */
	public Activity createTooShortInquiry (InquiryVO data) {
		return createTooShortInquiry (
				data.getInquiryData(),
				data.getReqMessageId(),
				data.getBotId(),
				data.getReqUserId(),
				data.getReqIp(),
				data.getReqDeviceType());
}
	
	/**
	 * 글자 수가 적어 질의어를 처리하지 않음 메세지 생성함
	 * @param message
	 * @param replyToId
	 * @param botId
	 * @param userId
	 * @return
	 */
	public Activity createTooShortInquiry (String message, String replyToId, String botId, String userId, String reqIp, String reqDeviceType) {
		
		if ( !StringUtils.hasText(message) || !StringUtils.hasText(userId) ) {
			return null;
		}
		
		String message2 = this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_SHORT_ERROR);
		
		Activity activity = new Activity();
		activity.setReplyToId(replyToId);
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_ERROR);
		activity.setMessage(message2);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(botId);
		activity.setUserId(userId);
		activity.setUserIp(reqIp);
		activity.setDeviceType(reqDeviceType);
		
		return activity;		
	}
	
	/**
	 * "질문을 이해하지 못했습니다." 응답 Activity Object 생성
	 * @param reqActivity
	 * @return
	 */
	public Activity cannotUnderstand (Activity reqActivity) {
		return cannotUnderstand (
					reqActivity.getMessage(),
					reqActivity.getReplyToId(), 
					reqActivity.getBotId(), 
					reqActivity.getUserId(),
					reqActivity.getUserIp(),
					reqActivity.getDeviceType());
	}
	
	/**
	 * "질문을 이해하지 못했습니다." 응답 Activity Object 생성
	 * @param data
	 * @return
	 */
	public Activity cannotUnderstand (InquiryVO data) {
		return cannotUnderstand (
					data.getInquiryData(),
					data.getReqMessageId(),
					data.getBotId(),
					data.getReqUserId(),
					data.getReqIp(),
					data.getReqDeviceType());
	}
	
	/**
	 * "질문을 이해하지 못했습니다." 응답 Activity Object 생성
	 * @param replyToId
	 * @param botId
	 * @param userId
	 * @return
	 */
	public Activity cannotUnderstand (String inquiryData, String replyToId, String botId, String userId, String reqIp, String reqDeviceType) {

		String message = this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_INTENT_NONE);
		
		Activity activity = new Activity();
		activity.setReplyToId(replyToId);
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_ERROR);
		activity.setMessage(message);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(botId);
		activity.setUserId(userId);
		activity.setUserIp(reqIp);
		activity.setDeviceType(reqDeviceType);
		
		List<Button> activityButtonList = new ArrayList<Button>();
		//activityButtonList.add(this.makeSearchButton(inquiryData));
		activityButtonList.add(this.makeHelpButton());
		
		activity.setButtons(activityButtonList);
		
		return activity;
	}
	
	/**
	 * 오류 발생 응답 Activity Object 생성
	 * @param reqActivity
	 * @return
	 */
	public Activity errorWarning (Activity reqActivity) {
		return errorWarning (
				reqActivity.getMessage(), 
				reqActivity.getReplyToId(), 
				reqActivity.getBotId(), 
				reqActivity.getUserId(),
				reqActivity.getUserIp(),
				reqActivity.getDeviceType());
	}
	
	/**
	 * 오류 발생 응답 Activity Object 생성
	 * @param data
	 * @return
	 */
	public Activity errorWarning (InquiryVO data) {
		return errorWarning (
				data.getInquiryData(),
				data.getReqMessageId(),
				data.getBotId(),
				data.getReqUserId(),
				data.getReqIp(),
				data.getReqDeviceType());
	}
	
	/**
	 * 오류 발생 응답 Activity Object 생성
	 * @param replyToId
	 * @param botId
	 * @param userId
	 * @return
	 */
	public Activity errorWarning (String inquiryData, String replyToId, String botId, String userId, String reqIp, String reqDeviceType) {

		String message = this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_PROCESS_ERROR);
		
		Activity activity = new Activity();
		activity.setReplyToId(replyToId);
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_ERROR);
		activity.setMessage(message);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(botId);
		activity.setUserId(userId);
		activity.setUserIp(reqIp);
		activity.setDeviceType(reqDeviceType);
		
		List<Button> activityButtonList = new ArrayList<Button>();
		//activityButtonList.add(this.makeSearchButton(inquiryData));
		activityButtonList.add(this.makeHelpButton());
		
		activity.setButtons(activityButtonList);
		
		return activity;
	}
	
	/**
	 * 권한 없음 메세지 처리 Activity Object 생성
	 * @param data
	 * @return
	 */
	public Activity disAllowedWarning (InquiryVO data) {
		return disAllowedWarning (
				data.getInquiryData(),
				data.getReqMessageId(),
				data.getBotId(),
				data.getReqUserId(),
				data.getReqIp(),
				data.getReqDeviceType());
	}
	
	/**
	 * 권한 없음 메세지 처리 Activity Object 생성
	 * @param replyToId
	 * @param botId
	 * @param userId
	 * @param reqIp
	 * @param reqDeviceType
	 * @return
	 */
	public Activity disAllowedWarning (String inquiryData, String replyToId, String botId, String userId, String reqIp, String reqDeviceType) {

		String message = this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_DISALLOW);
		
		Activity activity = new Activity();
		activity.setReplyToId(replyToId);
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_ERROR);
		activity.setMessage(message);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(botId);
		activity.setUserId(userId);
		activity.setUserIp(reqIp);
		activity.setDeviceType(reqDeviceType);
		
		List<Button> activityButtonList = new ArrayList<Button>();
		//activityButtonList.add(this.makeSearchButton(inquiryData));
		activityButtonList.add(this.makeHelpButton());
		
		activity.setButtons(activityButtonList);
		
		return activity;
	}
	
	/**
	 * "데이터가 없습니다." 응답 Activity Object 생성
	 * @param data
	 * @return
	 */
	public Activity noDataInLegacy (InquiryVO data) {
		
		String noResultMessage = null; 
				
		// Action Mapper Data 에서 조회 데이터가 없을 경우 메세지가 있으면 가져옴
		if ( (data != null) && (data.getAction() != null) ) {
			
			Action action = data.getAction();
			String jsonMapper = action.getMapper();
			
			if ( !StringUtils.isEmpty(jsonMapper) ) {
				try {
					//Mapper Data 파싱하기
		            ObjectMapper mapper = new ObjectMapper();
		            JsonNode root = mapper.readTree(jsonMapper); // <=== Json String 으로 대체
		            JsonNode node = root.path(MAPPER_PATH);
		            JsonNode nodeMessage = root.path(MESSAGE_PATH); 
		            
		            //조회된 Data 가 없을 경우 Activity Message
	            	noResultMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
	            	
				} catch (Exception e) {
				}
			}
		}
		
		return noDataInLegacy (
				data.getInquiryData(),
				noResultMessage,
				data.getReqMessageId(),
				data.getBotId(),
				data.getReqUserId(),
				data.getReqIp(),
				data.getReqDeviceType());
	}
	
	/**
	 * 조회된 데이터가 없을 경우 메세지 처리
	 * @param inquiryData
	 * @param noResultMessage
	 * @param replyToId
	 * @param botId
	 * @param userId
	 * @param reqIp
	 * @param reqDeviceType
	 * @return
	 */
	public Activity noDataInLegacy (String inquiryData, String noResultMessage, String replyToId, String botId, String userId, String reqIp, String reqDeviceType) {
		
		//기 입력된 메세지가 있으면 그 메세지를 사용하고 없으면 DB에서 읽어온다.
		String message = (StringUtils.isEmpty(noResultMessage)) ? this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_DATANONE) : noResultMessage;
		
		Activity activity = new Activity();
		activity.setReplyToId(replyToId);
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype("");
		activity.setMessage(message);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(botId);
		activity.setUserId(userId);
		activity.setUserIp(reqIp);
		activity.setDeviceType(reqDeviceType);
		
		List<Button> activityButtonList = new ArrayList<Button>();
		//activityButtonList.add(this.makeSearchButton(inquiryData));
		activityButtonList.add(this.makeHelpButton());
		
		activity.setButtons(activityButtonList);
		
		return activity;
	}
	
	/**
	 * 의도분석 처리 시 오류 발생 응답 Activity Object 생성
	 * @param data
	 * @return
	 */
	public Activity intentErrorWarning (InquiryVO data) {
		return intentErrorWarning (
				data.getInquiryData(),
				data.getReqMessageId(),
				data.getBotId(),
				data.getReqUserId(),
				data.getReqIp(),
				data.getReqDeviceType());
	}
	
	public Activity intentErrorWarning (InquiryVO data, int errorType) {
		
		Activity activity = intentErrorWarning (
								data.getInquiryData(),
								data.getReqMessageId(),
								data.getBotId(),
								data.getReqUserId(),
								data.getReqIp(),
								data.getReqDeviceType());
		
		String message = null;
		
		switch (errorType) {
		case CommonCode.INQUIRY_STATE_INTENT_ERR_CALL :
			message = this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_NLU_NETWORK_ERROR);
			break;
		case CommonCode.INQUIRY_STATE_INTENT_ERR_SERVER :
			message = this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_NLU_SERVER_ERROR);
			break;
		}
		
		if ( message != null ) {
			activity.setMessage(message);
		}
		
		return activity;
	}
	
	/**
	 * 의도분석 처리 시 오류 발생 응답 Activity Object 생성
	 * @param replyToId
	 * @param botId
	 * @param userId
	 * @return
	 */
	public Activity intentErrorWarning (String inquiryData, String replyToId, String botId, String userId, String reqIp, String reqDeviceType) {

		String message = this.botService.getBotMessage(botId, BotCode.BOT_MESSAGE_TYPE_INTENT_ERROR);
		
		Activity activity = new Activity();
		activity.setReplyToId(replyToId);
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_ERROR);
		activity.setMessage(message);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(botId);
		activity.setUserId(userId);
		activity.setUserIp(reqIp);
		activity.setDeviceType(reqDeviceType);
		
		List<Button> activityButtonList = new ArrayList<Button>();
		//activityButtonList.add(this.makeSearchButton(inquiryData));
		activityButtonList.add(this.makeHelpButton());
		
		activity.setButtons(activityButtonList);
		
		return activity;
	}
	
	/**
	 * 개별 응답 메세지 처리, 응답 Activity Object 생성
	 * @param replyToId
	 * @param botId
	 * @param userId
	 * @param reqIp
	 * @param reqDeviceType
	 * @param message
	 * @return
	 */
	public Activity simpleResponseMessage (String replyToId, String botId, String userId, String reqIp, String reqDeviceType, String message) {
		
		Activity activity = new Activity();
		activity.setReplyToId(replyToId);
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype("");
		activity.setMessage(message);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(botId);
		activity.setUserId(userId);
		activity.setUserIp(reqIp);
		activity.setDeviceType(reqDeviceType);
		
		return activity;
	}
	
	/**
	 * 질의문이 숫자 또는 전화번호 형식일 경우 검색을 실패했을 떄 메세지
	 * @param data
	 * @return
	 */
	public Activity cannotUnderstandPhoneType (InquiryVO data) {
		
		String message = this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_PHONE_NONE);
		
		Activity activity = new Activity();
		activity.setReplyToId(data.getReqMessageId());
		activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_ERROR);
		activity.setMessage(message);
		activity.setSenderType(ActivityCode.SENDER_TYPE_BOT);
		activity.setBotId(data.getBotId());
		activity.setUserId(data.getReqUserId());
		activity.setUserIp(data.getReqIp());
		activity.setDeviceType(data.getReqDeviceType());
		
		List<Button> activityButtonList = new ArrayList<Button>();
		//activityButtonList.add(this.makeSearchButton(inquiryData));
		activityButtonList.add(this.makeHelpButton());
		
		activity.setButtons(activityButtonList);
		
		return activity;
	}
	
	/**
	 * 도움말 버튼 생성
	 * @return
	 */
	private Button makeHelpButton () {
		
		Button activityButton = new Button();
		activityButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);
		activityButton.setAction("도움말");
		activityButton.setTitle("도움말");
		
		return activityButton;
	}
	
	/**
	 * 통합검색 버튼 생성
	 * @param inquiryData
	 * @param tenantId
	 * @return
	 */
	public Button makeSearchButton (String inquiryData, String tenantId) {
		
		if ( StringUtils.isEmpty(inquiryData)  ) {
			return null;
		}
		
		String totalSearchUrlEncoded = null;
		
		try {
			
			//통합 검색 URL 정보를 Properties 에서 읽어온다.
			String totalSearchUrl = this.dialogConfig.getDialogInfo(tenantId, "url", "totalSearch");
			
			String searchUrl = String.format(totalSearchUrl, inquiryData);
			UriComponents uriComponent = UriComponentsBuilder.fromHttpUrl(searchUrl).build().encode("UTF-8");
			totalSearchUrlEncoded = uriComponent.toUriString();
		} catch (UnsupportedEncodingException e) {
			return null;
		}
		
		Button searchButton = new Button();
		searchButton.setType(CommonCode.INTENT_BUTTON_TYPE_LINK);
		searchButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
		searchButton.setAction(totalSearchUrlEncoded);
		
		//질의어가 10글자 미만이면 #+질의어, 10자 이상이면 통합검색
		if (inquiryData.length() < 10) {
			searchButton.setTitle("#"+inquiryData);
		}
		else {
			searchButton.setTitle("통합검색");
		}
		
		return searchButton;
		
	}
	
	/**
	 * 통합검색 버튼 생성
	 * @param inquiryData
	 * @param tenantId
	 * @return
	 */
	public Button makeSearchInGroupButton (String inquiryData, String tenantId) {
		
		if ( StringUtils.isEmpty(inquiryData)  ) {
			return null;
		}
		
		String totalSearchUrlEncoded = null;
		
		try {
			
			//통합 검색 URL 정보를 Properties 에서 읽어온다.
			String totalSearchUrl = this.dialogConfig.getDialogInfo(tenantId, "url", "totalSearch");
			
			StringBuffer url = new StringBuffer(totalSearchUrl).append(TOTAL_SEARCH_GROUP_TAB);
			String searchUrl = String.format(url.toString(), inquiryData);
			UriComponents uriComponent = UriComponentsBuilder.fromHttpUrl(searchUrl).build().encode("UTF-8");
			totalSearchUrlEncoded = uriComponent.toUriString();
		} catch (UnsupportedEncodingException e) {
			return null;
		}
		
		Button searchButton = new Button();
		searchButton.setType(CommonCode.INTENT_BUTTON_TYPE_LINK);
		searchButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
		searchButton.setAction(totalSearchUrlEncoded);
		searchButton.setTitle("그룹사 인원 검색");
		
		return searchButton;
		
	}
	
	/**
	 * 자동 실행 설정 버튼 생성
	 * @return
	 */
	public Button makeAutoRunButton (Map<String, Object> actionParams) {
		Button autoRunButton = new Button();
		autoRunButton.setType(CommonCode.BUTTON_TYPE_AUTORUN);
		autoRunButton.setActionType(CommonCode.BUTTON_TYPE_AUTORUN);
		autoRunButton.setAction(ActivityCode.ATTACHMENT_TYPE_POPUP);
		autoRunButton.setTitle("자동으로 알려주는 알람을 설정해서 편하게 확인해 보시는 건 어떠세요?");
		
		if ( (actionParams != null) && (!actionParams.isEmpty()) ) {
			autoRunButton.setActionParams(actionParams);
		}
		
		return autoRunButton;
	}
	
	/**
	 * 사용자별 자동알림 설정 목록을 조회함
	 * com.lgcns.vpa.push.service.UserAutoRunService 에 정의되어 있는 내용인데 해당 Service에서 DialogHandlerService 를 호출하기 때문에
	 * 반복 호출을 피하기 위하여 여기에 별도로 정의함
	 * @param botId
	 * @param userId
	 * @return
	 */
	public List <UserAutoRun> getUserAutoRunList (String botId, String userId) {
		
		if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(userId) ) {
			return null;
		}
		
		List <UserAutoRun> resultList = userAutoRunDao.list(botId, userId);
		
		return ( resultList == null || resultList.isEmpty() ) ? null : resultList;
	}
}
