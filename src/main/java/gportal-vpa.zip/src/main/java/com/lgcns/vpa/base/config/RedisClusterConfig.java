/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ClusterConfigurationProperties.java
 * Author        : hyeom
 * Copyright 2017 LG CNS All rights reserved
 *------------------------------------------------------------------------------ */

package com.lgcns.vpa.base.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Redis cluster 설정 properties
 * @author hyeom
 */
@Component
@ConfigurationProperties(prefix = "spring.redis.cluster")
public class RedisClusterConfig {

    List<String> nodes;

    public List<String> getNodes() {
        return nodes;
    }

    public void setNodes(List<String> nodes) {
        this.nodes = nodes;
    }

}
