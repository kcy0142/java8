/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : DialogConfig.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.base.config;

import java.util.Collections;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
public class DialogConfig {
	private Map<String, Map<String, Map<String, String>>> dialog;

	public Map<String, Map<String, Map<String, String>>> getDialog() {
		return dialog;
	}

	public void setDialog(Map<String, Map<String, Map<String, String>>> dialog) {
		this.dialog = dialog;
	}
	
	public Map<String, Map<String, String>> getDialogByTenantId(String tenantId) {
        if (dialog == null || !dialog.containsKey(tenantId)) {
            return Collections.emptyMap();
        }
        return dialog.get(tenantId);
    }
	
	public Map<String, String> getDialogInfoMap(String tenantId, String groupKey) {
        Map<String, Map<String, String>> serversMap = getDialogByTenantId(tenantId);
        if (serversMap == null) {
            return null;
        }
        return serversMap.get(groupKey);
    }
    
    public String getDialogInfo(String tenantId, String groupKey, String key) {
        Map<String, String> dialogInfoMap = getDialogInfoMap(tenantId, groupKey);
        if (dialogInfoMap == null) {
            return null;
        }
        return dialogInfoMap.get(key);
    }
    
    @Bean
    DialogConfig dialogConfigBean() {
        return new DialogConfig();
    }
}
