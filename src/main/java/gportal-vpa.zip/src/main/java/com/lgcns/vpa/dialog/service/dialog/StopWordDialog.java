/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : StopWordDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.StopWord;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.service.StopWordService;

/**
 * <PRE>
 * 불용어(관용어구)를 처리하기 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 7. 12.
 */
//의도분석 전 관용어구(불용어) 조회 처리
@Component("StopWordDialog")
public class StopWordDialog  extends VpaDialog {

	@Autowired
	private StopWordService stopWordService;
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Override
	protected boolean validator(InquiryVO data) {
		if ( (data == null) || (!StringUtils.hasText(data.getInquiryData())) ) {
			return false;
		}
		
		return true;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		return true;
	}

	@Override
	protected String processor(InquiryVO data) {
		return "Inquiry StopWord";
	}

	@Override
	protected Activity afterWork(InquiryVO data, String stopWordReponseMessage) {
		
		//불용어 Data 조회 (특수문자 제거, 유의어가 치환된 질의어로 조회)
		StopWord stopWord = stopWordService.getStopWordData(data.getInquiryData(), data.getBotId());
		
		if (stopWord == null) {
			
			Activity reqActivity = data.getRequestActivity();
			
			if ( (reqActivity != null) && (!StringUtils.isEmpty(reqActivity.getPreSynonymMessage())) ) {
				//불용어 Data 조회 (특수문자 제거, 유의어 치환이 되지 않은 질의어로 조회)
				stopWord = stopWordService.getStopWordData(reqActivity.getPreSynonymMessage(), data.getBotId());
			}
			
			if ( stopWord == null ) {
				return null;
			}
		}
		
		//불용어 조회 결과 응답 메세지가 있으면 응답하고 아니면 null
		if (StringUtils.hasText(stopWordReponseMessage)) {
			Activity resultActivity = this.commonResponeService.createSimpleResponse (
					//stopWord.getResponseMessage(), 
					stopWord.getResponseMessageForDisplay(),
					data.getReqMessageId(),
					data.getBotId(),
					data.getReqUserId(),
					data.getReqIp(),
					data.getReqDeviceType());
			
			resultActivity.setSubtype(CommonCode.SUBTYPE_STOPWORD);
			resultActivity.setAnimation(stopWord.getAnimationForDisplay());
			
			return resultActivity;
		}
		
		return null;
	}

}
