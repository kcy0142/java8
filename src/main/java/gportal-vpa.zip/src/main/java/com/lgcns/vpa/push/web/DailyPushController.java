package com.lgcns.vpa.push.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.push.service.DailyPushService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * Push 알림 api 컨트롤러
 * </pre>
 * @author
 */
@RestController
@CrossOrigin(value="*")
@RequestMapping(value="/api/daily")
public class DailyPushController extends BaseController{
    final Logger logger = LoggerFactory.getLogger(DailyPushController.class);
    
    @Autowired
    ConfigService configService;
    
    @Autowired
    BotService botService;
    
    @Autowired
    ApplicationContext applicationContext;
       
    @RequestMapping(value="/{pushId}", method= RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<Map<String, Object>> execute(@PathVariable String pushId, @RequestParam(required = false) Map<String, String> params) {
    	
    	if (StringUtils.isEmpty(pushId) || StringUtils.isEmpty(params.get("activityId"))) {
    		throw new RuntimeException("정보가 유효하지 않습니다.");
    	}
    	
    	User user = this.getUser();
    	
    	PushConfig pushConfig = configService.retrievePushConfig(pushId, user.getUserId());
    	if (pushConfig == null || StringUtils.isEmpty(pushConfig.getWorkerName())) {
    		throw new RuntimeException("정보가 유효하지 않습니다.");
    	}

    	Bot bot = botService.retrieveBot(pushConfig.getBotId());
        if (bot == null) {
            throw new RuntimeException("봇 정보가 유효하지 않습니다.");
        }
        
    	DailyPushService dailyPushService = (DailyPushService)applicationContext.getBean(pushConfig.getWorkerName());

    	List<Attachment> attachments = dailyPushService.execute(params, pushConfig, bot, user, this.getTenantId());
    	
    	Map<String, Object> result = new HashMap<>();
    	result.put("activityId", params.get("activityId"));
    	result.put("index", params.get("index"));
    	result.put("attachments", attachments);

    	return new ResponseEntity<>(result, HttpStatus.OK);
    }
}
