/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : DateUtils.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.base.util;

import java.util.Calendar;
import java.util.Date;

public class DateUtils {
	
	/**
	 * 입력된 일자의 월 계산
	 * @param referenceDate
	 * @param month
	 * @return
	 */
	public static Date addMonth(Date referenceDate, int month) {
		Calendar c = Calendar.getInstance(); 
		c.setTime(referenceDate); 
		c.add(Calendar.MONTH, month);
		return c.getTime();
	}
	
	public static Date addWeek(Date referenceDate, int week) {
		Calendar c = Calendar.getInstance(); 
		c.setTime(referenceDate); 
		c.add(Calendar.WEEK_OF_MONTH, week);
		return c.getTime();
	}
}
