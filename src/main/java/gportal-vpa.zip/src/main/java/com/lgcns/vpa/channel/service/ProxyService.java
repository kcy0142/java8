/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service;

import java.util.List;
import java.util.Map;

import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 포탈 서비스
 * </pre>
 * @author
 */
public interface ProxyService {
    
    /**
     * 사용자의 축하합니다 정보 조회 (메인 포탈) 
     * @param user
     * @param tenantId
     * @return
     */
    List<Map<String, String>> retrieveMyCongratulation(User user, String tenantId);
    
    /**
     * 시스템 및 메뉴 검색
     * @param user
     * @param tenantId
     * @param searchWord
     * @return
     */
    List<Map<String, String>> searchSystemMenu(User user, String tenantId, String searchWord);
    
    /**
     * 즐겨찾기 시스템 및 메뉴 검색
     * @param user
     * @param tenantId
     * @return
     */
    List<Map<String, String>> searchFavoriteSystemMenu(User user, String tenantId);
}
