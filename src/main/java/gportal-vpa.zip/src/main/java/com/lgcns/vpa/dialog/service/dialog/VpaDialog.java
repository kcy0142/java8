/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : VpaDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.service.dialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.DialogUtil;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * Dialog Parent class
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
public abstract class VpaDialog {
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	/**
	 * 질의에 대한 처리  TransAction 실행
	 * @param data : Action 을 처리할 Data
	 * @param emptyResultIsNull : 결과가 없을 경우 return을 null 로 할지 여부, true 이면 null, false 이면 응답 메세지
	 * @return
	 */
	public Activity action (InquiryVO data, boolean emptyResultIsNull) {
		Activity result = null;
		String intentMessage = data.getIntentMessage();
		StringBuffer msgbuf = new StringBuffer();
		
		//Parameter mapping and Validation && 권한 검사
		if ( validator(data) && (hasActionRight(data)) ) {
			
			//Data (Backend Proxy, Redis, DB 등) 조회
			String procData = this.processor(data);
			
			//Action Uri가 없을 경우 Template 내용으로만 응답 생성
			if (CommonCode.ACTION_URI_NONE.equals(procData)) {
				try {
					//응답 메세지 생성
					result = afterWork(data, null);
				} catch (Exception e) {
					//오류 발생 메세지
					result = (emptyResultIsNull) ? null : this.commonResponeService.errorWarning(data);
				}
			}
			//조회 중 오류가 발생한 경우
			else if ( (!StringUtils.hasText(procData)) || (CommonCode.ACTION_RESULT_ERROR.equals(procData)) ) {
				//오류 발생 메세지
				result = (emptyResultIsNull) ? null : this.commonResponeService.errorWarning(data);
				
				//Intent Message + result message
				if ( !StringUtils.isEmpty(intentMessage) ) {
					msgbuf.append(intentMessage).append("\n\n").append(result.getMessage());
					result.setMessage(msgbuf.toString());
				}
			}
			//조회 결과가 없을 경우
			else if ( CommonCode.ACTION_RESULT_NONE.equals(procData) ) {
				//조회 결과가 없습니다. 메세지
				result = (emptyResultIsNull) ? null : this.commonResponeService.noDataInLegacy(data);
				
				//Intent Message + result message
				if ( !StringUtils.isEmpty(intentMessage) ) {
					msgbuf.append(intentMessage).append("\n\n").append(result.getMessage());
					result.setMessage(msgbuf.toString());
				}
			}
			else {
				try {
					//응답 메세지 생성
					result = afterWork(data, procData);
					
					//응답 메세지가 Null 이면 오류 발생 처리
					if (result == null) {
						result = (emptyResultIsNull) ? null : this.commonResponeService.errorWarning(data);
					}
				} catch (Exception e) {
					//오류 발생 메세지
					result = (emptyResultIsNull) ? null : this.commonResponeService.errorWarning(data);
					
					//Intent Message + result message
					if ( !StringUtils.isEmpty(intentMessage) ) {
						msgbuf.append(intentMessage).append("\n\n").append(result.getMessage());
						result.setMessage(msgbuf.toString());
					}
				}
			}

			// 의도가 분석 되었을 경우, IntentAnimation 정보 처리
			if ( (result != null) && (!StringUtils.isEmpty(data.getIntentId())) ) {
				result.setAnimation( data.getIntentAnimation() );
			}
		}
		//파라미터 매핑이 잘못되었거나 권한이 없을 경우
		else {
			//"잘 모르겠습니다. 응답 메세지 생성"
			result = (emptyResultIsNull) ? null : this.commonResponeService.cannotUnderstand(data);
		}
		
		return result;
	}
	
	/**
	 * Parameter mapping & Validation
	 * @param data
	 * @return
	 */
	protected abstract boolean validator(InquiryVO data);
	
	/**
	 * 실행 권한 검사
	 * @param data
	 * @return
	 */
	protected abstract boolean hasActionRight(InquiryVO data);
	
	/**
	 * Legacy system 또는 Redis 등에 질의 처리
	 * @param data
	 * @return
	 */
	protected abstract String processor(InquiryVO data);
	
	/**
	 * processor 처리 후 응답 메세지 생성 등 처리
	 * @param data
	 * @param proxyResponseJsonData
	 * @return
	 */
	protected abstract Activity afterWork(InquiryVO data, String proxyResponseJsonData);
	
	/**
	 * Intent에 정의되어 있는 버튼 처리
	 * @param buttons
	 * @return
	 */
	protected List<Button> makeActivityButtonList ( List<RelatedButton> buttons ) {
		
		if ( (buttons == null) || (buttons.isEmpty()) ) {
			return null;
		}
		
		return DialogUtil.makeActivityButtonList(buttons);
		
	}//makeIntentButton() end
}
