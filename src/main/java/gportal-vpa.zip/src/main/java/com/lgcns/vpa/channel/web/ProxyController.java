/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.web;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.service.ProxyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 프록시 조회 Controller
 * </pre>
 * @author
 */
@RequestMapping(value="/api/proxy")
@CrossOrigin(value="*")
@RestController
public class ProxyController extends BaseController {
    
    @Autowired
    private ProxyService proxyService;

    /**
     * 시스템 및 메뉴 조회
     * @param principal
     * @param searchWord
     * @return
     */
    @RequestMapping(value="/systems", method= RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<List<Map<String, String>>> searchSystemMenu(@RequestParam(value = "searchWord", required = false) String searchWord) {
        List<Map<String, String>> results = proxyService.searchSystemMenu(this.getUser(), this.getTenantId(), searchWord);
        return new ResponseEntity<>(results, HttpStatus.OK);
    }
    
    @RequestMapping(value="/systems/favorites", method= RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<List<Map<String, String>>> searchFavoriteSystemMenu() {
        List<Map<String, String>> results = proxyService.searchFavoriteSystemMenu(this.getUser(), this.getTenantId());
        return new ResponseEntity<>(results, HttpStatus.OK);
    }
}
