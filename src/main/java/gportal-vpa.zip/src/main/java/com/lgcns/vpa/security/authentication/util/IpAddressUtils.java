/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.security.authentication.util;

import javax.servlet.http.HttpServletRequest;

/**
 * <pre>
 * IP주소 유틸
 * </pre>
 * @author
 */
public class IpAddressUtils {
    
    /**
     * 클라이언트 IP 확인
     * @param request
     * @return
     */
    public static String getClientIpAddress(HttpServletRequest request) {
        String ipaddress = request.getHeader("X-Forwarded-For");
     
        if (ipaddress == null || ipaddress.length() == 0 || "unknown".equalsIgnoreCase(ipaddress)) {
            ipaddress = request.getHeader("Proxy-Client-IP");
        }
        if (ipaddress == null || ipaddress.length() == 0 || "unknown".equalsIgnoreCase(ipaddress)) {
            ipaddress = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ipaddress == null || ipaddress.length() == 0 || "unknown".equalsIgnoreCase(ipaddress)) {
            ipaddress = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ipaddress == null || ipaddress.length() == 0 || "unknown".equalsIgnoreCase(ipaddress)) {
            ipaddress = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ipaddress == null || ipaddress.length() == 0 || "unknown".equalsIgnoreCase(ipaddress)) {
            ipaddress = request.getRemoteAddr();
        }
        return ipaddress;
    }
}
