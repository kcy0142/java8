package com.lgcns.vpa.push.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.PushService;

/**
 * <pre>
 * 내가 쓴 글의 댓글 Push 알림 Service
 * </pre>
 * @author
 */
@Service("multi.replyPushService")
public class ReplyPushServiceImpl extends PushAbstractService implements PushService {
	
    @Autowired
    RedisMessagePublisher redisMessagePublisher;
    
    @Autowired
	ActivityService activityService;
    
    @Autowired
    private ConfigService configService;
    
    @Override
    public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig){
    	
    	String botId = params.get("botId");
    	String userId = params.get("userId");
    	String message = params.get("message");
    	String action = params.get("action");
    	String descriptions = params.get("descriptions");
    	String title = params.get("title");
    	String text = params.get("text");
    	String senderName = params.get("senderName");

    	
    	
    	checkBotId(botId);
    	checkUserId(userId);
		
		PushConfig pushUserConfig = configService.retrievePushConfig(pushConfig.getPushId(), userId);
		
		if(pushUserConfig.getUseYn().equals("Y")){
			Activity activity = createPushActivity(botId, userId, pushUserConfig.getLocaleCode(), message);
			
			Attachment attachment = new Attachment();
			
			attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
			attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
			
			Element element = new Element();
			element.setActionType(ActivityCode.ACTION_TYPE_LINK);
			element.setAction(action);
			element.setDescriptions(descriptions);
			element.setTitle(title);
			element.setText(text);
			 
			activity.addAdditionalProperty("title", title);
			activity.addAdditionalProperty("content",text);
			activity.addAdditionalProperty("sender", senderName);
			activity.addAdditionalProperty("url", action);
			
			
			attachment.addElement(element);
			activity.addAttachment(attachment);
			
			redisMessagePublisher.publish(activity);
		}
    	
	}
	
}
