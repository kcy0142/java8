/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : JacksonUtils.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.fasterxml.jackson.databind.node.MissingNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

public class JacksonUtils {
	/**
	 * from json혹은 to json으로 변환하기 위한 mapper클래스
	 */
	private static ObjectMapper mapper;
	
	static {
		mapper = new ObjectMapper();
	}
	
	public static ObjectNode createNode() {
		return mapper.createObjectNode();
	}
	
	public static MissingNode createMissingNode() {
		return MissingNode.getInstance();
	}
	
	public static String getString(JsonNode node) {
		String str = null;
		switch(node.getNodeType()) {
		case MISSING : 
			break;
		case OBJECT : 
			str = JacksonUtils.toString(node);
			break;
		default : 
			str = node.asText();
			break;
		}
		return str;
	}
	
	
	public static String toString(JsonNode node) {
		if( node == null ) {
			return null;
		}
		try {
			return mapper.writeValueAsString(node);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}
	public static JsonNode read(Map<String, Object> map) {
		if( map == null ) {
			return null;
		}
		
		return mapper.convertValue(map, JsonNode.class);
	}
	
	
	public static JsonNode read(String jsonString) {
		if( StringUtils.isEmpty(jsonString)) {
			return null;
		}
		try {
			return mapper.readTree(jsonString);
		} catch (Exception e) {
		}
		return null;
	}
	
	public static Map<String, Object> toMap(JsonNode jsonNode) {
		
		if( jsonNode == null ) {
			return null;
		}
		return mapper.convertValue(jsonNode, Map.class);
	}
	
	public static List<String> toList(JsonNode jsonNode) {
		if( jsonNode == null || jsonNode.getNodeType() != JsonNodeType.ARRAY ) {
			return Collections.EMPTY_LIST;
		}
		
		ArrayNode arrayNode = (ArrayNode)jsonNode;
		List<String> list = new ArrayList<>(arrayNode.size());
		
		for( int i = 0; i < arrayNode.size(); i++ ) {
			list.add(toString(arrayNode.get(i)));
		}
		
		return list;
	}
}
