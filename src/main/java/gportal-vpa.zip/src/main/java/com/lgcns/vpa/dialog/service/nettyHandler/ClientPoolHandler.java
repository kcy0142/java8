/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ClientPoolHandler.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.service.nettyHandler;

import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.lgcns.vpa.dialog.service.NettyPoolClientService;
import com.lgcns.vpa.dialog.util.TripleDESUtil;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.pool.ChannelPool;
import io.netty.util.Attribute;

/**
 * <PRE>
 * Netty Client Handler
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
public class ClientPoolHandler extends SimpleChannelInboundHandler<String> {

	private static final Logger log = LoggerFactory.getLogger(ClientPoolHandler.class);
	private final ChannelPool channelPool;
	
	public ClientPoolHandler (ChannelPool channelPool) {
        this.channelPool = channelPool;
    }
	
	@Override
	protected void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {
		
		String result = null;
		
		if ( StringUtils.hasText(msg) ) {
			//String->map으로 전환
			ObjectMapper mapper=new ObjectMapper();
			JsonNode root = mapper.readTree(msg);
			
			//Message 복호화 시작
	        String tenantId = root.path("tenantId").asText();
	        String mapKey = root.path("mapKey").asText();
	        String secretKey = TripleDESUtil.decrypt(mapKey);
	        String encryptedMessage = root.path("actionMessage").asText();

	        String decryptedMessage = TripleDESUtil.decrypt( encryptedMessage, secretKey );
	        if( StringUtils.hasText(decryptedMessage ) ) {	        
	        	JsonNode actionResultJsonNode = mapper.readTree(decryptedMessage);
	        	((ObjectNode) root).set("actionResult", actionResultJsonNode);
	        }
	        
	        ((ObjectNode) root).put("actionMessage", "decrypted");
	        
	        result = root.toString();
			
		}
		
		Attribute<CompletableFuture<String>> futureAttribute = ctx.channel().attr(NettyPoolClientService.FUTURE);
		CompletableFuture<String> future = futureAttribute.get();
		
		channelPool.release(ctx.channel());
		ctx.close();
        future.complete(result);
	}
	
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
		Attribute<CompletableFuture<String>> futureAttribute = ctx.channel().attr(NettyPoolClientService.FUTURE);
		CompletableFuture<String> future = futureAttribute.get();
        cause.printStackTrace();
        channelPool.release(ctx.channel());
        ctx.close();
        future.completeExceptionally(cause);
	}
	
	
//	
	/*@Override
    public void channelActive(ChannelHandlerContext ctx) {
		
		StringBuilder msg = new StringBuilder(action.toJson());
		msg.append("\r\n");
		
		//ctx.writeAndFlush("1234\r\n");
		ctx.writeAndFlush(msg.toString());
	}*/
	
	
/*	protected void channelRead0_test(ChannelHandlerContext ctx, String msg) throws Exception {
		System.out.println("@@@@@Return Message : ["+msg+"]");
		System.out.println("channelId : "+ctx.channel().id());
		Attribute<CompletableFuture<String>> futureAttribute = ctx.channel().attr(NettyPoolClientService.FUTURE);
        //CompletableFuture<String> future = futureAttribute.getAndRemove();
		CompletableFuture<String> future = futureAttribute.get();

       // channelPool.release(ctx.channel(), ctx.channel().voidPromise());
        future.complete(msg);
	}
	
	@Override
	protected void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {
		
		log.info("@@@@@ channelRead0 Return Message : "+msg+"");
		
		String result = null;
		
		if ( StringUtils.hasText(msg) ) {
				
			
			//String->map으로 전환
			ObjectMapper mapper=new ObjectMapper();
			JsonNode root = mapper.readTree(msg);
			
			//Message 복호화 시작
	        String tenantId = root.path("tenantId").asText();
	        String mapKey = root.path("mapKey").asText();
	        String secretKey = TripleDESUtil.decrypt(mapKey);
	        String encryptedMessage = root.path("actionMessage").asText();
	        String decryptedMessage = TripleDESUtil.decrypt( encryptedMessage, secretKey );
	        
	        if( StringUtils.hasText(decryptedMessage ) ) {
		        JsonNode actionResultJsonNode = mapper.readTree(decryptedMessage);
	        
		        if ( actionResultJsonNode != null ) {
		        	((ObjectNode) root).set("actionResult", actionResultJsonNode);
		        }
	        }
	        ((ObjectNode) root).put("actionMessage", "decrypted");
	        
	        result = mapper.writeValueAsString(root);
        
		}
		Attribute<CompletableFuture<String>> futureAttribute = ctx.channel().attr(NettyPoolClientService.FUTURE);
		
		CompletableFuture<String> future = futureAttribute.get();
		channelPool.release(ctx.channel(), ctx.channel().voidPromise());
		
		log.info("@@@@@ channelRead0 Return last result : "+result+"");
		ctx.close();
        future.complete(result);
        
	}
	
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
		Attribute<CompletableFuture<String>> futureAttribute = ctx.channel().attr(NettyPoolClientService.FUTURE);
		//CompletableFuture<String> future = futureAttribute.getAndRemove();
		CompletableFuture<String> future = futureAttribute.get();
        cause.printStackTrace();
        channelPool.release(ctx.channel());
        ctx.close();
        future.completeExceptionally(cause);
	}*/
	 
}
