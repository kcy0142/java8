/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseDocument;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.config.BotConfig;
import com.lgcns.vpa.channel.model.config.PushConfig;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <pre>
 * 봇 대화관리 Document Model
 * </pre>
 * @author
 */
@Document(collection="conversations")
@CompoundIndexes({
    @CompoundIndex(name = "conversation_idx1", def = "{'userId': 1, 'botId': 1}", unique = true)
})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Conversation extends BaseDocument {
    // 오픈시 대화는 사용자 : Bot 이 1 : 1 로 전제하에 개발됨 (userId, botId)
    // 향후 다자간 대화를 사용하는 경우 participants 필드를 활용하면 됨 (participants)

    /**
     * 사용자 ID
     */
    @Indexed(name = "conversation_idx2")
    private String userId;

    /**
     * 봇 ID (ObjectID)
     */
    @Indexed(name = "conversation_idx3")
    private String botId;

    /**
     * 대화 입장일시 (최종 입장일시 업데이트)
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private Date enterDate;
 
    /**
     * 최종 데일리 푸시 조회일시 (최종 조회일시 업데이트)
     */
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private Date dailyPushDate;
    
    /**
     * 봇 정보
     */
    @Transient
    private Bot bot;

    /**
     * 참여자 정보 (다자간 대화 서비스 지원하지 않는 경우 사용하지 않음)
     */
    @Transient
    private List<Participant> participants;

    /**
     * 대화 내역 (Activity)
     */
    @Transient
    private List<Activity> activities;
    
    /**
     * 마지막 대화 (Activity)
     */
    @Transient
    private Activity lastActivity;

    /**
     * 메시지 액티비티 건수
     */
    @Transient
    private Integer activityCount;
    
    /**
     * 사용자의 대화 목록
     */
    @Transient
    List<Conversation> conversations;

    /**
     * 개인별 봇 설정
     */
    @Transient
    private BotConfig botConfig;

    /**
     * 데일리 알림 설정
     */
    @Transient
    private List<PushConfig> dailyPushConfigs;
    
    /**
     * 푸시 알림 설정
     */
    @Transient
    private List<PushConfig> pushConfigs;
    
    /**
     * 최초 로그인 여부
     */
    @Transient
    private boolean firstLogin;
    
    /**
     * 당일 최초 로그인 여부
     */
    @Transient
    private boolean firstTodayConversation;
    
    /**
     * 데일리 푸시 표시 여부
     */
    @Transient
    private boolean hasUserTodayDailyPush;

    /**
     * 오늘의 이벤트
     */
    @Transient
    private Event event;
    
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public Bot getBot() {
        return bot;
    }

    public void setBot(Bot bot) {
        this.bot = bot;
    }

    public Date getEnterDate() {
        return enterDate;
    }

    public void setEnterDate(Date enterDate) {
        this.enterDate = enterDate;
    }

    public Date getDailyPushDate() {
        return dailyPushDate;
    }

    public void setDailyPushDate(Date dailyPushDate) {
        this.dailyPushDate = dailyPushDate;
    }

    public List<Activity> getActivities() {
        return activities;
    }

    public void setActivities(List<Activity> activities) {
        this.activities = activities;
    }
    
    public Activity getLastActivity() {
        return lastActivity;
    }

    public void setLastActivity(Activity lastActivity) {
        this.lastActivity = lastActivity;
    }

    public Conversation addActivity(Activity activity) {
        if (this.activities == null) {
            this.activities = new ArrayList<>();
        }
        this.activities.add(activity);
        return this;
    }
    
    public Integer getActivityCount() {
        return activityCount;
    }

    public void setActivityCount(Integer activityCount) {
        this.activityCount = activityCount;
    }

    public List<Conversation> getConversations() {
        return this.conversations;
    }

    public void setConversations(List<Conversation> conversations) {
        this.conversations = conversations;
    }

    public Conversation addConversation(Conversation conversation) {
        if (this.conversations == null) {
            this.conversations = new ArrayList<>();
        }
        this.conversations.add(conversation);
        return this;
    }

    public List<Participant> getParticipants() {
        return participants;
    }

    public void setParticipants(List<Participant> participants) {
        this.participants = participants;
    }

    public Conversation addParticipant(Participant participant) {
        if (this.participants == null) {
            this.participants = new ArrayList<>();
        }
        participants.add(participant);
        return this;
    }
    
    public BotConfig getBotConfig() {
        return botConfig;
    }

    public void setBotConfig(BotConfig botConfig) {
        this.botConfig = botConfig;
    }
    
    public List<PushConfig> getDailyPushConfigs() {
        return dailyPushConfigs;
    }

    public void setDailyPushConfigs(List<PushConfig> dailyPushConfigs) {
        this.dailyPushConfigs = dailyPushConfigs;
    }

    public List<PushConfig> getPushConfigs() {
        return pushConfigs;
    }

    public void setPushConfigs(List<PushConfig> pushConfigs) {
        this.pushConfigs = pushConfigs;
    }
    
    public boolean isHasUserTodayDailyPush() {
        return hasUserTodayDailyPush;
    }

    public void setHasUserTodayDailyPush(boolean hasUserTodayDailyPush) {
        this.hasUserTodayDailyPush = hasUserTodayDailyPush;
    }
    
    public boolean isFirstLogin() {
        return firstLogin;
    }

    public void setFirstLogin(boolean firstLogin) {
        this.firstLogin = firstLogin;
    }

    public boolean isFirstTodayConversation() {
        return firstTodayConversation;
    }

    public void setFirstTodayConversation(boolean firstTodayConversation) {
        this.firstTodayConversation = firstTodayConversation;
    }
    
    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    /**
     * <pre>
     * 대화 참여자 (다자간 대화인 경우에만 활용)
     * </pre>
     * @author
     */
    public static class Participant {

        /**
         * 참여자 ID
         */
        private String participantId;

        /**
         * 참여자 유형 (U: 사용자, B: Bot) or Bot 여부: botYn (Y/N)
         */
        private String participantType;

        /**
         * 대화 입장일시 (최종 입장일시 업데이트)
         */
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private Date enterDate;

        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private Date registDate;

        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
        private Date updateDate;

        public String getParticipantId() {
            return participantId;
        }

        public void setParticipantId(String participantId) {
            this.participantId = participantId;
        }

        public String getParticipantType() {
            return participantType;
        }

        public void setParticipantType(String participantType) {
            this.participantType = participantType;
        }

        public Date getEnterDate() {
            return enterDate;
        }

        public void setEnterDate(Date enterDate) {
            this.enterDate = enterDate;
        }

        public Date getRegistDate() {
            return registDate;
        }

        public void setRegistDate(Date registDate) {
            this.registDate = registDate;
        }

        public Date getUpdateDate() {
            return updateDate;
        }

        public void setUpdateDate(Date updateDate) {
            this.updateDate = updateDate;
        }
    }
}
