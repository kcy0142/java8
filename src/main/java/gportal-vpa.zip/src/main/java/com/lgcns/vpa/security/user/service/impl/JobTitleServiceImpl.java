package com.lgcns.vpa.security.user.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotMessage;
import com.lgcns.vpa.channel.service.impl.BotServiceImpl.BotContracts;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.intent.entity.EntityDictionary.UserContracts;
import com.lgcns.vpa.security.user.dao.JobTitleDao;
import com.lgcns.vpa.security.user.model.JobTitle;
import com.lgcns.vpa.security.user.service.JobTitleService;

@Service("multi.jobTitleService")
public class JobTitleServiceImpl implements JobTitleService {
	
	@Autowired
	private JobTitleDao jobTitledao;

	/**
     * JobTitle 정보를 cache하기 위한 용도임
     */
    @Autowired
    private RedisTemplate redisTemplate;
    
    /**
	 * JOB Title key --> 상세
	 */
	public static final String JOB_TITLE_CODE_KEY 	= "%s:jobTitle:code:%s";
	
	public static final String JOB_TITLE_DATA 		= "%s:jobTitle:data:%s:%s";
	
	public static final String COL_JT_NAME 			= "JOB_TITLE_NAME";
	public static final String COL_JT_EN_NAME 		= "JOB_TITLE_ENGLISH_NAME";
    
    /**
     * Job Title 목록 조회
     * @param botId
     * @return
     */
    
	public List<JobTitle> selectAllJobTitle(String botId) {
		
		List<JobTitle> jobTitleList = null;
		
		// 1. Redis의 JobTitle 정보를 읽어온다.
		// 2. Redis 정보가 없으면 DB에서 정보를 읽어온다.
		// 3. DB 정보를 읽어온 후 Redis에 정보를 Load 한다.
		// 4. 결과를 리턴한다.
		
		//Redis 정보를 조회
		String tenantId = DataSourceKeyHolder.getDataSourceKey();
		String jobTitleCodeKey = String.format(JOB_TITLE_CODE_KEY, tenantId, botId);
		
		SetOperations<String, String> setOper = redisTemplate.opsForSet();
		HashOperations<String, String, Object> hasOper = redisTemplate.opsForHash();
    	//ListOperations<String, BotMessage> listOps = redisTemplate.opsForList();
		
		Set<String> jobTitleCodes = setOper.members(jobTitleCodeKey);
    	
		if ( jobTitleCodes.isEmpty() ) {
			jobTitleList = this.jobTitledao.selectAllJobTitle();
			
			//Redis에 JobTitle 정보 Load
			if ( (jobTitleList != null) && (!jobTitleList.isEmpty()) ) {
				
				String jobTitleCode = null, jobTitleDataKey = null;
				
				for ( JobTitle jobTitle : jobTitleList) {
					jobTitleCode = jobTitle.getJobTitleCode();
					jobTitleDataKey = String.format(JOB_TITLE_DATA, tenantId, botId, jobTitleCode);
							
					setOper.remove(jobTitleCodeKey, jobTitleCode);
					hasOper.delete(jobTitleDataKey, COL_JT_NAME);
					hasOper.delete(jobTitleDataKey, COL_JT_EN_NAME);
					
					setOper.add(jobTitleCodeKey, jobTitleCode);
					hasOper.put(jobTitleDataKey, COL_JT_NAME, jobTitle.getJobTitleName());
					hasOper.put(jobTitleDataKey, COL_JT_EN_NAME, jobTitle.getJobTitleEnglishName()); 
				}
			}
		}
		else {
			
			jobTitleList = new ArrayList<JobTitle>();
			Map<String, Object> jobTitleMap = null; 
					
			//Redis에서 JobTitle Data를 읽어옴
			for (String jobTitleCode : jobTitleCodes) {
				if ( !StringUtils.isEmpty(jobTitleCode) ) {
					jobTitleMap = hasOper.entries(String.format(JOB_TITLE_DATA, tenantId, botId, jobTitleCode));
					
					if ( !jobTitleMap.isEmpty() ) {
						jobTitleList.add(new JobTitle (jobTitleCode, (String)jobTitleMap.get(COL_JT_NAME), (String)jobTitleMap.get(COL_JT_EN_NAME)));
					}
				}
			}
		}
    	
		
		return ( (jobTitleList == null) || (jobTitleList.isEmpty()) ) ? null : jobTitleList;
	}
	

}
