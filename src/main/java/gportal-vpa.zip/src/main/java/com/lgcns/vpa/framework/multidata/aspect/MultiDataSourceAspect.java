/* ------------------------------------------------------------------------------
 * Project       : NextEP Project
 * Source        : MongoAspect.java
 * Author        : 최환준
 * Copyright 2017 LG CNS All rights reserved
 *------------------------------------------------------------------------------ */
package com.lgcns.vpa.framework.multidata.aspect;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.security.authentication.model.UserDetailsImpl;

/**
 * bean명이 vpa.*Service인 경우, 혹은 메소드에 com.lgcns.vpa.framework.multidata.annotation.MultiDataSource를 설정
 * 한 경우,  * 서비스 도메인으로부터 routing할 datasource key를 설정함
 * @author 70399
 */

@Aspect 
@Component
@Order(value=0)
public class MultiDataSourceAspect {

    private static final Logger logger = LoggerFactory.getLogger(MultiDataSourceAspect.class);

    

    @Autowired
    Environment env;

    @Before("bean(multi.*Service)||@annotation(com.lgcns.vpa.framework.multidata.annotation.MultiDataSource)")
    public void doBefore(final JoinPoint joinPoint) { 
        DataSourceKeyHolder.DataSourceKey dataSourceKey = DataSourceKeyHolder.getRawDataSourceKey();
        
        logger.info("KEY INFO : {} ", dataSourceKey);
        if( dataSourceKey == null ) {
	        
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        String tenantId = null;
	        if (authentication != null &&
	        	authentication.isAuthenticated() && 
	        	authentication instanceof UsernamePasswordAuthenticationToken){

	            UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
	            
	            logger.info("{} - from SecurityContextHolder:" + userDetails.getTenantId());
	            tenantId = userDetails.getTenantId();

	        } else {
	        	if ( RequestContextHolder.getRequestAttributes() != null ) {
	
	        		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	        		tenantId = (request != null && request.getAttribute("vpa.tenantId") != null) ?  
	        				request.getAttribute("vpa.tenantId").toString() : env.getProperty(request.getServerName());
	        	}
	        } 
	        if( StringUtils.isEmpty(tenantId)){
	        	logger.warn("tenantId is null");
	        	return;
	        }
	        
            DataSourceKeyHolder.setDataSourceKey(tenantId);
            dataSourceKey = DataSourceKeyHolder.getRawDataSourceKey();
        }
        dataSourceKey.increaseReference();
    }

    @After("bean(multi.*Service)||@annotation(com.lgcns.vpa.framework.multidata.annotation.MultiDataSource)")
    public void doAfter(final JoinPoint joinPoint) {
    	DataSourceKeyHolder.DataSourceKey dataSourceKey = DataSourceKeyHolder.getRawDataSourceKey();
        if( dataSourceKey != null && dataSourceKey.decreaseReference() < 1 ) {
        	DataSourceKeyHolder.clearDataSourceKey();
        }
    }

    @AfterThrowing(pointcut="bean(multi.*Service)||@annotation(com.lgcns.vpa.framework.multidata.annotation.MultiDataSource)", throwing="ex")	
    public void afterThrowing(final JoinPoint joinPoint, Throwable ex) {
    	DataSourceKeyHolder.DataSourceKey dataSourceKey = DataSourceKeyHolder.getRawDataSourceKey();
        
    	if( dataSourceKey != null && dataSourceKey.decreaseReference() < 1 ) {
        	DataSourceKeyHolder.clearDataSourceKey();
        }
    }
}