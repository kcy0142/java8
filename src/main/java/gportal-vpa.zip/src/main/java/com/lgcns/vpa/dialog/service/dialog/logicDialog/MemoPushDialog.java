/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : MemoPushDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.model.InquiryVO;

/**
 * <PRE>
 * 메모알림 목록조회 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 4.
 */
@Component("MemoPushDialog")
public class MemoPushDialog extends LogicDialog {

	//private static final Logger LOG = LoggerFactory.getLogger(MemoPushDialog.class);
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	@Override
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_MEMO);
	        //attachment.setTitle(inquiryData.getIntentMessage());
	        
	        // 오늘 메모알림이 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("등록된 메모알림이 없습니다.");
	            
	        }
	        // 오늘 메모알림이 존재하는 경우    
	        else {
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
	        			//String userId = proxyResult.get("userId").toString();
	    				//String message = proxyResult.get("message").toString();
	    				String title = ( proxyResult.get("title") != null ) ? proxyResult.get("title").toString() : "";
	    				String text = ( proxyResult.get("text") != null ) ? proxyResult.get("text").toString() : "";
	    				
	    				Element element = new Element();
	    				element.setTitle(title);
	    				element.setText(text);
	    				
	    				attachment.addElement(element);
	        		}
	        	}//for
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}

}
