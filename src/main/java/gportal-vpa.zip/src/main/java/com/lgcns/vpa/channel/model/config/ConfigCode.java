/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.config;

/**
 * <pre>
 * 사용자 및 봇 설정 Code
 * </pre>
 * @author
 */
public interface ConfigCode {
    
    /**
     * 알림 유형코드 (전체)
     */
   String PUSH_TYPE_CODE_ALL = "ALL";
    
	/**
	 * 알림 유형코드 (데일리 알림)
	 */
   String PUSH_TYPE_CODE_DAILY = "DAILY";
   
   /**
    * 알림 유형코드 (푸시 알림)
    */
   String PUSH_TYPE_CODE_PUSH = "PUSH";
   
   /**
    * 알림 유형코드 (시스템 알림)
    */
   String PUSH_TYPE_CODE_SYSTEM = "SYSTEM";
  
  /**
   * 알림 속성 양식 유형
   */
  String FORM_TYPE_CODE_RADIO = "RADIO";
  
  String FORM_TYPE_CODE_CHECK = "CHECK";
  
  String FORM_TYPE_CODE_SELECT = "SELECT";
}