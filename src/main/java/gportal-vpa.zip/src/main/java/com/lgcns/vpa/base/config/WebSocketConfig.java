/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.base.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.session.ExpiringSession;
import org.springframework.session.web.socket.config.annotation.AbstractSessionWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;

/**
 * <pre>
 * Spring WebSocket 설정
 * </pre>
 * @author
 */
@Configuration
@EnableScheduling
@EnableWebSocketMessageBroker
public class WebSocketConfig extends AbstractSessionWebSocketMessageBrokerConfigurer<ExpiringSession> {
    // WebSocketConnectHandlerDecoratorFactory
    // 스프링 세션이 종료될 때 열려있는 웹소켓커넥션을 종료시키는데 WebSocketSession 필요합니다.
    
    // SessionRepositoryMessageInterceptor
    // HandshakeInterceptor로써 모든 StompWebSocketEndpointRegistration에 추가됩니다.
    // 이것은 마지막 접근된 시간을 수정하기 위해, 세션이 웹소켓 프로퍼티에 추가된다는 것을 보장합니다
    
    // SessionRepositoryMessageInterceptor
    // ChannelInterceptor로써, 우리의 인바운드 ChannelRegistration에 추가됩니다.
    // 이것은 인바운드 메시지가 수신되는 매시간과, 스프링세션에 접근되는 마지막시간이 updated됨을 보장합니다.
    
    // WebSocketRegistryListener
    // 스프링 빈으로써 생성됩니다. 이것은 웹소켓 코넥션에 해당하는 모든 세션 아이디의 매핑을 가지고 있음을 보장합니다.
    // 이 매핑을 가지고 있음으로써, 우리는 스프링 세션(http session)이 종료될 때 모든 웹소켓을 닫을 수가 있습니다
    
    final Logger logger = LoggerFactory.getLogger(WebSocketConfig.class);
    
    @Override
    protected void configureStompEndpoints(StompEndpointRegistry registry) {
        registry
            .addEndpoint("/ws")
            .setAllowedOrigins("*")
            .withSockJS()
            .setSessionCookieNeeded(true);
            //.setStreamBytesLimit(512 * 1024)
            //.setHttpMessageCacheSize(1000)
            //.setDisconnectDelay(30 * 1000);
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.enableSimpleBroker("/topic");
        config.setApplicationDestinationPrefixes("/app");
    }
}