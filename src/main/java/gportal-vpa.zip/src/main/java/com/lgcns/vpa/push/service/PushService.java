/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : PushService.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service;

import java.util.Map;

import com.lgcns.vpa.channel.model.config.PushConfig;

/**
 * <pre>
 *  Push 알림 Service
 * </pre>
 * @author
 */
public interface PushService {

	/**
	 * Push 알림 공통 서비스
	 * @param params
	 * @param tenantId
	 * @param pushConfig
	 */
	public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig);
	
}
