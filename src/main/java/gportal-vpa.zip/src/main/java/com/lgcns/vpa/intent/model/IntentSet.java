/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentSet.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.model;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.lgcns.vpa.intent.model.IntentMongo.Parameter;
import com.lgcns.vpa.intent.util.MessageUtils;

/**
 * 의도는 동일하나 파라미터셋이 다른 경우, 
 * @author 70399
 *
 */
public class IntentSet extends IntentBase implements Iterable<IntentBase>{
	
	private String messageTemplate;
	
	public IntentSet() {
		super();
	}
	
	public IntentSet(IntentMongo intentMongo) {
		super(intentMongo);
	}
	
	@Override
	public Iterator<IntentBase> iterator() {
		return new IntentIterator();
	}
	
	public void setMessageTemplate(String messageTemplate) {
		this.messageTemplate = messageTemplate;
	}
	
	public String toString() {
		String str = "";//super.toString();
		Iterator<IntentBase> iterator = iterator();
		while(iterator.hasNext()) {
			str += iterator.next().toString();
		}
		return str;
	}

	class IntentIterator implements Iterator<IntentBase> {

		private int pos = 0;
		private String dupField;
		private Parameter dupParameter;
		List<String> dups;
		public IntentIterator() {
			dupField = getStatus().getField();
			dupParameter = getParameter(dupField);
			Object obj = dupParameter.getValue();
			if( obj != null && obj instanceof List ) {
				dups = (List)obj;
			} else {
				dups = Collections.EMPTY_LIST;
			}
		}
		@Override
		public boolean hasNext() {
		
			return dups.size() > pos;
		}

		@Override
		public IntentBase next() {

			IntentBase entry = new IntentBase(getId(), getBotId(), getIntentId(), getIntentName(), getIntentType(), getContexts(), isAutorun(), getUtterance());
			entry.setStatus(getStatus());
			entry.putParameters(dupField, 
					new Parameter(dupField, 
							dups.get(pos), 
							dupParameter.getDataType(), 
							dupParameter.isRequired()));
			entry.setMessage(MessageUtils.translateText(dups.get(pos), messageTemplate));
			pos++;
			return entry;
		}
		
	}

}
