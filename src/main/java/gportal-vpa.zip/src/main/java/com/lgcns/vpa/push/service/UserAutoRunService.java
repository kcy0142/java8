/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserAutoRunService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service;

import java.util.List;
import java.util.Map;

import com.lgcns.vpa.push.model.UserAutoRun;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * 개인별 자동 실행 Service
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 11. 28.
 */
public interface UserAutoRunService {
	
	/**
	 * 개인별 설정된 자동 실행 목록 조회
	 * @param botId
	 * @param userId
	 * @return
	 */
	public List<UserAutoRun> list(String botId, String userId);
	
	/**
	 * 개인별 자동실행 내역 상세 조회
	 * @param botId
	 * @param userAutoRunId
	 * @return
	 */
	public UserAutoRun retrieve(String botId, String userAutoRunId);
	
	/**
	 * 개인별 자동실행 내역 생성
	 * @param userAutoRun
	 * @return
	 */
	public String create(UserAutoRun userAutoRun);
	
	/**
	 * 개인별 자동실행 내역 삭제
	 * @param botId
	 * @param userAutoRunId
	 */
	public void delete(String botId, String userAutoRunId);
	
	/**
	 * 현재 시간대(현재 시간 +- 20분)의 자동 실행해야하는 개인별 자동 실행 내역 목록 조회
	 * @param botId
	 * @param reqUser
	 * @return
	 */
	public List<UserAutoRun> listFireTarget(String botId, User reqUser);
	
	/**
	 * 자동 실행중인 개인별 자동 실행 내역의 실행 상태 변경
	 * @param params
	 */
	public void updateProcessStatusFireTarget(Map<String, Object> params);
	
	/**
	 * 자동 실행중인 개인별 자동 실행 내역의 실행 상태 변경
	 * @param botId
	 * @param nextRunTimeEnd
	 * @param reqUser
	 */
	public void updateProcessStatusFireTarget(String botId, long nextRunTimeEnd, User reqUser);
	
	/**
	 * 자동 실행을 완료한 개인별 자동 실행 내역의 상태 변경
	 * @param userAutoRun
	 */
	public void updateResultStatus(UserAutoRun userAutoRun);
	
	/**
	 * 개인별 자동 실행 설정내용의 실행
	 * @param botId
	 * @param tenantId
	 * @param reqUser
	 */
	public void startAutoRunJob(String botId, String tenantId, User reqUser);
	
	/**
	 * WebSocket이 연결중인지 검사
	 * @param userId
	 * @return
	 */
	public boolean isWebSocketAlive (String userId);
	
	/**
	 * 실행 중인 사용자 자동 실행 건의 초기화, 오류성 데이터를 초기화 한다.
	 * 초기화는 상태를 Waiting 으로, nextRunTime을 현재 시간 이후로 설정함
	 * @param botId
	 * @param tenantId
	 * @param reqUser
	 */
	public void runningUserAutoRunInit (String botId, String tenantId, User reqUser);
}
