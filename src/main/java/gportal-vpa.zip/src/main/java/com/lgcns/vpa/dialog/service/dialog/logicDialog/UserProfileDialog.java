/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserProfileDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;

/**
 * <PRE>
 * 임직원 정보 조회 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 9.
 */
@Component("UserProfileDialog")
public class UserProfileDialog extends LogicDialog {

	//private static final Logger LOG = LoggerFactory.getLogger(UserProfileDialog.class);
	
	@Autowired
	private DialogConfig dialogConfig;
	
	@Override
	protected List<Attachment> getAttachment(InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet)
			throws Exception {
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_USRE_PROFILE);
	        
	        // 사용자 정보가 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	        	attachment.setDescriptions("조회된 사용자 정보가 없습니다.");
	        }
	        else {
	        	
	        	/*"id": "73381",
	        	-- "corpCode": "LG01", (없어도 됨)
	        	"imageUrl": "http://approval.lgcns.com/files/photo/LG01/73381.jpg",
	        	"additionalProperties": {
	        	   USER_ID "userId": "73381",
	        	   USER_NAME "userName": "김상영",
	        	   JOB_TITLE_NAME "jobTitleName": "차장",
	        	   JOB_TITLE_ENGLISH_NAME "jobTitleEnglishName": "Application Development Advisory",
	        	   GROUP_ID "groupId": "9912333,
	        	   GROUP_NAME "groupName": "UC서비스팀",
	        	   FULL_PATH_NAME "fullPathName": "하이테크 사업부 ERP운영담당 UC서비스팀",
	        	   MOBILE "mobile": "010-3424-2846",
	        	   OFFICE_PHONE_NO "officePhoneNo": "02-2099-1111",
	        	   MAIL "mail": "gportal@lgcns.com",
	        	   "corpCode": "LG01" 
	        	}
	        	
	        	{
				USER_ID=66098, USER_NAME=김성진, USER_TITLE=부장, 
				JOB_TITLE_NAME=부장, JOB_TITLE_ENGLISH_NAME=Application Development Senior Leader, 
				GROUP_NAME=개발혁신팀, JOB_DUTY_NAME=Application Development Senior Leader, 
				USER_PHOTO_URL=http://approval.lgcns.com/files/photo/LG01/66098.jpg, 
				USER_EMAIL=gportal@lgcns.com, MAIL=gportal@lgcns.com, 
				OFFICE_PHONE_NO=02-2099-6841, MOBILE=010-3397-5909, 
				TIMEZONE=Asia/Tokyo, 
				OFFICE_ADDRESS=서울특별시 영등포구 여의대로 24 (여의도동) FKI 타워28층, 
				LEADER=1, 
				GROUP_ID=98905, 
				FULL_PATH_NAME=하이테크사업부 엔터프라이즈솔루션이행담당 개발혁신팀, 
				FULL_PATH_ENGLISH_NAME=Hi-Tech BD. Enterprise Solution Unit Development Innovation Team, 
				CORP_NAME=LG CNS, 
				CORP_ENGLISH_NAME=LG CNS
				}
	        	*/
	        	
	        	//User Profile Image Url을 Properties 에서 읽어온다.
	        	String userProfileUrl = this.dialogConfig.getDialogInfo(inquiryData.getTenantId(), "url", "userProfileImage");
	        	String id = null, userName = null, jobTitleName = null, jobTitleEnglishName = null, userPhotoUrl = null, leader = null;
	        	String groupId = null, groupName = null, fullPathName = null, mobile = null, officePhoneNo = null, mail = null, jobDutyName = null;
	        	
	        	// 사용자 항목 처리
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		
	        		id = ( proxyResult.get("USER_ID") != null ) ? String.valueOf(proxyResult.get("USER_ID")) : "";
	        		userName = ( proxyResult.get("USER_NAME") != null ) ? String.valueOf(proxyResult.get("USER_NAME")) : "";
	        		jobTitleName = ( proxyResult.get("JOB_TITLE_NAME") != null ) ? String.valueOf(proxyResult.get("JOB_TITLE_NAME")) : "";
	        		jobTitleEnglishName = ( proxyResult.get("JOB_TITLE_ENGLISH_NAME") != null ) ? String.valueOf(proxyResult.get("JOB_TITLE_ENGLISH_NAME")) : "";
	        		jobDutyName = ( proxyResult.get("JOB_DUTY_NAME") != null ) ? String.valueOf(proxyResult.get("JOB_DUTY_NAME")) : "";
	        		groupId = ( proxyResult.get("GROUP_ID") != null ) ? String.valueOf(proxyResult.get("GROUP_ID")) : null;
	        		groupName = ( proxyResult.get("GROUP_NAME") != null ) ? String.valueOf(proxyResult.get("GROUP_NAME")) : "";
	        		fullPathName = ( proxyResult.get("FULL_PATH_NAME") != null ) ? String.valueOf(proxyResult.get("FULL_PATH_NAME")) : "";
	        		mobile = ( proxyResult.get("MOBILE") != null ) ? String.valueOf(proxyResult.get("MOBILE")) : "";
	        		officePhoneNo = ( proxyResult.get("OFFICE_PHONE_NO") != null ) ? String.valueOf(proxyResult.get("OFFICE_PHONE_NO")) : "";
	        		mail = ( proxyResult.get("MAIL") != null ) ? String.valueOf(proxyResult.get("MAIL")) : "";
	        		leader = ( proxyResult.get("LEADER") != null ) ? String.valueOf(proxyResult.get("LEADER")) : "";
	        		userPhotoUrl = ( proxyResult.get("USER_PHOTO_URL") != null ) ? String.valueOf(proxyResult.get("USER_PHOTO_URL")) : 
	        																	   String.format(userProfileUrl, inquiryData.getCompanyCode(), id);
	        		
	        		// additionalProperties 설정
                    Map<String, Object> additionalProperties = new HashMap<String, Object>();
                    additionalProperties.put("userName", userName);
                    additionalProperties.put("jobTitleName", jobTitleName);
                    additionalProperties.put("jobTitleEnglishName", jobTitleEnglishName);
                    additionalProperties.put("jobDutyName", jobDutyName);
                    additionalProperties.put("groupId", groupId);
                    additionalProperties.put("groupName", groupName);
                    additionalProperties.put("fullPathName", fullPathName);
                    additionalProperties.put("mobile", mobile);
                    additionalProperties.put("officePhoneNo", officePhoneNo);
                    additionalProperties.put("mail", mail);
                    additionalProperties.put("leader", leader);
                    
                    
	        		Element element = new Element();
	        		element.setId(id);
	        		element.setType(CommonCode.ELEMENT_TYPE_PEOPLE);
	        		element.setCorpCode(inquiryData.getCompanyCode());
	        		element.setImageUrl(userPhotoUrl);
	        		element.setAdditionalProperties(additionalProperties);
	        		
	        		attachment.addElement(element);
	        	}
	        }
	        
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}

}
