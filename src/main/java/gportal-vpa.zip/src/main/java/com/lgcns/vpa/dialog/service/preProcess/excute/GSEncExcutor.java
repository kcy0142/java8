/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : LGCnsExcutor.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.preProcess.excute;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.ActionService;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.service.dialog.VpaDialog;
import com.lgcns.vpa.dialog.util.DialogUtil;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.framework.multidata.annotation.MultiDataSource;
import com.lgcns.vpa.intent.model.Intent;
import com.lgcns.vpa.intent.model.IntentMongo;
import com.lgcns.vpa.intent.model.IntentMongo.Utterance;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * GS Enc 전처리 로직
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2018. 1. 17.
 */
@Component("GSEncExcutor")

public class GSEncExcutor extends PreProcessExcutor {
	
	private static Logger LOG = LoggerFactory.getLogger(GSEncExcutor.class); 
	
	//전처리 질의문 패턴 교체
	private static final String KEYWORD_PATTERN = "\\{[A-Z]{1,2}\\}";
	
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Value("#{'${gsenc.preprocess.intent.list}'.split(',')}") 
	private List<String> preIntentIds;
	
	@Override
	@MultiDataSource
	protected Activity preProcess(InquiryVO inquiry) {
		
		LOG.debug("[{}] preProcess start ", DataSourceKeyHolder.getDataSourceKey());
		
		//요청된 질의문
		String inquiryData = inquiry.getInquiryData();
		//TenantId
		String tenantId = inquiry.getTenantId();
		
		//preprocess intent list에서 패턴 매칭된 의도가 있다면 
		//사용자 질의문을 변환하여 리턴한다.
		Query query = new Query(
				Criteria.where("intentId").in(preIntentIds));
		
		DataSourceKeyHolder.setDataSourceKey(tenantId);
		
		List<IntentMongo> preIntentList = mongoTemplate.find(query, IntentMongo.class);
		
		String replaceQuery = null;
		for( IntentMongo preIntent : preIntentList) {
			replaceQuery = replaceUtterances(preIntent.getUtterances(), inquiryData);
			
			if( !StringUtils.isEmpty(replaceQuery)) {
				break;
			}
		
		}
		if( !StringUtils.isEmpty(replaceQuery)) {
			inquiry.setInquiryData(replaceQuery);
		} 
		
		LOG.debug("[{}] inquiryData after preprocessor : {} ", DataSourceKeyHolder.getDataSourceKey(), replaceQuery);
		return null;
	}
	
	private String replaceUtterances(List<Utterance> utterances, String inquiryData) {
		String replaceQuery = null;
		for( Utterance utterance : utterances ) {
			replaceQuery = replace(utterance.getParsedText(), inquiryData);
			
			if( !StringUtils.isEmpty(replaceQuery)) {
				break;
			}
		}
		return replaceQuery;
	}
	/**
	 * 질의문이 학습문장 패턴과 일치하는 지 확인
	 * 일치할 경우, 키워드 전후로 [] 변환
	 * @param utterance
	 * @param inquery
	 * @return
	 */
	private String replace(String utterance, String inquery) {
		
		String noSpace = "(\\\\S+)";
		String pattern = utterance.replaceAll("\\s+", "\\\\s+");
		pattern = pattern.replaceAll(KEYWORD_PATTERN, noSpace );
		
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(inquery);
		//패턴이 매칭 확인
		if( !m.matches()) {
			return null;
		}
		
		String replace = "";
		int begin = 0;
		for(int i = 1; i <= m.groupCount(); i++) {
			int end = m.start(i);
			replace += inquery.substring(begin, end);
			replace += "[" + m.group(i) + "]";
			begin = m.end(i);
		}
		replace += inquery.substring(begin);
		return replace;
	}

}
