package com.lgcns.vpa.push.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.push.service.DailyPushService;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.ActivityCode;

/**
 * <pre>
 * 오늘의 일정 Daily Push Service
 * </pre>
 * @author
 */
@Service("multi.plannerDailyPushService")
public class PlannerDailyPushServiceImpl extends PushAbstractService implements DailyPushService {
    
    @Value("${spring.profiles.active}")
    private String profiles;
    
    // 실행예시:
    // EXEC GPTDB.gpt_user.VPASDP_SCHEDULE_DAILY_SEL '73381', '20170911', '20170911', '73381'
    
    @Autowired
    private MessageSource messageSource;
    
    @Override
    public List<Attachment> execute(Map<String, String> param, PushConfig pushConfig, Bot bot, User user, String tenantId) {
        
        LocalDate now = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd").withLocale(Locale.KOREAN);
        
        
        TransferSyncVO transferSyncVO = new TransferSyncVO();
        transferSyncVO.setActionUri(pushConfig.getActionUri());
        transferSyncVO.setTenantId(tenantId);
        
        String startDt = formatter.format(now);
       
        if (!CollectionUtils.isEmpty(param) && !StringUtils.isEmpty(param.get("startDt"))) {
            startDt = param.get("startDt");
        }
        
        String endDt = startDt;

        Map<String, Object> actionParam = new HashMap<>();
        actionParam.put("USER_ID", user.getUserId());
        actionParam.put("SEARCH_START_DT", startDt);
        actionParam.put("SEARCH_END_DT", endDt);
        actionParam.put("LOGIN_USER_ID", user.getUserId());
        actionParam.put("TIMEDIFFERENCE", null);
        actionParam.put("LOCALE", null);
        
        transferSyncVO.setActionParam(actionParam);
        
        List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
        List<Attachment> attachments = null;
        
        // 1. 오늘 일정이 존재하는 경우    
        // 2017.08.18 데일리 푸시의 경우 데이터가 존재하지 않는 경우, 영역을 표시하지 않는다.
        if (!CollectionUtils.isEmpty(proxyResultSet)) {
            Attachment attachment = new Attachment();
            attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
            attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_PLANNER);
            attachment.setTitle(pushConfig.getPushName());
      
            // 페이지 블럭 네비게이션 적용
            attachment.setBlockPagingType(ActivityCode.PAGING_TYPE_PAGER);
            attachment.setBlockDataType(ActivityCode.BLOCK_DATA_TYPE_DATE);
            
            // 오늘일자 혹은 조회일자를 기본으로 표시함
            attachment.setCurrentBlock(startDt);
               
            // 네비게이션 URL            
            String baseUrl = "/api/daily/%s?startDt=${currentBlock}";
            
            RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
            if (null != requestAttributes && requestAttributes instanceof ServletRequestAttributes) {
                HttpServletRequest request = ((ServletRequestAttributes)requestAttributes).getRequest();
                String serverUrl = String.format("%s://%s:%d", request.getScheme(), request.getServerName(), request.getServerPort());
                
                if (!StringUtils.isEmpty(serverUrl)) {
                    baseUrl = serverUrl + baseUrl;
                }
            }
            
            String pushId = pushConfig.getPushId();
            attachment.setBlockDataUrl(String.format(baseUrl, pushId));

            
            // 데일리 푸시 설명글 생성   
            // 오늘 {0} 건의 일정이 있습니다.
            StringBuffer descriptions = new StringBuffer()
                    .append(messageSource.getMessage(
                            "meesage.push.daily.planner.descriptions", 
                            new String[] { StringUtils.toString(proxyResultSet.size()) },
                            new Locale(user.getLocaleCode())));

            attachment.setDescriptions(descriptions.toString());  

            // 일정 항목 처리
            List<Element> elements = proxyResultSet.stream().map(data -> new Element() {
                private static final long serialVersionUID = -4803937536892622504L;
                {
                    this.setId(StringUtils.toString(data.get("ID")));
                    this.setBlock(StringUtils.toString(data.get("BASE_DT")));
                    this.setTitle(StringUtils.toString(data.get("SCHEDULE_TITLE")));
                    this.setSubtitle(StringUtils.toString(data.get("SUBTITLE")));
                    this.setDescriptions(StringUtils.toString(data.get("DESCRIPTIONS")));
                    this.setActionType(ActivityCode.ACTION_TYPE_LINK);
                    this.setAction(StringUtils.toString(data.get("ACTION")));
                    
                    this.addAdditionalProperty("publicYn", StringUtils.toString(data.get("PUBLIC_YN")));
                    this.addAdditionalProperty("kind", StringUtils.toString(data.get("ICON")));
                    
                    // 일정 시간 계산을 위하여 필요함
                    this.addAdditionalProperty("startDate", StringUtils.toString(data.get("START_DATE")));
                    this.addAdditionalProperty("endDate", StringUtils.toString(data.get("END_DATE")));
                    this.addAdditionalProperty("startDt", StringUtils.toString(data.get("START_DT")));
                    this.addAdditionalProperty("endDt", StringUtils.toString(data.get("END_DT")));
                    this.addAdditionalProperty("stTime", StringUtils.toString(data.get("ST_TIME")));
                    this.addAdditionalProperty("edTime", StringUtils.toString(data.get("ED_TIME")));
                    this.addAdditionalProperty("wholeday", StringUtils.toString(data.get("WHOLEDAY")));
                }
            }).collect(Collectors.toList());
            
            attachment.setElements(elements);
            attachment.setDefaultBlock(formatter.format(now));
            
            attachments = Arrays.asList(attachment);
        }
        
        return attachments;
    }
}
