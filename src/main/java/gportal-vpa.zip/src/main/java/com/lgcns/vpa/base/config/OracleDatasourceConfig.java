package com.lgcns.vpa.base.config;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.lookup.BeanFactoryDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.lgcns.vpa.framework.multidata.datasource.DataSourceRouter;

@Configuration
@EnableTransactionManagement(order=1)
@MapperScan(basePackages = "com.lgcns.vpa",  annotationClass = Mapper.class)
public class OracleDatasourceConfig implements BeanFactoryAware {

	@Value("${mybatis.mapperLocations}")
	private String mapperLocations;
	
	@Value("${mybatis.configuration.map-underscore-to-camel-case}")
	private boolean mapUnderscoreToCamelCase;
	
	@Autowired
	private BeanFactory beanFactory;

    /**
     * LG CNS DataSource 생성
     */
    @Bean(name="lgcnsDataSource")
    @ConfigurationProperties(prefix="spring.datasource.lgcns")
    public DataSource lgcnsDataSource() {
        return DataSourceBuilder.create().build();
    }
    
    /**
     * GS ENC DataSource 생성
     */
    @Profile(value={"local","dev"})
    @Bean(name="gsencDataSource")
    @ConfigurationProperties(prefix="spring.datasource.gsenc")
    public DataSource gsencDataSource() {
        return DataSourceBuilder.create().build();
    }
    
	/**
	 * DataSource 생성 
	 */
	@Primary
	@Bean(name="dataSourceRouter")
	public DataSourceRouter dataSourceRouter() {
		
		DataSourceRouter router = new DataSourceRouter();
		
		router.setTargetDataSources(multiDatasourceProperty().getDatasources());
		router.setDataSourceLookup(new BeanFactoryDataSourceLookup(beanFactory));
		return router;
	}

    /**
     * Transaction 설정
     */
    @Bean
    public PlatformTransactionManager transactionManager(@Qualifier("dataSourceRouter") DataSource dataSource) {
        DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
        transactionManager.setGlobalRollbackOnParticipationFailure(false);
        return transactionManager;
    }

    /**
     * MyBatis 연동을 위한 SessionFactory 설정
     */
    @Primary
    @Bean(name="sqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("dataSourceRouter") DataSource dataSource) throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(dataSource);
        
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        sessionFactory.setMapperLocations(resolver.getResources(mapperLocations));

        SqlSessionFactory sessionFactoryBean = sessionFactory.getObject();
        sessionFactoryBean.getConfiguration().setMapUnderscoreToCamelCase(mapUnderscoreToCamelCase);

        return sessionFactoryBean;
    }

    /**
     * MyBatis 연동을 위한 SessionTemplate 설정
     */
    @Primary
    @Bean(name="sqlSessionTemplate")
    public SqlSessionTemplate sqlSessionTemplate (SqlSessionFactory sqlSessionFactory) throws Exception {
        final SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory);
        return sqlSessionTemplate;
    }
    
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
	}
	
	@Bean(name="multiDatasourceProperty")
	public MultiDataSourceProperty multiDatasourceProperty() {
		return new MultiDataSourceProperty();
	}
	
	@ConfigurationProperties(prefix="oracle")
	public class MultiDataSourceProperty {
		
		private Map<Object, Object> datasources;

		public Map<Object, Object> getDatasources() {
			return datasources;
		}

		public void setDatasources(Map<Object, Object> sources) {
			this.datasources = sources;
		}
		
		@PostConstruct
		public void init() {
			System.out.println("*****************************");
			System.out.println(datasources);
			System.out.println("*****************************");
			
		}
	}
}
