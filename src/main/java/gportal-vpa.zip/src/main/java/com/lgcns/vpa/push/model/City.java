package com.lgcns.vpa.push.model;

public class City {
    
    /**
     * 도시코드
     */
    private String cityCode;
    
    /**
     * 도시명
     */
    private String cityName;
    
    private String cityEnglishName;
    
    /**
     * 도시 전체명 (예: 서울특별시 영등포구)
     */
    private String cityAllName;
    
    /**
     * 도시 축약명 (예: 서울 영등포구)
     */
    private String cityAllDisplayName;
    
    private String cityAllEnglishName;

    private String cityAllDisplayEnglishName;

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityEnglishName() {
        return cityEnglishName;
    }

    public void setCityEnglishName(String cityEnglishName) {
        this.cityEnglishName = cityEnglishName;
    }

    public String getCityAllName() {
        return cityAllName;
    }

    public void setCityAllName(String cityAllName) {
        this.cityAllName = cityAllName;
    }

    public String getCityAllDisplayName() {
        return cityAllDisplayName;
    }

    public void setCityAllDisplayName(String cityAllDisplayName) {
        this.cityAllDisplayName = cityAllDisplayName;
    }

    public String getCityAllEnglishName() {
        return cityAllEnglishName;
    }

    public void setCityAllEnglishName(String cityAllEnglishName) {
        this.cityAllEnglishName = cityAllEnglishName;
    }

    public String getCityAllDisplayEnglishName() {
        return cityAllDisplayEnglishName;
    }

    public void setCityAllDisplayEnglishName(String cityAllDisplayEnglishName) {
        this.cityAllDisplayEnglishName = cityAllDisplayEnglishName;
    }
}
