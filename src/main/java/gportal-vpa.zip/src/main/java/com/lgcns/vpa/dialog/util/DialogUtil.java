/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : DialogUtil.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * Dialog 처리에 쓰이는 지원 기능 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 11. 3.
 */
public class DialogUtil {

	private static final String SPACE_STR = " ";
	/**
	 * Intent에 정의되어 있는 버튼 처리
	 * @param buttons
	 * @return
	 */
	public static List<Button> makeActivityButtonList ( List<RelatedButton> buttons ) {
		
		if ( (buttons == null) || (buttons.isEmpty()) ) {
			return null;
		}
		
		List<Button> activityButtonList = new ArrayList<Button>();
		
		for ( RelatedButton<String> button : buttons ) {
			if (button != null) {
				
				Button activityButton = new Button();
				
				//Link Type Button
				if ( CommonCode.INTENT_BUTTON_TYPE_LINK.equalsIgnoreCase(button.getType()) ) {
					//RelatedButton<String> button = tmpButton;
					activityButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
					activityButton.setAction(button.getAction());
					activityButton.setTitle(button.getName());
					
					//Button Parameter 처리
					if ( !StringUtils.isEmpty(button.getParams()) ) {
						
						Map<String, Object> actionParams = JsonConverter.jsonToMap(button.getParams());
						
						if ( (actionParams != null) && (!actionParams.isEmpty()) ) {
							
							//Post 방식에 필요한 Parameter 는 ActionParameter에 설정함
							activityButton.setActionParams(actionParams);
							
							//PopupHeight 처리
							if ( actionParams.containsKey("popupHeight") ) {
								Object heightObj = actionParams.get("popupHeight");
								
								if ( heightObj != null ) {
									try {
										if ( heightObj instanceof String ) {
											int popupHeight = Integer.parseInt(String.valueOf(heightObj));
											activityButton.setPopupHeight(popupHeight);
										}
										else if ( heightObj instanceof Integer ) {
											activityButton.setPopupHeight( (Integer) heightObj );
										}
									} catch (Exception e) {
										activityButton.setPopupHeight(0);
									}
								}
							}
							
							//PopupWidth 처리
							if ( actionParams.containsKey("popupWidth") ) {
								Object widthObj = actionParams.get("popupWidth");
								
								if ( widthObj != null ) {
									try {
										if ( widthObj instanceof String ) {
											int popupWidth = Integer.parseInt(String.valueOf(widthObj));
											activityButton.setPopupWidth(popupWidth);
										}
										else if ( widthObj instanceof Integer ) {
											activityButton.setPopupWidth( (Integer) widthObj );
										}
									} catch (Exception e) {
										activityButton.setPopupWidth(0);
									}
								}
							}
						}
					}//if
					
					activityButtonList.add(activityButton);
				}
				//InQuiry Type Button
				else if (CommonCode.INTENT_BUTTON_TYPE_INQUIRY.equalsIgnoreCase(button.getType())) {
					//RelatedButton<String> button = tmpButton;
					activityButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);
					activityButton.setAction(button.getAction());
					activityButton.setTitle(button.getName());
					
					activityButtonList.add(activityButton);
				}
				//Call Type Button
				else if (CommonCode.INTENT_BUTTON_TYPE_CALL.equalsIgnoreCase(button.getType())) {
					//RelatedButton<String> button = tmpButton;
					activityButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_CALL);
					activityButton.setAction(button.getAction());
					activityButton.setTitle(button.getName());
					
					//Button Parameter 처리
					if ( !StringUtils.isEmpty(button.getParams()) ) {
						
						Map<String, Object> actionParams = JsonConverter.jsonToMap(button.getParams());
						
						if ( (actionParams != null) && (!actionParams.isEmpty()) ) {
							
							//Post 방식에 필요한 Parameter 는 ActionParameter에 설정함
							activityButton.setActionParams(actionParams);
							
							//PopupHeight 처리
							if ( actionParams.containsKey("popupHeight") ) {
								Object heightObj = actionParams.get("popupHeight");
								
								if ( heightObj != null ) {
									try {
										if ( heightObj instanceof String ) {
											int popupHeight = Integer.parseInt(String.valueOf(heightObj));
											activityButton.setPopupHeight(popupHeight);
										}
										else if ( heightObj instanceof Integer ) {
											activityButton.setPopupHeight( (Integer) heightObj );
										}
									} catch (Exception e) {
										activityButton.setPopupHeight(0);
									}
								}
							}
							
							//PopupWidth 처리
							if ( actionParams.containsKey("popupWidth") ) {
								Object widthObj = actionParams.get("popupWidth");
								
								if ( widthObj != null ) {
									try {
										if ( widthObj instanceof String ) {
											int popupWidth = Integer.parseInt(String.valueOf(widthObj));
											activityButton.setPopupWidth(popupWidth);
										}
										else if ( widthObj instanceof Integer ) {
											activityButton.setPopupWidth( (Integer) widthObj );
										}
									} catch (Exception e) {
										activityButton.setPopupWidth(0);
									}
								}
							}
						}
					}//if
					
					activityButtonList.add(activityButton);
				}//if-else
			}
		}//for
		
		return ( activityButtonList.isEmpty() ) ? null : activityButtonList;
	}//makeIntentButton() end
	
	/**
	 * Camel 실행용 Action Uri 에 개행문자, 탭문자를 공백문자 제거하고 공백문자로 변경함
	 * @param actionUri
	 * @return
	 */
	public static String makeActionUriForRun ( String actionUri ) {
		if ( StringUtils.isEmpty(actionUri) ) {
			return actionUri;
		}
		
		String acitonUriForRunStr = actionUri.replace("\r\n", SPACE_STR);
		acitonUriForRunStr = acitonUriForRunStr.replace("\n", SPACE_STR);
		acitonUriForRunStr = acitonUriForRunStr.replace("\t", SPACE_STR);
		
		return acitonUriForRunStr;
	}
}
