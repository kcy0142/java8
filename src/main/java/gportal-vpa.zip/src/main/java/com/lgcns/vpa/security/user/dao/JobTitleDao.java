package com.lgcns.vpa.security.user.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.lgcns.vpa.security.user.model.JobTitle;

@Mapper
@Repository
public interface JobTitleDao {
    /**
     * JOB Title 목록 조회
     * @return
     * @throws Exception
     */
    public List<JobTitle> selectAllJobTitle();

}
