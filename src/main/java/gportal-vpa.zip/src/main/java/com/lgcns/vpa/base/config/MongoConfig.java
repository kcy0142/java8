package com.lgcns.vpa.base.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;

import com.lgcns.vpa.framework.multidata.datasource.MongoDbFactory;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;

/**
 * MongoDB 연결 설정 클래스
 * @author 최환준
 * TODO : 테넌트의 멀티데이터소스로의 라우팅
 */
@Configuration
@ComponentScan(basePackages={"com.lgcns.vpa"})
@EnableAspectJAutoProxy
public class MongoConfig extends AbstractMongoConfiguration {
	
    @Autowired
    Environment environment;
    
	/**
	 * mongoDB 접속 host
	 * @see application.yml
	 */
	@Value("${spring.data.mongodb.host}")
	private String mongoHost;
	
	/**
	 * mongoDB 접속 port
	 * @see application.yml
	 */
	@Value("${spring.data.mongodb.port}")
	private int mongoPort;

	@Value("${spring.data.mongodb.database}")
	private String database;
	/**
	 * mongoDB 접속 계정
	 */
	@Value("${spring.data.mongodb.username}")
	private String userName;
	
	/**
	 * mongoDB 접속 계정 패스워드
	 */
	@Value("${spring.data.mongodb.password}")
	private String password;
	
	/**
	 * 연결 풀
	 * @return
	 * @throws Exception
	 */
	/*@Bean(name="lgeTemplate")
	public MongoTemplate lgeMongoTemplate() throws Exception {

		MongoTemplate mongoTemplate =
		    new MongoTemplate(new MongoClient(mongoHost, mongoPort),"lge");
		return mongoTemplate;

	}*/
	
	/**
	 * 연결 풀
	 * @return
	 * @throws Exception
	 *//*
	@Bean(name="lgcnsTemplate")
	public MongoTemplate lgcnsMongoTemplate() throws Exception {

		MongoTemplate mongoTemplate =
		    new MongoTemplate(mongo(),"lgcns");
		return mongoTemplate;

	}
*/
	@Bean
	@Override
	public MongoDbFactory mongoDbFactory() throws Exception {
      return new MongoDbFactory((MongoClient)mongo(), getDatabaseName());
	}
	
	@Override
	protected String getDatabaseName() {
		
		return database;
	}


	@Override
	public Mongo mongo() throws Exception {
		MongoCredential mongoCredential = MongoCredential
				.createCredential(userName, getDatabaseName(),
						password.toCharArray());
		
		// TODO: 우아하게 고쳐주세요.
		List<String> profiles = new ArrayList<String>(Arrays.asList(environment.getActiveProfiles()));
		if (profiles.contains("app")) {
	        MongoClientOptions mongoOptions = MongoClientOptions.builder().readPreference(ReadPreference.secondaryPreferred()).build();

	        List<ServerAddress> replicaServers = new ArrayList<>();
	        String[] servers = mongoHost.split(",");
	        for (String server : servers) {
	            replicaServers.add(new ServerAddress(server, mongoPort));
	        }
	        
	        return new MongoClient(replicaServers, Arrays.asList(mongoCredential), mongoOptions);
		} else {
		      return new MongoClient(new ServerAddress(mongoHost, mongoPort), Arrays.asList(mongoCredential));
		}
	}
	
//    @Override
//    @Profile("app")
//    public Mongo mongo() throws Exception {
//        MongoCredential mongoCredential = MongoCredential
//                .createCredential(userName, getDatabaseName(),
//                        password.toCharArray());
//        
//        
//        // MongoCredential mongoCredential = MongoCredential.createCredential(userName, getDatabaseName(), password.toCharArray());
//
//        MongoClientOptions mongoOptions = MongoClientOptions.builder().readPreference(ReadPreference.primaryPreferred()).build();
//
//        MongoClient mongoClient = new MongoClient(mongoReplicaSetConfigProperties.getSeeds(), Arrays.asList(mongoCredential), mongoOptions);
//
//        // uri 를 사용하는 경우 아래와 같이 Replica Set Connection string 사용 가능함
//        // mongodb://[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]
//        return mongoClient;
//    }	
	
	@Bean(name="mongoDatasourceProperty")
	public MongoDataSourceProperty multiDatasourceProperty() {
		return new MongoDataSourceProperty();
	}
	
	@ConfigurationProperties
	public class MongoDataSourceProperty {
		
		private Map<Object, Map<Object, Object>> mongodb;

		public Map<Object, Map<Object, Object>> getMongodb() {
			return mongodb;
		}

		public void setMongodb(Map<Object, Map<Object, Object>> mongodb) {
			this.mongodb = mongodb;
		}
		
		@PostConstruct
		public void init() {
			System.out.println("*****************************");
			System.out.println(mongodb);
			System.out.println("*****************************");
			
		}
		
	}

   /**
    * MontoTemplate
    * 컬렉션 내 _class 필드 제거하기 위하여 오버라이딩함
    */
   @Bean
   @Override
    public MongoTemplate mongoTemplate() throws Exception {
         MappingMongoConverter converter = mappingMongoConverter();
         converter.setTypeMapper(new DefaultMongoTypeMapper(null));
         return new MongoTemplate(mongoDbFactory(), converter);
    }
}
