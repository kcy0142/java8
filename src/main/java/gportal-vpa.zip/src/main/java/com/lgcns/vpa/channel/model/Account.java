/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.channel.model.config.UserConfig;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 사용자 계정 View Model
 * 사용자 정보 및 전역 설정 등을 포함
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Account {

    /**
     * 사용자 정보
     */
    private User user;

    /**
     * 사용자 설정
     */
    private UserConfig userConfig;

    /**
     * 사용자 기본 BOT
     */
    private Bot defaultBot;
    
    private List<Bot> botList;
    
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public UserConfig getUserConfig() {
        return userConfig;
    }

    public void setUserConfig(UserConfig userConfig) {
        this.userConfig = userConfig;
    }

    public Bot getDefaultBot() {
        return defaultBot;
    }

    public void setDefaultBot(Bot defaultBot) {
        this.defaultBot = defaultBot;
    }

	public List<Bot> getBotList() {
		return botList;
	}

	public void setBotList(List<Bot> botList) {
		this.botList = botList;
	}
}
