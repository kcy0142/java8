/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : RecommandUserExceptServiceImpl.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.channel.service.impl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.channel.model.RecommandUserExcept;
import com.lgcns.vpa.channel.service.RecommandUserExceptService;
import com.lgcns.vpa.framework.multidata.annotation.MultiDataSource;

/**
 * <PRE>
 * 관리자 추천키워드, 사용자의 자주쓰는 키워드, 최근 키워드 중 사용자가 표시 제외한 목록의 관리 Service 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 7. 20.
 */
@Service("multi.recommandUserExceptService")
public class RecommandUserExceptServiceImpl implements RecommandUserExceptService {
	
	private static final Logger LOG = LoggerFactory.getLogger(RecommandUserExceptServiceImpl.class);
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	/**
	 * 사용자 지정 키워드 제외 목록 조회
	 * @param userId
	 * @param botId
	 * @return
	 */
	public List<RecommandUserExcept> listRecommandUserExcept (String userId, String botId) {
		
		/*Criteria criteria = null;
		
		if ( botId != null ) {
			criteria = Criteria.where("botId").is(botId).andOperator(Criteria.where("userId").is(userId));
		}
		else {
			criteria = Criteria.where("botId").exists(false).andOperator(Criteria.where("userId").is(userId));
		}*/
		
		Criteria criteria = new Criteria();
		
		if ( botId != null ) {
			criteria.andOperator( Criteria.where("botId").is(botId), Criteria.where("userId").is(userId));
		}
		else {
			criteria.andOperator( Criteria.where("botId").exists(false), Criteria.where("userId").is(userId));
		}
		
		Query query = new Query();
		query.addCriteria(criteria);
		
		query.fields()
		.include("id")
		.include("userId")
		.include("exceptWord")
		.include("botId")
		.include("registerId")
		.include("registerName")
		.include("registDate");
		
		query.with(new Sort(Sort.Direction.ASC, "exceptWord"));
		
		return this.mongoTemplate.find(query, RecommandUserExcept.class);
	}
	
	/**
	 * id로 사용자 지정 키워드 제외 상세정보 조회
	 * @param id
	 * @param botId
	 * @return
	 */
	public RecommandUserExcept getRecommandUserExcept (String id, String botId) {
		Query query = new Query();
		
		if (botId != null) {
			query.addCriteria(Criteria.where("id").is(id).andOperator(Criteria.where("botId").is(botId)));
		}
		else {
			query.addCriteria(Criteria.where("id").is(id));
		}
		
		RecommandUserExcept recommandUserExcept = this.mongoTemplate.findOne(query, RecommandUserExcept.class);
		return recommandUserExcept;
	}
	
	/**
	 * 제외 키워드로 사용자 지정 키워드 제외 상세정보 조회
	 * @param exceptWord
	 * @param userId
	 * @param botId
	 * @return
	 */
	@Override
	@MultiDataSource
	public RecommandUserExcept getRecommandUserExceptName(String exceptWord, String userId, String botId) {
		
		Criteria criteria = new Criteria();
		
		if ( botId != null ) {
			criteria.andOperator(Criteria.where("userId").is(userId), Criteria.where("exceptWord").is(exceptWord), Criteria.where("botId").is(botId));
		}
		else {
			criteria.andOperator(Criteria.where("userId").is(userId), Criteria.where("exceptWord").is(exceptWord), Criteria.where("botId").exists(false));
		}
		
		Query query = new Query();
		query.addCriteria(criteria);
		
		RecommandUserExcept recommandUserExcept = this.mongoTemplate.findOne(query, RecommandUserExcept.class);
		return recommandUserExcept;
	}
	
	/**
	 * 사용자 지정 키워드 제외 정보 생성
	 * @param exceptWord
	 * @param userId
	 * @param userName
	 * @param botId
	 * @return
	 */
	@Override
	@MultiDataSource
	public RecommandUserExcept createRecommandUserExcept (String exceptWord, String userId, String userName, String botId) {
		
		if ( !StringUtils.hasText(exceptWord) || !StringUtils.hasText(userId) || !StringUtils.hasText(botId) ) {
			return null;
		}
		
		RecommandUserExcept existData = this.getRecommandUserExceptName( exceptWord, userId, botId );
		
		if ( existData != null) {
			return existData;
		}
		
		RecommandUserExcept recommandUserExcept = new RecommandUserExcept();
		recommandUserExcept.setUserId(userId);
		recommandUserExcept.setBotId(botId);
		recommandUserExcept.setExceptWord(exceptWord);
		recommandUserExcept.setRegisterId(userId);
		recommandUserExcept.setRegisterName(userName);
		
		Date date = new Date(System.currentTimeMillis());
		recommandUserExcept.setRegistDate(date);
		
		this.mongoTemplate.save(recommandUserExcept);
		
		return this.getRecommandUserExcept(recommandUserExcept.getId(), recommandUserExcept.getBotId());
	}
	
	/**
	 * 사용자 지정 키워드 제외 정보 삭제
	 * @param id
	 * @param botId
	 * @return
	 */
	@Override
	@MultiDataSource
	public void deleteRecommandUserExcept (String id, String botId) {
		
		Query query = new Query();
		
		if (botId != null) {
			query.addCriteria(Criteria.where("id").is(id).andOperator(Criteria.where("botId").is(botId)));
		}
		else {
			query.addCriteria(Criteria.where("id").is(id));
		}
		
		this.mongoTemplate.findAndRemove(query, RecommandUserExcept.class);
	}
	
	/**
	 * 사용자 지정 키워드 제외 사용자별 정보 모두 삭제
	 * @param userId
	 * @param botId
	 * @return
	 */
	@Override
	@MultiDataSource
	public void deleteRecommandUserExceptAll (String userId, String botId) {
		Query query = new Query();
		
		if (botId != null) {
			query.addCriteria(Criteria.where("userId").is(userId).andOperator(Criteria.where("botId").is(botId)));
		}
		else {
			query.addCriteria(Criteria.where("userId").is(userId));
		}
		
		this.mongoTemplate.findAndRemove(query, RecommandUserExcept.class);
	}
}
