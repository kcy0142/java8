/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : RecommandUserExceptService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.channel.service;

import java.util.List;

import com.lgcns.vpa.channel.model.RecommandUserExcept;


/**
 * <PRE>
 * 관리자 추천키워드, 사용자의 자주쓰는 키워드, 최근 키워드 중 사용자가 표시 제외한 목록의 관리 Service 선언
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 7. 20.
 */
public interface RecommandUserExceptService {
	
	/**
	 * 사용자 지정 키워드 제외 목록 조회
	 * @param userId
	 * @param botId
	 * @return
	 */
	public List<RecommandUserExcept> listRecommandUserExcept (String userId, String botId);
	
	/**
	 * id로 사용자 지정 키워드 제외 상세정보 조회
	 * @param id
	 * @param botId
	 * @return
	 */
	public RecommandUserExcept getRecommandUserExcept (String id, String botId);
	
	/**
	 * 제외 키워드로 사용자 지정 키워드 제외 상세정보 조회
	 * @param exceptWord
	 * @param userId
	 * @param botId
	 * @return
	 */
	public RecommandUserExcept getRecommandUserExceptName(String exceptWord, String userId, String botId);
	
	/**
	 * 사용자 지정 키워드 제외 정보 생성
	 * @param exceptWord
	 * @param userId
	 * @param userName
	 * @param botId
	 * @return
	 */
	public RecommandUserExcept createRecommandUserExcept (String exceptWord, String userId, String userName, String botId);
	
	/**
	 * 사용자 지정 키워드 제외 정보 삭제
	 * @param id
	 * @param botId
	 * @return
	 */
	public void deleteRecommandUserExcept (String id, String botId);
	
	/**
	 * 사용자 지정 키워드 제외 사용자별 정보 모두 삭제
	 * @param userId
	 * @param botId
	 * @return
	 */
	public void deleteRecommandUserExceptAll (String userId, String botId);
	
}
