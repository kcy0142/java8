/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : AspectPrecedence.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.framework.multidata.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.DeclarePrecedence;

@Aspect
@DeclarePrecedence("com.lgcns.vpa.framework.multidata.aspect.* ,org.springframework.transaction.aspectj.AnnotationTransactionAspect, *")
public class AspectPrecedence {

}
