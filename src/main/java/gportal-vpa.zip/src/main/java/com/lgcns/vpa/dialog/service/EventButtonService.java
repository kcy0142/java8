/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : EventButtonService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.util.JsonUtil;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * Event 결과화면에서 Previous, Next Button 의 처리를 위한 Srevice 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 16.
 */
@Service("multi.eventButtonService")
public class EventButtonService {
	
	private static final Logger LOG = LoggerFactory.getLogger(EventButtonService.class);
	
	@Autowired
	private NettyPoolClientService nettyPoolClientService;
	
	@Autowired
	ConfigService configService;
	
	@Value("${spring.profiles.active}")
    private String profiles;
	
	
	
    public List<Attachment> execute(Map<String, String> param, User reqUser, String userId) {
        
    	if ( (reqUser == null) || (StringUtils.isEmpty(userId)) ) {
    		LOG.info("userId:["+userId+"], status:[Parameter가 부족하여 일정을 조회할 수 없습니다.],reqUser:["+reqUser+"],param["+param+"]");
    		return null;
    	}
    	else {
    		LOG.info("userId:["+userId+"],reqUser:["+reqUser+"],param["+param+"]");
    	}
    	
    	String tenantId = reqUser.getTenantId();
        LocalDate now = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd").withLocale(Locale.KOREAN);
        
        String ip = "";
        String pushId="120000080016"; //오늘의 일정조회
        PushConfig pushConfig = configService.retrievePushDetail(pushId, ip);
        String actionUri = pushConfig.getActionUri();
        
        LOG.info("################### eventButtonService pushConfig getActionUri:" + pushConfig.getActionUri());
        
        TransferSyncVO transferSyncVO = new TransferSyncVO();
        transferSyncVO.setActionUri(actionUri);
        transferSyncVO.setTenantId(tenantId);
        
        String startDt = formatter.format(now);
       
        if (!CollectionUtils.isEmpty(param) && !StringUtils.isEmpty(param.get("startDt"))) {
            startDt = param.get("startDt");
        }
        
        String endDt = startDt;

        Map<String, Object> actionParam = new HashMap<>();
        actionParam.put("USER_ID", userId);
        actionParam.put("SEARCH_START_DT", startDt);
        actionParam.put("SEARCH_END_DT", endDt);
        actionParam.put("LOGIN_USER_ID", reqUser.getUserId());
        actionParam.put("TIMEDIFFERENCE", "");
        actionParam.put("LOCALE", "");
        
        transferSyncVO.setActionParam(actionParam);
        
        List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);

        LOG.info("userId:["+userId+"],reqUser:["+reqUser+"],param["+param+"],proxyResultSet:["+proxyResultSet+"]");
        if (proxyResultSet == null) {
        	return null;
        }
        
        Attachment attachment = null;
		
		try {
			
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_PLANNER);

	        // 페이지 블럭 네비게이션 적용
	        attachment.setBlockPagingType(ActivityCode.PAGING_TYPE_PAGER);
	        attachment.setBlockDataType(ActivityCode.BLOCK_DATA_TYPE_DATE);
	        
	        // 오늘일자를 기본으로 표시함
	        attachment.setCurrentBlock(formatter.format(now));
	        
            // 페이징 정보
            // FIXME: RequestContextHolder 말고, Server 정보 가지고올 방법 없나?
            String restUrl = "local".equals(this.profiles) ? "http://localhost:8080/api/dailog/event/%s?startDt=${currentBlock}" : "/api/dailog/event/%s?startDt=${currentBlock}";
            attachment.setBlockDataUrl(String.format(restUrl, userId));

            String block = null, id = null, title = null, subtitle = null, action = null, publicYn = null, kind = null, readYn = null;
            
            // 오늘 일정이 존재하는 경우  
            if (!CollectionUtils.isEmpty(proxyResultSet)) {
            	for (Map<String, Object> proxyResult : proxyResultSet) {
            		block = ( proxyResult.get("BASE_DT") != null ) ? String.valueOf(proxyResult.get("BASE_DT")) : "";
            		id = ( proxyResult.get("ID") != null ) ? String.valueOf(proxyResult.get("ID")) : "";
            		title = ( proxyResult.get("TITLE") != null ) ? String.valueOf(proxyResult.get("TITLE")) : "";
            		subtitle = ( proxyResult.get("SUBTITLE") != null ) ? String.valueOf(proxyResult.get("SUBTITLE")) : "";
            		action = ( proxyResult.get("ACTION") != null ) ? String.valueOf(proxyResult.get("ACTION")) : "";
            		publicYn = ( proxyResult.get("PUBLIC_YN") != null ) ? String.valueOf(proxyResult.get("PUBLIC_YN")) : "";
            		readYn = ( proxyResult.get("READ_YN") != null ) ? String.valueOf(proxyResult.get("READ_YN")) : ""; 
            		kind = ( proxyResult.get("ICON") != null ) ? String.valueOf(proxyResult.get("ICON")) : "";
            		
            		// additionalProperties 설정
                    Map<String, Object> additionalProperties = new HashMap<String, Object>();
                    additionalProperties.put("publicYn", publicYn);
                    additionalProperties.put("readYn", readYn);
                    additionalProperties.put("kind", kind);
                    
            		Element element = new Element();
            		element.setBlock(block);// 페이지 블럭 ID
            		element.setId(id);
            		element.setType(CommonCode.ELEMENT_TYPE_TEXT);
            		//element.setCorpCode(inquiryData.getCompanyCode());
            		element.setTitle(title);
            		element.setSubtitle(subtitle);
            		element.setActionType(ActivityCode.ACTION_TYPE_LINK);
            		
            		if ( "Y".equalsIgnoreCase(readYn) ) {
            			element.setAction(action);
            		}
            		else {
            			element.setAction("");
            		}
            		element.setAdditionalProperties(additionalProperties);
            		
            		attachment.addElement(element);
            	}
            	
	            LOG.info("userId:["+userId+"],reqUser:["+reqUser+"],param["+param+"],attachment:"+JsonUtil.toJson(attachment)+"]");
            }
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
    }
	
	/**
	 * Backend Proxy 서버 호출 후 응답(ActionResult) 전송
	 * Backend Proxy 정보조회시 오류발생, 결과 없음, 파라미터 매핑 오류, 권한 없음의 경우 null 리턴
	 * @param transferSyncVO
	 * @return
	 */
	public List<Map<String, Object>> callProxy(TransferSyncVO transferSyncVO) {
		
		String responseData = null;
		
		List<Map<String, Object>> proxyResultSet =  null;
		
		try {
			
			responseData = nettyPoolClientService.sendToBnpSync(transferSyncVO);
			
			if (responseData != null && StringUtils.hasText(responseData))  {
			
				TransferSyncVO responseVO =  new  TransferSyncVO();
				ObjectMapper mapper = new ObjectMapper();
				responseVO =  mapper.readValue(responseData, TransferSyncVO.class);
				
				if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
					proxyResultSet = responseVO.getActionResult();
				}
				
			}
		} catch (IOException e) {
			LOG.debug("###responseData###"+responseData);
			throw new RuntimeException(e);
		} catch (Exception e) {
			LOG.debug("###responseData###"+responseData);
			throw new RuntimeException(e);
		}
		
		return proxyResultSet;
	}
}
