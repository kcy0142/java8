package com.lgcns.vpa.push.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.PushService;

/**
 * <pre>
 * 실적 결산 완료 Push 알림 Service
 * </pre>
 * @author
 */
@Service("multi.performancePushService")
public class PerformancePushServiceImpl extends PushAbstractService implements PushService{
    
    @Autowired
	ActivityService activityService;
    
    @Autowired
    RedisMessagePublisher redisMessagePublisher;
	
    @Override
	public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig){
    	
    	String botId = params.get("botId");
    	String userIdList =params.get("userIdList");
    	String message = params.get("message");
    	
    	checkBotId(botId);

    	if(userIdList.isEmpty()){
    		throw new RuntimeException("정보가 유효하지 않습니다.");
    	}
    	
    	String[] userIds = userIdList.split(",");
    	
    	for(String userId:userIds){
    		Activity activity = createPushActivity(botId, userId, ActivityCode.DEFAULT_LOCALE_CODE, message);
			
			redisMessagePublisher.publish(activity);
    	}
		
	}
	
}
