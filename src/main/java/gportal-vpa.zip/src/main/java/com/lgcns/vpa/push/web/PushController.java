package com.lgcns.vpa.push.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.push.service.PushService;

/**
 * <pre>
 * Push 알림 api 컨트롤러
 * </pre>
 * @author
 */
@RestController
@CrossOrigin(value="*")
@RequestMapping(value="/api/push")
public class PushController extends BaseController{
    final Logger logger = LoggerFactory.getLogger(PushController.class);
    
    @Autowired
    ConfigService configService;
    
    @Autowired
    ApplicationContext applicationContext;
    
    /**
     * Push 알림 공통 컨트롤러
     * @param params
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/{pushId}", method= RequestMethod.POST)
    public ResponseEntity<Object> push(@PathVariable String pushId, @RequestBody (required=false) Map<String, String> params, HttpServletRequest req) throws Exception {
    	
    	if(StringUtils.isEmpty(pushId)||StringUtils.isEmpty(params.get("botId"))){
    		throw new RuntimeException("정보가 유효하지 않습니다.");
    	}
    	
        String ip = req.getHeader("X-FORWARDED-FOR") != null ?  req.getHeader("X-FORWARDED-FOR") :  req.getRemoteAddr();
        
        PushConfig pushConfig = configService.retrievePushDetail(pushId, ip);
        
        if(pushConfig == null || pushConfig.getUseYn().equals("N")){
        	throw new RuntimeException("사용하지 않는 알림입니다.");
        }
        
    	if(!pushConfig.isIpCheckResult()){
    		logger.info("######################");
    		logger.info("req.getHeader(X-FORWARDED-FOR)  : " + req.getHeader("X-FORWARDED-FOR"));
    		logger.info("req.getRemoteAddr() : " + req.getRemoteAddr());
    		logger.info("######################");
    		throw new RuntimeException("허용하지 않은 IP 입니다.");
    	}
    	
    	String workerName = pushConfig.getWorkerName();
    	if(StringUtils.isEmpty(workerName)){
    		throw new RuntimeException("정보가 유효하지 않습니다.");
    	}
    	
    	PushService pushService = (PushService)applicationContext.getBean(workerName);
    	pushService.execute(params, getTenantId(), pushConfig);
    	
    	return new ResponseEntity<>(HttpStatus.OK);
    }
    
    
    /**
     * redisSessionRemoveTest Push Test
     * @param pushId
     * @return
     */
    @RequestMapping(value="/test/{pushId}", method= RequestMethod.GET)
    public String redisSessionRemoveTest(@PathVariable String pushId) {
    	
    	if ( StringUtils.isEmpty(pushId) ) {
    		return "ERROR";
    	}
    	
    	Map<String, String> params = new HashMap<String, String>();
    	params.put("botId", "120000080013");
    	
    	String ip = "10.78.224.187";
    	PushConfig pushConfig = configService.retrievePushDetail(pushId, ip);
    	
    	String workerName = "multi.redisSessionRemoveService";
    	
		PushService pushService = (PushService)applicationContext.getBean(workerName);
		
    	pushService.execute(params, getTenantId(), pushConfig);
    	

    	return "OK";
    }
    
    /**
     * redisSessionRemove Push 
     * @return
     */
    @RequestMapping(value="/removeSession", method= RequestMethod.GET)
    public String redisSessionRemove() {
    	
    	
    	Map<String, String> params = new HashMap<String, String>();
    	params.put("botId", "120000080013");
    	
    	PushConfig pushConfig = new PushConfig();
    	
    	String workerName = "multi.redisSessionRemoveService";
		PushService pushService = (PushService)applicationContext.getBean(workerName);
    	pushService.execute(params, getTenantId(), pushConfig);

    	return "OK";
    }
    
    /**
     * Notification Push Test
     * @param pushId
     * @return
     */
    @RequestMapping(value="/test/{pushId}/{testType}/{targetGroupIds}", method= RequestMethod.GET)
    public String notificationTest(@PathVariable String pushId, @PathVariable String testType, @PathVariable String targetGroupIds) {
    	
    	if ( StringUtils.isEmpty(pushId) ) {
    		return "ERROR";
    	}
    	
    	/*if (RequestContextHolder.getRequestAttributes() != null) {
    		RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
    		RequestContextHolder.setRequestAttributes(attrs, true);
    		RequestContextHolder.resetRequestAttributes();
    	}*/
    	
    	if ( "PS_0001".equals(pushId) ) {
        	
        	Map<String, String> params = new HashMap<String, String>();
        	params.put("botId", "120000080013");
        	
        	// 전체 사용자 Text
        	if ( "A".equals(testType) ) {
        		params.put("message", "[Notification Msg] ${userName} ${jobTitle}님께 엘비가 알려 드려요.");
            	params.put("type", "0");
            	//params.put("targetGroupIds", "120008535709"); --최환준, 강유경
            	//params.put("targetGroupIds", "120008535705"); --All
            	//params.put("targetGroupIds", "120008535708"); --정보전략팀+UC서비스템+최환준+강유경
            	
            	params.put("targetGroupIds", targetGroupIds);
        	}
        	// 전체 사용자 Intent
        	else if ( "B".equals(testType) ) {
        		params.put("message", "[Notification Intent] ${userName} ${jobTitle}님께 엘비가 알려 드려요.");
        		params.put("inquiry", "직원 식당 안내");
            	params.put("type", "1");
            	params.put("targetGroupIds", targetGroupIds);
        	}
        	else {
        		params.put("message", "[Notification Msg] ${userName} ${jobTitle}님께 엘비가 알려 드려요.");
            	params.put("type", "0");
            	params.put("targetGroupIds", targetGroupIds);
        	}
        	
    		String ip = "10.78.224.187";
        	PushConfig pushConfig = configService.retrievePushDetail(pushId, ip);
        	String workerName = pushConfig.getWorkerName();
        	
    		PushService pushService = (PushService)applicationContext.getBean(workerName);
    		
        	pushService.execute(params, getTenantId(), pushConfig);
    	}
    	
    	return "OK";
    }
}
