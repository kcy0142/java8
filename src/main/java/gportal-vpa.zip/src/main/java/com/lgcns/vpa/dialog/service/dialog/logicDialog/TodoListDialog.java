/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : TodoListDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfigProperty;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.util.ParameterChecker;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * Todo 목록 조회 처리를 위한 Dialog 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 8.
 */
@Component("TodoListDialog")
public class TodoListDialog extends LogicDialog {
	
	private static final Logger LOG = LoggerFactory.getLogger(TodoListDialog.class);
	
	@Autowired
    private MessageSource messageSource;
	
	@Override
	protected boolean validator(InquiryVO data) {
		Action action = data.getAction();
		boolean isValid = false;
		
		//Parameter validator
		if (action != null) {
			if ( !StringUtils.hasText(action.getActionUri()) ) {
				isValid = true;
			}
			else {
				isValid = true;
				Map<String, Object> newIntentParam = null;
				
				if ( action.getActionUri().startsWith("sql-stored") ) {
					//Intent Parameter 에서 누락된 Parameter 는 각 Type 의 기본 값으로 Parameter 값을 설정함
					newIntentParam = ParameterChecker.parameterValidator(action.getActionUri(), data.getIntentParam());
				}
				
				newIntentParam = ( newIntentParam == null ) ? new HashMap<String, Object>() : newIntentParam;
				
				LocalDateTime now = LocalDateTime.now();
		        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd").withLocale(Locale.KOREAN);
		        
		        /* 지연건 포함으로 1개월 이전 건 부터 데이터를 조회함 */
		        newIntentParam.put("fromDT", formatter.format(now.minusMonths(1)));
		        newIntentParam.put("endDT", formatter.format(now));
		        
				data.setIntentParam(newIntentParam);
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
						 "], actionUri:["+action.getActionUri()+"], Intent Param:["+data.getIntentParam()+"]");
			}
		}
		else {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+"], Validation을 수행할 action 정보가 없음");
		}
		
		return isValid;
	}

	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	@Override
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			
			User user = inquiryData.getReqUser();
			if ( user == null ) {
				user = new User();
				user.setEmpNo(inquiryData.getReqUserId());
				user.setLocaleCode("ko");
			}
			
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        // Todo 목록이 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("등록된 Todo 목록이 없습니다.");
	            
	        }
	        // Todo 목록이 존재하는 경우    
	        else {
	        	
	        	if (proxyResultSet != null && proxyResultSet.size() > 0) {
                    // 금일 마감 또는 지연된 건이 {0}개 있습니다.
	        		attachment.setDescriptions(
                            messageSource.getMessage("meesage.push.daily.todo.descriptions1", 
                                    new String[]{String.valueOf(proxyResultSet.size())},
                                    new Locale(user.getLocaleCode())));
                } else {
                	attachment.setDescriptions(
                            messageSource.getMessage("meesage.push.daily.todo.nodata1",
                                    null,
                                    new Locale(user.getLocaleCode())));
                }
	        	
	        	String title = null;
	        	String subtitle = null;
	        	String action = null;
	        	String value = null;
	        	String classNames = null;
	        	StringBuffer descriptions = null;
	        	
	        	/*Date today = new Date();
	        	SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");*/
	        	
	        	LocalDate now = LocalDate.now();
	        	DateTimeFormatter resultFormatter = DateTimeFormatter.ofPattern("yyyy.MM.dd").withLocale(Locale.KOREAN);
	            String today = resultFormatter.format(now);
	            
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
	        			//String userId = proxyResult.get("userId").toString();
	    				//String message = proxyResult.get("message").toString();
	    				title = (proxyResult.get("TODO_REQ_NM") != null) ? proxyResult.get("TODO_REQ_NM").toString() : "";
	    				subtitle = (proxyResult.get("TODO_TYPE_NM") != null) ? proxyResult.get("TODO_TYPE_NM").toString() : "";
	    				action = (proxyResult.get("TODO_LINK") != null) ? proxyResult.get("TODO_LINK").toString() : "";
	    				
	    				// To-Do 상태 표시
	    				value = (proxyResult.get("TODO_STATUS") != null) ? proxyResult.get("TODO_STATUS").toString() : "";
	                    try {
	                        String endDateString = (proxyResult.get("TODO_END_DT") != null) ? proxyResult.get("TODO_END_DT").toString() : "";
	                        long days = 0;
	                        
	                        // 지연 (D+Days)
	                        // FIXME: 날짜 계산 수정할 것 (JDK 1.8)
	                        if ("1".equals(proxyResult.get("DELAY_FLAG").toString())) {
	                        	classNames = "warning";
	                            if (!StringUtils.isEmpty(endDateString)) {
	                                //days = (int)((today.getTime() - sdf.parse(endDateString).getTime()) / (1000 * 60 * 60 * 24));
	                                days = ChronoUnit.DAYS.between(LocalDate.parse(endDateString, resultFormatter), now);
	                                if (days > 0) {
	                                    value = messageSource.getMessage("meesage.push.daily.todo.delayDay",
	                                    								 new String[] {String.valueOf(days)},
	                                    								 new Locale(user.getLocaleCode()));
	                                }
	                            }
	                        } 
	                        // 금일 마감
	                        else if (today.equals(endDateString)) {
	                            value = messageSource.getMessage("meesage.push.daily.todo.today", null, new Locale(user.getLocaleCode()));   
	                        }
	                    } catch (Exception e) {
	                        e.printStackTrace();
	                    }
	                    
	                    //Description
	                    descriptions = new StringBuffer();
                    	if ( proxyResult.get("APPR_SYS_NM") != null ) {
                    		descriptions.append(proxyResult.get("APPR_SYS_NM").toString());
                    	}
	                    
	                    if ( proxyResult.get("EMP_NM") != null ) {
	                        if ( proxyResult.get("APPR_SYS_NM") != null ) {
	                            descriptions.append(" | ");
	                        }
	                        descriptions.append(proxyResult.get("EMP_NM").toString());
	                    }
	                    
	                    if ( proxyResult.get("TODO_END_DT") != null ) {
	                        if ( proxyResult.get("EMP_NM") != null ) {
	                            descriptions.append(" | ");
	                        }
	                        descriptions.append(proxyResult.get("TODO_END_DT").toString());
	                    }
	    				
	    				Element element = new Element();
	    				element.setTitle(title);
	    				element.setSubtitle(subtitle);
	    				element.setAction(action);
	    				element.setActionType(ActivityCode.ACTION_TYPE_LINK);
	    				element.setValue(value);
	    				
	    				if ( !StringUtils.isEmpty(descriptions) ) {
	    					element.setDescriptions(descriptions.toString());
	    				}
	    				
	    				if ( !StringUtils.isEmpty(classNames) ) {
	    					element.setClassNames(classNames);
	    				}
	    				
	    				attachment.addElement(element);
	        		}
	        	}//for
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
}
