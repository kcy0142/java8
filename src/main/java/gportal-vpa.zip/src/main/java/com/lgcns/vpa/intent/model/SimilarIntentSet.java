/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentSet2.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 유사 의도 모음
 * @author 70399
 *
 */
public class SimilarIntentSet extends IntentBase {

	private List<IntentBase> intents;
	
	public SimilarIntentSet() {
		intents = new ArrayList<IntentBase>();
	}
	
	public int size() {
		return intents.size();
	}
	
	public void addIntent(IntentBase intent) {
		intents.add(intent);
	}
	
	public List<IntentBase> getIntents() {
		return this.intents;
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for( IntentBase intent : intents ) {
			sb.append(intent);
			sb.append("\n");
		}
		
		return sb.toString();
	}
}
