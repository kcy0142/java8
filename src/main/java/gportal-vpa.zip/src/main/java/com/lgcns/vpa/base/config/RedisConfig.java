package com.lgcns.vpa.base.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.push.RedisMessageSubscriber;

@Configuration
@EnableConfigurationProperties(RedisClusterConfig.class)
public class RedisConfig {
	
	@Autowired
	RedisClusterConfig redisClusterConfig;
	
	
	@Bean
    public RedisConnectionFactory createRedisConnectionFactory() {
		JedisConnectionFactory factory = new JedisConnectionFactory(new RedisClusterConfiguration(redisClusterConfig.getNodes()));  
		factory.setUsePool(true);

        return factory;
    }

    @Bean
    public RedisTemplate<String, Object> redisTemplate() {
        final RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
        template.setConnectionFactory(createRedisConnectionFactory());
        template.setDefaultSerializer(new GenericJackson2JsonRedisSerializer());
        template.setKeySerializer(new StringRedisSerializer());
        template.setHashKeySerializer(new GenericJackson2JsonRedisSerializer());
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        return template;
    }
    
    @Bean
    public CacheManager redisCacheManager(RedisTemplate<String, Object> redisTemplate) {
        RedisCacheManager cacheManager = new RedisCacheManager(redisTemplate);
        return cacheManager;
    }
    
   /**
    * Redis Subscriber Listener 등록
    */
    @Bean
    public RedisMessageListenerContainer redisContainer() {
    	RedisMessageListenerContainer container = new RedisMessageListenerContainer(); 
    	container.setConnectionFactory(createRedisConnectionFactory()); 
    	container.addMessageListener(messageListener(),  new ChannelTopic(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH)); 
    	return container; 
    }
    
    /**
     * Redis Subscriber
     */
    @Bean
    RedisMessageSubscriber  redisMessageSubscriber(){
    	return new RedisMessageSubscriber();
    }
    
    /**
     * Redis Subscriber Listener Adapter
     */
    @Bean
    public MessageListenerAdapter messageListener() { 
        return new MessageListenerAdapter(redisMessageSubscriber());
    }
}
