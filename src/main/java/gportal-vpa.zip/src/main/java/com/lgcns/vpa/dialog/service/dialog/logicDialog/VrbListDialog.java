/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : VrbListDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.base.config.ServersConfig;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.util.ParameterChecker;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * 주요 VRB 개최현황조회 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 4.
 */
@Component("VrbListDialog")
public class VrbListDialog extends LogicDialog {
	private static final Logger LOG = LoggerFactory.getLogger(VrbListDialog.class);
	
	@Autowired
    private MessageSource messageSource;
	
	@Autowired
    private ServersConfig serversConfig;
	
	@Override
	protected boolean validator(InquiryVO data) {
		Action action = data.getAction();
		boolean isValid = false;
		
		//Parameter validator
		if (action != null) {
			if ( !StringUtils.hasText(action.getActionUri()) ) {
				isValid = true;
			}
			else {
				
				//Parameter 추가
				LocalDateTime now = LocalDateTime.now();
		        String fromDate = new StringBuffer(String.valueOf(now.getYear())).append(".01.01").toString();
		        String toDate = new StringBuffer(String.valueOf(now.getYear())).append(".12.31").toString();
				
		        //TODO userId Parameter 를 Intent 에서 받을 수 있게 처리, 2017.08.07 현재 SEEEION.id 에서 Error 발생
		        Map<String, Object> actionParams = data.getIntentParam();
		        if (actionParams == null) {
		        	actionParams = new HashMap<String, Object>();
		        	actionParams.put("userId", data.getReqUserId());
		        	actionParams.put("fromDate", fromDate);
		        	actionParams.put("toDate", toDate);
		        }
		        else {
		        	actionParams.put("userId", data.getReqUserId());
		        	actionParams.put("fromDate", fromDate);
		        	actionParams.put("toDate", toDate);
		        }
		        
		        data.setIntentParam(actionParams);
		        
		        isValid = true;
		        Map<String, Object> newIntentParam = null;
				
				if ( action.getActionUri().startsWith("sql-stored") ) {
					//Intent Parameter 에서 누락된 Parameter 는 각 Type 의 기본 값으로 Parameter 값을 설정함
					newIntentParam = ParameterChecker.parameterValidator(action.getActionUri(), data.getIntentParam());
					data.setIntentParam(newIntentParam);
				}
				
				newIntentParam = ( newIntentParam == null ) ? new HashMap<String, Object>() : newIntentParam;
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
						 "], actionUri:["+action.getActionUri()+"], Intent Param:["+data.getIntentParam()+"]");
			}
		}
		else {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+"], Validation을 수행할 action 정보가 없음");
		}
		
		return isValid;
	}

	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	@Override
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			User user = (inquiryData.getReqUser() == null) ? new User() : inquiryData.getReqUser();
			
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        //attachment.setTitle(inquiryData.getIntentMessage());
	        
	        // 페이징 타입 설정 
	        attachment.setPagingType(ActivityCode.PAGING_TYPE_MORE);
	        attachment.setMaxListSize(ActivityCode.PAGING_NO_LIMIT);
	        
	        // SI 주요 수주현황이 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("등록된 주요 VRB 개최 현황이 없습니다.");
	        }
	        // SI 주요 수주현황이 존재하는 경우    
	        else {
	        	
	        	String id = null;
	        	String title = null;
	        	String setSubtitle = null;
	        	StringBuffer setDescriptions = null;
	        	String setAction = null;
	        	String setActionType = null;
	        	double conAmt = 0.0;
	        	
	            String vrbItemUrl = serversConfig.getServersInfo(inquiryData.getTenantId(), "officeplus", "vrbItemUrl");
	            String vrbListUrl = serversConfig.getServersInfo(inquiryData.getTenantId(), "officeplus", "vrbListUrl");
	            
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
	        			
	        			// 프로젝트명 | 금액 | 완료단계 | 예상계약일
	        			id = proxyResult.get("SAP_PJT_CD").toString();
	    				title = proxyResult.get("PROJECT_NM").toString();
	    				setSubtitle = proxyResult.get("SAP_AUART_STEP_NM").toString();
	    				
	    				try {
	                        conAmt = Double.parseDouble(proxyResult.get("CON_AMT").toString()) / 100000000;
	                        conAmt = Math.round(conAmt * 100) / 100.0;
	                    } catch (Exception e) {}
	    				
	    				// 예상계약일
	    				setDescriptions = new StringBuffer();
	    				setDescriptions.append(messageSource.getMessage("meesage.push.daily.vrb.contDate", null, new Locale(user.getLocaleCode())));
	    				setDescriptions.append(" ").append(String.valueOf(proxyResult.get("CON_DATE"))).append("\n\r");
	    				setDescriptions.append(messageSource.getMessage("meesage.push.daily.vrb.hldDate", null, new Locale(user.getLocaleCode())));
	    				setDescriptions.append(" ").append(String.valueOf(proxyResult.get("HLD_DATE")));
                        
	    				setAction = String.format(vrbItemUrl, String.valueOf(proxyResult.get("SAP_PJT_CD").toString()));
	    				setActionType = ActivityCode.ACTION_TYPE_LINK;  
	    				
	    				Element element = new Element();
	    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	    				element.setId(id); 
	    				element.setTitle(title); 
	    				element.setSubtitle(setSubtitle);
	    				element.setDescriptions(setDescriptions.toString());
	    				element.setAction(setAction);
	    				element.setActionType(setActionType);
	    				element.setAmount(String.valueOf(conAmt));
                        // 억원
	    				element.setUnit(
                        			messageSource.getMessage("meesage.push.daily.common.billion", 
                        									 null, new Locale(user.getLocaleCode())));
                        
	    				attachment.addElement(element);
	        		}
	        	}//for
	        	
	        	attachment.setPopupUrl(vrbListUrl);
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}

}
