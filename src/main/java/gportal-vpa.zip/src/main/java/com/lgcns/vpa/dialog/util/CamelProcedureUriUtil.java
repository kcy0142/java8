/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : CamelProcedureUriUtil.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.lgcns.vpa.dialog.model.CamelProcedureUriVO;

/**
 * <PRE>
 * Procedure Meta Data를 Camel Procedure 전송 양식으로 변경함
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 7. 5.
 */
public class CamelProcedureUriUtil {
	private static final String 
			VARCHAR_TYPE		= "VARCHAR",
			NVARCHAR_TYPE		= "NVARCHAR",
			INTEGER_TYPE		= "INTEGER",
			CHAR_TYPE			= "CHAR";

	public static CamelProcedureUriVO changeFixedParameter (String query) {
		if (!StringUtils.hasText(query)) {
			return null;
		}
		
		//Procedure 의 기 정의된 Parameter정보를 가져온다.
		//ex) NVARCHAR ${headers.companyCode},NVARCHAR ${headers.langSet},NVARCHAR ${headers.asset},NVARCHAR ''
		int strPos = query.indexOf("(");
		int endPos = query.indexOf(")");
		String targetStr = query.substring(strPos+1, endPos);
		StringBuffer newQueary = new StringBuffer(query.substring(0, strPos+1));
		
		//System.out.println("targetStr : ["+targetStr+"]");
		
		if ( !StringUtils.hasText(query) ) {
			return null;
		}
		
		//Parameter를 개별로 분리한다.
		String [] splitTargetStr = targetStr.split(",");
		
		if ( (splitTargetStr == null) || (splitTargetStr.length <= 0) ) {
			return null;
		}
				
		Map<String, Object> resultMap = new HashMap<String, Object>();
		String fixedParamName = "FIXED_";
		String tmp = null;
		String paramTmp = null;
		List<String> paramTmpList = new ArrayList<String>();
		
		//$로 시작하지 않은 고정 값을 갖는 Parameter를 
		//Camel에서 인식하는 ${header.변수명}형태로 변경한다.
		for (int i=0; i < splitTargetStr.length; i++) {
			// "|" 문자가 포함되어 있으면 ","로 변환한다.
			tmp = (splitTargetStr[i].contains("|")) ? splitTargetStr[i].replace("|", ",") : splitTargetStr[i];
			
			if ( StringUtils.hasText(tmp) ) {
				paramTmp = CamelProcedureUriUtil.insertFixedParamToMap(resultMap, tmp.trim(), fixedParamName+i);
				if (paramTmp != null) {
					paramTmpList.add(paramTmp);
				}
			}
		}
		
		if (paramTmpList.size() > 0) {
			int paramSize = paramTmpList.size();
			for (int i = 0; i < paramSize; i++) {
				newQueary.append(paramTmpList.get(i));
				if (i < (paramSize-1)) {
					newQueary.append(",");
				}
			}
		}
		newQueary.append(query.substring(endPos));
		
		//System.out.println("newQuery : ["+newQueary+"]");
		
		return ( StringUtils.isEmpty(newQueary.toString()) ) ? null : new CamelProcedureUriVO(newQueary.toString(), resultMap);
	}//changeFixedParameter
	
	private static String insertFixedParamToMap (Map<String, Object> resultMap, String paramStr, String paramName) {
		if ( !StringUtils.hasText(paramStr) ) {
			return null;
		}
		
		int delemeterPos = paramStr.indexOf(" ");
		
		String type = paramStr.substring(0, delemeterPos);
		String value = paramStr.substring(delemeterPos).trim();
		
		if ( !StringUtils.hasText(type) || (!StringUtils.hasText(type.trim())) ||
			 !StringUtils.hasText(value) || (!StringUtils.hasText(value.trim())) ) {
			return null;
		}
		
		StringBuffer parameter = new StringBuffer();
		
		try {
			switch (type.toUpperCase()) {
				case NVARCHAR_TYPE :
					String valNvar = getStringValue(value);
					if (valNvar != null) {
						resultMap.put(paramName, valNvar);
						parameter.append(NVARCHAR_TYPE).append(" ").append("${headers.").append(paramName).append("}");
					}
					else {
						parameter.append(NVARCHAR_TYPE).append(" ").append("${headers.").append(value.substring(2));
					}
					//System.out.println("TYPE : ["+ParameterUtil.NVARCHAR_TYPE+"],["+value+"],["+paramName+"],["+valNvar+"],["+parameter+"]");
					break;
				case VARCHAR_TYPE :
					String valVar = getStringValue(value);
					if (valVar != null) {
						resultMap.put(paramName, valVar);
						parameter.append(VARCHAR_TYPE).append(" ").append("${headers.").append(paramName).append("}");
					}
					else {
						parameter.append(VARCHAR_TYPE).append(" ").append("${headers.").append(value.substring(2));
					}
					//System.out.println("TYPE : ["+ParameterUtil.VARCHAR_TYPE+"],["+value+"],["+paramName+"],["+valVar+"],["+parameter+"]");
					break;
				case INTEGER_TYPE :
					Integer valInt = getIntegerValue(value);
					if (valInt != null) {
						resultMap.put(paramName, valInt);
						parameter.append(INTEGER_TYPE).append(" ").append("${headers.").append(paramName).append("}");
					}
					else {
						parameter.append(INTEGER_TYPE).append(" ").append("${headers.").append(value.substring(2));
					}
					//System.out.println("TYPE : ["+ParameterUtil.INTEGER_TYPE+"],["+value+"],["+paramName+"],["+valInt+"],["+parameter+"]");
					break;
				case CHAR_TYPE :
					Character valChar = getCharacterValue(value);
					if (valChar != null) {
						resultMap.put(paramName, valChar);
						parameter.append(CHAR_TYPE).append(" ").append("${headers.").append(paramName).append("}");
					}
					else {
						parameter.append(CHAR_TYPE).append(" ").append("${headers.").append(value.substring(2));
					}
					//System.out.println("TYPE : ["+ParameterUtil.CHAR_TYPE+"],["+value+"],["+paramName+"],["+valChar+"],["+parameter+"]");
					break;
			}
		} catch (Exception e) {
			return null;
		}
		
		return ( (parameter != null) && (parameter.length() > 0) ) ? parameter.toString() : null;
	}
	
	private static String getStringValue (String data) {
		
		if ( !StringUtils.hasLength(data) || data.startsWith("$") ) {
			return null;
		}
		
		String result = data.trim(); 
		
		if ( data.startsWith("'") || data.startsWith("\"") ) {
			if ( data.endsWith("'") || data.endsWith("\"") ) {
				result = result.substring(1, result.length()-1);
			}
			else {
				result = result.substring(1);
			}
		}
		else if ( data.endsWith("'") || data.endsWith("\"") ) {
			result = result.substring(0, result.length()-1);
		}
		
		return result;
	}
	
	private static Integer getIntegerValue (String data) {
		
		if ( !StringUtils.hasLength(data) || data.startsWith("$") ) {
			return null;
		}
		
		String result = data.trim(); 
		
		if ( data.startsWith("'") || data.startsWith("\"") ) {
			if ( data.endsWith("'") || data.endsWith("\"") ) {
				result = result.substring(1, result.length()-1);
			}
			else {
				result = result.substring(1);
			}
		}
		else if ( data.endsWith("'") || data.endsWith("\"") ) {
			result = result.substring(0, result.length()-1);
		}
		
		if ( StringUtils.hasText(result) ) {
			try {
				return new Integer(result);
			} catch (Exception e) {
				return null;
			}
		}
		else {
			return null;
		}
	}
	
	private static Character getCharacterValue (String data) {
		
		if ( !StringUtils.hasLength(data) || data.startsWith("$") ) {
			return null;
		}
		
		String result = data.trim(); 
		
		if ( data.startsWith("'") || data.startsWith("\"") ) {
			if ( data.endsWith("'") || data.endsWith("\"") ) {
				result = result.substring(1, result.length()-1);
			}
			else {
				result = result.substring(1);
			}
		}
		else if ( data.endsWith("'") || data.endsWith("\"") ) {
			result = result.substring(0, result.length()-1);
		}
		
		if ( StringUtils.hasText(result) ) {
			try {
				return new Character(result.charAt(0));
			} catch (Exception e) {
				return null;
			}
		}
		else {
			return null;
		}
	}
}
