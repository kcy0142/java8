/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service;

import com.lgcns.vpa.channel.model.Bot;

/**
 * <pre>
 * 봇 관리 Service
 * </pre>
 * @author
 */
public interface BotService {
	
	static final String BOT_STATUS_PUSH = "bot.status.push";
    /**
     * 봇 정보 조회
     * @param botId
     * @return
     */
    Bot retrieveBot(String botId);
    
    /**
	 * Bot 메세지 조회
	 * @param botId
	 * @param messageType
	 * @return
	 */
	String getBotMessage( String botId, String messageType );
	
	long success(Bot bot);
	
	/**
	 * DAAP 실패 횟수 증가
	 */
	long fail(Bot bot);
}
