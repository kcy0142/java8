/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserAutoRunServiceImpl.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.push.dao.UserAutoRunDao;
import com.lgcns.vpa.push.model.UserAutoRunConfig;
import com.lgcns.vpa.push.service.UserAutoRunConfigService;

/**
 * <pre>
 * 개인별 자동 실행 Service 구현
 * </pre>
 * @author 김가원
 * @version v1.0 2017. 12. 7.
 */
@Service("multi.userAutoRunConfigService")
@Transactional
public class UserAutoRunConfigServiceImpl implements UserAutoRunConfigService{

	
	@Autowired
	private UserAutoRunDao userAutoRunDao;
	
    /**
     * 현재 시간이 사용자 자동실행 설정 버튼 표시 시간인지 조회
     * @param botId
     * @return
     */
    public boolean isDisplayAutoRunButton(String botId) {
    	
    	if ( StringUtils.isEmpty(botId) ) {
    		return false;
    	}
    	
    	//시간 설정 내용을 조회
    	List<UserAutoRunConfig> configList = this.userAutoRunDao.listUserAutoRunConfig(botId);
    	
    	if ( (configList == null) || (configList.isEmpty()) ) {
    		return false;
    	}
    	
    	boolean isDisplayTime = false;
    	
    	//현재 시간 정보 구하기
    	LocalDateTime now = LocalDateTime.now();
		int hhmm = now.getHour()*100 + now.getMinute();
    	
    	int startTime = 0, endTime = 0;
    	
    	for ( UserAutoRunConfig uarConfig : configList ) {
    		if ( uarConfig == null ) {
    			continue;
    		}
    		
    		startTime = uarConfig.getStartTime();
    		endTime = uarConfig.getEndTime();
    		
    		if ( (hhmm >= startTime) && (hhmm <= endTime) ) {
    			isDisplayTime =  true;
    			break;
    		}
    	}
    	
    	return isDisplayTime;
    }
	
}
