/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : MongoIterable.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * <PRE>
 * Mongodb 처리하는 business logic 에서 쓰이는 Iterable 을 처리하는 Utility Class
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
public class MongoIterable<T> implements Iterable<T> {
	
	private List<T> list;
	
	public MongoIterable (T [] t) {
		this.list = Arrays.asList(t);
		//Collections.reverse(this.list);
	}
	
	public MongoIterable (List<T> list) {
		this.list = new ArrayList<T>();
		
		Iterator<T> tmp = list.iterator();
		while (tmp.hasNext()) {
			this.list.add(tmp.next());
		}
	}
	
	@Override
	public Iterator<T> iterator() {
		return this.list.iterator();
	}
	
	/*public static void main (String [] args) {
		
		List<BookMongo> list1 = new ArrayList<BookMongo>();
		list1.add(new BookMongo("111", "AAA111"));
		list1.add(new BookMongo("222", "BBB222"));
		list1.add(new BookMongo("333", "CCC333"));
		list1.add(new BookMongo("444", "DDD444"));
		
		BookMongo [] array1 = new BookMongo[list1.size()];
		list1.toArray(array1);
		
		Iterable<BookMongo> data = new MongoIterable<BookMongo>(array1);
		Iterable<BookMongo> data1 = new MongoIterable<BookMongo>(list1);
		
		BookMongo book1 = list1.get(0);
		book1.setAuthor("111111");
		
		Iterator<BookMongo> book_0 = data.iterator();
		Iterator<BookMongo> book_1 = data1.iterator();
		
		while (book_0.hasNext()) {
			System.out.println("book_0 ==> "+book_0.next());
		}
		System.out.println("###########################################################");
		while (book_1.hasNext()) {
			System.out.println("book_1 ==> "+book_1.next());
		}
	}*/
	
}
