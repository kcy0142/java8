/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseModel;

/**
 * <pre>
 * 사용자 봇 설정 Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BotConfig extends BaseModel {

    /**
     * 사용자 ID
     */
    private String userId;

    /**
     * 봇 ID
     */
    private String botId;
    
    /**
     * 봇 닉네임
     */
    private String botNickname;
    
    /**
     * 사진 URL (작은 그림)
     */
    private String smallIconUrl;
    
    /**
     * 사진 URL
     */
    private String iconUrl;
    
    /**
     * Daily 알림 사용여부
     */
    private String dailyPushYn;
    
    /**
     * Push 알림 사용여부
     */
    private String pushYn;
    
    /**
     * HTML5 데스크탐 알림 사용여부
     */
    private String desktopPushYn;
    
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getBotId() {
		return botId;
	}
	
	public void setBotId(String botId) {
		this.botId = botId;
	}
	
	public String getBotNickname() {
		return botNickname;
	}
	
	public void setBotNickname(String botNickname) {
		this.botNickname = botNickname;
	}
	
	public String getSmallIconUrl() {
		return smallIconUrl;
	}
	
	public void setSmallIconUrl(String smallIconUrl) {
		this.smallIconUrl = smallIconUrl;
	}
	
	public String getIconUrl() {
		return iconUrl;
	}
	
	public void setIconUrl(String iconUrl) {
		this.iconUrl = iconUrl;
	}

    public String getDailyPushYn() {
        return dailyPushYn;
    }

    public void setDailyPushYn(String dailyPushYn) {
        this.dailyPushYn = dailyPushYn;
    }

    public String getPushYn() {
        return pushYn;
    }

    public void setPushYn(String pushYn) {
        this.pushYn = pushYn;
    }

    public String getDesktopPushYn() {
        return desktopPushYn;
    }

    public void setDesktopPushYn(String desktopPushYn) {
        this.desktopPushYn = desktopPushYn;
    }
}
