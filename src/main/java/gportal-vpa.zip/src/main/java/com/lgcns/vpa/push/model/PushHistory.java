/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : Push.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

/**
 * <PRE>
 * test
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 9. 13.
 */
package com.lgcns.vpa.push.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonInclude;
/**
 * 
 * <PRE>
 * memo와 planner 배치 실행시 실행 count 이력 저장
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 9. 13.
 */
@Document(collection="pushHistory")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PushHistory {

	/**
     * botId
     */
	private String botId;
	
	/**
     * Push Id
     */

	private String pushId;
	
	/**
     * jobGroup(lgcns)
     */
	private String jobGroup;
	
	/**
     * jobName(ex:MemoBatch)
     */
	private String jobName;
	
	
	
	/**
     * 입력 데이터 수
     */
	private int responseCount;
	
	/**
     *실제 push된 count
     */
	private int executeCount;
	
	@DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
	private Date sentDate; 

	public String getPushId() {
		return pushId;
	}

	public void setPushId(String pushId) {
		this.pushId = pushId;
	}

	

	public int getResponseCount() {
		return responseCount;
	}

	public void setResponseCount(int responseCount) {
		this.responseCount = responseCount;
	}

	public int getExecuteCount() {
		return executeCount;
	}

	public void setExecuteCount(int executeCount) {
		this.executeCount = executeCount;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}


	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobGroup() {
		return jobGroup;
	}

	public void setJobGroup(String jobGroup) {
		this.jobGroup = jobGroup;
	}
	
	
	
	
}

