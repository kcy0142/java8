/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : ArrayDeserializer.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

public class ScoreDeserializer extends StdDeserializer<List<Score>> {
	
	private static final int MIN_MATCH_RATE = 20;
	private static final int MAX_SIZE 		= 15;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ScoreDeserializer() { 
        this(null); 
    } 
 
    public ScoreDeserializer(Class<?> vc) { 
        super(vc); 
    }
 
    /**
     * "intentScore": [["일정 조회", 61.0], ["Todo 조회", 34.0]]}}
     */
    @Override
    public List<Score> deserialize(
      JsonParser jsonparser, DeserializationContext context) 
      throws IOException {
    	List<Score> scores = new ArrayList<>();
        JsonToken token = jsonparser.getCurrentToken();
        if( token == JsonToken.START_ARRAY ) {
        	while(true) {
	        	token = jsonparser.nextToken();
	        	if( token != JsonToken.START_ARRAY ) {
	        		return scores;
	        	}
	        	jsonparser.nextToken();
	        	
	        	Score score = new Score();
	        	score.setName(jsonparser.getText());
	        	jsonparser.nextToken();
	        	score.setScore(jsonparser.getDoubleValue());
	        	if( score.getScore() < MIN_MATCH_RATE ) {
	        		break;
	        	}
	        	
	        	scores.add(score);
	        	
	        	if( scores.size() > MAX_SIZE ) {
	        		break;
	        	}
	        	jsonparser.nextToken();
        	}
        } 
        return scores;
    }
}
