/* ------------------------------------------------------------------------------
 * Project       : NextEP Project
 * Source        : DataSourceRouter.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.framework.multidata.datasource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;


/**
 * DataSourceKeyHolder에 저장된 key명으로 oracle datasource를 설정함
 * @author 
 */
public class DataSourceRouter extends AbstractRoutingDataSource {

	protected final Logger log = LoggerFactory.getLogger(DataSourceRouter.class);
	
	
    private boolean lenientFallback = false;

    
    public void setLenientFallback(boolean lenientFallback) {
        this.lenientFallback = lenientFallback;
    }

    
    @Override
    public void afterPropertiesSet() {
        super.afterPropertiesSet();
        setLenientFallback(lenientFallback);
    }
    
	@Override
	protected Object determineCurrentLookupKey() {
		
		String dataSourceKey = DataSourceKeyHolder.getDataSourceKey();
		
		log.info("DataSourceRouter : \"" + dataSourceKey + "\" is being used as a datasource key...");
		// TODO: 임시 루프태에서 dao 조회시 간혹 dataSourceKey 가 null 인 상황 발생함
		dataSourceKey = StringUtils.isEmpty(dataSourceKey) ? "lgcns" : dataSourceKey;
		
		return dataSourceKey;
	}
}
