/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseModel;
import com.lgcns.vpa.channel.model.Bot;

import java.util.List;

/**
 * <pre>
 * 사용자 및 봇 설정 View Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Config extends BaseModel {

    /**
     * 사용자 ID
     */
    private String userId;

    /**
     * 봇 ID
     */
    private String botId;

    /**
     * 봇 정보
     */
    private Bot bot;

    /**
     * 사용자 설정
     */
    private UserConfig userConfig;

    /**
     * 개인별 봇 설정
     */
    private BotConfig botConfig;

    /**
     * 데일리 알림 설정
     */
    private List<PushConfig> dailyPushConfigs;

    /**
     * 푸시 알림 설정
     */
    private List<PushConfig> pushConfigs;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public Bot getBot() {
        return bot;
    }

    public void setBot(Bot bot) {
        this.bot = bot;
    }

    public UserConfig getUserConfig() {
        return userConfig;
    }

    public void setUserConfig(UserConfig userConfig) {
        this.userConfig = userConfig;
    }

    public BotConfig getBotConfig() {
        return botConfig;
    }

    public void setBotConfig(BotConfig botConfig) {
        this.botConfig = botConfig;
    }

    public List<PushConfig> getDailyPushConfigs() {
        return dailyPushConfigs;
    }

    public void setDailyPushConfigs(List<PushConfig> dailyPushConfigs) {
        this.dailyPushConfigs = dailyPushConfigs;
    }

    public List<PushConfig> getPushConfigs() {
        return pushConfigs;
    }

    public void setPushConfigs(List<PushConfig> pushConfigs) {
        this.pushConfigs = pushConfigs;
    }
}
