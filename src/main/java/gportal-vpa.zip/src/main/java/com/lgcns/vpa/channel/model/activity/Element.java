package com.lgcns.vpa.channel.model.activity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * <pre>
 * 엘리먼트 인터페이스 Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Element implements Serializable {
    
    private static final long serialVersionUID = 4962079004233849861L;

    /**
     * 엘리먼트 유형
	 * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String type;
    
    /**
     * 엘리먼트 서브유형 
     * 일반적으로 쓸일 없음. 축하합니다. 처림 하나의 엘리먼트가 미묘하게 다른 경우 사용
     */
    private String subtype;
    
	/**
	 * 엘리먼트 ID (원본 데이터 ID)
	 */
	private String id;

    /**
     * 제목
     */
    private String title;

    /**
     * 부제목
     */
    private String subtitle;

    /**
     * 설명
     */
    private String descriptions;

	/**
	 * 텍스트
	 */
	private String text;

    /**
     * 값
     */
    private String value;
    
    /**
     * 값 (금액, 수량 등 산술 표현에 사용)
     */
    private String amount;

    /**
     * 단위
     */
    private String unit;
    
    /**
     * 사용자 정보
     */
    private String userId;
    
    private String userName;
    
    private String jobTitleName;
    
    private String userImageUrl;
    
    private String teamName;
    
    private String corpCode;
    
    /**
     * 일시 정보
     */
    private String datetime;
    
    private String date;
    
    private String time;
    
    /**
     * 스타일 클래스 (danger, warning, success, info)
     * 복수인 경우: class1 class2 [classN]
     */
    private String classNames;
    
    private int popupWidth;
    
    private int popupHeight;

    /**
     * 이미지 URL
     */
    private String imageUrl;

    /**
     * 바디 데이터 (테이블인 경우)
     */
    private List<SubElement> subElements;
    
    private List<Object> elements;
    
    /**
     * 버튼
     */
    private List<Button> buttons;

    /**
     * 확장 속성
     */
    private Map<String, Object> additionalProperties;
    
    // 액션정보
    
    /**
     * 액션 유형 (link: 링크, inquiry: 인텐트처리)
     */
    private String actionType;
    
    /**
     * 액션
     */
    private String action;
    
    /**
     * 액션 파라미터
     */
    private Map<String, Object> actionParams;    

    /**
     * 페이지 블럭
     * 네비게이션(이전, 다음)에 사용하는 페이지 정보
     * 예시: 플래너의 경우 일자 (20170304)
     */
    private String block;
    
    /**
     * 페이지 블럭명
     * 네비게이션(이전, 다음)에 사용하는 페이지 명칭 정보
     * 예시: 플래너의 경우 일자 (2017년 7월 17일 화요일)
     */
    private String blockName;
    
    public Element () {
    }
    
    public Element (List<SubElement> subElements) {
    	this.subElements = subElements;
    }
        
    public Element (String type, String title, Map<String, Object> additionalProperties) {
    	this.type = type;
    	this.title = title;
    	this.additionalProperties = additionalProperties;
    }
    
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
    public String getSubtype() {
        return subtype;
    }

    public void setSubtype(String subtype) {
        this.subtype = subtype;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public String getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getClassNames() {
		return classNames;
	}

	public void setClassNames(String classNames) {
		this.classNames = classNames;
	}
	
	public int getPopupWidth() {
        return popupWidth;
    }

    public void setPopupWidth(int popupWidth) { 
        this.popupWidth = popupWidth;
    }

    public int getPopupHeight() {
        return popupHeight;
    }

    public void setPopupHeight(int popupHeight) {
        this.popupHeight = popupHeight;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getJobTitleName() {
        return jobTitleName;
    }

    public void setJobTitleName(String jobTitleName) {
        this.jobTitleName = jobTitleName;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getUserImageUrl() {
        return userImageUrl;
    }

    public void setUserImageUrl(String userImageUrl) {
        this.userImageUrl = userImageUrl;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCorpCode() {
        return corpCode;
    }

    public void setCorpCode(String corpCode) {
        this.corpCode = corpCode;
    }

    public List<Button> getButtons() {
		return buttons;
	}

	public void setButtons(List<Button> buttons) {
		this.buttons = buttons;
	}
	
	public Element addButton(Button button) {
		if (this.buttons == null) {
			this.buttons = new ArrayList<>();
		}
		this.buttons.add(button);
		return this;
	}

	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

	public Element addAdditionalProperty(String key, Object value) {
		if (this.additionalProperties == null) {
			this.additionalProperties = new HashMap<>();
		}
		this.additionalProperties.put(key, value);
		return this;
	}

	public List<SubElement> getSubElements() {
		return subElements;
	}

	public void setSubElements(List<SubElement> subElements) {
		this.subElements = subElements;
	}
	
	public Element addSubElement(SubElement subElement) {
		if (this.subElements == null) {
			this.subElements = new ArrayList<>();
		}
		this.subElements.add(subElement);
		return this;
	}
	
    public List<Object> getElements() {
        return elements;
    }

    public void setElements(List<Object> elements) {
        this.elements = elements;
    }	
    
    public Element addElement(Object element) {
        if (this.elements == null) {
            this.elements = new ArrayList<>();
        }
        elements.add(element);
        return this;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Map<String, Object> getActionParams() {
        return actionParams;
    }

    public void setActionParams(Map<String, Object> actionParams) {
        this.actionParams = actionParams;
    }

	public String toStringForDialogHandler() {
		return "[type=" + type + ", text=" + text + ", actionType=" + actionType + ", action=" + action
				+ ", actionParams=" + actionParams + "]";
	}
}
