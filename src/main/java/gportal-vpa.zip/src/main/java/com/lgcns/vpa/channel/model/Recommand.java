/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : Recommand.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.channel.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.query.Update;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * <PRE>
 * 관리자 추천 키워드 Modeling Object
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Document(collection="recommands")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Recommand {
	@Id
	private String id;
	
	/**
	 * 표시 순서
	 */
	private String displayOrder;
	
	/**
	 * 추천 키워드 아이디
	 */
	private String recommandId;
	
	/**
	 * 추천키워드 표시용 제목
	 */
	private String recommandName;
	
	/**
	 * 추천키워드 Action 실행 시 메세지
	 */
	private String message;
	
	/**
	 * 추천키워드 ActionType ("link":팝업화면, "inquiry":의도분석)
	 * default값을 inquiry
	 */
	private String actionType = "inquiry";
	
	/**
	 * 추천키워드 Action ("link":팝업화면용 URL, "inquiry":의도분석용 Message)
	 */
	private String action;
	
	/**
	 * 관리화면용 설명
	 */
	private String description;
	
	/**
	 * 사용여부
	 */
	private String useYn;
	
	/**
	 * Action 을 사용하는 챗봇 구분 id
	 */
	private String botId;
	
	/* 여기서부터 하위로는 공통임. 
	 * 추후에 공통 Parent 에서 상속하는 것으로 처리*/
	
	/**
	 * 생성자 userId
	 */
	private String registerId;
	
	/**
	 * 생성자 명
	 */
	private String registerName;
	
	/**
	 * 생성일자
	 */
	private Date registDate;
	
	/**
	 * 수정자 userId
	 */
	private String updaterId;
	
	/**
	 * 수정자 명
	 */
	private String updaterName;
	
	/**
	 * 수정일자
	 */
	private Date updateDate;
	
	/**
	 * Client 에서 Keyword를 구성하는데 필요한 Type
	 * ex) dailyPush, deleteActivities, changeBot, fixed 또는 값이 없을 수도 있음
	 */
	private String type;
	
	/**
	 * Client 에서 Keyword를 구성하는데 필요한 iconName;
	 */
	private String iconName;
	
	/**
	 * Client 에서 Keyword를 구성할 때 recommandName을 Keyword 버튼 명으로 표시할 지 여부 설정
	 */
	private String displayYn;

	public Recommand() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}

	public String getRecommandId() {
		return recommandId;
	}

	public void setRecommandId(String recommandId) {
		this.recommandId = recommandId;
	}

	public String getRecommandName() {
		return recommandName;
	}

	public void setRecommandName(String recommandName) {
		this.recommandName = recommandName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getRegisterName() {
		return registerName;
	}

	public void setRegisterName(String registerName) {
		this.registerName = registerName;
	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}

	public String getUpdaterId() {
		return updaterId;
	}

	public void setUpdaterId(String updaterId) {
		this.updaterId = updaterId;
	}

	public String getUpdaterName() {
		return updaterName;
	}

	public void setUpdaterName(String updaterName) {
		this.updaterName = updaterName;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIconName() {
		return iconName;
	}

	public void setIconName(String iconName) {
		this.iconName = iconName;
	}
	
	public String getDisplayYn() {
		return displayYn;
	}

	public void setDisplayYn(String displayYn) {
		this.displayYn = displayYn;
	}

	/**
	 * 수정용 Parameter 인 Update Object 생성
	 * @return
	 */
	public Update getUpdateObject () {
		
		Update update = new Update();
		update.set("displayOrder", this.displayOrder);
		update.set("recommandId", this.recommandId);
		update.set("recommandName", this.recommandName);
		update.set("action", this.action);
		update.set("actionType", this.actionType);
		
		update.set("message", this.actionType);
		update.set("description", this.description);
		update.set("useYn", this.useYn);
		update.set("type", this.type);
		update.set("iconName", this.iconName);
		
		update.set("displayYn", this.displayYn);
		update.set("botId", this.botId);
		update.set("updaterId", this.updaterId);
		update.set("updaterName", this.updaterName);
		update.set("updateDate", new Date(System.currentTimeMillis()));
		
		return update;
	}

	@Override
	public String toString() {
		return "Recommand [id=" + id + ", displayOrder=" + displayOrder + ", recommandId=" + recommandId
				+ ", recommandName=" + recommandName + ", message=" + message + ", actionType=" + actionType
				+ ", action=" + action + ", description=" + description + ", useYn=" + useYn + ", botId=" + botId
				+ ", registerId=" + registerId + ", registerName=" + registerName + ", registDate=" + registDate
				+ ", updaterId=" + updaterId + ", updaterName=" + updaterName + ", updateDate=" + updateDate + ", type="
				+ type + ", iconName=" + iconName + ", displayYn=" + displayYn + "]";
	}
}
