/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SearchContactDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * 업무담당자 목록 조회 처리를 위한 Dialog 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 8.
 */
@Component("SearchContactDialog")
public class SearchContactDialog extends LogicDialog {
	
	private static final Logger LOG = LoggerFactory.getLogger(SearchContactDialog.class);

	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private BotService botService;
	
	@Autowired
	private DialogConfig dialogConfig;
	
	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet =  null;
			
			TransferSyncVO responseVO =  new  TransferSyncVO();
			ObjectMapper mapper = new ObjectMapper();
			responseVO =  mapper.readValue(proxyResponseJsonData, TransferSyncVO.class);
			
			if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
				proxyResultSet = responseVO.getActionResult();
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
					//Proxy에서 조회된 결과(JsonData)에서 Attachment 를 구함
					attachments = this.getAttachment(data, proxyResultSet);
					
					if ( (attachments != null) && (!attachments.isEmpty()) ) {
						
						StringBuffer activityMessage = new StringBuffer(); 
						
			        	Map<String, Object> intentParam = data.getIntentParam();
			        	if ( intentParam != null ) {
			        		activityMessage.append( String.valueOf(intentParam.get("title")) );
			        		
				        	if ( attachments.get(0) != null ) {
								Attachment attachment = attachments.get(0);
								List<Element> elements = attachment.getElements();
								
								//Activity Result Message  변경
								//담당자 목록이 중복 되었을 경우 "총 N명의 사용자가 조회되었습니다. 질의하실 대상을 선택해주세요." 로 출력함
								//TODO  향 후 의도분석에서 메세지 출력 시 대체함
								if ( (elements != null) && (elements.size() > 1)) {
									activityMessage.append(" 업무담당자 ");
									activityMessage.append(String.format(this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_MULTI_RESULT), elements.size()));
								}
								else {
									activityMessage.append(" 업무담당자를 조회한 결과입니다.");
								}
							}
				        	else {
				        		activityMessage.append(" 업무담당자를 조회한 결과입니다.");
				        	}
			        	}
			        	
			        	resultActivity.setMessage(activityMessage.toString());
						resultActivity.setAttachments(attachments);
						
					}
					else {
						LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
						
						//Data 가 없음
			        	resultActivity = this.commonResponeService.simpleResponseMessage(
								data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
								this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
					}
					
					//의도분석의 Button이 있는 경우 처리
					if ( data.getIntentButtons() != null ) {
						List<RelatedButton> buttons = data.getIntentButtons();
						List<Button> activityButtonList = super.makeActivityButtonList(buttons);
						
						if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
							resultActivity.setButtons(activityButtonList);
						}
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	@Override
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_PEOPLE_LIST);
	        
	        // 조회된 담당자 목록이 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("조회된 담당자 목록이 없습니다.");
	        }
	        // 조회된 담당자 목록이 존재하는 경우    
	        else {
	        	
	        	//사용자 Profile Image Url 정보를 Properties 에서 읽어온다. 
	        	String userProfileUrl = this.dialogConfig.getDialogInfo(inquiryData.getTenantId(), "url", "userProfileImage");
	        	
	        	StringBuffer title = null;
	        	StringBuffer subtitle = null;
	        	StringBuffer action = null;
	        	StringBuffer descriptions = null;
	        	String assignType = null;
	        	String id = null;
	        	String text = null;
	        	
	        	String empNm = null, titleNm = null, systemNm = null, label1 = null, label2 = null; 
	        	String deptAllNm = null, empMailId = null, empMobile = null, deptNm = null, deptCd = null, empTelNo = null;
	        	//사용자 목록의 이미지를 처리하기 위하여 Element 설정내용
	        	// 1) id : userId, type:people, corpCode : CompanyCode를 설정하여야 사용자 이미지가 조회된다.
	        	// 2) imageUrl : http://approval.lgcns.com/files/photo/{corpCode}/{userId}.jpg 설정 ==> URL 을 설정파일로 추출하여야 한다.
	        	
	        	/*{
	        		SYSTEM_NM=U-Security, 
	        		SORT_NO=57, 
	        		LABEL1=정보보안예외요청[처리], LABEL1_GLOBAL=, LABEL2=반출입승인요청(FKI), LABEL2_GLOBAL=, LABEL3=, LABEL3_GLOBAL=, 
	        		ADMIN_TYPE=EMP, ADMIN_NO=A33422, EMP_NM=박상규, TITLE_NM=(대리), EMP_MAIL_ID=naengsoo@cnspartner.com, 
	        		DEPT_ALL_NM=CHO 경영지원팀, EMP_TEL_NO=02-2099-0760, EMP_MOBILE=010-4155-8725, DEPT_CD=12022, DEPT_NM=경영지원팀, 
	        		ASSIGN_TYPE=W, USE_FG=Y, ADMIN_NO_DEPT_CD=12022, ALL_FG=N} */ 
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
        			
	        			id = ( (proxyResult.get("ADMIN_NO") != null) ) ? String.valueOf(proxyResult.get("ADMIN_NO")) : null;
	        			empNm = ( (proxyResult.get("EMP_NM") != null) ) ? String.valueOf(proxyResult.get("EMP_NM")) : null; 
	        			titleNm = ( (proxyResult.get("TITLE_NM") != null) ) ? String.valueOf(proxyResult.get("TITLE_NM")) : null; 
	        			systemNm = ( (proxyResult.get("SYSTEM_NM") != null) ) ? String.valueOf(proxyResult.get("SYSTEM_NM")) : null; 
	        			label1 = ( (proxyResult.get("LABEL1") != null) ) ? String.valueOf(proxyResult.get("LABEL1")) : null; 
	        			label2 = ( (proxyResult.get("LABEL2") != null) ) ? String.valueOf(proxyResult.get("LABEL2")) : null; 
	        			deptAllNm = ( (proxyResult.get("DEPT_ALL_NM") != null) ) ? String.valueOf(proxyResult.get("DEPT_ALL_NM")) : null;
	        			deptNm = ( (proxyResult.get("DEPT_NM") != null) ) ? String.valueOf(proxyResult.get("DEPT_NM")) : null;
	        			deptCd = ( (proxyResult.get("DEPT_CD") != null) ) ? String.valueOf(proxyResult.get("DEPT_CD")) : null;
	        			empMailId = ( (proxyResult.get("EMP_MAIL_ID") != null) ) ? String.valueOf(proxyResult.get("EMP_MAIL_ID")) : null;
	        			empMobile = ( (proxyResult.get("EMP_MOBILE") != null) ) ? String.valueOf(proxyResult.get("EMP_MOBILE")) : null;
	        			empTelNo = ( (proxyResult.get("EMP_TEL_NO") != null) ) ? String.valueOf(proxyResult.get("EMP_TEL_NO")) : null;
	        			
	        			
	        			//Title
	    				title = new StringBuffer("");
	    				if ( !StringUtils.isEmpty(empNm) ) {
	    					title.append(empNm);
	    				}
	    				
	    				if ( !StringUtils.isEmpty(titleNm) ) {
	    					if ( !StringUtils.isEmpty(empNm) ) {
	    						title.append(" ");
	    					}
	    					
	    					title.append(titleNm);
	    				}
	    				
	    				//Subtitle ( ex)SYSTEM_NM [LABEL1 - LABEL2])
	    				subtitle = new StringBuffer("");
	    				if ( !StringUtils.isEmpty(systemNm) ) {
	    					subtitle.append(systemNm);
	    				}
	    				
	    				if ( !StringUtils.isEmpty(label1) ) {
	    					if ( !StringUtils.isEmpty(systemNm) ) {
	    						subtitle.append(" ");
	    					}
	    					
	    					subtitle.append("[").append(label1);
	    				}
	    				
	    				if ( !StringUtils.isEmpty(label2) ) {
	    					if ( !StringUtils.isEmpty(label1) ) {
	    						subtitle.append(" - ");
	    					}
	    					else {
	    						subtitle.append(" [");
	    					}
	    					
	    					subtitle.append(label2).append("]");
	    				}
	    				else {
	    					if ( !StringUtils.isEmpty(label1) ) {
	    						subtitle.append("]");
	    					}
	    				}
	    				
	    				//Text
	    				text = deptAllNm;
	    				
	    				//Action
	    				action = new StringBuffer("");
	    				if ( !StringUtils.isEmpty(deptNm)  ) {
	    					action.append(deptNm);
	    				}
	    				
	    				if ( !StringUtils.isEmpty(empNm) ) {
	    					if ( !StringUtils.isEmpty(deptNm) ) {
	    						action.append(" ");
	    					}
	    					
	    					action.append(empNm);
	    				}
	    				
	    				if ( !StringUtils.isEmpty(titleNm) ) {
	    					if ( !StringUtils.isEmpty(empNm) ) {
	    						action.append(" ");
	    					}
	    					
	    					action.append(titleNm);
	    				}
	    				
	                    //Description Mail + Mobile
	                    descriptions = new StringBuffer("");
	                    if ( !StringUtils.isEmpty(empMailId) ) {
	                        descriptions.append(empMailId);
	                    }
	                    
	                    if ( !StringUtils.isEmpty(empMobile) ) {
	    					if ( !StringUtils.isEmpty(empMailId) ) {
	    						descriptions.append(" | ");
	    					}
	    					
	    					descriptions.append(empMobile);
	    				}
	                    
	                    /*//ASSIGN_TYPE 타입 : 'S':시스템담당자  'W':업무담당자
	                    if ( proxyResult.get("ASSIGN_TYPE") != null ) {
	                        if (!StringUtils.isEmpty(proxyResult.get("DEPT_NM"))) {
	                            descriptions.append(" | ");
	                        }
	                        assignType = proxyResult.get("ASSIGN_TYPE").toString();
	                        if ("S".equals(assignType)) {
	                        	descriptions.append("시스템담당자");
	                        }
	                        else if ("W".equals(assignType)) {
	                        	descriptions.append("업무담당자");
	                        }
	                    }*/
	    				
	    				Element element = new Element();
	    				element.setId(id);
	    				element.setTitle(title.toString());
	    				element.setSubtitle(subtitle.toString());
	    				element.setText(text);
	    				element.setAction(action.toString());
	    				element.setActionType(ActivityCode.ACTION_TYPE_INQUIRY);
	    				
	    				if ( !StringUtils.isEmpty(descriptions) ) {
	    					element.setDescriptions(descriptions.toString());
	    				}
	    				
	    				if ( !StringUtils.isEmpty(userProfileUrl) ) {
	    					element.setImageUrl(String.format(userProfileUrl, inquiryData.getCompanyCode(), id));
	    				}
	    				
	    				element.setType(CommonCode.ELEMENT_TYPE_PEOPLE);
	    				element.setCorpCode(inquiryData.getCompanyCode());
	    				
	    				
	    				// additionalProperties 설정
	                    Map<String, Object> additionalProperties = new HashMap<String, Object>();
	                    additionalProperties.put("userName", empNm);
	                    additionalProperties.put("jobTitleName", titleNm);
	                    additionalProperties.put("jobTitleEnglishName", titleNm);
	                    additionalProperties.put("jobDutyName", titleNm);
	                    additionalProperties.put("groupId", deptCd);
	                    additionalProperties.put("groupName", deptNm);
	                    additionalProperties.put("fullPathName", deptAllNm);
	                    additionalProperties.put("mobile", empMobile);
	                    additionalProperties.put("officePhoneNo", empTelNo);
	                    additionalProperties.put("mail", empMailId);
	                    //additionalProperties.put("leader", leader);
	                    element.setAdditionalProperties(additionalProperties);
	                    
	    				attachment.addElement(element);
	        		}
	        	}//for
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
}
