/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.Conversation;
import com.lgcns.vpa.channel.model.UserFeedback;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.ServiceLog;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.channel.service.ConversationService;
import com.lgcns.vpa.security.user.model.User;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * <pre>
 * 액티비티 관리 Service
 * </pre>
 * @author 김청욱
 */
@Service("multi.activityService")
public class ActivityServiceImpl implements ActivityService {

    private static final int DEFAULT_LIMIT_COUNT = 10;

    private static final int MAX_LIMIT_COUNT = 100;

    @Autowired
    private MongoTemplate mongoTemplate;
    
    @Autowired
    private ConversationService conversationService;

    
    @Autowired
    private RedisTemplate redisTemplate;
    
    /**
     * 액티비티 저장
     * @param activity
     * @return
     */
    @Override
    public Activity insertActivity(Activity activity) {
        mongoTemplate.save(activity, "activities");
        return activity;
    }
    
    @Override
    public Activity insertAllActivity(Activity activity) {
    	List<Conversation> conversationList = conversationService.retrieveConversationList(activity.getBotId());
    
    	Activity newActivity;
    	for( Conversation conversation : conversationList ) {
    		newActivity = new Activity();
    		newActivity.setTempId(activity.getTempId());
    		newActivity.setBotId(activity.getBotId());
    		newActivity.setUserId(conversation.getUserId());
    		newActivity.setSenderType(activity.getSenderType());
    		newActivity.setSubtype(activity.getSubtype());
    		newActivity.setSentDate(activity.getSentDate());
    		newActivity.setUpdateDate(activity.getUpdateDate());
    		newActivity.setMessage(activity.getMessage());
    		newActivity.setButtons(activity.getButtons());
    		
    		mongoTemplate.save(newActivity, "activities");
    	}
    	
    	return activity;
    }
    
    /**
     * 액티비티 동시 저장
     * @param activity
     * @return
     */
    @Override
    public Activity insertAllActivity(Activity requestActivity,Activity responseActivity) {
    	
    	mongoTemplate.save(requestActivity, "activities");
    	responseActivity.setReplyToId(requestActivity.getId());
    	mongoTemplate.save(responseActivity, "activities");
         
        return responseActivity;
    }

    /**
     * 최근 액티비티 조회
     * @param botId
     * @param limit
     * @param user
     * @param includeDailyPush
     * @return
     */
    @Override
    public List<Activity> retrieveRecentActivityList(String botId, int limit, User user, boolean includeDailyPush) {
        Query findQuery = new Query();
        		
        List<String> excludeSubtypes = Arrays.asList(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_DAILY_PUSH);
        
        Criteria activityCriteria = null;
        activityCriteria = Criteria.where("botId").is(botId);
        
        activityCriteria.and("userId").in(user.getUserId(), "ALL");
    	activityCriteria.and("delYn").ne("Y");
    	//activityCriteria.and("type").is(ActivityCode.ACTIVITY_TYPE_MESSAGE);
    	
       /* // 데일리 푸시 포함
        if (includeDailyPush) {
            // 당일 마지막 데일리 푸시 조회
            Criteria dailyPushCriteria = 
                    Criteria.where("userId").is(user.getUserId())
                        .and("botId").is(botId)
                        .and("type").is(ActivityCode.ACTIVITY_TYPE_MESSAGE)
                        .and("subtype").in(excludeSubtypes)
                        .and("delYn").ne("Y")
                        .and("sentDate")
                            .gte(LocalDateTime.of(LocalDate.now(), LocalTime.MIDNIGHT));
                           // .lt(LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.MIDNIGHT));
            
            Activity dailyPush = mongoTemplate.findOne(
                    new Query().addCriteria(dailyPushCriteria).with(new Sort(Sort.Direction.DESC, "_id")), Activity.class, "activities");
           
            
            // 데일리 푸시 존재
            if (dailyPush != null) {
                // Criteria criteriaSubTypeAndDate = new Criteria();
                // criteriaSubTypeAndDate.andOperator(Criteria.where("registDate").gte(LocalDateTime.of(LocalDate.now(), LocalTime.MIDNIGHT)), Criteria.where("subtype").in(excludeSubtypes));
                Criteria criteriaLastDailyPush = Criteria.where("_id").is(dailyPush.getId()).and("subtype").in(excludeSubtypes);
                
                Criteria criteriaSubType = Criteria.where("subtype").nin(excludeSubtypes);
                activityCriteria.orOperator(criteriaLastDailyPush, criteriaSubType); 
            } 
            // 데일리 푸시 미존재
            else {
                Criteria criteriaSubType = Criteria.where("subtype").nin(excludeSubtypes);
                activityCriteria.andOperator(criteriaSubType); 
            }
        }
        // 데일리 푸시 제외
        else {
            Criteria criteriaSubType = Criteria.where("subtype").nin(excludeSubtypes);
            activityCriteria.andOperator(criteriaSubType); 
        }*/

    	findQuery.addCriteria(activityCriteria).with(new Sort(Sort.Direction.DESC, "sentDate"));

        List<Activity> activityList = mongoTemplate.find(findQuery.limit(this.validateLimitCount(limit)), Activity.class, "activities");

        Collections.reverse(activityList);

        return activityList;        
    }
 
    /**
     * 이전 액티비티 조회
     * @param botId
     * @param cursorId
     * @param limit
     * @param user
     * @param includeDailyPush
     * @return
     */
    @Override
    public List<Activity> retrieveBeforeActivityList(String botId, String cursorId, int limit, User user, boolean includeDailyPush) {
        List<String> excludeSubtypes = Arrays.asList(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_DAILY_PUSH);

        Query findQuery = new Query();
        
        Criteria activityCriteria = null;
        activityCriteria = Criteria.where("botId").is(botId);
        
        activityCriteria.and("userId").in(user.getUserId(),"ALL");
    	activityCriteria.and("delYn").ne("Y");
    	//activityCriteria.and("type").is(ActivityCode.ACTIVITY_TYPE_MESSAGE);
    	
    	if ( !StringUtils.isEmpty(cursorId)) {
         	activityCriteria.and("_id").lt(new ObjectId(cursorId));
        }
    	
    	/*// 데일리 푸시 포함
        if (includeDailyPush) {
            // 당일 마지막 데일리 푸시 조회
            Criteria dailyPushCriteria = 
                    Criteria.where("userId").is(user.getUserId())
                        .and("botId").is(botId)
                        .and("type").is(ActivityCode.ACTIVITY_TYPE_MESSAGE)
                        .and("subtype").in(excludeSubtypes)
                        .and("delYn").ne("Y")
                        .and("sentDate")
                            .gte(LocalDateTime.of(LocalDate.now(), LocalTime.MIDNIGHT));
                           // .lt(LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.MIDNIGHT));
            
            Activity dailyPush = mongoTemplate.findOne(
                    new Query().addCriteria(dailyPushCriteria).with(new Sort(Sort.Direction.DESC, "_id")), Activity.class, "activities");
            
            // 데일리 푸시 존재
            if (dailyPush != null) {
                // Criteria criteriaSubTypeAndDate = new Criteria();
                // criteriaSubTypeAndDate.andOperator(Criteria.where("registDate").gte(LocalDateTime.of(LocalDate.now(), LocalTime.MIDNIGHT)), Criteria.where("subtype").in(excludeSubtypes));
                Criteria criteriaLastDailyPush = Criteria.where("_id").is(dailyPush.getId()).and("subtype").in(excludeSubtypes);
                
                Criteria criteriaSubType = Criteria.where("subtype").nin(excludeSubtypes);
                activityCriteria.orOperator(criteriaLastDailyPush, criteriaSubType); 
            } 
            // 데일리 푸시 미존재
            else {
                Criteria criteriaSubType = Criteria.where("subtype").nin(excludeSubtypes);
                activityCriteria.andOperator(criteriaSubType); 
            }
        }
        // 데일리 푸시 제외
        else {
            Criteria criteriaSubType = Criteria.where("subtype").nin(excludeSubtypes);
            activityCriteria.andOperator(criteriaSubType); 
        }*/

        findQuery.addCriteria(activityCriteria).with(new Sort(Sort.Direction.DESC, "_id"));

        List<Activity> activityList = mongoTemplate.find(findQuery.limit(this.validateLimitCount(limit)), Activity.class, "activities");

        //이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다.2018.01.09
    	//james
    	
    	System.out.println("###########################retrieveBeforeActivityList 이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다##########################");
    	Query findPushQuery = new Query();
    	Criteria criteriaPush = Criteria.where("userId").is(user.getUserId());
    	criteriaPush.and("subtype").is("push");
    	criteriaPush.and("readDate").exists(false);

    	findPushQuery.addCriteria(criteriaPush);

    	Update update = new Update();
    	update.set("readDate", new Date());
    	mongoTemplate.updateMulti(findPushQuery, update, Activity.class, "activities");
    	//이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다.2018.01.09

        Collections.reverse(activityList);

        return activityList;
    }

    /**
     * 액티비티 카운트 조회
     * @param botId
     * @param user
     * @return
     */
    public Integer retrieveActivityCount(String botId, User user) {
        int activityCount = 0;
        
//        Criteria criteria = Criteria.where("userId").is(user.getUserId())
//            .and("botId").is(botId)
//            .and("delYn").ne("Y")
//            .and("type").is(ActivityCode.ACTIVITY_TYPE_MESSAGE);
//             
//        MatchOperation match = Aggregation.match(criteria);
//         
//        GroupOperation group = Aggregation.group("userId").count().as("total");
//        Aggregation aggregation = Aggregation.newAggregation(match, group);
//        AggregationResults<DBObject> aggregationResults = mongoTemplate.aggregate(aggregation, "activities", DBObject.class);
//
//        activityCount = (Integer) aggregationResults.getUniqueMappedResult().get("total");
      
        return activityCount;
    }
    
    /**
     * 유효한 페이징 확인
     * @param count
     * @return
     */
    private int validateLimitCount(int count) {
        return count < 1 || count > MAX_LIMIT_COUNT ? DEFAULT_LIMIT_COUNT : count;
    }

    /**
     * 마지막 액티비티 조회
     * @param botId
     * @param user
     * @return
     */
    @Override
    public Activity retrieveLastActivity(String botId, User user) {
        Query findQuery = new Query();
        findQuery.addCriteria(
            Criteria.where("userId").is(user.getUserId()).and("botId").is(botId)
            	.and("delYn").ne("Y")
                .and("type").is(ActivityCode.ACTIVITY_TYPE_MESSAGE))
                .with(new Sort(Sort.Direction.DESC, "_id"));

        return mongoTemplate.findOne(findQuery, Activity.class, "activities");
    }
    
    /**
     * 현 대화의 전체 액티비티 삭제
     * @param botId
     * @param user
     */
    @Override
    public void deleteAllActivities(String botId, User user) {
        Query removeQuery = new Query()
            .addCriteria(Criteria.where("userId").is(user.getUserId()).and("botId").is(botId));
       
        Date today = new Date();
        Update update = new Update();
        update.set("delYn", "Y");
        update.set("delDate", today);
        
        mongoTemplate.updateMulti(removeQuery, update, Activity.class);        
    }

    /**
     * 외부서비스 저장
     * @param serviceLog
     * @param user
     * @return
     */
    
    @Override
    public ServiceLog insertServiceLog(ServiceLog serviceLog, User user) {
       
    	
    	Date today = new Date();
       	serviceLog.setSentDate(today);
    	
    	mongoTemplate.insert(serviceLog);
        
        return serviceLog;
    }

    /**
     * 사용자의 피드백 저장
     * @param activity
     * @param user
     * @return
     */
    @Override
    public Activity updateUserFeedback(Activity activity, User user) {
       
    	Date today = new Date();
    	UserFeedback userFeedback= new UserFeedback();
    	userFeedback.setBotId(activity.getBotId());
    	userFeedback.setUserId(user.getUserId());
    	userFeedback.setFeedback(activity.getFeedback());
    	userFeedback.setFeedbackDate(today);
    	
    	mongoTemplate.insert(userFeedback);
        
    	return activity;
    }
    
    
    /**
     * 액티비티의 좋아요 및 피드백 조회
     * @param activityId
     * @param botId
     * @param user
     * @return
     */
    @Override
    public Activity retrieveFeedback(String activityId, String botId, User user) {
        if (!hasUserActivityPermission(botId, activityId, user.getUserId())) {
            throw new RuntimeException("해당 메시지에 대한 조회 권한이 없습니다.");
        }
        
        Query findQuery = new Query();
        findQuery.addCriteria(Criteria.where("id").is(activityId));
        findQuery.fields()
            .include("id")
            .include("botId")
            .include("like")
            .include("likeDate")
            .include("feedback")
            .include("feedbackType")
            .include("feedbackDate");
        
        return mongoTemplate.findOne(findQuery, Activity.class, "activities");
    }
    
    /**
     * 액티비티 조회 및 수정 권한 확인
     * @param botId
     * @param activityId
     * @param userId
     * @return
     */
    public boolean hasUserActivityPermission(String botId, String activityId, String userId) {
        boolean hasUserPermission= false;
        
        try {
            Query findQuery = new Query();
            findQuery.addCriteria(Criteria.where("id").is(activityId).and("userId").is(userId).and("botId").is(botId));
            findQuery.fields().include("id");
            
            hasUserPermission = mongoTemplate.findOne(findQuery, Activity.class, "activities") != null;

        } catch (Exception e) {
            hasUserPermission= false;
        }
        
        return hasUserPermission;
    }

    /**
     * 액티비티의 좋아요 및 피드백 저장
     * @param activity
     * @param user
     * @return
     */
    @Override
    public Activity updateFeedback(Activity activity, User user) {
        if (!hasUserActivityPermission(activity.getBotId(), activity.getId(), user.getUserId())) {
            throw new RuntimeException("해당 메시지에 대한 저장 권한이 없습니다.");
        }
        
        Date today = new Date();
        Query findQuery = new Query().addCriteria(Criteria.where("id").is(activity.getId()));
        Update update = new Update();
        
        if (!StringUtils.isEmpty(activity.getLike()))
            update.set("like", activity.getLike()).set("likeDate", today);
        
        if (!StringUtils.isEmpty(activity.getFeedback()))
            update.set("feedback", activity.getFeedback()).set("feedbackDate", today);
        
        if (!StringUtils.isEmpty(activity.getFeedbackType()))
            update.set("feedbackType", activity.getFeedbackType());
        
        mongoTemplate.updateFirst(findQuery, update, Activity.class, "activities");
        
        return mongoTemplate.findOne(findQuery, Activity.class, "activities");
    }
    
    @Override
    public void updateMessageRead(String botId, String userId, String activityId,String tempId) {
    	
    	//멀티봇 환경에서 푸쉬는 봇ID와는 상관없이 Push 서비스 되고 있어서 botId 주석 처리
    	//2017.11.29
    	Query findQuery = new Query();
    	Criteria criteria = Criteria.where("userId").is(userId);
    	//		.and("botId").is(botId);
    	
    	if( !StringUtils.isEmpty(activityId) ) {
    		criteria.and("_id").is(new ObjectId(activityId));
    	}else{
    		if( !StringUtils.isEmpty(tempId) ) {
        		criteria.and("tempId").is(tempId);
        	}
    	}
    	
    	
    	
    	findQuery.addCriteria(criteria);

    	Update update = new Update();
        update.set("readDate", new Date());
    	mongoTemplate.updateFirst(findQuery, update, Activity.class, "activities");
    	
    }
    
    @Override
    public long getUnreadCount(String botId, String userId) {
    	Query findQuery = new Query();
    	//멀티봇 환경에서 푸쉬는 봇ID와는 상관없이 Push 서비스 되고 있어서 botId 주석 처리
    	//2017.11.29
    	//보낸날짜 24시간 기준으로 수정(2018.01.04)
    	//보낸날짜 12시간 전것으로 수정(2018.01.09)
    	
    	findQuery.addCriteria(Criteria.where("userId").is(userId)
    			//.and("botId").is(botId)
    			.and("subtype").is("push")
    			.and("delYn").ne("Y")
    			//.and("sentDate").gte(LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.now()))
    			.and("sentDate").gte(LocalDateTime.now().minusHours(12))
    			.lte(LocalDateTime.of(LocalDate.now(), LocalTime.now()))
    			.and("readDate").exists(false));
    	
    	return mongoTemplate.count(findQuery, Activity.class);
    	
    }
    
    
    /**
     * readDate 업데이트 
     * @param botId
     * @param userId
     */
    @Override
    public void updateReadDate(String botId, String userId) {
       
    	System.out.println("###########################updateReadDate 이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다##########################");
    	Query findPushQuery = new Query();
    	Criteria criteriaPush = Criteria.where("userId").is(userId);
    	criteriaPush.and("subtype").is("push");
    	criteriaPush.and("readDate").exists(false);

    	findPushQuery.addCriteria(criteriaPush);

    	Update update = new Update();
    	update.set("readDate", new Date());
    	mongoTemplate.updateMulti(findPushQuery, update, Activity.class, "activities");
    }
    
    @Override
    public List<Activity> getUnreadPush(String botId,String userId) {
    	Query findQuery = new Query();
    	findQuery.addCriteria(Criteria.where("userId").is(userId)
    			.and("botId").is(botId)
    			.and("subtype").is("push")
    			.and("delYn").ne("Y")
    			//.and("sentDate").gte(LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.now()))
    			.and("sentDate").gte(LocalDateTime.now().minusHours(12))
    			.lte(LocalDateTime.of(LocalDate.now(), LocalTime.now()))
    			.and("readDate").exists(false));
    	
    	return mongoTemplate.find(findQuery, Activity.class);
    }
    
    @Override
    public String getRedisSession( String userId) {
    	String result="";
    	
    	// 웹소켓 연결정보를 REDIS에서 삭제한다.
		String key = String.format("webscoket:%s", userId);
		
		String webSocketSessionId = (String)redisTemplate.opsForHash().get(key, "webSocketSessionId");
		String sessionId = (String)redisTemplate.opsForHash().get(key, "sessionId");

		
			
		String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
		String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
			 
		if( redisTemplate.hasKey(sessionIdKey) ) {
			result="### userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId;
		}else{
			result="session has no existed";
		}
		
    	return result;
    	
    }
    
    /*
     * 사용자 세션 삭제
     * @see com.lgcns.vpa.channel.service.ActivityService#getRedisSessionId(java.lang.String)
     */
    @Override
    public String removeSession( String userId) {
    	String result="";
    	
    	// 웹소켓 연결정보를 REDIS에서 삭제한다.
		String key = String.format("webscoket:%s", userId);
		
		String webSocketSessionId = (String)redisTemplate.opsForHash().get(key, "webSocketSessionId");
		String sessionId = (String)redisTemplate.opsForHash().get(key, "sessionId");

		
			
		String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
		String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
			 
		if( redisTemplate.hasKey(sessionIdKey) ) {
			result="### userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+" expired";
		}else{
			result="session has no existed";
		}
		
		 // 웹소켓 연결정보를 REDIS에서 삭제한다.
	    redisTemplate.expire(key, 0, TimeUnit.MINUTES);
	    redisTemplate.expire(webSocketSessionIdKey, 0, TimeUnit.MINUTES);  
	    redisTemplate.expire(sessionIdKey, 0, TimeUnit.MINUTES); 
	    
    	return result;
    	
    }
    
    /*
     * 웹소켓 ID를 통해 사용자 상태 체크
     * @see com.lgcns.vpa.channel.service.ActivityService#getRedisSessionId(java.lang.String)
     */
    @Override
    public String getRedisSessionId( String webSocketSessionId) {
    	String result="";
    	
    	String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
    	
    	String sessionId = (String)redisTemplate.opsForHash().get(webSocketSessionIdKey, "sessionId");
		String userId = (String)redisTemplate.opsForHash().get(webSocketSessionIdKey, "userId");

		
		String key = String.format("webscoket:%s", userId);
		String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
		
		if( redisTemplate.hasKey(key) ) {
			result="### userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId;
		}else{
			result="webSocketSessionId has no existed";
		}
		
    	return result;
    	
    }
    
    
    @Override
    public   List<Activity> getRedisAllSession( String botId) {
    	List<Activity> activities = new ArrayList<>();
    	//StringBuilder msg = new StringBuilder();
    	Query query = new Query();
		
		query.addCriteria(Criteria.where("enterDate").gte(LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MIN))
		.lte(LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX)));
		
		
		//msg.append("################# start tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MIN)+", end tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX)+"\n");
				
		query.fields()
		.include("userId");
		
		List<String> conversationList =mongoTemplate.find(query, String.class,"conversations");
		ObjectMapper objectMapper = new ObjectMapper();
		
		JsonNode jsonNode = null ;
		HashOperations<String, String, Object> hashOper = redisTemplate.opsForHash();
		
		//msg.append("################# conversationList.size():"+conversationList.size()+"\n");
		
		List<String> listOfUser = new ArrayList<String>();
		
		
		int cnt=0;
		int no=0;
		for(String userInfo : conversationList){
			Activity activity =new Activity();
			no=no+1;
			try {
				jsonNode = objectMapper.readTree(userInfo);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String userId = jsonNode.get("userId").asText();
			listOfUser.add(userId);
			
			// 웹소켓 연결정보를 REDIS에서 삭제한다.
			String key = String.format("webscoket:%s", userId);
			String message="";
			 
			String webSocketSessionId = (String)redisTemplate.opsForHash().get(key, "webSocketSessionId");
			String sessionId = (String)redisTemplate.opsForHash().get(key, "sessionId");

			
				
			String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
			String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
				 
				 
			if( redisTemplate.hasKey(sessionIdKey) ) {
				message="session is expired";
			 	cnt=cnt+1;
			}else{
				message="session has no existed";
			}
			activity.setUserId(userId);
			activity.setMessage("################# No:"+no+",userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+",msg:"+message);
		    activities.add(activity);
			//msg.append("################# No:"+no+",userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+",msg:"+msg+"\n");
			 
		}
		
		//msg.append("######## session expired count:"+cnt+"\n");
		
    	//return msg.toString();
    	return activities;
    	
    }
    
    @Override
    public   List<Activity> getRedisAllSessionTest( String botId) {
    	List<Activity> activities = new ArrayList<>();
    	//StringBuilder msg = new StringBuilder();
    	Query query = new Query();
		
    	Conversation conversatoin=new Conversation();
    	
    	Calendar start = new GregorianCalendar();
    	start.add(Calendar.DATE, -1);
    	start.set(Calendar.HOUR_OF_DAY, 0); 
    	start.set(Calendar.MINUTE, 0);
    	start.set(Calendar.SECOND, 0);

    	Calendar end = new GregorianCalendar();
    	end.add(Calendar.DATE, -1);
    	end.set(Calendar.HOUR_OF_DAY, 23); 
    	end.set(Calendar.MINUTE, 59);
    	end.set(Calendar.SECOND, 59);
    	
    	conversatoin.setEnterDate(start.getTime());
    	conversatoin.setDailyPushDate(end.getTime());
    	
		query.addCriteria(Criteria.where("enterDate").gte(conversatoin.getEnterDate()).lte(conversatoin.getDailyPushDate()));
		
		
		//msg.append("################# start tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MIN)+", end tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX)+"\n");
				
		query.fields()
		.include("userId");
		
		List<String> conversationList =mongoTemplate.find(query, String.class,"conversations");
		ObjectMapper objectMapper = new ObjectMapper();
		
		JsonNode jsonNode = null ;
		HashOperations<String, String, Object> hashOper = redisTemplate.opsForHash();
		
		//msg.append("################# conversationList.size():"+conversationList.size()+"\n");
		
		List<String> listOfUser = new ArrayList<String>();
		
		
		int cnt=0;
		int no=0;
		for(String userInfo : conversationList){
			Activity activity =new Activity();
			no=no+1;
			try {
				jsonNode = objectMapper.readTree(userInfo);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String userId = jsonNode.get("userId").asText();
			listOfUser.add(userId);
			
			// 웹소켓 연결정보를 REDIS에서 삭제한다.
			String key = String.format("webscoket:%s", userId);
			String message="";
			 
			String webSocketSessionId = (String)redisTemplate.opsForHash().get(key, "webSocketSessionId");
			String sessionId = (String)redisTemplate.opsForHash().get(key, "sessionId");

			
				
			String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
			String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
				 
				 
			if( redisTemplate.hasKey(sessionIdKey) ) {
				message="session is expired";
			 	cnt=cnt+1;
			}else{
				message="session has no existed";
			}
			activity.setUserId(userId);
			activity.setMessage("################# No:"+no+",userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+",msg:"+message);
		    activities.add(activity);
			//msg.append("################# No:"+no+",userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+",msg:"+msg+"\n");
			 
		}
		
		//msg.append("######## session expired count:"+cnt+"\n");
		
    	//return msg.toString();
    	return activities;
    	
    }
  
}