/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.web;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lgcns.vpa.base.web.BaseController;

/**
 * <pre>
 * VPA 클라이언트(Entry Point) Controller
 * </pre>
 * @author
 */
@Controller
public class IndexController extends BaseController {   
    /**
     * 클라이언트 엔트리 포인트
     * @return
     */
    @RequestMapping(value={"/", "/client/**"}, method= RequestMethod.GET)
    public String client(HttpServletRequest request, HttpServletResponse response) {       
        response.setHeader("Cache-Control", "no-store");   
        response.setHeader("Pragma", "no-cache");   
        response.setDateHeader("Expires", 0);
        
        if ("HTTP/1.1".equals(request.getProtocol()))
            response.setHeader("Cache-Control", "no-cache"); 
        
        return "index";
    }
}
