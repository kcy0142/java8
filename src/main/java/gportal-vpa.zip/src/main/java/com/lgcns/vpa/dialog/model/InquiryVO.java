/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : InquiryVO.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.model;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * Mongodb 연동 및 다이얼로그 핸들러의 Transaction 관리를 위한 Model 정의
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
public class InquiryVO {
	
	//질의 처리에 대한 고유 아이디
	private String inquiryId;
	
	//의도 아이디
	private String intentId;

	//의도의 Slot Filling 여부
	private String slotFillingYn;
	
	//질의문 Type (message, search, typeahead, polling, greeting 등)
	//private String activityType;
	
	//질의문 Type (질의문, 버튼, choice, 검색, 사용자 검색, 프로젝트 검색 등)
	//private String activitySubType;
	
	//질의문
	private String inquiryData;
	
	//질의 시 입력된 Action Parmaeter
	private Map<String, Object> reqActionParams;
	
	//의도 파라미터
	private Map<String, Object> intentParam;

	//파라미터 중복일 경우 사용되는 Element List
	private List<Element> paramElements;
	
	//진행 상태
	private int processStatus;
	
	//의도분석 결과 Type (Slot Filling, Parameter duplication, intent duplication 등)
	private int intentResultType;
	
	//의도분석 결과 Message (응답의 )
	private String intentMessage;
	
	//의도 Animation 정보
	private String intentAnimation;
	
	//자동 실행이 가능한 Intnet 인지 여부
	private boolean intentAutoRunYn;
	
	/**
	 * 연관 버튼
	 */
	private List<RelatedButton> intentButtons;
	
	//의도와 Mapping 된 Action
	private Action action;
	
	//Action 결과 Message
	private String actionResult;
	
	//요청자 userId
	private String reqUserId;
	
	//요청자 GroupId
	//private String reqGroupId;
	
	//요청자 reqCompanyCode
	private String reqCompanyCode;
	
	//요청 Message Id
	private String reqMessageId;
	
	//요청자 정보
	private User reqUser;
	
	/**
     * 사용자 IP
     */
	private String reqIp;
	
	/**
     * 채널 디바이스 유형
     */
	private String reqDeviceType;
	
	/**
	 * Action 을 사용하는 회사코드
	 */
	private String companyCode;
	
	/**
	 * Action 을 사용하는 챗봇 구분 id
	 */
	private String botId;
	
	//질의가 요청된 Activity
	private Activity requestActivity;
		
	//질의에 대한 응답 Activity
	private Activity responseActivity;
	
	//질의한 TenantId
	private String tenantId;
	
	/**
     * 개발기간동안 인텐트 분석 및 다이얼로그 핸들러 처리결과 표시를 위한 필드
     */
    @Transient
    private String intentLog;
    
    @Transient
    private String dialogLog;
    
    /**
     * 통함 건색 결과 저장
     */
    private List<Map<String , Object>> searchResult = null;
    
    /**
     * 통합 검색용 질의문
     */
    private String searchInquiryData = null;
	
    /**
     * 의도분석 서버와 연동에 걸린 시간
     */
    private long spentTimeIntent;
    
    /**
     * Proxy 연동에 걸린 시간
     */
    private long spentTimeProxy;
    
    private String intentType;
    
	public InquiryVO() {}
	
	/*public InquiryVO(String reqUserId, String inquiryData) {
		this.reqUserId = reqUserId;
		this.inquiryData = inquiryData;
	}*/
	
	public InquiryVO(User reqUser, String inquiryData, String reqIp, String reqDeviceType) {
		this.reqUser = reqUser;
		this.reqUserId = reqUser.getUserId();
		this.inquiryData = inquiryData;
		this.reqIp = reqIp;
		this.reqDeviceType = reqDeviceType;
	}
	/*
	public InquiryVO(String inquiryId, String intentId, String inquiryData, String reqUserId,
			String reqGroupId, String reqCompanyCode, String reqMessageId) {
		super();
		this.inquiryId = inquiryId;
		this.intentId = intentId;
		this.inquiryData = inquiryData;
		this.reqUserId = reqUserId;
		this.reqGroupId = reqGroupId;
		this.reqCompanyCode = reqCompanyCode;
		this.reqMessageId = reqMessageId;
	}*/

	public String getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(String inquiryId) {
		this.inquiryId = inquiryId;
	}

	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}

	public String getSlotFillingYn() {
		return slotFillingYn;
	}

	public void setSlotFillingYn(String slotFillingYn) {
		this.slotFillingYn = slotFillingYn;
	}

	public String getInquiryData() {
		return inquiryData;
	}

	public void setInquiryData(String inquiryData) {
		this.inquiryData = inquiryData;
	}
	
	public Map<String, Object> getReqActionParams() {
		return reqActionParams;
	}

	public void setReqActionParams(Map<String, Object> reqActionParams) {
		this.reqActionParams = reqActionParams;
	}

	public Map<String, Object> getIntentParam() {
		return intentParam;
	}

	public void setIntentParam(Map<String, Object> intentParam) {
		this.intentParam = intentParam;
	}
	
	public List<Element> getParamElements() {
		return paramElements;
	}

	public void setParamElements(List<Element> paramElements) {
		this.paramElements = paramElements;
	}

	public int getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(int processStatus) {
		this.processStatus = processStatus;
	}

	public int getIntentResultType() {
		return intentResultType;
	}

	public void setIntentResultType(int intentResultType) {
		this.intentResultType = intentResultType;
	}
	
	public String getIntentMessage() {
		return intentMessage;
	}

	public void setIntentMessage(String intentMessage) {
		this.intentMessage = intentMessage;
	}
	
	public String getIntentAnimation() {
		return intentAnimation;
	}

	public void setIntentAnimation(String intentAnimation) {
		this.intentAnimation = intentAnimation;
	}
	
	public boolean getIntentAutoRunYn() {
		return intentAutoRunYn;
	}

	public void setIntentAutoRunYn(boolean intentAutoRunYn) {
		this.intentAutoRunYn = intentAutoRunYn;
	}

	public List<RelatedButton> getIntentButtons() {
		return intentButtons;
	}

	public void setIntentButtons(List<RelatedButton> intentButtons) {
		this.intentButtons = intentButtons;
	}

	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}
	
	public String getActionResult() {
		return actionResult;
	}

	public void setActionResult(String actionResult) {
		this.actionResult = actionResult;
	}

	public String getReqUserId() {
		return reqUserId;
	}

	public void setReqUserId(String reqUserId) {
		this.reqUserId = reqUserId;
	}

	public User getReqUser() {
		return reqUser;
	}

	public void setReqUser(User reqUser) {
		this.reqUser = reqUser;
	}

	public String getReqCompanyCode() {
		return reqCompanyCode;
	}

	public void setReqCompanyCode(String reqCompanyCode) {
		this.reqCompanyCode = reqCompanyCode;
	}
	
	public String getReqMessageId() {
		return reqMessageId;
	}

	public void setReqMessageId(String reqMessageId) {
		this.reqMessageId = reqMessageId;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getReqIp() {
		return reqIp;
	}

	public void setReqIp(String reqIp) {
		this.reqIp = reqIp;
	}

	public String getReqDeviceType() {
		return reqDeviceType;
	}

	public void setReqDeviceType(String reqDeviceType) {
		this.reqDeviceType = reqDeviceType;
	}

	public Activity getRequestActivity() {
		return requestActivity;
	}

	public void setRequestActivity(Activity requestActivity) {
		this.requestActivity = requestActivity;
	}

	public Activity getResponseActivity() {
		return responseActivity;
	}

	public void setResponseActivity(Activity responseActivity) {
		this.responseActivity = responseActivity;
	}
	
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getIntentLog() {
		return intentLog;
	}

	public void setIntentLog(String intentLog) {
		this.intentLog = intentLog;
	}

	public String getDialogLog() {
		return dialogLog;
	}

	public void setDialogLog(String dialogLog) {
		this.dialogLog = dialogLog;
	}
	
	public List<Map<String, Object>> getSearchResult() {
		return searchResult;
	}

	public void setSearchResult(List<Map<String, Object>> searchResult) {
		this.searchResult = searchResult;
	}
	
	public String getSearchInquiryData() {
		return searchInquiryData;
	}

	public void setSearchInquiryData(String searchInquiryData) {
		this.searchInquiryData = searchInquiryData;
	}

	public long getSpentTimeIntent() {
		return spentTimeIntent;
	}

	public void setSpentTimeIntent(long spentTimeIntent) {
		this.spentTimeIntent = spentTimeIntent;
	}

	public long getSpentTimeProxy() {
		return spentTimeProxy;
	}

	public void setSpentTimeProxy(long spentTimeProxy) {
		this.spentTimeProxy = spentTimeProxy;
	}

	public String getIntentType() {
		return intentType;
	}

	public void setIntentType(String intentType) {
		this.intentType = intentType;
	}

	@Override
	public String toString() {
		return "InquiryVO [inquiryId=" + inquiryId + ", intentId=" + intentId + ", intentType=" + intentType +", slotFillingYn=" + slotFillingYn
				+ ", inquiryData=" + inquiryData + ", reqActionParams=" + reqActionParams + ", intentParam="
				+ intentParam + ", paramElements=" + paramElements + ", processStatus=" + processStatus
				+ ", intentResultType=" + intentResultType + ", intentMessage=" + intentMessage + ", intentButtons="
				+ intentButtons + ", action=" + action + ", actionResult=" + actionResult + ", reqUserId=" + reqUserId
				+ ", reqCompanyCode=" + reqCompanyCode + ", reqMessageId=" + reqMessageId + ", reqUser=" + reqUser
				+ ", reqIp=" + reqIp + ", reqDeviceType=" + reqDeviceType + ", companyCode=" + companyCode + ", botId="
				+ botId + ", requestActivity=" + requestActivity + ", responseActivity=" + responseActivity
				+ ", tenantId=" + tenantId + ", intentLog=" + intentLog + ", dialogLog=" + dialogLog + ", searchResult="
				+ searchResult + ", searchInquiryData=" + searchInquiryData + "]";
	}

	/**
	 * Json Data 생성
	 * @return
	 */
	public String toJson () {
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(this);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}
}