/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ActionService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.framework.multidata.annotation.MultiDataSource;



/**
 * <PRE>
 * Action Data 를 MongoDB에서 관리할  business logic 처리용 Service
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 6. 9.
 */
@Service("multi.actionService")
public class ActionService {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	/**
	 * Action Data 생성
	 * @param action
	 * @return
	 */
	@MultiDataSource
	public String insert (Action action) {
		
		String actionId = null;
		
		if (action != null) {
			
			String uuid = UUID.randomUUID().toString().replace("-", "");
			action.setIntentId("INT"+uuid);
			action.setActionId("ACT"+uuid);
			
			Date currentDate = new Date(System.currentTimeMillis());
			action.setRegistDate(currentDate);
			action.setUpdateDate(currentDate);
			this.mongoTemplate.insert(action);
			
			actionId = action.getActionId();
		}
		
		return actionId;
	}
	
	/**
	 * Action Data 다중 생성
	 * @param actions
	 */
	@MultiDataSource
	public void insertMulti (List<Action> actions) {
		if ( (actions != null) && (!actions.isEmpty()) ) {
			
			Date currentDate = new Date(System.currentTimeMillis());
			String uuid = null;
			
			for (Action action : actions) {
				if (action != null) {
					
					uuid = UUID.randomUUID().toString().replace("-", "");
					action.setIntentId("INT"+uuid);
					action.setActionId("ACT"+uuid);
					
					action.setRegistDate(currentDate);
					action.setUpdateDate(currentDate);
				}
			}
			
			this.mongoTemplate.insertAll(actions);
		}
	}
	
	/**
	 * Action Data의 모든 field를 Update함
	 * @param action
	 */
	@MultiDataSource
	public void updateAllField (Action action) {
		if (action != null) {
			Query query = new Query();
			query.addCriteria(new Criteria("actionId").is(action.getActionId()));
			
			Update update = action.getUpdateObject();
			
			this.mongoTemplate.updateFirst(query, update, Action.class);
		}
	}
	
	/**
	 * Action Data의 응답생성용 Template를 Update함
	 * @param actionId
	 * @param template
	 */
	@MultiDataSource
	public void updateResponseTemplate (String actionId, String template) {
		if (!StringUtils.isEmpty(template)) {
			Query query = new Query();
			query.addCriteria(new Criteria("actionId").is(actionId));
			
			Update update = new Update();
			update.set("responseTemplate", template);
			
			this.mongoTemplate.updateFirst(query, update, Action.class);
		}
	}
	
	/**
	 * 등록되어 있는 모든 Action Data를 조회함
	 * @return
	 */
	@MultiDataSource
	public List<Action> getListAll () {
		List<Action> result = this.mongoTemplate.findAll(Action.class);
		return result;
	}
	
	/**
	 * 등록되어 있는 Action Data 중 intentId 로 조회
	 * @param intentId
	 * @return
	 */
	@MultiDataSource
	public Action getActionByIntentId (String intentId) {
		
		Query query = new Query();
		query.addCriteria(new Criteria("intentId").is(intentId));
		
		Action result = this.mongoTemplate.findOne(query, Action.class);
		return result;
	}
	
	/**
	 * 등록되어 있는 Action Data 중 actionId 로 조회
	 * @param intentId
	 * @return
	 */
	@MultiDataSource
	public Action getActionByActionId (String actionId) {
		
		Query query = new Query();
		query.addCriteria(new Criteria("actionId").is(actionId));
		
		Action result = this.mongoTemplate.findOne(query, Action.class);
		return result;
	}
}
