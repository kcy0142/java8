/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : TargetInfo.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.model;

public class TargetInfo {
	
	/**
	 * Notification 대상 그룹 정보의 Bot Id
	 */
	private String botId;
	
	/**
	 * Notification 대상 그룹 아이디
	 */
	private String targetGroupId;
	
	/**
	 * Notification 대상 그룹 정보의 정렬순서
	 */
	private int orderNum;
	
	/**
	 * Notification 대상 그룹의 개별 정보 Type (0:사용자, 1:부서, 99:전사)
	 */
	private int type;
	
	/**
	 * Notification 대상 그룹의 개별 정보 아이디 (사용자일 경우 : 사용자 아이디, 부서일 경우 : 부서 아이디) 
	 */
	private String infoId;
	
	/**
	 * Notification 대상 그룹의 개별 정보사 사용자일 경우 사용자의 부서 아이디
	 */
	private String infoTeamId;

	public TargetInfo () {}

	public TargetInfo(String botId, String targetGroupId, int orderNum, int type, String infoId, String infoTeamId) {
		super();
		this.botId = botId;
		this.targetGroupId = targetGroupId;
		this.orderNum = orderNum;
		this.type = type;
		this.infoId = infoId;
		this.infoTeamId = infoTeamId;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getTargetGroupId() {
		return targetGroupId;
	}

	public void setTargetGroupId(String targetGroupId) {
		this.targetGroupId = targetGroupId;
	}

	public int getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(int orderNum) {
		this.orderNum = orderNum;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getInfoId() {
		return infoId;
	}

	public void setInfoId(String infoId) {
		this.infoId = infoId;
	}

	public String getInfoTeamId() {
		return infoTeamId;
	}

	public void setInfoTeamId(String infoTeamId) {
		this.infoTeamId = infoTeamId;
	}
}
