package com.lgcns.vpa.base.config;

import java.io.File;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.messaging.simp.SimpMessagingTemplate;

import com.lgcns.vpa.intent.entity.EntityDictionary;
import com.lgcns.vpa.intent.translator.TranslateScriptEngine;

@Configuration
public class IntentConfig implements ApplicationContextAware {
	
	private ApplicationContext context;
	@Value("${intent.transcript.path}")
	private String transcript;

/*	@Bean(name="dictionary")
    public EntityDictionary createEntityDictionary() {
        
        Resource resource = context.getResource(transcript);
    	return new EntityDictionary(resource);
    }
*/
	@Bean(name="translateScriptEngine")
	public TranslateScriptEngine createTranslateScriptEngine() {
		Resource resource = context.getResource(transcript);
	    return new TranslateScriptEngine(resource);	
	}
	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.context = context;
		
	}
}
