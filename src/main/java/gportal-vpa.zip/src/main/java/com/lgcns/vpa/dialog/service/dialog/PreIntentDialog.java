/* ------------------------------------------------------------------------------
\ * Project       : NextEP Project VPA System
 * Source        : PreIntentDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.channel.service.SearchService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonUtil;
import com.lgcns.vpa.intent.model.IntentMongo;
import com.lgcns.vpa.intent.service.IntentService;
import com.lgcns.vpa.security.user.model.Group;
import com.lgcns.vpa.security.user.service.GroupService;

/**
 * <PRE>
 * 2~3자의 질의문 전 처리를 위한 Dialog 정의
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 31.
 */
@Component("PreIntentDialog")
public class PreIntentDialog extends VpaDialog {
	
	private static final Logger LOG = LoggerFactory.getLogger(PreIntentDialog.class);
	
	@Autowired
	IntentService intentService;
	
	@Autowired
	private DialogConfig dialogConfig;
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	/**
	 * 통합검색 시 그룸 탭 검색 Option
	 */
	//private final String TOTAL_SEARCH_GROUP_TAB = "&collection=employee_group";
	
	@Autowired
	private SearchService searchService;
	
	@Autowired
	private BotService botService;
	
	@Autowired
	private GroupService groupService;
	
	/**
	 * 부서 조회를 위한 질의어의 조건, 질의어가 정의도어 있는 단어로 종료되는 경우
	 */
	private String [] GROUP_SEARCH_CONDITION = { "부", "부문", "센터", "담당", "실", "팀", "그룹", "법인", "연구소", "사무소", "단", "Team", "Gr", "파트", "part", "div" };
	
	/**
	 * Parameter mapping & Validation
	 * @param data
	 * @return
	 */
	protected boolean validator(InquiryVO data) {
		
		// 특수문자 제거 작업 포함
		/*if ( (data == null) ||  StringUtils.isEmpty(data.getInquiryData()) ) {
			if (data == null) {
				data = new InquiryVO();
			}
			
			data.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_SHORTWORD_ERR);
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:[false], 질의어의 수가 2~10자가 아니어서 전처리 수행하지 않음.");
			
			return false;
		}
		else {
			
			String inquiryText = data.getInquiryData();
			//질의문 특수 문자, 공백 제거
			if ( !StringUtils.isEmpty(inquiryText) ) {
				String match = "[^a-zA-Z0-9가-힣\\-/]";
				inquiryText = inquiryText.replaceAll(match, "");
			}
			
			if ( StringUtils.isEmpty(inquiryText) || (inquiryText.length() < 2) || (inquiryText.length() < 10)) {
				data.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_SHORTWORD_ERR);
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:[false], 질의어의 수가 2~10자가 아니어서 전처리 수행하지 않음.");
				
				return false;
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:[true], 질의어의 수가 2~10자여서 전처리 수행함.");
				return true;
			}
		}*/
		
		// 특수문자 제거 하지 않음
		if ( (data == null) ||  StringUtils.isEmpty(data.getInquiryData()) ) {
			
			if (data == null) {
				data = new InquiryVO();
			}
			
			data.setProcessStatus(CommonCode.INQUIRY_STATE_INTENT_SHORTWORD_ERR);
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:[false], 질의어의 정보가 없어서 전처리 수행하지 않음.");
			
			return false;
		}
		else {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:[true], 전처리 수행함.");
			return true;
		}
	}
	
	/**
	 * 실행 권한 검사
	 * @param data
	 * @return
	 */
	protected boolean hasActionRight(InquiryVO data) {
		return true;
	}
	
	/**
	 * Legacy system 또는 Redis 등에 질의 처리
	 * @param data
	 * @return
	 */
	protected String processor(InquiryVO data) {
		return "PreIntentDialog";
	}
	
	/**
	 * processor 처리 후 응답 메세지 생성 등 처리
	 * @param data
	 * @param proxyResponseJsonData
	 * @return
	 */
	protected Activity afterWork(InquiryVO inquiryData, String proxyResponseJsonData) {
		
		Activity resultActivity = null;
		Attachment attachment = null;
		int resultCount = 0, userCount = 0, groupCount = 0, contextCount = 0;
		Map<String, Object> mapData = null;
		String intentInquiry = null;
		boolean isUserListEmpty = true , isGroupListEmpty = true, isIntentMongoListEmpty = true, isPhoneNumberSearch = false;
		
		//통합 검색 URL 정보를 Properties 에서 읽어온다.
		String userProfileUrl = this.dialogConfig.getDialogInfo(inquiryData.getTenantId(), "url", "userProfileImage");
		String searchUserProfileId = this.dialogConfig.getDialogInfo(inquiryData.getTenantId(), "intentId", "searchUserProfile");
		
		try {
			
			String inquiryText = inquiryData.getInquiryData();
			//질의문 특수 문자, 공백 제거
			if ( !StringUtils.isEmpty(inquiryText) ) {
				String match = "[^a-zA-Z0-9가-힣\\-/]";
				inquiryText = inquiryText.replaceAll(match, "");
			}
			
			//특수문자를 제거한 질의어가 비어 있을 경우 null 리턴
			if ( StringUtils.isEmpty(inquiryText) ) {
				return null;
			}
			
			resultActivity = Activity.createBotMessage(inquiryData.getBotId(), inquiryData.getReqUserId());
			resultActivity.setSubtype(CommonCode.SUBTYPE_PREINTENT);
			
			attachment = ( attachment == null ) ? new Attachment() : attachment;
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        //TODO 임시 --> 임직원, 부서 검색 시 "000 전화번호, 000 전화 등 전화번호, 전화로 끝나는 검색어는 전화번호, 전화를 제거한 뒤 검색"
	        //NLU 에서 개체명 식별 기능이 충분히 작동하면 제거함
	        String tempUserGroupText = null;
	        
	        if ( inquiryText.endsWith("전화번호") ) {
	        	tempUserGroupText = inquiryText.substring(0, inquiryText.length()-4);
	        	tempUserGroupText = tempUserGroupText.trim();
	        }
	        else if ( inquiryText.endsWith("연락처") ) {
	        	tempUserGroupText = inquiryText.substring(0, inquiryText.length()-3);
	        	tempUserGroupText = tempUserGroupText.trim();
	        }
	        else if ( inquiryText.endsWith("전화") ) {
	        	tempUserGroupText = inquiryText.substring(0, inquiryText.length()-2);
	        	tempUserGroupText = tempUserGroupText.trim();
	        }
	        else {
	        	// 숫자로만 이루어졌을 경우 전화번호 구분자 "-" 처리함
	        	// 아닐 경우 입력값 그대로 조회함
	        	String phoneNumberText = StringUtils.getPhoneNumberPattern(inquiryText);
	        	
	        	if ( phoneNumberText != null ) {
	        		isPhoneNumberSearch = true;
	        		tempUserGroupText = phoneNumberText;
	        	}
	        	else {
	        		//전화번호 Pattern 인지 검사
	        		isPhoneNumberSearch = StringUtils.isPhonePattern(inquiryText);
	        		tempUserGroupText = inquiryText;
	        	}
	        }
	        //TODO 임시 종료
	        
			//질의어로 임직원 정보 통합검색
	        Map<String, String> options = new HashMap<String, String>();
	        //&prefixQuery=<ALIAS:employee> <CORP_CODE:
	        options.put("prefixQuery", "<ALIAS:employee> <CORP_CODE:" +inquiryData.getCompanyCode()+ ">");
	        options.put("listCount", "999");
	        
	        //List<Map<String, Object>> userList = this.searchService.search(inquiryData.getTenantId(), inquiryText, "user", options);
	        List<Map<String, Object>> userList = ( StringUtils.isEmpty(tempUserGroupText) ) ? null : this.searchService.search(inquiryData.getTenantId(), tempUserGroupText, "user", options);
	        isUserListEmpty = ( (userList == null) || (userList.isEmpty()) ) ? true : false; 
	        
	        //질의어로 부서정보 조회, 부서 정보는 조회 조건에 따라서 조회함
	        //List<Group> groupList = (this.isSearchGroup(inquiryText)) ? this.groupService.selectGroupName(inquiryText) : null;
	        List<Group> groupList = (this.isSearchGroup(tempUserGroupText)) ? this.groupService.selectGroupName(tempUserGroupText) : null;
	        isGroupListEmpty = ( (groupList == null) || (groupList.isEmpty()) ) ? true : false;
	        
	        //질의어로 Intent Context 정보 검색
			List<IntentMongo> intentMongoList = intentService.findByContext(inquiryData.getBotId(), inquiryText.toLowerCase(), false);
			isIntentMongoListEmpty = ( (intentMongoList == null) || (intentMongoList.isEmpty()) ) ? true : false;
			
			
			// 임직원 정보 처리
			// 임직원 정보만 1건이 검색 된 경우에는 임직원 Profile을 보여준다.
			if ( (userList != null) && (!userList.isEmpty()) ) {
				
				/* 통합 검색
					"userId" 	: "EMP_ID",
					"userName" 	: "EMP_NM",
					"leader"    : "LEADER",
					"jobTitleName" : "JOB_TITLE_NAME",
					"groupName" : "GROUP_NAME",
					"groupFullName" : "GROUP_ALL_NAME",
					"groupId" 	: "GROUP_ID",
					"officePhoneNo" : "OFFICE_PHONE_NO",
					"mail"		: "MAIL",
					"mobile" 	: "MOBILE",
					"corpCode"  : "CORP_CODE",
					"empType"   : "EMP_TYPE",     	//계정 구분 I : 정직원, O : 협력사, P : 공용계정, E : 자회사
					"corpType"  : "CORP_TYPE_CODE",	//법인 타입 구분 코드 H:본사 , C:해외법인, I : 자회사
					"jobTitleEnglishName" : "JOB_TITLE_ENGLISH_NAME"
				*/
				
				String groupName = null,  userName = null, mail = null, jobTitleName = null, id = null, jobTitleEnglishName = null;
				String fullPathName = null, groupId = null, mobile = null, corpCode = null, leader = null, officePhoneNo = null;
				String empType = null, corpType = null, nameTemp = null, empTypeTemp = null;
				
				StringBuffer titleBuf = null, actionBuf = null, descriptionBuf = null ;
				
				Map<String, String> checkDupMap = new HashMap<String, String>();
				String dupKey = null;
				
				for ( Map<String, Object> userMap : userList ) {
					if ( userMap == null) {
						continue;
					}
					
					nameTemp =  ( (userMap.get("userName") != null) ) ? String.valueOf(userMap.get("userName")) : "";
					empTypeTemp =  ( (userMap.get("empType") != null) ) ? String.valueOf(userMap.get("empType")) : "";
					mobile = ( (userMap.get("mobile") != null) ) ? String.valueOf(userMap.get("mobile")) : "";
					officePhoneNo = ( (userMap.get("officePhoneNo") != null) ) ? String.valueOf(userMap.get("officePhoneNo")) : "";
					
					if ( StringUtils.isEmpty(nameTemp) ) {
						continue;
					}
					
					//전화 번호 검색인 경우 모든 데이터를 처리함
					if ( !isPhoneNumberSearch ) {
						
						// 사용자, 공용계정의 경우 검색어 전체가 일치한 경우만 처리함
						// 2017.12.04 강유경 차장 요청
						if ( !nameTemp.trim().equals(inquiryText) && !nameTemp.equals(tempUserGroupText) ) {
							continue;
						}
						
						/*//공용 계정이 아닐 경우 이름 전체가 검색어와 일치한 경우 처리함
						if (!"P".equalsIgnoreCase(empTypeTemp)) {
							//if ( !(nameTemp.trim().equals(inquiryText) || nameTemp.equals(tempUserGroupText)) && !this.isContainPhoneNumber(inquiryText, mobile, officePhoneNo) ) {
							if ( !nameTemp.trim().equals(inquiryText) && !nameTemp.equals(tempUserGroupText) ) {
								continue;
							}
						}
						//공용 계정의 경우 이름 일부가 검색어와 일치한 경우 처리함
						else {
							String nameTempUpper = nameTemp.toUpperCase();
							String inquiryTextUpper = inquiryText.toUpperCase();
							String inquiryDateUpper = inquiryData.getInquiryData().toLowerCase();
							
							if ( (nameTempUpper.indexOf(inquiryTextUpper) < 0) && (nameTempUpper.indexOf(inquiryDateUpper) < 0) ) {
								continue;
							}
						}*/
					}
					
					//통합검색 정보
					id = ( (userMap.get("userId") != null) ) ? String.valueOf(userMap.get("userId")) : "";
					jobTitleName  = ( (userMap.get("jobTitleName") != null) ) ? String.valueOf(userMap.get("jobTitleName")) : "";
					jobTitleEnglishName = ( (userMap.get("jobTitleEnglishName") != null) ) ? String.valueOf(userMap.get("jobTitleEnglishName")) : "";
					mail = ( (userMap.get("mail") != null) ) ? String.valueOf(userMap.get("mail")) : "";
					userName = ( (userMap.get("userName") != null) ) ? String.valueOf(userMap.get("userName")) : "";
					
					groupName = ( (userMap.get("groupName") != null) ) ? String.valueOf(userMap.get("groupName")) : "";
					groupId = ( (userMap.get("groupId") != null) ) ? String.valueOf(userMap.get("groupId")) : "";
					fullPathName = ( (userMap.get("groupFullName") != null) ) ? String.valueOf(userMap.get("groupFullName")) : "";
					//mobile = ( (userMap.get("mobile") != null) ) ? String.valueOf(userMap.get("mobile")) : "";
					leader = ( (userMap.get("leader") != null) ) ? String.valueOf(userMap.get("leader")) : "";
					
					corpCode = ( (userMap.get("corpCode") != null) ) ? String.valueOf(userMap.get("corpCode")) : inquiryData.getCompanyCode();
					//officePhoneNo = ( (userMap.get("officePhoneNo") != null) ) ? String.valueOf(userMap.get("officePhoneNo")) : "";
					empType = ( (userMap.get("empType") != null) ) ? String.valueOf(userMap.get("empType")) : "";
					corpType = ( (userMap.get("corpType") != null) ) ? String.valueOf(userMap.get("corpType")) : "";
					
					//중복 검사
					dupKey = id+groupId+corpCode;
					if (checkDupMap.isEmpty()) {
						checkDupMap.put(dupKey, dupKey);
					}
					else {
						//중복일 경우 Element 로 추가하지 않음
						if (checkDupMap.get(dupKey) != null) {
							continue;
						}
						//중복이 아닐 경우
						else {
							checkDupMap.put(dupKey, dupKey);
						}
					}
					
					//title
					titleBuf = new StringBuffer("");			
    				if ( !StringUtils.isEmpty(userName) ) {
    					titleBuf.append(userName);
    				}
					
					if ( !StringUtils.isEmpty(jobTitleName) ) {
						if ( !StringUtils.isEmpty(userName) ) {
							titleBuf.append(" ");
						}
						
						titleBuf.append(jobTitleName);
					}
					
					//description
					descriptionBuf = new StringBuffer();
					if ( !StringUtils.isEmpty(mail)  ) {
						descriptionBuf.append(mail);
    				}
					
					if ( !StringUtils.isEmpty(mobile) ) {
    					if ( !StringUtils.isEmpty(mail) ) {
    						descriptionBuf.append(" | ");
    					}
    					
    					descriptionBuf.append(mobile);
    				}
					
					//Action
    				actionBuf = new StringBuffer("");
    				if ( !StringUtils.isEmpty(groupName)  ) {
    					actionBuf.append(groupName);
    				}
    				
    				if ( !StringUtils.isEmpty(userName) ) {
    					if ( !StringUtils.isEmpty(groupName) ) {
    						actionBuf.append(" ");
    					}
    					
    					actionBuf.append(userName);
    				}
    				
    				if ( !StringUtils.isEmpty(jobTitleName) ) {
    					if ( !StringUtils.isEmpty(userName) ) {
    						actionBuf.append(" ");
    					}
    					
    					actionBuf.append(jobTitleName);
    				}
    				
    				// additionalProperties 설정
                    Map<String, Object> additionalProperties = new HashMap<String, Object>();
                    additionalProperties.put("userName", userName);
                    additionalProperties.put("jobTitleName", jobTitleName);
                    additionalProperties.put("jobTitleEnglishName", jobTitleEnglishName);
                    additionalProperties.put("jobDutyName", jobTitleEnglishName);
                    additionalProperties.put("groupId", groupId);
                    additionalProperties.put("groupName", groupName);
                    additionalProperties.put("fullPathName", fullPathName);
                    additionalProperties.put("mobile", mobile);
                    additionalProperties.put("officePhoneNo", officePhoneNo);
                    additionalProperties.put("mail", mail);
                    additionalProperties.put("empType", empType);
                    additionalProperties.put("corpType", corpType);
                    additionalProperties.put("corpCode", corpCode);
                    additionalProperties.put("leader", leader);
                    
                    
					Element element = new Element();
    				element.setId(id);
    				element.setTitle(titleBuf.toString());
    				
    				if (inquiryData.getCompanyCode().equalsIgnoreCase(corpCode) && ("I".equalsIgnoreCase(empType) || "P".equalsIgnoreCase(empType))) {
    					element.setText(fullPathName);
    				}
    				else if (!inquiryData.getCompanyCode().equalsIgnoreCase(corpCode)) {
    					element.setText(fullPathName);
    				}
    				else {
    					element.setText(groupName);
    				}
    				element.setAction(actionBuf.toString());
    				element.setActionType(ActivityCode.ACTION_TYPE_INQUIRY);
    				element.setAdditionalProperties(additionalProperties);
    				
    				if ( !StringUtils.isEmpty(descriptionBuf) ) {
    					element.setDescriptions(descriptionBuf.toString());
    				}
    				
    				if ( !StringUtils.isEmpty(userProfileUrl) ) {
    					element.setImageUrl(String.format(userProfileUrl, corpCode, id));
    				}
				
    				// Entity Json용 Map Data
    				mapData = new HashMap<String, Object>();
    				mapData.put("name", userName);
    				mapData.put("title", jobTitleName);
    				mapData.put("groupFullName", fullPathName);
    				mapData.put("groupName", groupName);
    				mapData.put("id", id);
    				mapData.put("mobile", mobile);
    				mapData.put("corpCode", corpCode);
    				mapData.put("userType", empType);
    				mapData.put("userType", empType);
    				mapData.put("leader", leader);
    				mapData.put("mail", mail);
    				mapData.put("officePhoneNo", officePhoneNo);
                    
    				// additionalProperties 설정
                    Map<String, Object> actionParams = new HashMap<String, Object>();
                    actionParams.put("inquiryType", CommonCode.INQUIRY_TYPE_AUTO_SUGGFEST);
                    actionParams.put("intentId", searchUserProfileId);
                    actionParams.put("P_", JsonUtil.toJson(mapData));
					
                    //의도분석 정보 설정
    				element.setActionParams(actionParams);
    				
    				element.setType(CommonCode.ELEMENT_TYPE_PEOPLE);
    				element.setCorpCode(inquiryData.getCompanyCode());
    				attachment.addElement(element);
    				
    				resultCount++;
    				userCount++;
				}//for
				
				//결과 중 중복 사용자를 제외한 사용자 1명만 검색 되었을 경우 User Profile로 처리함
				if ( (resultCount == 1) && isGroupListEmpty && isIntentMongoListEmpty ) {
					attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_USRE_PROFILE);
				}
			}
			
			//부서 정보 처리
			if ( !isGroupListEmpty ) {
				String groupId = null;
	        	StringBuffer descriptions = new StringBuffer();
	        	String groupName = null, groupAllName = null, userName = null, jobTitle = null, officePhoneNo = null, mobile = null;
	        	
	        	//부서 Blog Url 정보를 Properties 에서 읽어온다. 
	        	String groupBlogUrl = this.dialogConfig.getDialogInfo(inquiryData.getTenantId(), "url", "groupBlog");
	        	
	        	// 부서 항목 처리
	        	for ( Group group : groupList) {
	        		
	        		descriptions.setLength(0);
	        		
	        		if ( group != null ) {
	        			
	        			groupName = ( !StringUtils.isEmpty(group.getGroupName()) ) ? group.getGroupName() : "";
	        			groupAllName = ( !StringUtils.isEmpty(group.getFullPath()) ) ? group.getFullPath() : "";
	        			groupId = ( !StringUtils.isEmpty(group.getGroupId()) ) ? group.getGroupId() : "";
	        			
	        			userName = ( !StringUtils.isEmpty(group.getLeaderName()) ) ? group.getLeaderName() : "";
	        			jobTitle = ( !StringUtils.isEmpty(group.getLeaderJobTitleName()) ) ? group.getLeaderJobTitleName() : "";
	        			officePhoneNo = ( !StringUtils.isEmpty(group.getLeaderOfficePhoneNo()) ) ? group.getLeaderOfficePhoneNo() : "";
	        			mobile = ( !StringUtils.isEmpty(group.getLeaderMobile()) ) ? group.getLeaderMobile() : "";
	        			
	        			if ( !StringUtils.isEmpty(userName) ) {
	        				descriptions.append("Leader : ");
	                        descriptions.append(userName);
	                    }
	        			
	        			if ( !StringUtils.isEmpty(jobTitle) ) {
	        				if ( !StringUtils.isEmpty(userName) ) {
	        					descriptions.append(" ");
	        				}
	                        descriptions.append(jobTitle);
	                    }
	        			
	        			if ( !StringUtils.isEmpty(officePhoneNo) ) {
	        				if ( !StringUtils.isEmpty(userName) ) {
	        					descriptions.append(" | ");
	        				}
	                        descriptions.append(officePhoneNo);
	                    }
	        			
	        			if ( !StringUtils.isEmpty(mobile) ) {
	        				if ( !StringUtils.isEmpty(officePhoneNo) ) {
	        					descriptions.append(" / ");
	        				}
	                        descriptions.append(mobile);
	                    }
	        			
	        			Element element = new Element();
	        			element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	        			element.setTitle(groupName);
	        			element.setText(groupAllName);
	        			element.setDescriptions(descriptions.toString());
	        			
	        			if ( !StringUtils.isEmpty(groupBlogUrl) && !StringUtils.isEmpty(groupId) ) {
		        			element.setAction(String.format(groupBlogUrl, groupId));
		        			element.setActionType(ActivityCode.ACTION_TYPE_LINK);
	        			}
	        			
	        			attachment.addElement(element);
	        			
	        			resultCount++;
	        			groupCount++;
	        		}
	        	}
			}
			
			//Intent Context 정보 처리
			if ( !isIntentMongoListEmpty ) {
				
	            String text = null, action = null;
	            
				for ( IntentMongo intentMongo : intentMongoList ) {
					if (intentMongo != null) {
						
						text = intentMongo.getUtterance().getText();
						action = intentMongo.getUtterance().getText();
						
						Element element = new Element();
						element.setType(CommonCode.ELEMENT_TYPE_TEXT);
						element.setTitle(text);
	    				element.setAction(action);
	    				element.setActionType(ActivityCode.ACTION_TYPE_INQUIRY);
	    				element.setCorpCode(inquiryData.getCompanyCode());
	    				attachment.addElement(element);
						
	    				resultCount++;
	    				contextCount++;
	    				
	    				if ( !StringUtils.isEmpty(text) ) {
	    					intentInquiry = text.toLowerCase();
	    				}
					}
				}//for
			}
			
		} catch (Exception e) {
			 e.printStackTrace();
			 LOG.info("inquiryId:["+inquiryData.getInquiryId()+"],질의어:["+inquiryData.getInquiryData()+"], 전처리 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
				
			//오류가 발생환 경우
			resultActivity = null;
		}
		
		//결과가 없고 질의어 형식이 전화번호 형식이 아니면 null return
		if (resultCount > 0)  {
			StringBuffer messageBuf = new StringBuffer();
			messageBuf.append(inquiryData.getInquiryData()).append(" 관련하여 ");
			
			if ( userCount == resultCount ) {//사용자 정보만 조회 되었는가?
				
				messageBuf.append(String.format(this.botService.getBotMessage(inquiryData.getBotId(), BotCode.BOT_MESSAGE_TYPE_MULTI_USER), resultCount));
				
				// 사용자만 1명 조회 되었을 경우 일정 조회버튼
				// 사용자만 1 또는 N명 조회되었을 경우 그룹사 인원 검색 버튼을 추가
				if ( mapData != null ) {
					if ( userCount == 1 ) {
						
						String userName = (mapData.get("name") != null) ? String.valueOf(mapData.get("name")) : "";
						String jobTitleName = (mapData.get("title") != null) ? String.valueOf(mapData.get("title")) : "";
						//String groupName = mapData.get("groupName", groupName);
						//String id = mapData.get("id", id);
						//String corpCode = mapData.get("corpCode", corpCode);
	    				
						StringBuffer actionBuf = new StringBuffer(userName);
						if ( !StringUtils.isEmpty(jobTitleName) ) {
							actionBuf.append(" ").append(jobTitleName).append(" 일정조회");
						}
						else {
							actionBuf.append(" 일정조회");
						}
						
						StringBuffer titleBuf = new StringBuffer(userName);
						titleBuf.append(" 일정조회");
						
						//일정 조회 버튼 추가
						Button eventInruiryButton = new Button();
						eventInruiryButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);
						eventInruiryButton.setAction(actionBuf.toString());
						eventInruiryButton.setTitle(titleBuf.toString());
						
						resultActivity.addButton(eventInruiryButton);
						
					}
					
					/*String totalSearchUrlEncoded = null;
					
					try {
						//통합 검색 URL 정보를 Properties 에서 읽어온다.
						String searchUrl = this.dialogConfig.getDialogInfo(tenantId, "url", "totalSearch");
					
						StringBuffer url = new StringBuffer(this.totalSearchUrl).append(TOTAL_SEARCH_GROUP_TAB);
						String searchUrl = String.format(url.toString(), inquiryData);
						UriComponents uriComponent = UriComponentsBuilder.fromHttpUrl(searchUrl).build().encode("UTF-8");
						totalSearchUrlEncoded = uriComponent.toUriString();
					} catch (UnsupportedEncodingException e) {
						totalSearchUrlEncoded = null;
					}
					
					// 그룹사 통합 검색 URL이 있으면 버튼 추가
					if ( totalSearchUrlEncoded != null ) {
						Button searchButton = new Button();
						searchButton.setType(CommonCode.INTENT_BUTTON_TYPE_LINK);
						searchButton.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
						searchButton.setAction(totalSearchUrlEncoded);
						searchButton.setTitle("그룹사 인원 검색");
						
						resultActivity.addButton(searchButton);
					}*/
					
					// 그룹사 통합 검색 URL이 있으면 버튼 추가
					resultActivity.addButton(this.commonResponeService.makeSearchInGroupButton(inquiryData.getInquiryData(), inquiryData.getTenantId()));
				}//if 사용자 조회 결과가 있으면
			}
			else {
				messageBuf.append(String.format(this.botService.getBotMessage(inquiryData.getBotId(), BotCode.BOT_MESSAGE_TYPE_MULTI_RESULT), resultCount));
			}
			
			resultActivity.addAttachment(attachment);
			
			//Context 정보가 1건만 조회 되었을 경우 의도분석 실행 메세지 리턴
			if ( (contextCount == 1) && (resultCount == 1) ) {
				
				resultActivity.setDialogLog(CommonCode.PREINQUERY_INTENT_ONLYONE);
				resultActivity.setMessage(intentInquiry);
			}
			else {
				resultActivity.setMessage(messageBuf.toString());
			}
		}
		else {
			
			//질의어가 전화번호 형식이고 조회 결과가 없으면
			//전화번호 끝 4자리로 조회가능하다는 안내메세지 반환
			if ( isPhoneNumberSearch || StringUtils.isNumericPattern(inquiryData.getInquiryData()) ) {
				resultActivity = this.commonResponeService.cannotUnderstandPhoneType(inquiryData);
				resultActivity.setSubtype(CommonCode.SUBTYPE_PREINTENT);
			}
			//조회 결과가 없으면 null 반환
			else {
				resultActivity = null;
			}
		}
		
		return resultActivity;
	}
	
	/**
	 * 부서 검색 대상여부 결정
	 * @param inquiryText
	 * @return
	 */
	private boolean isSearchGroup (String inquiryText) {
		
		if ( StringUtils.isEmpty(inquiryText) ) {
			return false;
		}
		
		int length = GROUP_SEARCH_CONDITION.length;
		for ( int i = 0; i < length; i++) {
			if ( inquiryText.endsWith(GROUP_SEARCH_CONDITION[i]) ) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * 전화번호, 핸드폰 번호가 일부 일치 하는지 여부 검사
	 * @param data
	 * @param mobile
	 * @param officePhoneNo
	 * @return
	 */
	private boolean isContainPhoneNumber ( String data, String mobile, String officePhoneNo ) {
		
		if ( StringUtils.isEmpty(data) || (StringUtils.isEmpty(mobile) && StringUtils.isEmpty(officePhoneNo)) ) {
			return false;
		}
		
		// 전화번호 가 일부 일치인 경우 true 반환
		if ( mobile.contains(data) || officePhoneNo.contains(data) ) {
			return true;
		}
		else {
			//검색어 중 숫자만 대상으로 일부 일치하는 경우 true 반환
			String dataTmp = StringUtils.removeNotNumeric(data);
			
			if ( StringUtils.isEmpty(dataTmp) ) {
				return false;
			}
			
			String mobileTmp = StringUtils.removeNotNumeric(mobile);
			
			if ( !StringUtils.isEmpty(mobileTmp) && mobileTmp.contains(data) ) {
				return true;
			}
			
			String officePhoneNoTmp = StringUtils.removeNotNumeric(officePhoneNo);
			
			if ( !StringUtils.isEmpty(officePhoneNoTmp) && officePhoneNoTmp.contains(data) ) {
				return true;
			}
		}
		
		return false;
	}
	
}
