/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentRestCall.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.intent.exception.IntentException;
import com.lgcns.vpa.intent.service.IntentRestService;
import com.lgcns.vpa.intent.service.IntentReasonResult;
import com.lgcns.vpa.intent.service.ReasonData;

/**
 * R&D 의도 추론 서비스 호출 Bean
 * TODO 서비스 URI는 tenant / bot id에 설정된값을 참조하도록 수정
 * @author 70399
 *
 */
@Component
public class IntentRestServiceImpl implements IntentRestService {
	private static final Logger LOG = LoggerFactory.getLogger(IntentRestService.class);
	
	@Autowired
	Environment environment;
	
	@Autowired
	BotService botService;
	
    @Resource(name="nluService")
    RestTemplate nluService;
	
    /**
     * 사용자 질의문에 대한 R&D 의도추론 결과를 반환
     */
    @Override
	public IntentReasonResult reason(Bot bot, String sentence) {
    	IntentRequest request = new IntentRequest();
    	request.setSentence(sentence);//preProcess(sentence));
    	IntentReasonResult result = null;
    	try {
	    	result = call(bot, "/intent/inference", request);
	    	LOG.info("sentence {} : inference : {}", sentence, result);
	    	if( !result.getResult() ) {
	    		throw new IntentException(IntentException.ERROR_NLU_CALL);
	    	}
	    
    	}catch(Throwable e) {
    		botService.fail(bot);
    		throw e;
    	}
    	botService.success(bot);
        return result;
    }
    /**
	 * 대문자--> 소문자, 특수문자, 공백 치환
	 * @param input
	 * @return
	 */
	private String preProcess(String input) {
		input = input.replaceAll("\\\"|\\'|\\^|\\*|\\+|\\?|!|\\.|\\,|\\}|\\{|\\(|\\)|\\$", "");
		input = input.replaceAll("\\s+", " ");
		return input.toLowerCase();
	}
    private IntentReasonResult call(Bot bot, String path, IntentRequest dapRequest) {
    	
    	dapRequest.setBotId(bot.getDapBotId());
    	
    	String tenantId = DataSourceKeyHolder.getDataSourceKey();
    	
    	dapRequest.setUserId(environment.getProperty("dap.user." + tenantId, "1000035"));
    	
    	URI uri = URI.create(bot.getDapNluService() + path);
    	try {
    		return nluService.postForObject(uri, dapRequest, IntentReasonResult.class);
    	}catch(HttpClientErrorException e) {
    		HttpStatus status = e.getStatusCode();
    		switch(status) {
    		case REQUEST_TIMEOUT : 
    		case NOT_FOUND :
    			throw new IntentException(IntentException.ERROR_NLU_CALL, e.getLocalizedMessage());
			default :
				throw new IntentException(IntentException.ERROR_NLU_SERVER, e.getLocalizedMessage());
    		}
    	}catch(Throwable e) {
    		e.printStackTrace();
			throw new IntentException(IntentException.ERROR_NLU_SERVER, e.getLocalizedMessage());
    	}
    }
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public class IntentRequest {
    	private String userId;
    	private String botId;
    	
    	private String sentence;
    	
    	public IntentRequest() {
    	}

    	public IntentRequest(String userId, String botId) {
    		this.userId = userId;
    		this.botId = botId;
    	}

    	public String getUserId() {
    		return userId;
    	}

    	public void setUserId(String userId) {
    		this.userId = userId;
    	}

    	public String getBotId() {
    		return botId;
    	}

    	public void setBotId(String botId) {
    		this.botId = botId;
    	}

    	public String getSentence() {
    		return this.sentence;
    	}
    	
    	public void setSentence(String sentence) {
    		this.sentence = sentence;
    	}
    }
    /**
     * TODO tenantid와 botid로 호출할 추론 URI를 조회함
     * @return
     */
/*    private String getBaseUri(String botId) {
    	     
    	if( "120000080013".equals(botId) ) {
    		return "http://27.122.226.179:8000/";
    	} else {//LGE HR : 
    		return "http://27.122.226.179:8002/";
    	}
    }

    @Override
	public IntentReasonResult reason(String botId, String sentence) {
    	
    	Map<String, Object> param = new HashMap<String, Object>();
    	param.put("sentence", sentence);
    	IntentReasonResult intentResult = null;
        try {
        	ResponseEntity<IntentReasonResult> response = nluService.exchange(
        			buildURI(botId, "inference", param), 
        			HttpMethod.GET, 
        			null, 
        			new ParameterizedTypeReference<IntentReasonResult>() {});
        	
        	intentResult = response.getBody();
        	if( !intentResult.getResult()) {
	    		throw new IntentException("추론 실패");
	    	}
        }catch(UnsupportedEncodingException e) {
        	LOG.error(e.getMessage());
        	throw new IntentException(e.getMessage());
        }
        
        return intentResult;
    }
    
    private URI buildURI(String botId, String path, Map<String, Object> param) throws UnsupportedEncodingException {
    	LOG.info(String.format("***BotId : %s intent Url : %s", botId, getBaseUri(botId)));
    	UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(getBaseUri(botId))
			    	.path(path);
		
    	if( param != null ) {
			for(Map.Entry<String, Object> e: param.entrySet()){
				uriBuilder = uriBuilder.queryParam(e.getKey(), e.getValue());
			}
    	}
		return uriBuilder.build().encode("UTF-8").toUri();
    }*/

}
