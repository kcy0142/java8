/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SiSalesDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * System Menu조회 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 10. 18.
 */
@Component("SystemMenuDialog")
public class SystemMenuDialog extends LogicDialog {

	private static final Logger LOG = LoggerFactory.getLogger(SystemMenuDialog.class);
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private BotService botService;
	
	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet =  null;
			
			TransferSyncVO responseVO =  new  TransferSyncVO();
			ObjectMapper mapper = new ObjectMapper();
			responseVO =  mapper.readValue(proxyResponseJsonData, TransferSyncVO.class);
			
			if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
				proxyResultSet = responseVO.getActionResult();
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
					//Proxy에서 조회된 결과(JsonData)에서 Attachment 를 구함
					attachments = this.getAttachment(data, proxyResultSet);
					
					if ( (attachments != null) && (!attachments.isEmpty()) ) {
						
						StringBuffer activityMessage = new StringBuffer(); 
						
			        	Map<String, Object> intentParam = data.getIntentParam();
			        	if ( intentParam != null ) {
			        		String searchMenu = (intentParam.get("searchMenu") != null) ? String.valueOf(intentParam.get("searchMenu")) : "";
			        		activityMessage.append( searchMenu.toUpperCase() );
			        		
				        	if ( attachments.get(0) != null ) {
								Attachment attachment = attachments.get(0);
								List<Element> elements = attachment.getElements();
								
								//Activity Result Message  변경
								//TODO  향 후 의도분석에서 메세지 출력 시 대체함
								if ( (elements != null) && (elements.size() > 1)) {
									activityMessage.append(" 시스템 메뉴 ");
									activityMessage.append(String.format(this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_MULTI_RESULT), elements.size()));
								}
								else {
									activityMessage.append(" 시스템 메뉴를 조회한 결과입니다.");
								}
							}
				        	else {
				        		activityMessage.append(" 시스템 메뉴를 조회한 결과입니다.");
				        	}
			        	}
			        	
			        	resultActivity.setMessage(activityMessage.toString());
						resultActivity.setAttachments(attachments);
						
					}
					else {
						LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
						
						//Data 가 없음
			        	resultActivity = this.commonResponeService.simpleResponseMessage(
								data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
								this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
					}
					
					//의도분석의 Button이 있는 경우 처리
					if ( data.getIntentButtons() != null ) {
						List<RelatedButton> buttons = data.getIntentButtons();
						List<Button> activityButtonList = super.makeActivityButtonList(buttons);
						
						if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
							resultActivity.setButtons(activityButtonList);
						}
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	@Override
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        // System Menu가 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("조회된 System Menu가 없습니다.");
	            
	        }
	        // System Menu가 존재하는 경우    
	        else {
	        	
	        	String title = null;
	        	String setDescriptions = null;
	        	String action = null;
	        	String popupSize = null;
	        	String [] popupSizeArray = null;
	        	int popupWidth = 0, popupHeight = 0;
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
	    				title = (proxyResult.get("MENU_NM") != null) ? proxyResult.get("MENU_NM").toString() : "";
	    				title = ( StringUtils.isEmpty(title) && (proxyResult.get("SYSTEM_NM") != null) ) ? proxyResult.get("SYSTEM_NM").toString() : title;
	    				
	    				setDescriptions = (proxyResult.get("NAME") != null) ? proxyResult.get("NAME").toString() : "";
	    				action = (proxyResult.get("SYSTEM_URL") != null) ? proxyResult.get("SYSTEM_URL").toString() : "";
	    				popupSize = (proxyResult.get("POPUP_SIZE") != null) ? proxyResult.get("POPUP_SIZE").toString() : "1075x740";
	    				
	    				popupSizeArray = popupSize.split("x");
	    				if ( (popupSizeArray != null) && (popupSizeArray.length == 2) ) {
	    					
	    					if ( !StringUtils.isEmpty(popupSizeArray[0]) && !StringUtils.isEmpty(popupSizeArray[1]) ) {
	    						try {
		    						popupWidth = Integer.parseInt(popupSizeArray[0].trim());
		    						popupHeight = Integer.parseInt(popupSizeArray[1].trim());
	    						} catch (Exception e) {
	    							popupWidth = 1075; 
		    						popupHeight = 740;
	    						}
	    					}
	    					else {
	    						popupWidth = 1075; 
	    						popupHeight = 740;
	    					}
	    				}
	    				
	    				Element element = new Element();
	    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	    				element.setTitle(title);
	    				element.setDescriptions(setDescriptions);
	    				element.setAction(action);
	    				element.setActionType(ActivityCode.ACTION_TYPE_LINK);
	    				element.setPopupWidth(popupWidth);
	    				element.setPopupHeight(popupHeight);
	    				
	    				attachment.addElement(element);
	        		}
	        	}//for
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}

}
