/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : RedisDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.service.dialog;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.security.user.service.UserRoleService;

/**
 * <PRE>
 * Redis에 Load된 정보를 조회하는 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Component("RedisDialog")
public class RedisDialog extends VpaDialog {

	private static final Logger LOG = LoggerFactory.getLogger(RedisDialog.class);
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Override
	protected boolean validator(InquiryVO data) {
		// TODO Auto-generated method stub
		return true;
	}
	
	@Override
	protected boolean hasActionRight(InquiryVO data) {
		boolean hasRight = false;
		
		if ( data.getReqUser() == null ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한을 검사할 Req User 정보가 없음");
			return false;
		}
		
		//인텐트별 사용자의 사용 권한 조회
		hasRight = this.userRoleService.validateUserRole(data.getReqUser(), data.getIntentId());
		
		if (!hasRight) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한 없음");
		}
		return hasRight;
	}

	@Override
	protected String processor(InquiryVO data) {
		
		//String result = nettyPoolClientService.sendToBnp(data);
		
		return "RedisDialog";
		//return result;
	}

	@Override
	protected Activity afterWork(InquiryVO data, String procData) {
		// TODO Auto-generated method stub
		return null;
	}

}
