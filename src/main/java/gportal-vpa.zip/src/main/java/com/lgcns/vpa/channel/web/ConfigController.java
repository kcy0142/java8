package com.lgcns.vpa.channel.web;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.config.Config;
import com.lgcns.vpa.channel.service.ConfigService;

/**
 * <pre>
 * 설정 관리 Controller
 * </pre>
 * @author
 */
@RequestMapping(value = "/api/settings")
@CrossOrigin(value = "*")
@RestController
public class ConfigController extends BaseController {
    
    @Autowired
    private ConfigService configService;
    
    /**
     * 나의 설정정보 조회
     * @param principal
     * @return
     */
    @RequestMapping(value="/users/me", method= RequestMethod.GET)
    public ResponseEntity<?> retrieveUserSettings(Principal principal) {
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * 나의 설정정보 수정
     * @param userId
     * @param principal
     * @return
     */
    @RequestMapping(value="/users/me", method= RequestMethod.PUT)
    public ResponseEntity<?> updateUserSettings(Principal principal) {
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
    /**
     * 사용자 별 봇 설정 조회
     * @param botId
     * @return
     */
    @RequestMapping(value = "/bots/{botId}", method = RequestMethod.GET)
    public ResponseEntity<Config> retrieveBotSettings(@PathVariable String botId) {
        Config config = configService.retrieveBotConfig(botId, this.getUser());
        return new ResponseEntity<>(config, HttpStatus.OK);
    }

    /**
     * 사용자 별 봇 설정 수정
     * @param botId
     * @param config
     * @return
     */
    @RequestMapping(value = "/bots/{botId}", method = RequestMethod.PUT)
    public ResponseEntity<?> updateBotSettings(@PathVariable String botId, @RequestBody Config config) {
        configService.updateBotConfig(config, this.getUser());
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
