/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service;

import java.util.List;

import com.lgcns.vpa.channel.model.config.Config;
import com.lgcns.vpa.channel.model.config.LegacyConfig;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.model.config.PushConfigProperty;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 사용자 및 봇 설정 Service
 * </pre>
 * @author
 */
public interface ConfigService {

    /**
     * 사용자의 봇 설정 조회 (알림 설정 포함)
     * @param botId
     * @param user
     * @return
     */
    Config retrieveBotConfig(String botId, User user);

    /**
     * 사용자의 봇 설정 저장
     * @param config
     * @param user
     */
    void updateBotConfig(Config config, User user);
    
    /**
     * 사용자의 알림 설정 조회
     * @param botId
     * @param userId
     * @param pushTypeCode
     * @return
     */
    PushConfig retrievePushConfig(String pushId, String userId);
    
    
    /**
     * 사용자의 알림 설정(리스트) 조회
     * @param searchCondition
     * @param user
     * @return
     */
    List<PushConfig> retrievePushConfigList(PushConfig searchCondition, User user);
        
    /**
     * 봇 알림 설정 생성 필요 여부 확인
     * true 인 경우, 기본 설정 정보를 생성한다.
     * @param botId
     * @param userId
     * @return
     */
    public boolean isUserCreatePushConfig(String botId, String userId);
    
    /**
     * 봇 알림 미사용 여부
     * @param botId
     * @param userId
     * @param pushTypeCode
     * @return
     */
    boolean isUserNotUsedPushByPushTypeCode(String botId, String userId, String pushTypeCode);
    
    /**
     * 봇 알림 기본 설정 생성
     * @param botId
     * @param userId
     */
    public void createPushConfig(String botId, String userId);
    
    /**
     * 알림 상세 정보 조회
     * @param pushId
     * @param ip
     * @return
     */
    public PushConfig retrievePushDetail(String pushId, String ip);
    
    /**
     * 알림 사용자 목록 조회
     * @param params
     * @return
     */
    List<PushConfig>retrievePushConfigAllUserList(String pushId, String userId);
    
    /**
     * 알림 속성 사용자 목록 조회
     * @param params
     * @return
     */
    List<PushConfigProperty>retrievePushConfigPropertyAllUserList(String pushId, String userId, String propertyId);
    
    /**
     * 레가시 조회
     * @param botId
     * @param legacyCode
     * @param legacyTypeCode
     * @return
     */
    LegacyConfig retrieveLegacyConfig(String legacyCode, String legacyTypeCode);
    
    
    /**
     * 레가시 정보(리스트) 조회
     * @param legacyCode
     * @return
     */
    List<LegacyConfig> retrieveLegacyConfigList(String legacyCode);
}
