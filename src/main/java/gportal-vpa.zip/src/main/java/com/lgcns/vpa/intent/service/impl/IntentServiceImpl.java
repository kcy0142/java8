package com.lgcns.vpa.intent.service.impl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.unwind;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.limit;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.LimitOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.Recommand;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.framework.multidata.annotation.MultiDataSource;
import com.lgcns.vpa.intent.entity.EntityDictionary;
import com.lgcns.vpa.intent.entity.EntityDictionary.EntityContracts;
import com.lgcns.vpa.intent.entity.EntityDictionary.UserContracts;
import com.lgcns.vpa.intent.entity.ParameterMap;
import com.lgcns.vpa.intent.entity.ParameterMap.ParamValue;
import com.lgcns.vpa.intent.exception.DialogueInvalidException;
import com.lgcns.vpa.intent.exception.DuplicateEntityException;
import com.lgcns.vpa.intent.exception.EntityException;
import com.lgcns.vpa.intent.exception.IntentException;
import com.lgcns.vpa.intent.exception.MissingEntityException;
import com.lgcns.vpa.intent.model.Faq;
import com.lgcns.vpa.intent.model.Intent;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.intent.model.IntentAnalysisResult;
import com.lgcns.vpa.intent.model.IntentAnalysisResult.Status;
import com.lgcns.vpa.intent.model.IntentBase;
import com.lgcns.vpa.intent.model.IntentMongo;
import com.lgcns.vpa.intent.model.IntentMongo.Action;
import com.lgcns.vpa.intent.model.IntentMongo.IntentType;
import com.lgcns.vpa.intent.model.IntentMongo.Parameter;
import com.lgcns.vpa.intent.model.IntentSet;
import com.lgcns.vpa.intent.model.SimilarIntentSet;
import com.lgcns.vpa.intent.service.IntentRestService;
import com.lgcns.vpa.intent.service.IntentReasonResult;
import com.lgcns.vpa.intent.service.IntentService;
import com.lgcns.vpa.intent.service.ReasonData;
import com.lgcns.vpa.intent.service.Score;
import com.lgcns.vpa.intent.translator.MessageTranslator;
import com.lgcns.vpa.intent.util.JacksonUtils;
import com.lgcns.vpa.intent.util.MessageUtils;

import static com.lgcns.vpa.intent.entity.EntityDictionary.EntityContracts.ReservedEntity;

/**
 * 의도 추론 서비스
 * @author 최환준
 *
 */
@Service
public class IntentServiceImpl implements IntentService {
	
	private static final Logger LOG = LoggerFactory.getLogger(IntentServiceImpl.class);
		
	private static final String KEYWORD = "\\[([^\\]]+)\\]";
	
	private static final Pattern KEYWORD_PATTERN = Pattern.compile(KEYWORD);
	
	

	@Value("${intent.nlu.threshold}")
	private int NLU_THRESHOLD;
	/**
	 * 의도 정보 조회
	 */
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private IntentContext context;
	
	/**
	 * R&D 의도추론 Restful Service 호출 Bean
	 */
	@Autowired
	private IntentRestService intentRest;
	
	@Autowired
	private EntityDictionary dictionary; 
	
	@Autowired
	private BotService botService;
	
	@Autowired
	private MessageTranslator messageTranslator;
	
	/**
	 * mongodb에 저장된 의도 objectid로 intent조회
	 */
	@MultiDataSource
	@Override
	public IntentMongo getIntent(Object id) {
		Query query = new Query();
        query.addCriteria(Criteria.where("intentId").is(id));
        query.fields()
			.include("id")
			.include("intentId")
			.include("intentName")
			.include("intentType")
			.include("botId")
			.include("contexts")
			.include("autorun")
			.include("message")
			.include("parameters")
			.include("actions")
			.elemMatch("utterances", Criteria.where("isRepresentative").is(true));
		IntentMongo intent = mongoTemplate.findOne(query, IntentMongo.class);
		return intent;
	}
	
	/**
	 * R&D intentid로 intent조회
	 */
	@MultiDataSource
	@Override
	public IntentMongo findByIntentId(String intentId) {
		
		if( StringUtils.isEmpty(intentId) ) {
			return null;
		}
		
		Query query = new Query();
        query.addCriteria(Criteria.where("extIntentId").is(intentId));
		query.fields()
			.include("id")
			.include("intentId")
			.include("intentType")
			.include("intentName")
			.include("botId")
			.include("contexts")
			.include("message")
			.include("parameters")
			.include("actions")
			.elemMatch("utterances", Criteria.where("isRepresentative").is(true));
		return mongoTemplate.findOne(query, IntentMongo.class);
	}
	
	/**
	 * R&D intentid로 intent조회
	 */
	@MultiDataSource
	@Override
	public IntentMongo findByIntentId(String intentType, String intentId) {
		
		if( StringUtils.isEmpty(intentId) || StringUtils.isEmpty(intentType) ) {
			return null;
		}
		
		Query query = new Query();
		
		Criteria criteria = Criteria.where("extIntentId").is(intentId);
		if( intentType.equals("0")) {
			criteria.and("intentType").is(intentType);
		}
        query.addCriteria(criteria);//.and("intentType").is(intentType));
		query.fields()
			.include("id")
			.include("intentId")
			.include("intentType")
			.include("intentName")
			.include("botId")
			.include("contexts")
			.include("autorun")
			.include("message")
			.include("animation")
			.include("parameters")
			.include("actions");
//			.elemMatch("utterances", Criteria.where("isRepresentative").is(true));
		return mongoTemplate.findOne(query, IntentMongo.class);
	}
	
	/**
	 * 이름과 의도 유형으로 intent를 조회함
	 * @param intentType
	 * @param intentName
	 * @return
	 */
	@MultiDataSource
	public IntentMongo findByIntentName(String intentType, String intentName) {
		
		//R&D에서 반환하는 값은 type별로 질의응답, 조회 등이 붙어서 옮
		intentName = trimIntentType(intentType, intentName);
		
        Criteria creteria = Criteria.where("intentName").regex(intentName);
        //인사말이면. type을 유지
        if( intentType.equals("0")) {
        	creteria.and("intentType").is("0");
        } 
        
		MatchOperation matchStage = Aggregation.match(creteria);
		SortOperation sort = sort(new Sort(Direction.DESC, "utterances.isRepresentative"));
		GroupOperation group = group("intentId").push("intentName").as("intentName").push("$utterances").as("utterances");
		
		ProjectionOperation projectStage = project()
				.and("intentId").arrayElementAt(0).as("intentId")
				.and("intentName").arrayElementAt(0).as("intentName")
				.and("utterances").arrayElementAt(0).as("utterance");
		
		Aggregation aggregation = Aggregation.newAggregation(matchStage, unwind("utterances"), sort, group, projectStage);
		AggregationResults<IntentMongo> result = mongoTemplate.aggregate(aggregation, "intents", IntentMongo.class);
		
		List<IntentMongo> list = result.getMappedResults();
		
		return list.isEmpty()?null:list.get(0);
	}
	
	private String trimIntentType(String intentType, String intentName) {
		
		String intentPost = null;
		switch(intentType) {
		case "0" : 
			intentPost = "안녕";
			break;
		case "1" :
			intentPost = "조회";
			break;
		case "2" :
			intentPost = "등록";
			break;
		case "3" : 
			intentPost = "질의응답";
			break;
		default :
			return intentName;
		}
		
		int idx = intentName.lastIndexOf(intentPost);
		
		if( idx < 0 ) {
			return intentName;
		}
		return intentName.substring(0, idx -1);
	}
	
	@MultiDataSource
	public List<IntentMongo> findByContext(String botId, String context, boolean smalltalkExclude) {
		return findByContext(botId, context, smalltalkExclude, false);
	}
	/**
	 * 자동완성용
	 * db.getCollection('intent_0808').aggregate([
		{ $match : {'contexts' : {$regex : '자산'}}},
		{ $sort : {'utterances.isRepresentative' : -1}},
		{ $project : { intentId : 1, utterance : {$arrayElemAt : ['$utterances', 0]}}}
		]);
	 */
	@MultiDataSource
	public List<IntentMongo> findByContext(String botId, String context, boolean smalltalkExclude, boolean like) {
		if( StringUtils.isEmpty(context)) {
			return java.util.Collections.EMPTY_LIST;
		}
		
		Criteria creteria;
		
		if( like ) {
			creteria = Criteria.where("contexts").regex(context).and("botId").is(botId);
		} else {
			creteria = Criteria.where("contexts").is(context).and("botId").is(botId);
		}
		
		if( smalltalkExclude ) {
			creteria.and("intentType").ne("0");
		}
		
		MatchOperation matchStage = Aggregation.match(creteria);
		
		SortOperation sort = sort(new Sort(Direction.DESC, "utterances.isRepresentative"));
		GroupOperation group = group("intentId").push("intentName").as("intentName").push("$utterances").as("utterances");
		
		ProjectionOperation projectStage = 
				project().andExpression("intentName").arrayElementAt(0).as("intentName")
				.andExpression("utterances").arrayElementAt(0).as("utterance");
		
		Aggregation aggregation = Aggregation.newAggregation(matchStage, unwind("utterances"), sort, group, projectStage, limit(11) );
		AggregationResults<IntentMongo> result = mongoTemplate.aggregate(aggregation, "intents", IntentMongo.class);
		
		
		return result.getMappedResults();
	}
	
	private String getFAQ(String intentId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("intentId").is(intentId));
		
		Faq faq = this.mongoTemplate.findOne(query, Faq.class);
		
		if(faq !=null){
			return faq.getContent();
		}else{
			return "";
		}
	}
	
	/**
	 * 질의문에 대하여 R&D 의도추론결과로부터 의도 메타데이터 정보를 조회하고
	 * 파라미터 치환과 관련 action목록을 반환함
	 * TODO 파라미터 치환 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@MultiDataSource
	@Override
	public IntentAnalysisResult reasonIntent(String tntId, String botId, String usrId, String queryString) {
		
		//matching율을 찍어주기 위함
		Score matching = null;
		ParameterMap inParams = new ParameterMap();
		IntentMongo intentMongo = null;
		IntentBase last = context.getLastIntent(tntId, usrId);
		boolean isSearch = false;

		if( last != null && last.getStatus() == Status.SLOT_FILLING ) {
			
			String field = last.getStatus().getField();
			if( ReservedEntity.PERSON.equals(field)) {
				person(queryString, inParams);
			} else {
				inParams.setString(field, queryString);
			}
			intentMongo = getIntent(last.getIntentId());
		} else {
			
			Bot bot = botService.retrieveBot(botId);
			
			Matcher m = KEYWORD_PATTERN.matcher(queryString);
			isSearch = m.find();
			if( isSearch ) {
				queryString = queryString.replaceAll(KEYWORD, "검색어");
			}
			//R&D 의도추론기 호출
			//TODO 조직명 검색을 위해서 공백을 추가함 이게 뭔짓이라냐..
			IntentReasonResult result = intentRest.reason(bot, queryString);
				
			ReasonData data = result.getData();
			LOG.info(String.format("reason result : %s", data));
			
			//의도유형_의도번호 
			String[] dapId = data.getIntentId().split("_");

			LOG.info(bot.toString());
			//의도 추론 성공 여부를 판단하여, 값 이하이면, 이전 의도의 개체명 사전과 일치하는 지 확인한다.
			List<Score> scores = data.getIntentScore(bot.getInferenceCutScore());
			
			if( scores == null || scores.isEmpty() ) {
				matching = Score.ZERO();
			} else {
				matching = scores.get(0);
			}
			
			/**
			 * 의도 매칭율이 임계값
			 */
			if( matching.getScore() < bot.getInferenceMinScore() ) {

				SimilarIntentSet similar = new SimilarIntentSet();
				
				for( Score score : scores ) {
					IntentMongo similarIntent = findByIntentName(dapId[0], score.getName());
					if( similarIntent == null ) {
						continue;
					}
					similar.addIntent(new IntentBase(similarIntent));
				}
				//유사한 의도가 있으면
				if( similar.size() > 0) {
					//인사말이 아닌 경우는 멀티
					if( !"0".equals(dapId[0]) ) {
						similar.setStatus(Status.MULTI_INTENTS);
						return new IntentAnalysisResult(similar, matching);
					}
				} else {
					return new IntentAnalysisResult(Status.NOT_UNDERSTAND, matching);
				}
			} 
			else {
				SimilarIntentSet similar = new SimilarIntentSet();
				
				//유사 의도 최소값
				double similarMinScore = matching.getScore() - bot.getInferenceScoreRange();
				for( Score score : scores ) {
					if( score.getScore() < bot.getInferenceMinScore() || 
							similarMinScore > score.getScore()) {
						break;
					}
					
					IntentMongo similarIntent = findByIntentName(dapId[0], score.getName());
					if( similarIntent == null ) {
						continue;
					}
					similar.addIntent(new IntentBase(similarIntent));
				}
				
				//인사말이 아니고 유사한 결과가 1보다 크면
				if( !"0".equals(dapId[0]) && similar.size() > 1) {
					similar.setStatus(Status.MULTI_INTENTS);
					return new IntentAnalysisResult(similar, matching);
				}
			}

			intentMongo = findByIntentId(dapId[0], dapId[1]);
			
			if( intentMongo == null ) {
				return new IntentAnalysisResult(Status.NOT_UNDERSTAND, Score.ZERO());
			}
			
			
			//동일 개체명이 한개 이상 존재할 수 있기 때문에 add로 
			//P[0], P[2] --> 개체명 치환시 P[0] --> P_0으로 됨. 만약 P개체가 한개라면 P_
			inParams = new ParameterMap();
			for( Entry<String, List<String>> entry : data.getEntity().entrySet() ) {
				for( String value : entry.getValue()) {
					inParams.add(entry.getKey(), value);
				}
			}
			
			if( isSearch ) {
				inParams.setString(EntityContracts.ReservedEntity.KEYWORD, m.group(1));
			}
		}
		
		//세션값으로 paramMap을 구성한다. Null 처리함
		if( !StringUtils.isEmpty(usrId) ) {
			inParams.set("SESSION", dictionary.findUser(tntId, usrId));
		}
		
		return propagate(tntId, botId, usrId, matching, inParams, intentMongo, new ParameterMap());
	}
	
	public IntentAnalysisResult transIntent(String tntId, String botId, String usrId, 
			String intentId, String entity, Map<String, Object> value) {
		
		IntentMongo intentMongo = getIntent(intentId);
		
		if( intentMongo == null ) {
			return new IntentAnalysisResult(Status.NOT_UNDERSTAND, Score.ZERO());
		}
		
		//개체명 
		ParameterMap entityParams = new ParameterMap();
		
		if( value != null ) {
			entityParams.set(entity, value);
		}
		
		return propagate(tntId, botId, usrId, Score.PERFECT(), new ParameterMap(), intentMongo, entityParams);
	}
	
	/**
	 * slot filling, duplicate 인 경우, 사용자가 선택/입력값에서 의도 처리를 완료함
	 * 1) 대화 문맥 조회
	 * 1.1) 대화 문맥이 없는 경우, 의도 분석으로 간다.
	 * 2) 입력된 개체 / 파라미터와 문맥의 개체(들)정보를 merge
	 * 2.1) 개체의 속성정보가 없는 경우, 개체 치환
	 * 3) 파라미터를 매핑
	 * 4) 동일 파라미터가 또 다시 중복이거나, 누락이면 1회만 봐준다.
	 * 4.1) 횟수 초과시, 메시지 출력하고 문맥에서 삭제함
	 * 5) 의도/상태/개체를 최근 문맥에 저장함
	 * @param tenantId
	 * @param botId
	 * @param userId
	 * @param intentId
	 * @param entity
	 * @param params
	 * @return
	 */
	public IntentAnalysisResult fillIntent(String tntId, String botId, String usrId, 
			String intentId, String entity, Object value) {
		
		IntentBase lastIntent = context.getLastIntent(tntId, usrId);
		if( lastIntent == null ) {
			return new IntentAnalysisResult(Status.NOT_UNDERSTAND, Score.ZERO());
		}
		
		IntentMongo intentMongo = getIntent(intentId);
		
		if( intentMongo == null ) {
			return new IntentAnalysisResult(Status.NOT_UNDERSTAND, Score.ZERO());
		}
		
		//사용자 입력값
		ParameterMap inParams = new ParameterMap();
		
		//개체명 
		ParameterMap entityParams = lastIntent.getEntities();
		if( value instanceof Map ) {
			entityParams.set(entity, (Map)value);
		} else {
			//문자열인 경우, 개체명 치환을 수행한다.
			inParams.set(entity, (String)value);
		}
		
		//세션값으로 paramMap을 구성한다. Null 처리함
		if( !StringUtils.isEmpty(usrId) ) {
			inParams.set("SESSION", dictionary.findUser(tntId, usrId));
		}
		return propagate(tntId, botId, usrId, Score.PERFECT(), inParams, intentMongo, entityParams);
	}
	
	/**
	 * 사용자 입력값을 치환해서 entityParams에 담는다.
	 * @param tntId
	 * @param botId
	 * @param usrId
	 * @param matching
	 * @param inParams
	 * @param intentMongo
	 * @param entityParams
	 * @return
	 */
	private IntentAnalysisResult propagate(String tntId, String botId, String usrId, Score matching,
			ParameterMap inParams, IntentMongo intentMongo, ParameterMap entityParams) {
		translateParams(tntId, botId, usrId, intentMongo, inParams, entityParams);

		//FAQ타입이면 faq db 메시지를 조회
		if( intentMongo.getIntentType().equals(IntentType.FAQ)) {
			intentMongo.setMessage(getFAQ(intentMongo.getIntentId()));
		}

		//치환된 개체명으로부터 파라미터를 구성하며, 파라미터 누락이나 중복을 체크함
		IntentBase intent = propagateIntent(tntId, usrId, intentMongo, inParams, entityParams);
		
		try {
			context.saveLastIntent(tntId, usrId, intent);
		}catch(DialogueInvalidException e) {
			return new IntentAnalysisResult(Status.NOT_UNDERSTAND, Score.ZERO());
		}
		
		LOG.info("reasonIntent : " + intent.toString());
		
		//성공이 아닌 경우 끝
		if( intent.getStatus() != Status.COMPLETED) {
			return new IntentAnalysisResult(intent, Score.ZERO());
		}
		
		//버튼 치환한다. 버튼명, url
		propagateRelatedButtons(intentMongo, entityParams, intent);
		return new IntentAnalysisResult(intent, (matching == null?Score.PERFECT() : matching));
	}
	
	/**
	 * 이전 대화의 파라미터에서 추론된 파라미터값이 필요하면
	 * @param entities
	 * @param lastParam
	 * @return
	 */
	private boolean isLastIntentParam(Map<String, List<String>> entities, ParameterMap lastParam) {
		for( Entry<String, List<String>> entry : entities.entrySet()) {
			if( lastParam.existNode(entry.getKey()) ) {
				return true;
			}
		}
		return false;
	}
	
	@SuppressWarnings("rawtypes")
	private void translateParams(
			String tntId, 
			String botId, 
			String usrId, 
			IntentMongo intentMongo, 
			ParameterMap inParams, 
			ParameterMap entityParams) {
		//개체명을 치환한다.
		
		for( Parameter outParam : intentMongo.getParameters() ) {
			ParamValue paramVal = ParameterMap.getParamValue((String)outParam.getValue());
			
			if( !paramVal.isEntity ) {
				continue;
			}
			
			//치환된 개체명이 존재하면 skip
			if( entityParams.existNode(paramVal.entity_0)) {
				continue;
			}

			//1. param명으로 개체명 사전을 뒤진다.
			switch(dictionary.getEntityType(paramVal.entity)) {

			case EntityContracts.ReservedEntity.PERSON : 
				//입력 파라미터에 값이 없는 경우, default값으로 리턴
					
				List<Map<String, Object>> userList = dictionary.findUsers(
						tntId, 
						inParams.getString("SESSION.groupId"),
						inParams.getString(paramVal.entity0),
						inParams.getString(EntityContracts.ReservedEntity.ORGANIZATION),
						inParams.getString(EntityContracts.ReservedEntity.TITLE));
				
				//중복건이 있을 수 있음으로
				for(Map<String, Object> user : userList) {
					String mailId = inParams.getString(EntityContracts.ReservedEntity.MAIL);
					String email  = (String)user.get(UserContracts.Columns.MAIL);
					
					if( !StringUtils.isEmpty(mailId) ) {
						if( !email.startsWith(mailId + "@") ) {
							continue;
						}
					}
					entityParams.add(paramVal.entity_0, user);
				}

				break;
			case EntityContracts.ReservedEntity.ORGANIZATION : 
				
				Map<String, Object> groupInfo = dictionary.findGroup(tntId, 
						inParams.getString(paramVal.entity0), 
						inParams.getString("SESSION.groupName"));
				
				entityParams.set(paramVal.entity_0, groupInfo);
				
				break;
			case EntityContracts.ReservedEntity.DATETIME : 
				try {
					//날짜값이 있는지 여부
					Map<String, Object> date = entityParams.getMap(EntityContracts.ReservedEntity.DATE);
		
					date = dictionary.findEntity( tntId, botId, 
							EntityContracts.ReservedEntity.DATETIME, 
							inParams.getString(paramVal.value), date.get("value"));
					
					entityParams.set(paramVal.entity_0, date);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
				
			case EntityContracts.ReservedEntity.DATE : 
				try {
					//날짜값이 있는지 여부
					List<String> days = inParams.getList(EntityContracts.ReservedEntity.DATE);
					
					Map<String, Object> date = null;
					for( String day : days ) {
						date = dictionary.findEntity( tntId, botId, 
								EntityContracts.ReservedEntity.DATE, 
								day, date);
					}
					
					entityParams.set(paramVal.entity_0, date);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case EntityContracts.ReservedEntity.SESSION : 
				continue;
				
			default :
				try {
					Map obj = (Map)dictionary.findEntity( tntId, botId, paramVal.entity, inParams.getString(paramVal.entity0));
					
					entityParams.set(paramVal.entity_0, obj);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 치환된 개체명으로 파라미터 매핑 처리, 이때, 누락이나 중복 파라미터를 체크하고, 
	 * Action을 넘겨줄 Intent 개체를 생성한다.
	 * @param intentMongo monogodb에서 조회한 의도 정보
	 * @param entityParams  개체명 치환된 정보
	 * @return IntentBase Dialogue Handler로 넘겨줄 의도객체 
	 */
	private IntentBase propagateIntent(String tntId, String usrId, IntentMongo intentMongo, ParameterMap inParams, ParameterMap entityParams) {
		
		List<Parameter> outParams = intentMongo.getParameters();
		
		/*
		 최근 대화의 파라미터를 머지하는 방법
		IntentBase recent = context.getLastIntent(tntId, usrId);
		ParameterMap lastParams = null;
		if( recent != null && recent.getStatus().equals(Status.COMPLETED)) {
			if( recent.isSameContextAs(intentMongo.getContexts())) {
				lastParams = recent.getEntities();
			}
		}*/
		
		//제일 먼저 유효성에서 걸린 상태가 최종 상태임
		Status status = Status.COMPLETED;
		
		//중복 혹은 누락된 개체명
		String[] fields = new String[3];
		int kIdx =0;

		//Dialogue handler로 전달할 intent의 parameter map개체
		Map<String, Parameter> parameters = new HashMap<>();
		Parameter nullParam = null ;
		
		//의도에 정의한 파라미터 값을 셋팅한다. 중복, 누락 발생시 다이얼로그로 전달은 한건만 된다.
		entity: 
		for( Parameter outParam : outParams ) {
			String paramNm  = outParam.getName();
			ParamValue paramVal = ParameterMap.getParamValue((String)outParam.getValue());
			
			//개체명으로 매핑된 파라미터인지 여부
			if( paramVal.isEntity ) {
				
				//중복 혹은 누락되었던 개체명인가?
				for(int i = 0 ; i < kIdx; i++ ) {
					if( paramVal.entity.equals(fields[i]) ) {
						continue entity;
					}
				}
				
				//치환된 개체값을 조회, 두개 이상인 경우, 중복 오류를 발생함
				if( outParam.getDataType() == null ) {
					continue;
				}
				try {
					switch(outParam.getDataType()) {
					case EntityContracts.ReservedEntity.DATE :
					case EntityContracts.ReservedEntity.DATETIME : 
						
						//날짜가 비어있으면 현재 날짜로 함.. 
						Date date = entityParams.getDate(paramVal.entity_0 + "." + paramVal.attribute);
						
						outParam.setValue(date);
						break;
					case EntityContracts.ReservedEntity.SESSION : 
						outParam.setValue(inParams.getString(paramVal.entity + "." + paramVal.attribute));
						break;
						
					default :
						outParam.setValue(entityParams.getString(paramVal.entity_0 + "." + paramVal.attribute));
						break;
					}
					parameters.put(paramNm, outParam);
				}catch(DuplicateEntityException e) {
					
					//중복된 개체가 여러개이더라도, 하나만 사용자 선택입력으로 보냄
					if( status == Status.COMPLETED ) {
						status = Status.DUP_PARAMETER;
						status.setField(paramVal.entity_0);
						
						//사용자 입력 엔터티 명으로 교체 --> slot filing시 사용함
						outParam.setValue(JacksonUtils.toList(entityParams.getNode(paramVal.entity_0)));
						parameters.put(paramVal.entity_0, outParam);
					}
					fields[kIdx++] = paramVal.entity;
					
					//중복 파라미터라면 필수 체크를 하지 않음.
					continue;
				}
				//slot filing은 사용자 입력값이 null인 경우만 해당됨.
				if( StringUtils.isEmpty(outParam.getValue()) ) {//
					
					//입력값이 있었는 지 확인 사람인 경우, 이름외에도 직급으로 물어보는경우가 있음
					boolean input = inParams.existNode(paramVal.entity0);
					if( !input && paramVal.entity.equals(EntityContracts.ReservedEntity.PERSON) ) {
						input = inParams.existNode(EntityContracts.ReservedEntity.TITLE);
					}
					
					if( !input ) {
						String defaultValue = outParam.getDefaultValue();
	
						if( defaultValue != null && defaultValue.startsWith("$")) {
							defaultValue = inParams.getString(defaultValue.substring(1));
						} 
						
						if( !StringUtils.isEmpty(defaultValue)) {
							outParam.setValue(defaultValue);	
						} /*else {
							
							//입력값이 없는 데, 필수라면, 최근 대화에서 추출
							if( outParam.isRequired() && lastParams != null && lastParams.existNode(paramVal.entity_0)) {
								outParam.setValue(lastParams.getString(paramVal.entity_0 + "." + paramVal.attribute));
							}
						}*/
					}
					//필수 여부를 확인하며, 하나만 사용자 선택 입력으로 보냄
					if( StringUtils.isEmpty(outParam.getValue())){ 
						if( outParam.isRequired() && status == Status.COMPLETED ) {
							status = Status.SLOT_FILLING;
							status.setField(paramVal.entity);
							nullParam = outParam;
						}
						fields[kIdx++] = paramVal.entity;
					}
				} 
			} 
		}

		IntentBase intent = IntentBase.createIntent(status, intentMongo);
		
		switch(status) {
		case COMPLETED : 
			intent.setParameters(parameters);
			intent.setMessage(messageTranslator.translateText(parameters, intentMongo.getMessageForDisplay()));
			intent.setAnimation(intentMongo.getAnimationForDisplay());
			break;
		case SLOT_FILLING : 
			entityParams.remove(status.getField());
			intent.putParameters(status.getField(), null);
			intent.setMessage(messageTranslator.translateText(parameters, nullParam.getPrompt()));
			break;
		case DUP_PARAMETER : 
			entityParams.remove(status.getField());
			
			IntentSet intentSet = (IntentSet)intent;
			intentSet.putParameters(status.getField(), parameters.get(status.getField()));
			//intentSet.setMessageTemplate("${groupName} ${name} ${title}");
			intentSet.setMessageTemplate("${groupName} ${name} ${titleNmEp}");
			
			intentSet.setMessage("값이 중복되었습니다.");
			break;
		default :
			throw new IllegalStateException("can not undersand");
		}
		
		//대화 문맥을 유지하기 위해서 치환된 개체를 저장한다.
		intent.setEntities(entityParams);
		return intent;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void propagateRelatedButtons(IntentMongo intentMongo, ParameterMap entityParams, IntentBase intent) {

		for( Action action : intentMongo.getActions() ) {
			
			RelatedButton button = null;
			String name = messageTranslator.translateText(intent.getParameters(), action.getName());
			switch(action.getType()) {
			case "Link" : 
			case "Call" : 
				button = new RelatedButton<String>();
				button.setName(name);
				button.setType(action.getType());
				button.setAction(messageTranslator.translateLink(intent.getParameters(), action.getAction()));
				button.setParams(messageTranslator.translateText(intent.getParameters(), action.getParams()));
				break;
			case "InQuiry" : 
				button = new RelatedButton<IntentBase>();
				button.setName(name);
				button.setType(action.getType());
				
				/*IntentMongo relData = getIntent(action.getIntentId());
				if( relData != null ) {
					continue;
				}

				IntentBase relIntent = propagateIntent(relData, entityParams);*/
				
				button.setAction(messageTranslator.translateText(intent.getParameters(), action.getAction()));
				
				
				break;
			}
			
			((Intent)intent).addButton(button);
			
		}
	}
	
	private static final Pattern PERSON = Pattern.compile("([^\\s]{5,20})?\\s?([^\\s]{2,10})?\\s?([^\\s{2,3}]+)?");
	
	private void person(String sentence, ParameterMap inParams) {
		Matcher matcher = PERSON.matcher(sentence);

		if( !matcher.find() ) {
			return;
		}

		for( int i = 0; i <= matcher.groupCount(); i++) {
			if( StringUtils.isEmpty(matcher.group(i))) {
				continue;
			}
			switch(i) {
			case 1 :
				inParams.setString(ReservedEntity.ORGANIZATION, matcher.group(1));
				break;
			case 2 :

				inParams.setString(ReservedEntity.PERSON, matcher.group(2));
				break;
			case 3 : 
				inParams.setString(ReservedEntity.TITLE, matcher.group(3));
				break;
			}
		}
	}
	
	
}
