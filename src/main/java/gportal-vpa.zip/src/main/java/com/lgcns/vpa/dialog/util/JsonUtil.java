/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : JsonUtil.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.util;

import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.Attachment;

public class JsonUtil {
	/**
	 * Activity Object 를 Json 으로 변환
	 * @param activity
	 * @return
	 */
	public static String toJson (Activity activity) {
			
		if ( activity == null ) {
			return null;
		}
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(activity);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}
	
	/**
	 * Attachment Object 를 Json 으로 변환
	 * @param activity
	 * @return
	 */
	public static String toJson (Attachment attachment) {
			
		if ( attachment == null ) {
			return null;
		}
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(attachment);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}
	
	/**
	 * Map 을 JsonString 으로 변환
	 * @param mapData
	 * @return
	 */
	public static String toJson (Map<String, Object> mapData) {
		
		if ( (mapData == null) || (mapData.isEmpty()) ) {
			return null;
		}
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(mapData);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}
}
