package com.lgcns.vpa.security.authentication.service.impl;

import javax.servlet.http.HttpServletRequest;
// import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
// import org.springframework.web.context.request.RequestContextHolder;
// import org.springframework.web.context.request.ServletRequestAttributes;

import com.lgcns.vpa.security.authentication.EndpointAuthenticationManager;
import com.lgcns.vpa.security.authentication.dao.AuthenticationDao;
import com.lgcns.vpa.security.authentication.service.EndpointAuthenticationService;
import com.lgcns.vpa.security.authentication.util.JWTUtils;

@Service("multi.endpointAuthenticationService")
public class EndpointAuthenticationServiceImpl implements EndpointAuthenticationService {
    
    private final Logger logger = LoggerFactory.getLogger(EndpointAuthenticationServiceImpl.class);
    
    @Autowired
    private AuthenticationDao authenticationDao;
    
    @Autowired
    @Qualifier("endpointAuthenticationManager")
    private EndpointAuthenticationManager endpointAuthenticationManager;

    /**
     * IP주소 체크
     * @param ipaddress
     * @return
     */
    @Override
    public boolean validateIpaddress(String ipaddress) {
        return !StringUtils.isEmpty(authenticationDao.selectIpaddress(ipaddress));
    }
    
    /**
     * 인증
     * @param request
     * @param authorizationCode
     * @param ipaddress
     */
    @Override
    public void authorize(HttpServletRequest request, String authorizationCode, String ipaddress) {
        
        // 1. 토큰 유효성 검사
        if (!JWTUtils.validateToken(authorizationCode, ipaddress)) {
            throw new AuthenticationServiceException("Invalid Authorization Code.");
        }

        // 2. 인증처리
        
        // 2.1. 토큰 디코딩
        String userId = JWTUtils.getSubjectFromToken(authorizationCode);

        logger.info("===================================================");
        logger.info("authorization_code is valid.");
        logger.info("userId: " + userId);
        logger.info("===================================================");            

        // 2.2. 인증처리 (Spring Security)
        Authentication authentication = endpointAuthenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userId, ""));
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new AuthenticationServiceException("Invalid Authentication.");
        }
        
        // 2-3. 이전 Session이 존재하는 경우 invalidate()
        try {
            // ServletRequestAttributes testAttr = (ServletRequestAttributes)RequestContextHolder.currentRequestAttributes();
            // HttpSession session = testAttr.getRequest().getSession(false);
            // session.invalidate();
        } catch (Exception e) {}

        // 3. 인증결과 저장
        SecurityContextHolder.getContext().setAuthentication(authentication);
        
        // 4. 로깅
        logger.info("===================================================");
        logger.info("authorize success.");
        logger.info("===================================================");
    }
    
    /**
     * 로그인 (개발서버에서만 사용)
     * @param token
     */    
    @Override
    public void login(Authentication token) {
        String password = token.getCredentials().toString();
        
        if (!"qwer1234".equals(password)) {
            throw new AuthenticationServiceException("Invalid Authentication.");
        }
        
        Authentication authentication = endpointAuthenticationManager.authenticate(token);
        SecurityContextHolder.getContext().setAuthentication(authentication);
    }
}
