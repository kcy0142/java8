package com.lgcns.vpa.push.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.PushService;

/**
 * <pre>
 * Push 알림 기본 Service
 * </pre>
 * @author
 */
@Service("multi.commonPushService")
public class CommonPushServiceImpl extends PushAbstractService implements PushService{
	
    @Autowired
    RedisMessagePublisher redisMessagePublisher;
    
    @Autowired
	ActivityService activityService;
    
    @Override
    public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig){
    	
    	ObjectMapper mapper = new ObjectMapper();
    	Activity activity= mapper.convertValue(params, Activity.class);
    	
		String botId = activity.getBotId();
    	String userId = activity.getUserId();
    	
    	checkBotId(botId);
    	checkUserId(userId);
    	
    	activity.setType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
    	activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH);
    	
    	redisMessagePublisher.publish(activity);
    	
    }
	
}
