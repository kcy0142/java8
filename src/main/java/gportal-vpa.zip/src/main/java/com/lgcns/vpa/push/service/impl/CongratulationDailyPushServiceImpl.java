/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.push.service.impl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.model.config.PushConfigProperty;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.push.service.DailyPushService;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.base.config.ServersConfig;
import com.lgcns.vpa.base.util.I18nUtils;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.ActivityCode;

/**
 * <pre>
 * 축하합니다. 데일리 Push Service
 * </pre>
 * @author
 */
@Service("multi.congratulationDailyPushService")
public class CongratulationDailyPushServiceImpl extends PushAbstractService implements DailyPushService {

    // [실행예시]
    // EXEC GPTDB.gpt_user.GPT_IF_CONGRATULATIONS  
    //     @T_GROUP       = '2',     -- 대상조직(0:미포함, 1:팀, 2:사업부 3:담당)
    //     @FAVORITE      = '0',     -- 즐겨찾기(0:미포함, 1:포함)
    //     @PROJECT       = '0',     -- 프로젝트(0:미포함, 1:포함)
    //     @PERIOD        = '1',     -- 기간(0:DAY, 1:WEEK, 2:MONTH)
    //     @LOGIN_USER_ID = 'admin', -- 로그인 USER_ID
    //     @LOCALE        = 'ko'     -- 로그인 로케일
    
    // [TYPE]
    //     - BIRTHDAY
    //     - WEDDING_ANNIV
    //     - LONG_SERVICE + CON_CODE
      
    @Autowired
    private ServersConfig serversConfig;
    
    @Autowired
    private MessageSource messageSource;
    
    @Autowired
    ConfigService configService;

    
    @Override
    public List<Attachment> execute(Map<String, String> param, PushConfig pushConfig, Bot bot, User user, String tenantId) {
     
        List<PushConfigProperty> pushConfigProperties = pushConfig.getPushConfigProperties();
        
        String localeCode = user.getLocaleCode();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM.dd").withLocale(Locale.KOREAN);
        String today = formatter.format(LocalDate.now());
        
        
        
        TransferSyncVO transferSyncVO = new TransferSyncVO();
        transferSyncVO.setActionUri(pushConfig.getActionUri());
        transferSyncVO.setTenantId(tenantId);
                
        // 사용자 프로파일
        String portalUrl = serversConfig.getServersInfo(tenantId, "gportal", "urlContextRoot");

        // 파라미터 설정
        Map<String, Object> actionParam = new HashMap<>();
        
        // 사용자 정보
        actionParam.put("LOGIN_USER_ID", user.getUserId());
        actionParam.put("LOCALE", localeCode);
        
        // T_GROUP
        // 대상조직 (0:미포함, 1:팀, 2:사업부 3:담당)
        actionParam.put("T_GROUP", "0");
        pushConfigProperties.stream().filter(property -> "T_GROUP".equals(property.getPropertyCode())).findFirst()
            .ifPresent(property -> {
                String value = StringUtils.isEmpty(property.getPropertyValue()) ? property.getDefaultPropertyValue() : property.getPropertyValue();
                actionParam.put("T_GROUP", value);
            });
        
        // FAVORITE
        // 즐겨찾기(0:미포함, 1:포함)
        actionParam.put("FAVORITE", "0");
        pushConfigProperties.stream().filter(property -> "FAVORITE".equals(property.getPropertyCode())).findFirst()
            .ifPresent(property -> {
                String value = StringUtils.isEmpty(property.getPropertyValue()) ? property.getDefaultPropertyValue() : property.getPropertyValue();
                actionParam.put("FAVORITE", "Y".equals(value) ? "1" : "0" );
            });  
        
        // PROJECT
        // 프로젝트(0:미포함, 1:포함)
        actionParam.put("PROJECT", "0");
        pushConfigProperties.stream().filter(property -> "PROJECT".equals(property.getPropertyCode())).findFirst()
            .ifPresent(property -> {
                String value = StringUtils.isEmpty(property.getPropertyValue()) ? property.getDefaultPropertyValue() : property.getPropertyValue();
                actionParam.put("PROJECT", "Y".equals(value) ? "1" : "0" );
            }); 
  
        // PERIOD
        // 기간(0:DAY, 1:WEEK, 2:MONTH)
        actionParam.put("PERIOD", "0");
        pushConfigProperties.stream().filter(property -> "PERIOD".equals(property.getPropertyCode())).findFirst()
            .ifPresent(property -> {
                String value = StringUtils.isEmpty(property.getPropertyValue()) ? property.getDefaultPropertyValue() : property.getPropertyValue();
                actionParam.put("PERIOD", value);
            }); 

        transferSyncVO.setActionParam(actionParam);
        
        List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
        List<Attachment> attachments = null;
        
        if (!CollectionUtils.isEmpty(proxyResultSet)) {
            Attachment attachment = new Attachment();
            attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
            attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_CONGRATULATION);
            attachment.setTitle(pushConfig.getPushName());
            
            // 타이틀 메시지
            int resultSize = proxyResultSet.size();
            switch (resultSize) {
                case 0:
                    break;
                case 1:
                    Map<String, Object> conUser = proxyResultSet.get(0);
                    
                    // 오늘 생일을 맞은 <em>이영우 차장</em>님의 기쁜 날을 축하해 주세요
                    attachment.setDescriptions(messageSource.getMessage("meesage.push.daily.congratulation.descriptions1",
                            new String[] {new StringBuffer().append(conUser.get("USER_NAME")).append(" ").append(conUser.get("JOB_TITLE_NAME")).toString()},
                            new Locale(user.getLocaleCode())));
                    break;
                default:
                    Map<String, Object> conUser1 = proxyResultSet.get(0);
                    Map<String, Object> conUser2 = proxyResultSet.get(1);
                    
                    // 오늘 생일을 맞은 <em>이영우 차장</em>님, <em>김상영 차장</em>님 외 <em>5명</em>의 기쁜 날을 축하해 주세요.
                    String descriptions = "";
                    
                    if (resultSize - 2 > 0) {
                        descriptions = messageSource.getMessage("meesage.push.daily.congratulation.descriptions3",
                                new String[] {
                                        new StringBuffer().append(conUser1.get("USER_NAME")).append(" ").append(conUser1.get("JOB_TITLE_NAME")).toString(),
                                        new StringBuffer().append(conUser2.get("USER_NAME")).append(" ").append(conUser2.get("JOB_TITLE_NAME")).toString(),
                                        StringUtils.toString(resultSize - 2)
                                    },
                                new Locale(user.getLocaleCode()));
                    } else {
                        descriptions = messageSource.getMessage("meesage.push.daily.congratulation.descriptions2",
                                new String[] {
                                        new StringBuffer().append(conUser1.get("USER_NAME")).append(" ").append(conUser1.get("JOB_TITLE_NAME")).toString(),
                                        new StringBuffer().append(conUser2.get("USER_NAME")).append(" ").append(conUser2.get("JOB_TITLE_NAME")).toString()
                                    },
                                new Locale(user.getLocaleCode()));
                    }
                    
                    attachment.setDescriptions(descriptions);
                    break;                    
            }
            
            List<Element> elements = proxyResultSet.stream().map(data -> new Element() {
                private static final long serialVersionUID = -4803937536892622504L;
                {
                    this.setId(StringUtils.toString(data.get("USER_ID")));
                    this.setUserId(StringUtils.toString(data.get("USER_ID")));
                    this.setDate(StringUtils.toString(data.get("CON_DATE")));
                    
                    if (I18nUtils.isDefaultLocaleCode(localeCode)) {
                        this.setUserName(StringUtils.toString(data.get("USER_NAME")));
                        this.setJobTitleName(StringUtils.toString(data.get("JOB_TITLE_NAME")));
                        this.setTeamName(StringUtils.toString(data.get("GROUP_NAME")));
                    } else {
                        this.setUserName(StringUtils.toString(data.get("USER_ENGLISH_NAME")));
                        this.setJobTitleName(StringUtils.toString(data.get("JOB_TITLE_ENGLISH_NAME")));
                        this.setTeamName(StringUtils.toString(data.get("GROUP_ENGLISH_NAME")));
                    }

                    this.setActionType(ActivityCode.ACTION_TYPE_LINK);
                    this.setAction(new StringBuffer().append(portalUrl).append(data.get("ACTION")).toString());
                    
                    // 유형처리
                    // 장기근속의 경우 CON_CODE || TYPE
                    if ("LONG_SERVICE".equals(data.get("TYPE"))) {
                        this.setType(StringUtils.toString(data.get("TYPE")));
                        this.setSubtype("Z||" + data.get("CON_CODE") + "||" + data.get("TYPE"));
                    } else {
                        this.setType(StringUtils.toString(data.get("TYPE")));
                        this.setSubtype(StringUtils.toString(data.get("TYPE")));
                    }
                    
                    this.addAdditionalProperty("years", StringUtils.toString(data.get("CON_CODE")));
                    this.addAdditionalProperty("today", today.equals(data.get("CON_DATE")));
                    this.addAdditionalProperty("groupAllName", StringUtils.toString(data.get("GROUP_ALL_NAME")));
                }
            }).collect(Collectors.toList());
            
            attachment.setElements(elements);
            attachments = Arrays.asList(attachment);
        }
                
        return attachments;
    }
}
