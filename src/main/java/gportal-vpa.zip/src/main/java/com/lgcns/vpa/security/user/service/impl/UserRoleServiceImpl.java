/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserRoleServiceImpl.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

/**
 * <PRE>
 * 사용자 역할 validate
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 8. 14.
 */
package com.lgcns.vpa.security.user.service.impl;

import org.springframework.stereotype.Service;

import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.security.user.service.UserRoleService;

/**
 * <PRE>
 * 사용자 역할 validate
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 8. 14.
 */
@Service("multi.userRoleService")
public class UserRoleServiceImpl implements UserRoleService {

	/**
     * 사용자 역할 validate
     * @param User
	 * @param intentId
     * @return
     */
	@Override
	public boolean validateUserRole(User user, String intentId) {
		
		boolean result=true;

		return result;
	}

	
}

