/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.service;

import com.lgcns.vpa.channel.model.Conversation;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.security.user.model.User;

import java.util.List;

/**
 * <pre>
 * 봇 대화관리 Service
 * </pre>
 * @author
 */
public interface ConversationService {
	
    /**
     * Conversation 초기화
     * @param botId
     * @param user
     * @param tenantId
     * @return
     */
    Conversation initialize(String botId, User user, String tenantId);

    /**
     * 사용자의 진행중인 Conversation 및 Bot 목록 조회
     * @param user
     * @return
     */
    List<Conversation> retrieveUserConversationAndBotList(User user);

    /**
     * bot의 대화목록, bot이 없으며, 테넌트가 사용중인 모든 bot에서 발생된 대화목록
     * @param botId
     * @return
     */
    List<Conversation> retrieveConversationList(String botId);
    
    /**
     * 접속시 인사말
     * @param botId
     * @param isEventMessage
     * @param tenantId
     * @param user
     * @return
     */
    List<Activity> retrieveGreeting(String botId, boolean isEventMessage, String tenantId, User user);
    
    /**
     * 일 최초 접속시 데일리 푸시 조회
     * @param botId
     * @param user
     * @param tenantId
     * @param reload
     * @return
     */
    List<Activity> retrieveDailyPush(String botId, User user, String tenantId, boolean reload);
    
    /**
     * 최근 대화이력 조회
     * @param botId
     * @param user
     * @param limit
     * @param tenantId
     * @return
     */
    List<Activity> retrieveRecentActivityList(String botId, User user, int limit, String tenantId);
    
    /**
     * 이전 대화이력 조회
     * @param botId
     * @param user
     * @param cursorId
     * @param limit
     * @param tenantId
     * @return
     */
    List<Activity> retrieveBeforeActivityList(String botId, User user, String cursorId, int limit, String tenantId);  
    
    
    /**
     * 푸쉬 읽음 표시 저장
     * @param activity
     * @param user
     * @return
     */
    void updateDailyPushDate(String botId, User user);
    
}
