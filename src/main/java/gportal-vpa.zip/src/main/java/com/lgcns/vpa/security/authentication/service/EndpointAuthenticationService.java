package com.lgcns.vpa.security.authentication.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;

public interface EndpointAuthenticationService {
    
    /**
     * IP주소 체크
     * @param ipaddress
     * @return
     */
    // FIXME: 운영 전개시 빼야함
    boolean validateIpaddress(String ipaddress);
    
    /**
     * 인증
     * @param request
     * @param authorizationCode
     * @param ipaddress
     */
    void authorize(HttpServletRequest request, String authorizationCode, String ipaddress);
    
    /**
     * 로그인 (개발서버에서만 사용)
     * @param authentication
     */
    void login(Authentication token);
}
