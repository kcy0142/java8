/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : Action.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.query.Update;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.util.StringUtils;

/**
 * <PRE>
 * Action Modeling Object
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 7. 12.
 */
@Document(collection="stopwords")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StopWord {
	@Id
	private String id;
	
	/**
	 * Action 고유의 아이디
	 */
	@Indexed
	private String stopWordId;
	
	/**
	 * StopWord 타입, IN: 포함문장, ALL:전체매칭문장
	 */
	private String stopWordType;
	
	/**
	 * Action 별 실행 Dialog 명
	 */
	private String stopWordName;
	
	/**
	 * Action Type ( ex) sql-sp, sql, rest 등)
	 */
	private String responseMessage;
	
	
	private String reponseUri;
	
	/**
	 * Action 을 사용하는 회사코드
	 */
	private String companyCode;
	
	/**
	 * Animation 정보
	 */
	private String animation;
	
	/**
	 * Action 을 사용하는 챗봇 구분 id
	 */
	private String botId;
	
	/* 여기서부터 하위로는 공통임. 
	 * 추후에 공통 Parent 에서 상속하는 것으로 처리*/
	
	/**
	 * 생성자 userId
	 */
	private String registerId;
	
	/**
	 * 생성자 명
	 */
	private String registerName;
	
	/**
	 * 생성일자
	 */
	private Date registDate;
	
	/**
	 * 수정자 userId
	 */
	private String updaterId;
	
	/**
	 * 수정자 명
	 */
	private String updaterName;
	
	/**
	 * 수정일자
	 */
	private Date updateDate;

	public StopWord() {}

	public StopWord(String id, String stopWordId, String stopWordType, String stopWordName, String responseMessage,
			String reponseUri, String companyCode, String botId, String registerId, String registerName,
			Date registDate, String updaterId, String updaterName, Date updateDate) {
		super();
		this.id = id;
		this.stopWordId = stopWordId;
		this.stopWordType = stopWordType;
		this.stopWordName = stopWordName;
		this.responseMessage = responseMessage;
		this.reponseUri = reponseUri;
		this.companyCode = companyCode;
		this.botId = botId;
		this.registerId = registerId;
		this.registerName = registerName;
		this.registDate = registDate;
		this.updaterId = updaterId;
		this.updaterName = updaterName;
		this.updateDate = updateDate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStopWordId() {
		return stopWordId;
	}

	public void setStopWordId(String stopWordId) {
		this.stopWordId = stopWordId;
	}
	
	public String getStopWordType() {
		return stopWordType;
	}

	public void setStopWordType(String stopWordType) {
		this.stopWordType = stopWordType;
	}

	public String getStopWordName() {
		return stopWordName;
	}

	public void setStopWordName(String stopWordName) {
		this.stopWordName = stopWordName;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getReponseUri() {
		return reponseUri;
	}

	public void setReponseUri(String reponseUri) {
		this.reponseUri = reponseUri;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	
	public String getAnimation() {
		return animation;
	}

	public void setAnimation(String animation) {
		this.animation = animation;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getRegisterName() {
		return registerName;
	}

	public void setRegisterName(String registerName) {
		this.registerName = registerName;
	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}

	public String getUpdaterId() {
		return updaterId;
	}

	public void setUpdaterId(String updaterId) {
		this.updaterId = updaterId;
	}

	public String getUpdaterName() {
		return updaterName;
	}

	public void setUpdaterName(String updaterName) {
		this.updaterName = updaterName;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	/**
	 * 응답 메세지를 구분자로 구분하여 그 중 임의의 값을 리턴함
	 * @return
	 */
	public String getResponseMessageForDisplay () {

		String responseMessageForDisplay = "";
		
		if ( !StringUtils.isEmpty(responseMessage) ) {
			String [] tmpList = StringUtils.splitExeptEmptyString(responseMessage, "||[");
			responseMessageForDisplay = StringUtils.getRamdomString(tmpList);
		}
		
		return responseMessageForDisplay;
	}
	
	/**
	 * 애니메니션값을 구분자로 구분하여 그 중 임의의 값을 리턴함
	 * @return
	 */
	public String getAnimationForDisplay () {

		String getAnimationForDisplay = "";
		
		if ( !StringUtils.isEmpty(animation) ) {
			String [] tmpList = StringUtils.splitExeptEmptyString(animation, "||[");
			getAnimationForDisplay = StringUtils.getRamdomString(tmpList);
		}
		
		return getAnimationForDisplay;
	}

	/**
	 * 수정용 Parameter 인 Update Object 생성
	 * @return
	 */
	public Update getUpdateObject () {
		
		Update update = new Update();
		update.set("stopWordId", this.stopWordId);
		update.set("stopWordType", this.stopWordType);
		update.set("stopWordName", this.stopWordName);
		update.set("responseMessage", this.responseMessage);
		update.set("reponseUri", this.reponseUri);
		update.set("companyCode", this.companyCode);
		update.set("botId", this.botId);
		update.set("updaterId", this.updaterId);
		update.set("updaterName", this.updaterName);
		update.set("updateDate", new Date(System.currentTimeMillis()));
		
		return update;
	}

	/**
	 * Json Data 생성
	 * @return
	 */
	public String toJson () {
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(this);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}
}