/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : RecommandUserExcept.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.channel.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * <PRE>
 * 관리자 추천키워드, 사용자의 자주쓰는 키워드, 최근 키워드 중 사용자가 표시 제외한 목록의 관리 Model 
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 7. 20.
 */
@Document(collection="userExcepts")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RecommandUserExcept {
	@Id
	private String id;
	
	/**
	 * 사용자 아이디
	 */
	private String userId;
	
	/**
	 * 제외 키워드
	 */
	private String exceptWord;
	
	/**
	 * Action 을 사용하는 챗봇 구분 id
	 */
	private String botId;
	
	/* 여기서부터 하위로는 공통임. 
	 * 추후에 공통 Parent 에서 상속하는 것으로 처리*/
	
	/**
	 * 생성자 userId
	 */
	private String registerId;
	
	/**
	 * 생성자 명
	 */
	private String registerName;
	
	/**
	 * 생성일자
	 */
	private Date registDate;

	public RecommandUserExcept() {}
	
	public RecommandUserExcept(String keyword) {
		exceptWord = keyword;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getExceptWord() {
		return exceptWord;
	}

	public void setExceptWord(String exceptWord) {
		this.exceptWord = exceptWord;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getRegisterName() {
		return registerName;
	}

	public void setRegisterName(String registerName) {
		this.registerName = registerName;
	}

	public Date getRegistDate() {
		return registDate;
	}

	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}

	
	@Override
	public boolean equals(Object obj) {
		boolean retVal = false;

		if (!StringUtils.hasText(exceptWord) ) {
			return retVal;
		}
		
	    if (obj instanceof RecommandUserExcept){
	    	RecommandUserExcept tobj = (RecommandUserExcept) obj;
	        retVal = exceptWord.equals(tobj.exceptWord);
	    }

	    return retVal;
	}

	@Override
	public int hashCode() {
		int hash = 7;
	    hash = 17 * hash + (StringUtils.hasText(exceptWord) ? exceptWord.hashCode() : 0);
	    return hash;
	}
	
	@Override
	public String toString() {
		return "RecommandUserExcept [id=" + id + ", userId=" + userId + ", exceptWord=" + exceptWord + ", botId="
				+ botId + ", registerId=" + registerId + ", registerName=" + registerName + ", registDate=" + registDate
				+ "]";
	}
	
}
