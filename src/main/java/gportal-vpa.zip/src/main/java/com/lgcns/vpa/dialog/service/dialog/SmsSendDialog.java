/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SmsSendDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.push.model.UserAutoRun;

/**
 * <PRE>
 * SMS 보내는 입력폼 Dialog
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 12. 18.
 */
@Component("SmsSendDialog")
public class SmsSendDialog extends VpaDialog {

private static final Logger LOG = LoggerFactory.getLogger(SmsSendDialog.class);
	
	
	
	@Autowired
	private CommonResponseService commonResponeService;
	

	
	@Override
	protected boolean validator(InquiryVO data) {
		if ( (data == null) || (!StringUtils.hasText(data.getInquiryData())) ) {
			return false;
		}
		
		return true;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		return true;
	}

	@Override
	protected String processor(InquiryVO data) {
		return "Inquiry SmsSend";
	}
	
	@Override
	protected Activity afterWork(InquiryVO data, String stopWordReponseMessage) {
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
			
	        
			List<Attachment> attachments = null;
			
			//개인:user,그룹이면 group
			String actionType=data.getAction().getActionType();
			
			//default user로 설정
			if(StringUtils.isEmpty(actionType)) {
				data.getAction().setActionType("user");
			}
			
			//통합 검색에서 조회된 결과로 Attachment 를 구함
		
			attachments = this.getAttachment(data);
			
			
			
			System.out.println("#################actionType:"+data.getAction().getActionType());
				
			//Activity Message
			StringBuffer activityMessage = new StringBuffer();
			Map <String, Object> intentParam = data.getIntentParam();
			String message=String.valueOf(intentParam .get("toUserName"))+" 님에게 뭐라고 보낼까요? 문자 발송 시 임직원 조회가 필요하시면 하단에 SMS 문자 발송을 클릭하세요.";
			//resultActivity.setMessage(message);
			
			resultActivity.setMessage(data.getIntentMessage());
			resultActivity.setAttachments(attachments);
			
			if ( data.getIntentButtons() != null ) {
				List<RelatedButton> buttons = data.getIntentButtons();
				List<Button> activityButtonList = super.makeActivityButtonList(buttons);
				
				if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
					resultActivity.setButtons(activityButtonList);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @return
	 */
	private List<Attachment> getAttachment (InquiryVO inquiryData) throws Exception {
		
		Attachment attachment = null;
				
		try {
			
			String fromMobile = null;
			String fromUserName = null;
			String toMobile = null;
			String toUserName = null;
			String toGroup = null;
			String toGroupName = null;
			
			//개인:user,그룹이면 group
			String actionType=inquiryData.getAction().getActionType();
			
			
			
			Map <String, Object> intentParam = inquiryData.getIntentParam();
			if ( intentParam != null ) {
				
				if(actionType.equals("user")){
					fromMobile = String.valueOf(intentParam .get("fromMobile"));
					fromUserName = String.valueOf(intentParam .get("fromUserName"));
					toMobile = String.valueOf(intentParam .get("toMobile"));
					toUserName = String.valueOf(intentParam .get("toUserName"));
				}else if(actionType.equals("group")){
					fromMobile = String.valueOf(intentParam .get("fromMobile"));
					fromUserName = String.valueOf(intentParam .get("fromUserName"));
					toGroup = String.valueOf(intentParam .get("toGroup"));
					toGroupName = String.valueOf(intentParam .get("toGroupName"));
					
					
				}else{
					fromMobile = String.valueOf(intentParam .get("fromMobile"));
					fromUserName = String.valueOf(intentParam .get("fromUserName"));
					toMobile = String.valueOf(intentParam .get("toMobile"));
					toUserName = String.valueOf(intentParam .get("toUserName"));
				}
				
			}
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_SMSSEND);
	        
			String title = null;
			String actionUrl = null;
			
			
			// additionalProperties 설정
            Map<String, Object> additionalProperties = new HashMap<String, Object>();
            additionalProperties.put("intentId", inquiryData.getIntentId());
            additionalProperties.put("id", inquiryData.getInquiryId());
           // additionalProperties.put("id", inquiryData.geti);
            additionalProperties.put("botId", inquiryData.getBotId());
            additionalProperties.put("toUserName", toUserName);
            additionalProperties.put("fromMobile", fromMobile);
            additionalProperties.put("fromUserName", fromUserName);
            additionalProperties.put("toMobile", toMobile);
            additionalProperties.put("toUserName", toUserName);
            
            additionalProperties.put("actionType", actionType);
            additionalProperties.put("toGroup", toGroup);
            additionalProperties.put("toGroupName", toGroupName);
            
            
            //String actionType=data.getAction().getActionType();
            
			Element element = new Element();
			element.setType(CommonCode.ELEMENT_TYPE_TEXT);
			element.setTitle(title);
			//element.setDescriptions(desciptions.toString());
			//element.setAmount(desciptions.toString());
			//element.setUnit("삭제");
			element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
			element.setAction(actionUrl);
			
			element.setAdditionalProperties(additionalProperties);
			
			attachment.addElement(element);
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
	

}
