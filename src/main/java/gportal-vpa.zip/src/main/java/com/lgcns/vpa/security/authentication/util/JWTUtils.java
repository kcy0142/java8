/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.security.authentication.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * <pre>
 * JWT 유틸
 * </pre>
 * @author
 */
@Component
public class JWTUtils {
    
    /**
     * JWT 시크릿
     */
    private static String SECRET;

    @Value("${security.jwt.secret}")
    public void setSecret(String secret) {
        SECRET = secret;
    }

    /**
     * JWT 만료시간 (초)
     */
    private static long EXPIRATION;

    @Value("${security.jwt.expiration}")
    public void setExpiration(long expiration) {
        EXPIRATION = expiration;
    }

    /**
     * JWT 토큰 생성 (인코딩)
     * @param userId
     * @param ipaddress
     * @return
     */
    public static String generateToken(String userId, String ipaddress) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("sub", userId);
        claims.put("ipaddress", ipaddress);
        return JWTUtils.generateToken(claims);
    }
    
    /**
     * JWT 토큰 클레임 조회 (디코딩)
     * @param token
     * @return
     */
    public static Claims getClaimsFromToken(String token) {
        Claims claims;
        try {   
            claims = Jwts.parser()
                    .setSigningKey(JWTUtils.SECRET)
                    .parseClaimsJws(token)
                    .getBody();
        } catch (Exception e) {
            claims = null;
        }
        return claims;
    }
    
    /**
     * JWT 토큰 유효성 체크
     * @param token
     * @param ipaddress
     * @return
     */
    public static boolean validateToken(String token, String ipaddress) {
        // JWT 유효성 체크
        // IP 주소 체크
        // 만료시간 (30초) 체크
        final Claims claims = JWTUtils.getClaimsFromToken(token);        
        if (claims == null) return false;
        
        final String subject = claims.getSubject();
        final String issuedIpaddress = (String) claims.get("ipaddress");
        
        System.out.println("request ipaddress : " + ipaddress + " issued Ipaddress" + issuedIpaddress);

        return (!StringUtils.isEmpty(subject) && (issuedIpaddress.equals(ipaddress) || issuedIpaddress.equals("127.0.0.1")) && !JWTUtils.isTokenExpired(token));
    }
    
    /**
     * JWT 토큰 Subject 조회 (디코딩)
     * @param token
     * @return
     */
    public static String getSubjectFromToken(String token) {
        String subject;
        try {
            final Claims claims = JWTUtils.getClaimsFromToken(token);
            subject = claims.getSubject();
        } catch (Exception e) {
            subject = null;
        }
        return subject;
    }

    /**
     * 토큰 만료여부 체크
     * @param token
     * @return
     */
    private static boolean isTokenExpired(String token) {
        final Date expiration = JWTUtils.getExpirationDateFromToken(token);
        return expiration.before(JWTUtils.generateDate());
    }
    
    /**
     * 토큰 생성 (SHA512)
     * @param claims
     * @return
     */
    private static String generateToken(Map<String, Object> claims) {
        return Jwts.builder()
                .setId(UUID.randomUUID().toString())
                .setClaims(claims)
                .setIssuedAt(JWTUtils.generateDate())
                .setExpiration(JWTUtils.generateExpirationDate())
                .signWith(SignatureAlgorithm.HS512, JWTUtils.SECRET)
                .compact();
    }
        
    /**
     * 토큰 만료일
     * @return
     */
    private static Date generateExpirationDate() {
        return new Date(System.currentTimeMillis() + JWTUtils.EXPIRATION * 1000);
    }

    /**
     * 토큰 생성일
     * @return
     */
    private static Date generateDate() {
        return new Date(System.currentTimeMillis());
    }

    /**
     * 토큰 만료일 조회 (디코딩)
     * @param token
     * @return
     */
    private static Date getExpirationDateFromToken(String token) {
        Date expiration;
        try {
            final Claims claims = JWTUtils.getClaimsFromToken(token);
            expiration = claims.getExpiration();
        } catch (Exception e) {
            expiration = null;
        }
        return expiration;
    }
}
