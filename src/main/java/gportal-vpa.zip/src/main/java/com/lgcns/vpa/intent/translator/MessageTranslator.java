/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : MessageUtils.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.translator;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.intent.model.IntentMongo.Parameter;

@Component("translator")
public class MessageTranslator {
	private static final SimpleDateFormat USER_YYMMDDE = new SimpleDateFormat("M월 d일 E요일", Locale.KOREAN);
	private static final SimpleDateFormat USER_YYMMDDHHMM = new SimpleDateFormat("M월 d일 E요일 HH시 mm분", Locale.KOREAN);
	
	private static final SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
	private static final SimpleDateFormat YYYYMMDDHHMM = new SimpleDateFormat("yyyyMMddHHmm");
	/**
	 * 단순 메시지를 치환하기 위한 문자열 패턴으로
	 * $user.name $date.yyyymmdd 일정을 알려드립니다.
	 */
	//private static final Pattern TEXT_PATTERN = Pattern.compile("(?i)(?<=\\$).*?(?=(\\$|\\s|$))");
	private static final Pattern TEXT_PATTERN = Pattern.compile("(?i)(?<=\\$\\{).*?(?=(\\}))");
	//script function여부
	private static final Pattern FUNC_PATTERN = Pattern.compile("([a-zA-Z0-1\\_]+)\\(([^\\)]*)\\)");
	@Autowired
	private TranslateScriptEngine scriptEngine;
	
	public String translateText(String jsonStr, String message) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			Map<String, Object> map = mapper.readValue(jsonStr, new TypeReference<Map<String, Object>>(){});
			
			if( StringUtils.isEmpty(message)) {
				return "";
			}
			
			Matcher matcher = TEXT_PATTERN.matcher(message);
			
			//치환된 문자열
			String trans = "";
			
			//변수 시작과 끝//${로시작하고 }로 끝난다.
			int begin = 0;
			int end = 0;
			while( matcher.find()) {
				end = matcher.start(0) - 2;
				trans += message.substring(begin, end);
				trans += map.getOrDefault(matcher.group(0), "");
				begin = matcher.end(0) + 1;
			}
			trans += message.substring(begin);
			return trans;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	
	/**
	 * 입력된 문자열에 변수를 paramMap에 있는 값으로 치환한다.
	 * @param paramMap
	 * @param text
	 * @return
	 */
	
	public String translateText(Map<String, Parameter> params, String message) {
	    if( StringUtils.isEmpty(message)) {
			return "";
		}
		
		Matcher matcher = TEXT_PATTERN.matcher(message);
		
		//치환된 문자열
		String trans = "";
		
		//변수 시작과 끝//${로시작하고 }로 끝난다.
		int begin = 0;
		int end = 0;
		while( matcher.find()) {
			end = matcher.start(0) - 2;
			trans += message.substring(begin, end);
			
			///
			String argument = matcher.group(0);
			if( isFunction(argument) ) {
				Object[] invokeParams = parse(argument);
				Parameter param;
				for( int i = 0; i < invokeParams.length; i++ ) {
					param = params.get(invokeParams[i]);
					if( param == null ) {
						continue;
					}
					
					invokeParams[i] = transParam(param);
				}
				trans += (String)scriptEngine.invokeFunction(
						(String)invokeParams[0], invokeParams);
			} else {
				Parameter param = params.get(argument);
				trans += transParam(param);
			}
/*			
			Parameter param = params.get(matcher.group(0));
			if( param != null ) {
				switch(param.getDataType()) {
				case "D" : 
					trans += USER_YYMMDDE.format((Date)param.getValue());
					break;
				case "DT" : 
					trans += USER_YYMMDDHHMM.format((Date)param.getValue());
					break;
				default :
					trans += StringUtils.isEmpty(param.getValue())?"" : param.getValue();
					break;
				}
			}
*/			begin = matcher.end(0) + 1;
		}
		trans += message.substring(begin);
		return trans;
	}
	
	public String translateLink(Map<String, Parameter> params, String message) {
	    if( StringUtils.isEmpty(message)) {
			return "";
		}
		
		Matcher matcher = TEXT_PATTERN.matcher(message);
		
		//치환된 문자열
		String trans = "";
		
		//변수 시작과 끝//${로시작하고 }로 끝난다.
		int begin = 0;
		int end = 0;
		while( matcher.find()) {
			end = matcher.start(0) - 2;
			trans += message.substring(begin, end);
			
			///
			String argument = matcher.group(0);
			if( isFunction(argument) ) {
				Object[] invokeParams = parse(argument);
				Parameter param;
				for( int i = 0; i < invokeParams.length; i++ ) {
					param = params.get(invokeParams[i]);
					if( param == null ) {
						continue;
					}
					
					invokeParams[i] = transParam(param);
				}
				trans += (String)scriptEngine.invokeFunction(
						(String)invokeParams[0], invokeParams);
			} else {
				Parameter param = params.get(argument);
				trans += transParam(param);
			}
/*			
			///
			Parameter param = params.get(matcher.group(0));
			if( param != null ) {
				switch(param.getDataType()) {
				case "D" : 
					trans += YYYYMMDD.format((Date)param.getValue());
					break;
				case "DT" : 
					trans += YYYYMMDDHHMM.format((Date)param.getValue());
					break;
				default :
					trans += StringUtils.isEmpty(param.getValue())?"" : param.getValue();
					break;
				}
			}
*/			begin = matcher.end(0) + 1;
		}
		trans += message.substring(begin);
		return trans;
	}
	
	private Object transParam(Parameter param) {
		if( param == null ) {
			return "";
		}
		
		switch(param.getDataType()) {
		case "D" : 
			return YYYYMMDD.format((Date)param.getValue());
		case "DT" : 
			return YYYYMMDDHHMM.format((Date)param.getValue());
		default :
			return StringUtils.isEmpty(param.getValue())?"" : param.getValue();
		}
	}
	private boolean isFunction(String invokeStr) {
		return FUNC_PATTERN.matcher(invokeStr).matches();
	}
	
	private String[] parse(String invokeStr) {
		Matcher fmatcher = FUNC_PATTERN.matcher(invokeStr);
		if( !fmatcher.matches())
		{
			return null;
		}
		
		String funcName = fmatcher.group(1);
		String paramStr   = fmatcher.group(2);
		
		String[] result = null;
		if( !StringUtils.isEmpty(paramStr) ) {
			String[] params = paramStr.split("\\s*,\\s*");
			result = new String[params.length + 1];
			result[0] = funcName;
			System.arraycopy(params, 0, result, 1, params.length);
		} else {
			result = new String[1];
			result[0] = funcName;
		}
		return result;
	}
	

}
