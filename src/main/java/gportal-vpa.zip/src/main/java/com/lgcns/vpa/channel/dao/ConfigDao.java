/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.lgcns.vpa.channel.model.config.LegacyConfig;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.model.config.PushConfigProperty;
import com.lgcns.vpa.channel.model.config.PushConfigPropertyValue;

/**
 * <pre>
 * 사용자 및 봇 설정 조회 Dao
 * </pre>
 * @author
 */
@Mapper
@Repository
public interface ConfigDao {
    /**
     * 봇 알림 설정 조회
     * 설정 정보가 없는 경우 PUSH 테이블에서 기본 값을 읽어온다.
     * @param userId
     * @param pushId
     * @return
     */
    PushConfig selectPushConfig(@Param("pushId") String pushId, @Param("userId") String userId);
    
    /**
     * 봇 알림 설정 목록 조회
     * 설정 정보가 없는 경우 PUSH 테이블에서 기본 값을 읽어온다.
     * @param botId
     * @param userId
     * @param NotiTypeCode
     * @return
     */
    // List<PushConfig> selectPushConfigList(@Param("botId") String botId, @Param("userId") String userId, @Param("pushTypeCode") String pushTypeCode);
    List<PushConfig> selectPushConfigList(PushConfig searchCondition);
    
    /**
     * 봇 알림 설정 생성 필요 여부 확인
     * @param botId
     * @param userId
     * @return
     */
    Boolean isUserNeedToCreatePushConfig(@Param("botId") String botId, @Param("userId") String userId);
    
    /**
     * 봇 알림 설정 등록
     * @param botId
     * @param userId
     * @return
     */
    void insertPushConfig(PushConfig pushConfig);
    
    /**
     * 봇 알림 설정 삭제
     * @param botId
     * @param userId
     */
    void deletePushConfigsByBotId(@Param("botId") String botId, @Param("userId") String userId);
    
    /**
     * 봇 알림 전체 미사용 여부 확인
     * @param botId
     * @param userId
     * @param pushTypeCode
     * @return
     */
    Boolean selectNotUsedByPushTypeCode(@Param("botId") String botId, @Param("userId") String userId, @Param("pushTypeCode") String pushTypeCode);
    
    /**
     * 봇 알림 속성 목록 조회
     * @param userId
     * @param pushId
     * @return
     */
    List<PushConfigProperty> selectPushConfigPropertyList(@Param("userId") String userId, @Param("pushId") String pushId);
    
    /**
     * 알림 속성의 코드 목록 조회(코드, 값)
     * @param pushId
     * @param propertyId
     * @return
     */
    List<PushConfigPropertyValue> selectPushPropertyValueList(@Param("pushId") String pushId, @Param("propertyId") String propertyId);
    
    /**
     * 봇 알림 속성 설정 삭제
     * @param userId
     * @param pushId
     */
    void deletePushConfigPropertyByPushId(@Param("userId") String userId, @Param("pushId") String pushId);
    
    
    /**
     * 봇 알림 속성 설정 삭제
     * @param userId
     */
    void deletePushConfigPropertyByUserId(@Param("userId") String userId);
    
    /**
     * 봇 알림 속성 설정 등록
     * @param pushConfigProperty
     */
    void insertPushConfigProperty(PushConfigProperty pushConfigProperty);
    
    /**
     * 봇 알림 속성 설정 등록
     * @param pushConfigProperty
     */
   // void insertPushConfigPropertyNew( @Param("list") Map<String,Object>  list);
    
    
      void insertPushConfigPropertyNew( @Param("list") List<PushConfigProperty> list);
    /**
     * 알림 상세 정보 조회
     * @param pushId
     * @param ip
     * @return
     */
    PushConfig selectPushDetail(@Param("pushId") String pushId, @Param("ip") String ip);
    
    /**
     * 알림 사용자 목록 조회
     * @param params
     * @return
     */
    List<PushConfig> selectPushConfigAllUserList(@Param("pushId") String pushId, @Param("userId") String userId);
    
    /**
     * 알림 속성 사용자 목록 조회
     * @param params
     * @return
     */
    List<PushConfigProperty> selectPushConfigPropertyAllUserList(@Param("pushId") String pushId, @Param("userId") String userId, @Param("propertyId") String propertyId);
 
    /**
     * 알림 설정 초기값 생성
     * @param botId
     * @param userId
     */
    void createPushConfig(@Param("botId") String botId, @Param("userId") String userId);
    
    /**
     * 알림 속성 초기값 생성
     * @param botId
     * @param userId
     */
    void createPushConfigProperty(@Param("botId") String botId, @Param("userId") String userId);
    
    
    /**
     * 레가시 조회
     * @param botId
     * @param legacyCode
     * @param legacyTypeCode
     * @return
     */
    LegacyConfig selectLegacyConfig(@Param("legacyCode") String legacyCode, @Param("legacyTypeCode") String legacyTypeCode);
    
    /**
     * 레가시 정보(리스트) 조회
     * @param legacyCode
     * @return
     */
    List<LegacyConfig> selectLegacyConfigList(@Param("legacyCode") String legacyCode);
}
