package com.lgcns.vpa.push.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import com.lgcns.vpa.channel.model.Conversation;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.config.LegacyConfig;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.SmsSendService;


/**
 * <pre>
 * SMS Send Service
 * </pre>
 * @author
 */
@Service("multi.smsSendService")
public class SmsSendServiceImpl extends PushAbstractService implements SmsSendService {
	
    @Autowired
    RedisMessagePublisher redisMessagePublisher;
    
    @Autowired
	ActivityService activityService;
    
    @Autowired
    ConfigService configService;
    
    @Autowired
    private MongoTemplate mongoTemplate;
    
   
    @Override
    public Map<String, String>  execute(Map<String, Object> params, String tenantId){
    	
    	Map<String, String> resultMap = new HashMap<String, String>();
    	
    	String legacyCode="SMS";
    	List<LegacyConfig> smsLegacyList=configService.retrieveLegacyConfigList(legacyCode);
    	String ACTION_URI_USER = "";
    	String ACTION_URI_GROUP = "";
    	for( LegacyConfig legacyConfig : smsLegacyList ) {
    		if(legacyConfig.getLegacyTypeCode().equals("USER")){
    			ACTION_URI_USER=legacyConfig.getActionUri();
    		}else if(legacyConfig.getLegacyTypeCode().equals("GROUP")){
    			ACTION_URI_GROUP=legacyConfig.getActionUri();
    		}
    	}
    	
    	//System.out.println("############sms ACTION_URI_USER:"+ACTION_URI_USER);
    	//System.out.println("############sms ACTION_URI_GROUP:"+ACTION_URI_GROUP);
    	
    	String actionType=(String) params.get("actionType"); //actionType:user,group
		String toGroup=(String) params.get("toGroup");       //그룹 아이디 
		TransferSyncVO transferSyncVO =  new TransferSyncVO();
		if(actionType.equals("user")){
			transferSyncVO.setActionUri(ACTION_URI_USER);
			transferSyncVO.setTenantId(tenantId);
		}else if(actionType.equals("group")){
			transferSyncVO.setActionUri(ACTION_URI_GROUP);
			transferSyncVO.setTenantId(tenantId);
		}
		transferSyncVO.setActionParam(params);
		
		
		String target=(String) params.get("target");
		
		String message="";
		if(actionType.equals("user")){
			
			if(target.equals("save")){
				List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
				
				
				if(proxyResultSet != null){
					
					message=(String) params.get("toUserName")+" 님께  다음과 같이 문자 발송 완료! <br><br>  "	+ "" + (String) params.get("content")+"  ";
					resultMap.put("RESULT", "OK");
					resultMap.put("message", message);
				}
				else{
					message=(String) params.get("toUserName")+" 님께 문자 발송 도중 에러가 발생했습니다.다시 확인해 주세요 ";
					resultMap.put("RESULT", "FAIL");
					resultMap.put("message", message);
					//문자 발송이 취소되었습니다.	발송 취소는 로그아웃, 닫기 클릭 시, 새로고침 했을 경우 취소됩니다.
				}
				
			}else if(target.equals("cancel")){
				message=(String) params.get("toUserName")+" 님께 문자 발송이  취소되었습니다";
				resultMap.put("RESULT", "FAIL");
				resultMap.put("message", message);
				
			}
			
			
		}else if(actionType.equals("group")){
			
			if(target.equals("save")){
				List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
				
				 //System.out.println("#############group result:"+proxyResultSet);
				 //#############group result:[{RET=41}]
				 String sendCount="";
				if(proxyResultSet != null){
					for (Map<String, Object> proxyResult : proxyResultSet) {
						sendCount = ( proxyResult.get("RET") != null ) ? String.valueOf(proxyResult.get("RET")) : "0";
					}
					
					
					message=(String) params.get("toGroupName")+" 그룹의 "+sendCount+ " 명에게  다음과 같이 문자 발송 완료! <br><br>  "	+ "" + (String) params.get("content")+"  ";
					resultMap.put("RESULT", "OK");
					resultMap.put("message", message);
				}
				else{
					message=(String) params.get("toGroupName")+" 그룹 문자 발송 도중 에러가 발생했습니다.다시 확인해 주세요 ";
					resultMap.put("RESULT", "FAIL");
					resultMap.put("message", message);
					//문자 발송이 취소되었습니다.	발송 취소는 로그아웃, 닫기 클릭 시, 새로고침 했을 경우 취소됩니다.
				}
				
			}else if(target.equals("cancel")){
				message=(String) params.get("toGroupName")+" 그룹 문자 발송이  취소되었습니다";
				resultMap.put("RESULT", "FAIL");
				resultMap.put("message", message);
				
			}
		}
		
		
		
		
		//replyToId 로 업뎃 시작
		String replyToId=(String) params.get("replyToId");
		if (!StringUtils.isEmpty(replyToId)) {
			Query query = new Query();
			query.addCriteria(new Criteria("replyToId").is(replyToId));
	
			Update update = new Update();
			update.set("message", message);
			update.set("sentDate", new Date());
			update.set("updateDate", new Date());
			update.set("attachments", "");
	
			this.mongoTemplate.updateFirst(query, update, Activity.class);
		}
		//replyToId 로 업뎃 끝
		
		return resultMap;
	}
	
}
