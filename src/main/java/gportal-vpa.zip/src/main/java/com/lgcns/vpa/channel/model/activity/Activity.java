/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.activity;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseDocument;

/**
 * <pre>
 *  액티비티 Model
 * </pre>
 * @author
 */
@Document(collection="activities")
@JsonInclude(JsonInclude.Include.NON_NULL)
@CompoundIndexes({
    @CompoundIndex(name = "activities_idx1", def = "{'userId': 1, 'botId': 1, 'sentDate' : -1}")
})
public class Activity extends BaseDocument implements Cloneable {

	private static final long serialVersionUID = 4220461820168818967L;
		
    /**
     * 원본 ID (회신 메시지인 경우)
     */
    private String replyToId;

    /**
     * 임시 ID (UI 에서 생성)
     */
    
    private String tempId;

    /**
     * 유형
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String type;

    /**
     * 세부유형
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String subtype;
    
    /**
     * 메시지 텍스트 (순수 텍스트)
     */
    private String message;
    
    /**
     * 유의어 처리 전 사용자 질의문 원본
     */
    private String preSynonymMessage;
    
    /**
     * 메시지 이미지
     */
    private String imageSrc;
    
    /**
     * 애니메이션
     */
    private String animation;
    
    @Transient
    private String animationTitle;
    
    @Transient
    private String animationContent;
    
    @Transient
    private int animationTimeout;
    
    /**
     * 메시지 텍스트 (포맷적용)
     */
    private String formattedMessage;

    /**
     * 발신자 유형 (user: 사용자, bot: 봇, system: 사용자)
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String senderType;
    
    /**
     * 메시지 발신일시
     */
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private Date sentDate;    
    
    /**
     * 사용자 ID
     */
    private String userId;
    
    /**
     * 사용자 명
     */
    private String userName;
    
    /**
     * 봇 ID
     */
    private String botId;

    /**
     * 봇 명
     */
    private String botName;
     
    /**
     * 데이터 Attachment (카드, 리스트 등의 UI 컴포넌트가 적재됨)
     */
    private List<Attachment> attachments;

    /**
     * 데이터 Attachment 레이아웃
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String attachmentLayout;
    
    /**
     * 버튼 리스트
     */
    private List<Button> buttons;

    /**
     * 사용자 IP
     */
    private String userIp;

    /**
     * 채널 디바이스 유형
     */
    private String deviceType;
    
    // 좋아요
    
    /**
     * 좋아요 (Y: 좋아요, N: 싫어요, '': 평가안함)
     */
    private String like;
    
    /**
     * 좋아요 등록일시
     */
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private Date likeDate;   
    
    /**
     * 좋아요 피드백
     */
    private String feedback;
    
    /**
     * 좋아요 피드백 등록일시
     */
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private Date feedbackDate;       
    
    /**
     * 좋아요 피드백 타입
     */
    private String feedbackType;
    
    /**
     * 유저 구분(일반/리더/임원)
     */
    private int leader;
    
	/**
     * 삭제 여부
     */
    private String delYn;
    
    /**
     * 삭제 등록 일시
     */
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private Date delDate; 
    
    /**
     * 확장 속성
     */
    private Map<String, Object> additionalProperties;
    
    /**
     * 액션 파라미터 (재질의 등에 이용)
     */
    @Transient
    private Map<String, Object> actionParams;
    
    /**
     * 개발기간동안 인텐트 분석 및 다이얼로그 핸들러 처리결과 표시를 위한 필드
     */
    @Transient
    private String intentLog;
    
    /**
     * 인텐트 아이디(좋아요/싫어요 의도별 분석)
     */
    private String intentId;
    
    /**
     * 인텐트 타입
     * case '0' : "인사"
	 * case '1' : "조회"
	 * case '2' : "등록"
	 * case '3' : "질의응답"
     */
    private String intentType;
    
    /**
     * 응답에 걸린 시간
     */
    private long spentTime;
    
    /**
     * 의도분석 서버와 연동에 걸린 시간
     */
    private long spentTimeIntent;
    
    /**
     * Proxy 연동에 걸린 시간
     */
    private long spentTimeProxy;
    
    /**
     * 전처리에 걸린 시간
     */
    private long spentTimePreIntent;
    
    /**
     * 메시지 request텍스트 (request 텍스트)
     */
    private String requestMessage;
    
    
    /**
     *  메시지 request 발신일시
     */
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private Date requestSentDate;  
    
    @Transient
    private String dialogLog;
    
    /**
     * 일 최초 실시간 데일리 푸시여부 (true: 데일리 푸시, false: 대화이력)
     */
    @Transient
    private boolean firstDailyPush;
    
    public String getReplyToId() {
        return replyToId;
    }

    public void setReplyToId(String replyToId) {
        this.replyToId = replyToId;
    }

    public String getTempId() {
        return tempId;
    }

    public void setTempId(String tempId) {
        this.tempId = tempId;
    }

    public String getType() {
        return type;
    }

    public Date getRequestSentDate() {
		return requestSentDate;
	}

	public void setRequestSentDate(Date requestSentDate) {
		this.requestSentDate = requestSentDate;
	}

	public void setType(String type) {
        this.type = type;
    }

    public String getSubtype() {
        return subtype;
    }

    public void setSubtype(String subtype) {
        this.subtype = subtype;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getPreSynonymMessage() {
		return preSynonymMessage;
	}

	public void setPreSynonymMessage(String preSynonymMessage) {
		this.preSynonymMessage = preSynonymMessage;
	}

	public String getAnimation() {
        return animation;
    }

    public void setAnimation(String animation) {
        this.animation = animation;
    }
    
    public String getAnimationTitle() {
        return animationTitle;
    }

    public void setAnimationTitle(String animationTitle) {
        this.animationTitle = animationTitle;
    }

    public String getAnimationContent() {
        return animationContent;
    }

    public void setAnimationContent(String animationContent) {
        this.animationContent = animationContent;
    }

    public int getAnimationTimeout() {
        return animationTimeout;
    }

    public void setAnimationTimeout(int animationTimeout) {
        this.animationTimeout = animationTimeout;
    }

    public String getFormattedMessage() {
        return formattedMessage;
    }

    public void setFormattedMessage(String formattedMessage) {
        this.formattedMessage = formattedMessage;
    }

    public String getImageSrc() {
        return imageSrc;
    }

    public void setImageSrc(String imageSrc) {
        this.imageSrc = imageSrc;
    }

    public String getSenderType() {
        return senderType;
    }

    public void setSenderType(String senderType) {
        this.senderType = senderType;
    }

    public String getUserIp() {
        return userIp;
    }

    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }
    
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public String getBotName() {
        return botName;
    }

    public void setBotName(String botName) {
        this.botName = botName;
    }

    public String getIntentLog() {
        return intentLog;
    }

    public void setIntentLog(String intentLog) {
        this.intentLog = intentLog;
    }

    public String getDialogLog() {
        return dialogLog;
    }

    public void setDialogLog(String dialogLog) {
        this.dialogLog = dialogLog;
    }

    public String getAttachmentLayout() {
        return attachmentLayout;
    }

    public void setAttachmentLayout(String attachmentLayout) {
        this.attachmentLayout = attachmentLayout;
    }

    public List<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }

    public Activity addAttachments(List<Attachment> attachments) {
        if (this.attachments == null) {
            this.attachments = new ArrayList<>();
        }
        this.attachments.addAll(attachments);
        return this;
    }

    public Activity addAttachment(Attachment attachment) {
        if (this.attachments == null) {
            this.attachments = new ArrayList<>();
        }
        this.attachments.add(attachment);
        return this;
    }
    
    public Attachment findAttachmentFirst () {
    	if ( (this.attachments == null) || (this.attachments.isEmpty()) ) {
    		return null;
    	}
    	
    	return this.attachments.get(0);
    }

    public List<Button> getButtons() {
        return buttons;
    }

    public void setButtons(List<Button> buttons) {
        this.buttons = buttons;
    }

    public Activity addButton(Button button) {
        if (this.buttons == null) {
            this.buttons = new ArrayList<Button>();
        }
        this.buttons.add(button);
        return this;
    }
    
    public Activity addButton(int position, Button button) {
        if (this.buttons == null) {
            this.buttons = new ArrayList<Button>();
        }
        
        position = (position >= this.buttons.size()) ? this.buttons.size() : position;
        position = (position < 0) ? 0 : position; 
        
        this.buttons.add(position, button);
        return this;
    }
    
    public String getLike() {
        return like;
    }

    public void setLike(String like) {
        this.like = like;
    }
    
    public Date getLikeDate() {
        return likeDate;
    }

    public void setLikeDate(Date likeDate) {
        this.likeDate = likeDate;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
    
    public Date getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(Date feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    public Map<String, Object> getAdditionalProperties() {
        return additionalProperties;
    }

    public void setAdditionalProperties(Map<String, Object> additionalProperties) {
        this.additionalProperties = additionalProperties;
    }

    public long getSpentTime() {
		return spentTime;
	}

	public void setSpentTime(long spentTime) {
		this.spentTime = spentTime;
	}
	
	public long getSpentTimeIntent() {
		return spentTimeIntent;
	}

	public void setSpentTimeIntent(long spentTimeIntent) {
		this.spentTimeIntent = spentTimeIntent;
	}

	public long getSpentTimeProxy() {
		return spentTimeProxy;
	}

	public void setSpentTimeProxy(long spentTimeProxy) {
		this.spentTimeProxy = spentTimeProxy;
	}

	public long getSpentTimePreIntent() {
		return spentTimePreIntent;
	}

	public void setSpentTimePreIntent(long spentTimePreIntent) {
		this.spentTimePreIntent = spentTimePreIntent;
	}

	public Activity addAdditionalProperty(String key, Object value) {
        if (this.additionalProperties == null) {
            this.additionalProperties = new HashMap<>();
        }
        this.additionalProperties.put(key, value);
        return this;
    }
    
    public Map<String, Object> getActionParams() {
        return actionParams;
    }

    public void setActionParams(Map<String, Object> actionParams) {
        this.actionParams = actionParams;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this).toString();
    }
    
    /**
     * 봇 메시지 생성
     * @param botId
     * @param userId
     * @return
     */
    public static Activity createBotMessage(String botId, String userId) {
        return Activity.createActivity(ActivityCode.ACTIVITY_TYPE_MESSAGE, ActivityCode.SENDER_TYPE_BOT, userId, botId);
    }
    
    /**
     * 사용자 메시지 생성
     * @param botId 
     * @param userId
     * @return
     */
    public static Activity createUserMessage(String botId, String userId) {
        return Activity.createActivity(ActivityCode.ACTIVITY_TYPE_MESSAGE, ActivityCode.SENDER_TYPE_USER, userId, botId);
    }
    
    public static Activity createActivity(String type, String senderType, String userId, String botId) {
        Date date = new Date();
        return new Activity() {
            {
                this.setType(type);
                this.setSenderType(senderType);
                this.setUserId(userId);
                this.setBotId(botId);
                this.setSentDate(date);
                
                this.setRegisterId(userId);
                this.setRegistDate(date);
                this.setUpdaterId(userId);
                this.setUpdateDate(date);
            }
        };
    }    

	public String getDelYn() {
		return delYn;
	}

	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}

	public Date getDelDate() {
		return delDate;
	}

	public void setDelDate(Date delDate) {
		this.delDate = delDate;
	}

	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}
	
	public String getIntentType() {
		return intentType;
	}

	public void setIntentType(String intentType) {
		this.intentType = intentType;
	}

	public String getFeedbackType() {
		return feedbackType;
	}

	public void setFeedbackType(String feedbackType) {
		this.feedbackType = feedbackType;
	}

    public boolean isFirstDailyPush() {
        return firstDailyPush;
    }

    public void setFirstDailyPush(boolean firstDailyPush) {
        this.firstDailyPush = firstDailyPush;
    }

	public int getLeader() {
		return leader;
	}

	public void setLeader(int leader) {
		this.leader = leader;
	}

	public String getRequestMessage() {
		return requestMessage;
	}

	public void setRequestMessage(String requestMessage) {
		this.requestMessage = requestMessage;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	
}
