/* ------------------------------------------------------------------------------
 * Project       : NextEP Project
 * Source        : ReasonData.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * R&D 의도 추론 결과 binding bean
 * @author 70399
 *
 */
public class ReasonData {
	private String intentId;
	private String intentName;
	
	//@JsonDeserialize(using = EntityDeserializer.class)
	private Map<String, List<String>> entity;
	//private double typeScore;
	
	@JsonDeserialize(using = ScoreDeserializer.class)
	private List<Score> intentScore;

	
	public String getIntentId() {
		return intentId;
	}
	
	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}
	
	public String getIntentName() {
		return intentName;
	}
	
	public void setIntentName(String intentName) {
		this.intentName = intentName;
	}
	
	public Map<String, List<String>> getEntity() {
		return entity;
	}
	
	public void setEntity(Map<String, List<String>> entity) {
		this.entity = entity;
	}
/*	@JsonAnySetter
	public void addEntity(String name, String value) {
		this.entity.put(name, value);
	}
/*	public double getTypeScore() {
		return typeScore;
	}
	public void setTypeScore(double typeScore) {
		this.typeScore = typeScore;
	}
*/
	
	public List<Score> getIntentScore(final double minScore) {
		
		if( intentScore != null ) {
			return intentScore.stream().filter(new Predicate<Score>() {
					@Override
					public boolean test(Score score) {
						return minScore < score.getScore();
					}
			}).collect(Collectors.toList());
		}
		return intentScore;
	}
	
	public void setIntentScore(List<Score> intentScore) {
		this.intentScore = intentScore;
	}
	
	public String toString() {
		
		return String.format("intentId : %s intentName : %s entity : %s intentScore : %s", 
				this.intentId, this.intentName, this.entity, this.intentScore);
	}
}
