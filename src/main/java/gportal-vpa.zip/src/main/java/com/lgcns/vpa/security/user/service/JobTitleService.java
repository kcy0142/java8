package com.lgcns.vpa.security.user.service;

import java.util.List;

import com.lgcns.vpa.security.user.model.JobTitle;

public interface JobTitleService {
	/**
	 * Job Title 목록 조회
	 * @param botId
	 * @return
	 */
    public List<JobTitle> selectAllJobTitle(String botId);
}
