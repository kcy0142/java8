/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.security.authentication.model;

import com.lgcns.vpa.security.user.model.User;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * <pre>
 * 사용자 인증 정보
 * </pre>
 * @author
 */
public class UserDetailsImpl implements UserDetails {
	private static final long serialVersionUID = 3662825745382751962L;

	/**
	 * 테넌트 ID
	 */
	private String tenantId;
	
	/**
	 * 사용자 객체
	 */
	private final User user;
	
	/**
	 * 권한
	 */
	private final List<SimpleGrantedAuthority> authorities;

    public UserDetailsImpl(User user, String tenantId) {
        this(user, Arrays.asList(new SimpleGrantedAuthority("ROLE_USER")), tenantId);
    }

    public UserDetailsImpl(User user, List<SimpleGrantedAuthority> authorities, String tenantId) {
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        } else {
            this.user = user;
            this.authorities = authorities;
            this.tenantId = tenantId;
        }
    }
    
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return "";
    }

    @Override
    public String getUsername() {
        return user.getUserId();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public User getUser() {
        return user;
    }

    public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	@Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this);
    }
}
