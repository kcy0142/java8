/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentRestException.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.exception;

public class IntentException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * request timeout
	 */
	public static final String ERROR_NLU_CALL  = "error_nlu_call";
	
	/**
	 * nlu service error
	 */
	public static final String ERROR_NLU_SERVER = "error_nlu_server";
	
	public static final String ERROR_ENTITY_TRAN= "error_entity_trans";
	
	private String errorCode;
	
	public IntentException(String message) {
		super(message);
	}
	
	public IntentException(String code, String message) {
		super(message);
		this.errorCode = code;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
}
