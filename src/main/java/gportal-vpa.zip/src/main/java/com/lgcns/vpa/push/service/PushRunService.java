/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : PushRunService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.dialog.service.DialogHandlerService;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.web.PushController;
import com.lgcns.vpa.security.user.model.User;

@Service("multi.pushRunService")
public class PushRunService {
	
	final Logger logger = LoggerFactory.getLogger(PushRunService.class);
	@Autowired
    private MessageSource messageSource;
	
	@Autowired
    private RedisMessagePublisher redisMessagePublisher;
	
	@Autowired
    private DialogHandlerService dialogHandlerService;
    
	@Autowired
    private UserAutoRunService userAutoRunService;
	
    @Autowired
    private TargetInfoService targetInfoService;
	
	/**
     * 메세지 타입 Push 처리
     * @param params
     * @param tenantId
     * @param isAllEmployee
     */
    @Async("threadPoolTaskExecutor")
    public void messageTypeSend(Map<String, String> params, String tenantId, boolean isAllEmployee) {   	
    	if ( (params == null) || (params.isEmpty()) || (StringUtils.isEmpty(tenantId)) ) {
    		return;
    	}
    	
    	String botId = params.get("botId");
    	String message = params.get("message");
    	String targetGroupIds = params.get("targetGroupIds");
    	
    	//TenantId 지정
    	DataSourceKeyHolder.setDataSourceKey(tenantId);
    	logger.info("########tenantId : {}", DataSourceKeyHolder.getDataSourceKey());
    	
    	//모든 임직원 대상 처리
    	if (isAllEmployee) {
    		Activity activity = createPushActivity(botId, "ALL", null, message);
			redisMessagePublisher.publish(activity);
    	}
    	//지정된 임직원 대상 처리
    	else {
    		//수신 대상자 그룹 정보 처리
        	String [] targetGroupIdArry = targetGroupIds.split(",");
        	
        	//Target 정보를 조회하기 위한 Parameter
        	Map<String, Object> daoParam = new HashMap<String, Object>();
        	daoParam.put("botId", botId);
        	daoParam.put("targetGroupIdList", targetGroupIdArry);
        	
        	List<User> targetUserList = this.targetInfoService.getTargetUserList(daoParam);
        	
        	if ( (targetUserList != null) && (!targetUserList.isEmpty()) ) {
				for ( User targetUser : targetUserList) {
					
					// WebSocket Session 이 유효한 경우에만 메세지 전송
    				if ( this.userAutoRunService.isWebSocketAlive(targetUser.getUserId()) ) {
    					Activity activity = createPushActivity(botId, targetUser.getUserId(), null, this.resMsgGenerator(message, targetUser));
    	    			redisMessagePublisher.publish(activity);
    				}
				}//for
			}
    	}
    }
    
    /**
     * 의도 타입 Push 처리
     * @param params
     * @param tenantId
     * @param isAllEmployee
     */
    @Async("threadPoolTaskExecutor")
    public void intentTypeSend(Map<String, String> params, String tenantId, boolean isAllEmployee) {
    	
    	if ( (params == null) || (params.isEmpty()) || (StringUtils.isEmpty(tenantId)) ) {
    		return;
    	}
    	
    	String botId = params.get("botId");
    	String message = params.get("message");
    	String type = params.get("type");
    	String inquiry = params.get("inquiry");
    	String targetGroupIds = params.get("targetGroupIds");
    	
    	//TenantId 지정
    	DataSourceKeyHolder.setDataSourceKey(tenantId);
        
        //의도 실행 타입인데 질의문이 없으면 리턴
    	if ( "1".equals(type) && StringUtils.isEmpty(inquiry) ) {
    		return;
    	}
    	
    	//수신 대상자 그룹 정보 처리
    	String [] targetGroupIdArry = targetGroupIds.split(",");
    	
    	//Target 정보를 조회하기 위한 Parameter
    	Map<String, Object> daoParam = new HashMap<String, Object>();
    	daoParam.put("botId", botId);
    	daoParam.put("targetGroupIdList", targetGroupIdArry);
    	
    	List<User> targetUserList = null;
    	
    	//모든 임직원 목록 조회
    	if (isAllEmployee) {
    		targetUserList = this.targetInfoService.getAllTargetUserList();
    	}
    	//지정된 임직원 목록 조회
    	else {
    		targetUserList = this.targetInfoService.getTargetUserList(daoParam);
    	}
    	
    	//대상자별 의도 실행
    	if ( (targetUserList != null) && (!targetUserList.isEmpty()) ) {
	    	Activity reqActivity = null, responseActivity = null;
	    	boolean isFirstRun = true, isRepeateInquiry = false;
	    	
			//TODO 사용자별 의도 실행 후 결과를 메세지로 전달
			for ( User targetUser : targetUserList ) {
				
				// WebSocket Session 이 유효한 경우에만 의도 실행
				if ( this.userAutoRunService.isWebSocketAlive(targetUser.getUserId()) ) {
					
					//최초 사용자의 의도를 분석하여 
					//의도가 인사, 질의응답, 전처리 결과이면 의도분석을 반복적으로 하지않고 응답 Activity를 재사용함
					//그 이외의 의도이면 반복적으로 의도분석을 계속함
					if ( isFirstRun ) {
						reqActivity = createPushIntentActivity(botId, targetUser.getUserId(), null, inquiry);
						responseActivity = dialogHandlerService.syncInquiry(reqActivity, targetUser, tenantId);
						
						if ( (responseActivity != null) && 
							 (("3".equals(responseActivity.getIntentType())) || 
							  ("0".equals(responseActivity.getIntentType())) ||
							  ("pre".equals(responseActivity.getSubtype()))) ) {
							isRepeateInquiry = true;
						}
						
						isFirstRun = false;
					}
					
					//Intent 가 질의응답이면
					if ( isRepeateInquiry ) {
						
						try {
							Activity responseActivityClone = (Activity) responseActivity.clone();
							this.intentTypeAction(reqActivity, targetUser, message, tenantId, responseActivityClone);
						} catch (Exception e) {
							
						}
					}
					else {
						reqActivity = createPushIntentActivity(botId, targetUser.getUserId(), null, inquiry);
						this.intentTypeAction(reqActivity, targetUser, message, tenantId);
					}
				}
			}//for
    	}
    }
    
    /**
     * push용 Activity 객체 생성
     * @param botId
     * @param userId
     * @param localeCode
     * @param message
     * @return
     */
    public Activity createPushActivity(String botId, String userId, String localeCode, String message){
    	Date date = new Date();
		Activity activity = new Activity();
		activity.setTempId(UUID.randomUUID().toString());
        activity.setBotId(botId);
        activity.setUserId(userId);
        activity.setSenderType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH);
		activity.setSentDate(date);
		activity.setUpdateDate(date);
		activity.setMessage(message);
		
		//default locale code setting
		if(StringUtils.isEmpty(localeCode)){
			localeCode=ActivityCode.DEFAULT_LOCALE_CODE;
		}
		
		List<Button> buttons = new ArrayList<Button>();
		Button button = new Button();
		button.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
		button.setAction("setting");
		button.setTitle(messageSource.getMessage("meesage.push.setting", null, new Locale(localeCode)));
		button.setIcon("fa-bell");
		buttons.add(button);
	
		activity.setButtons(buttons);
		
		return activity;		
    }
    
    /**
     * 자동 의도 실행형 Activity 생성
     * @param botId
     * @param userId
     * @param localeCode
     * @param message
     * @return
     */
    public Activity createPushIntentActivity (String botId, String userId, String localeCode, String message) {
    	Date date = new Date();
		Activity activity = new Activity();
		
		activity.setTempId(UUID.randomUUID().toString());
        activity.setBotId(botId);
        activity.setUserId(userId);
        activity.setSenderType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH);
		activity.setSentDate(date);
		activity.setUpdateDate(date);
		activity.setMessage(message);
		
		//default locale code setting
		if(StringUtils.isEmpty(localeCode)){
			localeCode=ActivityCode.DEFAULT_LOCALE_CODE;
		}
		
		return activity;
    }
    
    /**
     * Notification 에 지정된 Message를 응답용 메세지로 치환함
     * @param msg
     * @param user
     * @return
     */
    private String resMsgGenerator ( String msg, User user ) {
    	
    	if ( StringUtils.isEmpty(msg) || (user == null) ) {
    		return null;
    	}
    	
    	final String NAME = "${userName}", JOB_TITLE = "${jobTitle}", FIRST_NAME = "${firstName}";
    	String msgResult = msg;
    	
    	if ( msg.contains(NAME) ) {
    		msgResult = msgResult.replace(NAME, user.getUserName());
    	}
    	
    	if ( msg.contains(JOB_TITLE) ) {
    		msgResult = msgResult.replace(JOB_TITLE, user.getJobTitleName());
    	}

		if ( msg.contains(FIRST_NAME) ) {
			msgResult = msgResult.replace(NAME, StringUtils.getFirstNameKor(user.getUserName()));
		}
		
		return msgResult;
    }
    
    private void intentTypeAction ( Activity reqActivity, User targetUser, String message, String tenantId) {
    	this.intentTypeAction(reqActivity, targetUser, message, tenantId, null);
    }
    
    private void intentTypeAction ( Activity reqActivity, User targetUser, String message, String tenantId, Activity responseActivity ) {
    	
    	Activity activity = null;
    	
    	if ( responseActivity == null ) {
    		activity = dialogHandlerService.syncInquiry(reqActivity, targetUser, tenantId);
    	}
    	else {
    		activity = responseActivity;
    	}
		
		//의도 분석이 완료 되었을 경우만 발송
		if ( (activity != null) && (!ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_ERROR.equals(activity.getSubtype())) ) {
			
			activity.setId(reqActivity.getId());
			activity.setUserId(targetUser.getUserId());
			activity.setSenderType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
			activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH);
			activity.setSentDate(reqActivity.getSentDate());
			activity.setUpdateDate(reqActivity.getUpdateDate());
			
			StringBuffer msgBuf = new StringBuffer();
			msgBuf.append(activity.getMessage()).append("\n\n");
			msgBuf.append(this.resMsgGenerator(message, targetUser));
			
			activity.setMessage(msgBuf.toString());
			
			redisMessagePublisher.publish(activity);
		}
    }
}
