/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : MessageUtils.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.intent.model.IntentMongo.Parameter;
import com.lgcns.vpa.intent.translator.TranslateScriptEngine;

@Component
public class MessageUtils {
	private static final SimpleDateFormat USER_YYMMDDE = new SimpleDateFormat("M월 d일 E요일", Locale.KOREAN);
	private static final SimpleDateFormat USER_YYMMDDHHMM = new SimpleDateFormat("M월 d일 E요일 HH시 mm분", Locale.KOREAN);
	
	private static final SimpleDateFormat YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
	private static final SimpleDateFormat YYYYMMDDHHMM = new SimpleDateFormat("yyyyMMddHHmm");
	/**
	 * 단순 메시지를 치환하기 위한 문자열 패턴으로
	 * $user.name $date.yyyymmdd 일정을 알려드립니다.
	 */
	//private static final Pattern TEXT_PATTERN = Pattern.compile("(?i)(?<=\\$).*?(?=(\\$|\\s|$))");
	private static final Pattern TEXT_PATTERN = Pattern.compile("(?i)(?<=\\$\\{).*?(?=(\\}))");
	
	public static String translateText(String jsonStr, String message) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			Map<String, Object> map = mapper.readValue(jsonStr, new TypeReference<Map<String, Object>>(){});
			
			if( StringUtils.isEmpty(message)) {
				return "";
			}
			
			Matcher matcher = TEXT_PATTERN.matcher(message);
			
			//치환된 문자열
			String trans = "";
			
			//변수 시작과 끝//${로시작하고 }로 끝난다.
			int begin = 0;
			int end = 0;
			while( matcher.find()) {
				end = matcher.start(0) - 2;
				trans += message.substring(begin, end);
				trans += map.getOrDefault(matcher.group(0), "");
				begin = matcher.end(0) + 1;
			}
			trans += message.substring(begin);
			return trans;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	
	/**
	 * 입력된 문자열에 변수를 paramMap에 있는 값으로 치환한다.
	 * @param paramMap
	 * @param text
	 * @return
	 */
	
	public static String translateText(Map<String, Parameter> params, String message) {
	    if( StringUtils.isEmpty(message)) {
			return "";
		}
		
		Matcher matcher = TEXT_PATTERN.matcher(message);
		
		//치환된 문자열
		String trans = "";
		
		//변수 시작과 끝//${로시작하고 }로 끝난다.
		int begin = 0;
		int end = 0;
		while( matcher.find()) {
			end = matcher.start(0) - 2;
			trans += message.substring(begin, end);
			
			Parameter param = params.get(matcher.group(0));
			if( param != null ) {
				switch(param.getDataType()) {
				case "D" : 
					trans += USER_YYMMDDE.format((Date)param.getValue());
					break;
				case "DT" : 
					trans += USER_YYMMDDHHMM.format((Date)param.getValue());
					break;
				default :
					trans += StringUtils.isEmpty(param.getValue())?"" : param.getValue();
					break;
				}
			}
			begin = matcher.end(0) + 1;
		}
		trans += message.substring(begin);
		return trans;
	}
	
	public static String translateLink(Map<String, Parameter> params, String message) {
	    if( StringUtils.isEmpty(message)) {
			return "";
		}
		
		Matcher matcher = TEXT_PATTERN.matcher(message);
		
		//치환된 문자열
		String trans = "";
		
		//변수 시작과 끝//${로시작하고 }로 끝난다.
		int begin = 0;
		int end = 0;
		while( matcher.find()) {
			end = matcher.start(0) - 2;
			trans += message.substring(begin, end);
			
			Parameter param = params.get(matcher.group(0));
			if( param != null ) {
				switch(param.getDataType()) {
				case "D" : 
					trans += YYYYMMDD.format((Date)param.getValue());
					break;
				case "DT" : 
					trans += YYYYMMDDHHMM.format((Date)param.getValue());
					break;
				default :
					trans += StringUtils.isEmpty(param.getValue())?"" : param.getValue();
					break;
				}
			}
			begin = matcher.end(0) + 1;
		}
		trans += message.substring(begin);
		return trans;
	}

}
