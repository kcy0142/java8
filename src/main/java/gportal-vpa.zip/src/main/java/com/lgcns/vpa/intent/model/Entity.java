/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : Entity.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class Entity {
	
	private String id;
	private String botId;
	private String name;
	
	/**
	 * entity type's id
	 * in case of simple type, this value is null
	 */
	private String refEntityId;

	@Transient
	@JsonIgnore
	private Entity refEntity;

	@Transient
	private String refEntityName;
	
	private String phraseExp;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBotId() {
		return botId;
	}
	
	public void setBotId(String botId) {
		this.botId = botId;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getRefEntityId() {
		return refEntityId;
	}
	
	public void setRefEntityId(String refEntityId) {
		this.refEntityId = refEntityId;
	}

	public Entity getRefEntity() {
		return refEntity;
	}
	
	public void setRefEntity(Entity refEntity) {
		this.refEntity = refEntity;
	}
	
	public String getRefEntityName() {
		if( refEntity != null ) {
			return refEntity.getName();
		}
		return "";
	}
	
	public String getPhraseExp() {
		return phraseExp;
	}

	public void setPhraseExp(String phraseExp) {
		this.phraseExp = phraseExp;
	}
	
	public String toString() {
		return String.format("id : %s name : %s type : %s ref entity : %s", id, name, refEntity);
	}	
}
