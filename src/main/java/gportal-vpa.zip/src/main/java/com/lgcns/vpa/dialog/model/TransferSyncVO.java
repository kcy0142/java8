/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : TransferSyncVO.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.dialog.util.CamelProcedureUriUtil;

/**
 * <PRE>
 * Action Data 에서 Backend Proxy 에 전송용 Value Object를 생성
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 6. 9.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value=Include.NON_EMPTY)
public class TransferSyncVO {
	
	/**
	 * 질의 아이디
	 */
	private String inquiryId;
	
	/**
	 * 질의한 인텐트 아이디
	 */
	private String intentId;
	
	/**
	 * 질의한 TenantId 
	 */
	private String tenantId;
	
	/**
	 * 질의한 액션 아이디
	 */
	private String actionId;
	
	/**
	 * Backend Proxy 에서 실행될 from uri
	 */
	private String actionUri;
	
	/**
	 * Backend Proxy 에서 실행될 Parameter Name list 
	 */
	private Map<String, Object> actionParam;
	
	/**
	 * Backend Proxy 에서 실행된 후의 수신된 Result
	 */
	private List<Map<String, Object>> actionResult;
	
	/**
	 * Backend Proxy 에 질의한 봇아이디
	 */
	private String requestBotId;
	
	/**
	 * Backend Proxy 에 질의한 사용자 아이디
	 */
	private String requestUserId;
	
	/**
	 * Backend Proxy 에 질의한 사용자의 부서 아이디
	 */
	private String requestGroupId;
	
	/**
	 * Backend Proxy 에 질의한 사용자의 회사코드
	 */
	private String requestCompanyCode;
	
	/**
	 * Backend Proxy 에 질의한 일자
	 */
	private Date requestDate;
	
	private String successYn;
	private String description;
	
	public TransferSyncVO() {
		super();
	}

	public TransferSyncVO (InquiryVO inquiryVO) {
		super();
		this.inquiryId = inquiryVO.getInquiryId();
		this.intentId = inquiryVO.getIntentId();
		this.tenantId = inquiryVO.getTenantId();
		
		//this.requestBotId = inquiryVO.getBotId();
		//this.requestUserId = inquiryVO.getReqUserId();
		//this.requestGroupId = inquiryVO.getReqGroupId();
		//this.requestCompanyCode = inquiryVO.getReqCompanyCode();
		//this.requestDate = new Date(System.currentTimeMillis());
		
		Action action = inquiryVO.getAction();
		this.actionId = action.getActionId();
		this.actionParam = inquiryVO.getIntentParam();
		
		if ( action.getActionType().equalsIgnoreCase("sql")) {
			this.actionUri = action.getActionUri();
		}
		else {
			//ActionUri 값을 Camel Procedure Uri Type으로 변경
			CamelProcedureUriVO uriVO = CamelProcedureUriUtil.changeFixedParameter(action.getActionUri());
			if (uriVO != null) {
				this.actionUri = (uriVO.getQuery() != null) ? uriVO.getQuery() : action.getActionUri();
				if (uriVO.getParameters() != null) {
					this.actionParam.putAll(uriVO.getParameters());
				}
			}
			else {
				this.actionUri = action.getActionUri();
			}
		}
	}
	
	public TransferSyncVO(String inquiryId) {
		this.inquiryId = inquiryId;
	}
	
	public TransferSyncVO(String inquiryId, String intentId, String actionId, String tenantId,
			String actionUri, HashMap<String, Object> actionParam, String requestBotId,
			String requestUserId, String requestGroupId, String requestCompanyCode, Date requestDate) {
		super();
		this.inquiryId = inquiryId;
		this.intentId = intentId;
		this.actionId = actionId;
		this.tenantId = tenantId;
		this.actionUri = actionUri;
		this.actionParam = actionParam;
		this.requestBotId = requestBotId;
		this.requestUserId = requestUserId;
		this.requestGroupId = requestGroupId;
		this.requestCompanyCode = requestCompanyCode;
		this.requestDate = requestDate;
	}

	public String getInquiryId() {
		return inquiryId;
	}

	public void setInquiryId(String inquiryId) {
		this.inquiryId = inquiryId;
	}

	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public String getActionUri() {
		return actionUri;
	}

	public void setActionUri(String actionUri) {
		this.actionUri = actionUri;
	}

	public Map<String, Object> getActionParam() {
		return actionParam;
	}

	public void setActionParam(Map<String, Object> actionParam) {
		this.actionParam = actionParam;
	}

	public List<Map<String, Object>> getActionResult() {
		return actionResult;
	}

	public void setActionResult(List<Map<String, Object>> actionResult) {
		this.actionResult = actionResult;
	}

	public String getRequestBotId() {
		return requestBotId;
	}

	public void setRequestBotId(String requestBotId) {
		this.requestBotId = requestBotId;
	}

	public String getRequestUserId() {
		return requestUserId;
	}

	public void setRequestUserId(String requestUserId) {
		this.requestUserId = requestUserId;
	}

	public String getRequestGroupId() {
		return requestGroupId;
	}

	public void setRequestGroupId(String requestGroupId) {
		this.requestGroupId = requestGroupId;
	}

	public String getRequestCompanyCode() {
		return requestCompanyCode;
	}

	public void setRequestCompanyCode(String requestCompanyCode) {
		this.requestCompanyCode = requestCompanyCode;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public String getSuccessYn() {
		return successYn;
	}

	public void setSuccessYn(String successYn) {
		this.successYn = successYn;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "TransferSyncVO [inquiryId=" + inquiryId + ", intentId=" + intentId + ", tenantId=" + tenantId
				+ ", actionId=" + actionId + ", actionUri=" + actionUri + ", actionParam=" + actionParam
				+ ", actionResult=" + actionResult + ", requestBotId=" + requestBotId + ", requestUserId="
				+ requestUserId + ", requestGroupId=" + requestGroupId + ", requestCompanyCode=" + requestCompanyCode
				+ ", requestDate=" + requestDate + ", successYn=" + successYn + ", description=" + description + "]";
	}

	/**
	 * Json Data 생성
	 * @return
	 */
	public String toJson () {
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(this);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}
	
}
