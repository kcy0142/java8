/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : WeatherDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.base.util.I18nUtils;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.push.dao.WeatherDao;
import com.lgcns.vpa.push.model.City;
import com.lgcns.vpa.push.model.Weather;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.security.user.service.UserRoleService;

/**
 * <PRE>
 * 날씨 정보 조회 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 22.
 */
@Component("WeatherDialog")
public class WeatherDialog extends VpaDialog {

	private static final Logger LOG = LoggerFactory.getLogger(WeatherDialog.class);
	
	@Autowired
    private WeatherDao weatherDao;
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	
	@Value("${weather.default.tenant}")
	private String lgCnsTenantId;
	
	/**
     * 기본 도시 코드 (서울시 : 1100000000)
     */
    private static String DEFAULT_CITY_CODE;
    
    @Value("${weather.default-city-code}")
    public void setDefaultCityCode(String cityCode) {
        DEFAULT_CITY_CODE = cityCode;
    }
	
    @Override
	protected boolean validator(InquiryVO data) {
		
    	if ( data == null ) {
    		LOG.info("날씨를 조회할 요청 Data가 없어서 validator(false) 을 반환합니다.");
    		return false;
    	}
    	
		boolean isValid = false;
		
		// TODO 나중에 날씨 Data가 있을 경우 처리함 
		/*Map<String, Object> param = data.getIntentParam();
		if ( (param == null) || (param.isEmpty()) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
					 "], 날씨 조회를 위한 파라미터가 없음.");
		}
		else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date date = null;
			
			Map<String, Object> intentParam = data.getIntentParam();
			
			if ( intentParam.get("date") != null ) {
				
				if ( intentParam.get("date") instanceof Date ) {
					date =  (Date)intentParam.get("date");
					intentParam.put("date", sdf.format(date));
				}
				else {
					date = new Date(System.currentTimeMillis());
					intentParam.put("date", sdf.format(date));
				}
				
			}
			else {
				date = new Date(System.currentTimeMillis());
				intentParam.put("date", sdf.format(date));
			}
			
			data.setIntentParam(intentParam);
			
		}*/
		
		LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
				 "], Intent Param:["+data.getIntentParam()+"]");
		
		return true;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		boolean hasRight = false;
		
		if ( data.getReqUser() == null ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한을 검사할 Req User 정보가 없음");
			return false;
		}
		
		//인텐트별 사용자의 사용 권한 조회
		try {
			hasRight = this.userRoleService.validateUserRole(data.getReqUser(), data.getIntentId());
		} catch (Exception e) {
			hasRight = true;
		}
		
		if (!hasRight) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한 없음");
		}
		return hasRight;
	}
	
	@Override
	protected String processor(InquiryVO data) {
		if ( (data == null) || (data.getAction() == null) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 정보가 부정확함");
			return null;
		}
		
		String resultJsonData = "Weather";
		/*List<Map<String, Object>> searchResult = null;
		
		try {
			//날씨조회 요청
			
			//조회 결과 없음
			if ( (searchResult == null) || (searchResult.isEmpty()) ) {
				//결과가 없음
				resultJsonData = CommonCode.ACTION_RESULT_NONE;
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 결과가 없음");
			}
			//조회 결과 Json 변환
			else {
				ObjectMapper objMapper = new ObjectMapper();
				resultJsonData = objMapper.writeValueAsString(searchResult);
				data.setSearchResult(searchResult);
			}
			
		} catch (Exception e) {
			//오류 발생
			resultJsonData = CommonCode.ACTION_RESULT_ERROR;
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 중 오류 발생, Exception : " + e.toString());
		}*/
		
		return resultJsonData;
	}

	@Override
	protected Activity afterWork(InquiryVO data, String searchResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		/*if ( StringUtils.isEmpty(searchResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}*/
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			
				
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+null+"]");
			
			
			// 날씨 조회 정보 Attachment 생성
			attachments = this.getAttachment(data, null);
			
			if ( (attachments != null) && (!attachments.isEmpty()) ) {
				
				resultActivity.setMessage(data.getIntentMessage());
				resultActivity.setAttachments(attachments);
				
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						"조회된 날씨 정보가 없습니다.");
			}
			
			//의도분석의 Button이 있는 경우 처리
			if ( data.getIntentButtons() != null ) {
				List<RelatedButton> buttons = data.getIntentButtons();
				List<Button> activityButtonList = super.makeActivityButtonList(buttons);
				
				if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
					resultActivity.setButtons(activityButtonList);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * 날씨 조회 및 Attachment 생성
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 * @throws Exception
	 */
	protected List<Attachment> getAttachment(InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet)
			throws Exception {
		
		if ( inquiryData == null ) {
			LOG.info("날씨를 조회할 요청 정보가 없어 null을 반환합니다.");
			return null;
		}
		
		User user = inquiryData.getReqUser();
		
		if ( (user == null) || (user == null) ) {
			LOG.info("날씨를 조회할 요청 사용자 정보가 없어 null을 반환합니다.");
			return null;
		}
		
		// 사용자의 기본 TenantId
		String userTenantId = inquiryData.getTenantId();
		
		try {
			// 날씨정보는 LGCns DataSource 를 사용하여 정보를 가져옴
			//TenantId 지정
	    	DataSourceKeyHolder.setDataSourceKey(this.lgCnsTenantId);
			
			// 날씨 조회 일자 정보 처리
			String baseDate = null, fcstDate = null;
			Map<String, Object> intentParam = inquiryData.getIntentParam();
			boolean isTodayWeather = true;
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			
			if ( (intentParam != null) && (intentParam.get("date") != null) ) {
				Date date = (Date)intentParam.get("date");
				baseDate = sdf.format(date);
				fcstDate = baseDate;
				
				//조회날자가 현재일인지 검사
				Date curDate = new Date(System.currentTimeMillis());
				String curDateStr = sdf.format(curDate);
				if (!baseDate.equals(curDateStr)) {
					isTodayWeather = false;
				}			
			}
			else {
				Date date = new Date(System.currentTimeMillis());
				baseDate = sdf.format(date);
				fcstDate = baseDate;
			}
			/*else {
				LOG.info("날씨를 조회할 일자 정보가 없어 null을 반환합니다.");
				return null;
			}*/
			
			Attachment attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_WEATHER);
	        
	        Element element = new Element();
	        
	        // 1. 지역 구분
	        // 1) 의도 파라미터 중 cityname에 지정된 
	        // 2) 로그인 사용자의 근무지 주소 조회
	        // 3) 서울시 강서구 (DEFAULT_CITY_CODE)
	        String searchCityName = null;
	        if ( (intentParam != null) && (intentParam.containsKey("cityname")) ) {
	        	searchCityName = (String) intentParam.get("cityname");
	        }
	        
	        Weather weatherCondition = new Weather();
	        String cityCode = DEFAULT_CITY_CODE;
	        City cityLocation = null;
	        
	        // 검색이 요청된 지역의 정보가 있으면 조건 요청된 지역정보를 조회함
	        // 검색이 요청된 지역의 정보가 없으면 사용자 사무실 정보로 조회
	        // 검색 요청 지역 정보와 사무실 정보가 없으면 기본 정보로 조회
	        if ( !StringUtils.isEmpty(searchCityName) ) {
	        	// 검색어와 일치하는 지역정보 검색
	        	cityLocation = weatherDao.selectCityBySearchNameEqual(searchCityName);
            	
            	if ( (cityLocation == null) || (StringUtils.isEmpty(cityLocation.getCityCode())) ) {
            		// 검색어와 유사한(LIKE) 지역정보 검색
            		cityLocation = weatherDao.selectCityBySearchNameLike(searchCityName);
            	}
	        }
	        
	        // 검색이 요청된 지역의 정보가 없거나 검색이 요청된 지역이 없으면 사무실 주소를 기본으로 함
            if ( ((cityLocation == null) || (StringUtils.isEmpty(cityLocation.getCityCode()))) && (!StringUtils.isEmpty(user.getOfficeBasicAddress())) ) {
            	cityLocation = weatherDao.selectCityByOfficeAddress(user.getOfficeBasicAddress());
            }
	        
            // 검색 요청 지역 정보 또는 사무실 정보가 있으면 그 지역의 지역정보를 사용함
            if ( (cityLocation != null) && (!StringUtils.isEmpty(cityLocation.getCityCode())) ) {
                cityCode = cityLocation.getCityCode();
            }
            
	        // 2. 지정 일자 날씨 조회 (나중에 Data가 있을 경우 처리)
	        if ( baseDate != null ) {
	        	weatherCondition.setBaseDate(baseDate);
	        	weatherCondition.setFcstDate(fcstDate);
	        }
	        
	        weatherCondition.setSearchCityCode(cityCode);
	                        
	        // 3. 해당 지역의 초단기 실황 조회
	        //Weather weatherGrib = weatherDao.selectWeatherByCityCode(weatherCondition);
	        Weather weatherGrib = null;
	        List<Weather> todayWeatherList = weatherDao.selectForecastWeatherListToday(weatherCondition);
	        
	        // 해당 지역의 초단기 실황 조회 (1시간 단위 정보 중에서 조회)
	        if (isTodayWeather) {
	        	weatherGrib = weatherDao.selectWeatherByCityCode(weatherCondition);
	        }
	        // 초단기 실황 목록에서 현재 시간의 구간에 해당하는 정보를 가져온다. (3시간 단위 정보중에서 조회)
	        else if ( (todayWeatherList != null) && (!todayWeatherList.isEmpty()) ) {
	        	
	        	if (todayWeatherList.size() == 1) {
	        		weatherGrib = todayWeatherList.get(0);
	        	}
	        	else {
	        		
	        		String fcstTime = "1500";
	        		
	        		/*//오늘 날씨 조회일 경우 시간별로 구분하여 조회, 내일/모레 등 날씨의 경우 1500시기준 
	        		if (isTodayWeather) {
		        		//조회 시간의 날씨를 조회할 때 사용함. 단, 1500시 기준의 날씨를 조회할 때는 주석 처리함
			        	LocalDateTime now = LocalDateTime.now();
			    		int hour = now.getHour();
			    		double hourDouble = hour + 1;
			    		
			    		switch ( (int) Math.ceil(hourDouble/3) ) {
							case 0 :
								fcstTime = "0000";
								break;
							case 1 :
								fcstTime = "0300";
								break;
							case 2 :
								fcstTime = "0600";
								break;
							case 3 :
								fcstTime = "0900";
								break;
							case 4 :
								fcstTime = "1200";
								break;
							case 5 :
								fcstTime = "1500";
								break;
							case 6 :
								fcstTime = "1800";
								break;
							case 7 :
								fcstTime = "2100";
								break;
							case 8 :
								fcstTime = "0000";
								break;
							default :
								fcstTime = "1200";
						}
		    		}*/
		
		    		for (Weather weatherTmp : todayWeatherList) {
		    			if ( (weatherTmp != null) && (fcstTime.equals(weatherTmp.getFcstTime())) ) {
		    				weatherGrib = weatherTmp;
		    				break;
		    			}
		    		}
		    		
		    		if (weatherGrib == null) {
		        		weatherGrib = todayWeatherList.get(0);
		        	}
		    		
		    		if (weatherGrib != null) {
		    			weatherGrib.setT1H(weatherGrib.getT3H());
		    		}
	        	}
	        }//if
	        
	        //날씨 정보가 있으면 처리함
	        if ( weatherGrib != null ) {
		        if (!I18nUtils.isDefaultLocaleCode(user.getLocaleCode())) {
		            weatherGrib.setCityAllDisplayName(weatherGrib.getCityAllDisplayEnglishName());
		        }
		        
		        element.addAdditionalProperty("weather", weatherGrib);
		        
		        // 4. 해당 지역의 동네예보 조회
		        element.addAdditionalProperty("forecasts", weatherDao.selectForecastWeatherListByCityCode(weatherCondition));
		        
		        attachment.addElement(element);
		        
		        return Arrays.asList(attachment);
	        }
	        else {
	        	return null;
	        }
	     
		} catch ( Exception e ) {
			throw e;
		} finally {
			// 사용자의 원래 TenantId 지정
	    	DataSourceKeyHolder.setDataSourceKey(userTenantId);
		}
	}//getAttachment()

}
