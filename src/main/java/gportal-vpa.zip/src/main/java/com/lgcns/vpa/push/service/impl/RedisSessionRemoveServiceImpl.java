package com.lgcns.vpa.push.service.impl;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.PushService;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;



/**
 * <pre>
 * redisSe Service
 * </pre>
 * @author
 */
@Service("multi.redisSessionRemoveService")
public class RedisSessionRemoveServiceImpl extends PushAbstractService implements PushService{
    
    @Autowired
	ActivityService activityService;
    
    @Autowired
    RedisMessagePublisher redisMessagePublisher;
	
	@Autowired
	RedisTemplate redisTemplate;
	
	@Autowired 
	private MongoTemplate mongoTemplate;
	
	private static final Logger LOG = LoggerFactory.getLogger(RedisSessionRemoveServiceImpl.class);
	
    @Override
	public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig){
    	
    	
    	String botId = params.get("botId");
    	
    	Query query = new Query();
		
		query.addCriteria(Criteria.where("enterDate").gte(LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MIN))
		.lte(LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX)));
		
		System.out.println("#################start tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MIN)+", end tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX));
		LOG.info("#################start tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MIN)+", end tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX));
				
		query.fields().include("userId");
		List<String> conversationList =mongoTemplate.find(query, String.class,"conversations");
		ObjectMapper objectMapper = new ObjectMapper();
		
		JsonNode jsonNode = null ;
		HashOperations<String, String, Object> hashOper = redisTemplate.opsForHash();
		
		System.out.println("#################conversationList.size():"+conversationList.size());
		LOG.info("#################conversationList.size():"+conversationList.size());
		int cnt=0;
		int no=0;
		String userList="";
		String userTemp="";
		for(String userInfo : conversationList){
			no=no+1;
			try {
				jsonNode = objectMapper.readTree(userInfo);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			String userId = jsonNode.get("userId").asText();
			
			userList=userList+"'"+userId+"',";
			userTemp=userId;
			 
			// 웹소켓 연결정보를 REDIS에서 삭제한다.
			String key = String.format("webscoket:%s", userId);
			String msg="";
			 
			String webSocketSessionId = (String)redisTemplate.opsForHash().get(key, "webSocketSessionId");
			String sessionId = (String)redisTemplate.opsForHash().get(key, "sessionId");

			
				
			String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
			String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
				 
				 
			if( redisTemplate.hasKey(sessionIdKey) ) {
			 	msg="session is expired";
			 	cnt=cnt+1;
			}else{
			 	msg="session has no existed";
			}
			
			System.out.println("#################No:"+no+",userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+",msg:"+msg);
			LOG.info("#################No:"+no+",userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+",msg:"+msg);
			// redisTemplate.delete(key);
			//redisTemplate.delete(webSocketSessionIdKey);
			//redisTemplate.delete(sessionIdKey);
				 
		          
		    // 웹소켓 연결정보를 REDIS에서 삭제한다.
		    redisTemplate.expire(key, 0, TimeUnit.MINUTES);
		    redisTemplate.expire(webSocketSessionIdKey, 0, TimeUnit.MINUTES);  
		    redisTemplate.expire(sessionIdKey, 0, TimeUnit.MINUTES); 
		}
		
		System.out.println("########session expired count:"+cnt);
		LOG.info("########session expired count:"+cnt);
		
		//String userInfo="db.getCollection('conversations').find({userId:{ $in: ["+userList+"'"+userTemp+"' ] }},{botId:1,userId:1,enterDate:1}).sort({enterDate:-1})";
		
		//String activityInfo="db.getCollection('activities').find({$and:[{userId:{ $in: ["+userList+"'"+userTemp+"' ] }},{ subtype: \"greeting\" },{sentDate:{$gte:new ISODate(\""+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX)+"\") }} ]},{botId:1,userId:1,sentDate:1})";
         
		 
		//System.out.println("######## MondoDb Query userInfo:"+userInfo);
		//LOG.info("######## MondoDb Query userInfo:"+userInfo);
		
		//System.out.println("######## MondoDb Query activityInfo:"+activityInfo);
		//LOG.info("######## MondoDb Query activityInfo:"+activityInfo);
	}
    
  
	
}
