/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : EventButtonController.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.dialog.service.EventButtonService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * Event 처리 시 Previous, Next button api 컨트롤러
 * </pre>
 * @author
 */
@RestController
@CrossOrigin(value="*")
@RequestMapping(value="/api/dailog/event")
public class EventButtonController extends BaseController {
	
	private static final Logger LOG = LoggerFactory.getLogger(EventButtonController.class);
	
	@Autowired
	private EventButtonService eventButtonService;
	
	@RequestMapping(value="/{userId}", method= RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<Map<String, Object>> eventButtonProc(
    		@PathVariable String userId,
    		@RequestParam(required = false) Map<String, String> param) {
		
		if (StringUtils.isEmpty(userId)) {
    		throw new RuntimeException("일정을 조회할 사용자 정보가 유효하지 않습니다.");
    	}
		
		User reqUser = this.getUser();
		List<Attachment> attachments = eventButtonService.execute(param, reqUser, userId);
		
		
		Map<String, Object> result = new HashMap<>();
    	result.put("activityId", param.get("activityId"));
    	result.put("index", param.get("index"));
    	result.put("attachments", attachments);

    	LOG.info("userId:["+userId+"],param:["+param+"],result:["+result+"]");
    	
    	return new ResponseEntity<>(result, HttpStatus.OK);
	}
}
