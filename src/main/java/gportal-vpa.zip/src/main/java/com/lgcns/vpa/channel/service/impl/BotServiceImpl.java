package com.lgcns.vpa.channel.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.dao.BotDao;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.BotMessage;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.channel.service.impl.BotServiceImpl.BotContracts.Columns;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;

import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.stereotype.Service;

/**
 * <pre>
 * 봇 관리 Service
 * </pre>
 * @author
 */
@Service("multi.botService")
public class BotServiceImpl implements BotService {

	private static final Logger LOG = LoggerFactory.getLogger(BotServiceImpl.class);
	
	/**
	 * 실패 통지를 위한 실패율 구간
	 */
	public static final double[] BOT_FAIL_THRESHOLD_RANGE = {2d,3d,5d,8d,13d,21d,34d,55d,89d,100d};//PIVOT
	
	public static final int BOT_TTL 		= 180;
	
    @Autowired
    private BotDao botDao;
    
    /**
     * bot정보를 cache하기 위한 용도임
     */
    @Autowired
    private RedisTemplate redisTemplate;

    /**
     * 봇 정보 조회
     * @param botId
     * @return
     */
    @SuppressWarnings("unchecked")
	@Override
    public Bot retrieveBot(String botId) {
    	
    	String tenantId = DataSourceKeyHolder.getDataSourceKey();
    	String botKey = BotContracts.getKey(tenantId, botId);
    	
    	HashOperations<String, String, Object> hashOper = redisTemplate.opsForHash();
    	Bot bot = null;
    	if( redisTemplate.hasKey(botKey) ) {
    		
    		Map<String, Object> botData = hashOper.entries(botKey);
    		
    		bot = new Bot();
    		bot.setTenantId(tenantId);
    		bot.setBotId(botId);
    		bot.setBotName((String)botData.get(Columns.BOT_NAME));
    		bot.setBotEnglishName((String)botData.get(Columns.BOT_ENGLISH_NAME));
    		bot.setPortalId((String)botData.get(Columns.PORTAL_ID));
    		bot.setUseYn((String)botData.get(Columns.USE_YN));
    		bot.setDescription((String)botData.get(Columns.DESCRIPTION));
    		bot.setIconUrl((String)botData.get(Columns.ICON_URL));
    		bot.setSmallIconUrl((String)botData.get(Columns.SMALL_ICON_URL));
    		
    		bot.setDapBotId((String)botData.get(Columns.DAAP_BOT_ID));
    		bot.setDapNluService((String)botData.get(Columns.DAAP_NLU_SERVICE));
    		bot.setUpdateDate((Date)botData.get(Columns.BOT_UPDATE_DATE));
    		bot.setInferenceMinScore((Integer)botData.getOrDefault(Columns.INFERENCE_MIN_SCORE, 40));
    		bot.setInferenceScoreRange((Integer)botData.getOrDefault(Columns.INFERENCE_SCORE_RANGE, 3));
    		bot.setInferenceCutScore((Integer)botData.getOrDefault(Columns.INFERENCE_CUT_SCORE, 35));
    		bot.setDapFailCnt((Integer)botData.getOrDefault(Columns.DAAP_FAIL_CNT, 0));
/*    		Object failCnt = botData.get(Columns.DAAP_FAIL_CNT);
    		
    		bot.setDapFailCnt(failCnt == null ? 0 : (Integer)failCnt);
*/    		//특정 시간 마다 할 까?
    	} else {
    		bot = botDao.selectBotDetail(botId);

    		Map<String, Object> botData = new HashMap<>();
    		botData.put(Columns.BOT_ID, 			bot.getBotId());
    		botData.put(Columns.BOT_NAME, 			bot.getBotName());
    		botData.put(Columns.BOT_ENGLISH_NAME, 	bot.getBotEnglishName());
    		botData.put(Columns.PORTAL_ID, 			bot.getPortalId());
    		botData.put(Columns.USE_YN, 			bot.getUseYn());
    		botData.put(Columns.DESCRIPTION, 		bot.getDescription());
    		botData.put(Columns.ICON_URL, 			bot.getIconUrl());
    		botData.put(Columns.SMALL_ICON_URL, 	bot.getSmallIconUrl());
    		botData.put(Columns.INFERENCE_MIN_SCORE, bot.getInferenceMinScore());
    		botData.put(Columns.INFERENCE_SCORE_RANGE, bot.getInferenceScoreRange());
    		botData.put(Columns.INFERENCE_CUT_SCORE, bot.getInferenceCutScore());

    		botData.put(Columns.DAAP_BOT_ID, 		bot.getDapBotId());
    		botData.put(Columns.DAAP_NLU_SERVICE, 	bot.getDapNluService());
    		botData.put(Columns.BOT_UPDATE_DATE, 	bot.getUpdateDate());
    		botData.put(Columns.DAAP_FAIL_CNT, 0);
    		hashOper.putAll(botKey, botData);
    	}
    	
        return bot;
    }
    
    /**
	 * Bot 메세지 조회
	 * @param botId
	 * @param messageType
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String getBotMessage( String botId, String messageType ) {
		
		String tenantId = DataSourceKeyHolder.getDataSourceKey();
    	String messageKey = BotContracts.getMessageKey(tenantId, botId, messageType);
    	
    	ListOperations<String, BotMessage> listOps = redisTemplate.opsForList();
    	
    	BotMessage botMessage = null;
    	
    	if( redisTemplate.hasKey(messageKey) && listOps.size(messageKey) > 0L) {
    		int index = new Random().nextInt(listOps.size(messageKey).intValue());
    		botMessage = listOps.index(messageKey, index);
    	} else {
    		//type을 가져오도록 수정함
    		List<BotMessage> messageList = botDao.selectBotMessageListByType(botId, messageType);
    		
    		if( messageList != null && !messageList.isEmpty() ) { 
	    		listOps.rightPushAll(messageKey, messageList.toArray(new BotMessage[0]));
	    		
	    		int index = new Random().nextInt(listOps.size(messageKey).intValue());
	
	    		botMessage = messageList.get(index);
    		}
    	}
    	
		//botMessage 가 없으면 DB에서 직접 조회함
		if ( botMessage == null ) {
			BotMessage params = new BotMessage();
	        params.setBotId(botId);
	        params.setMessageType(messageType);
	       
	        botMessage = botDao.selectRandomBotMessageByType(params);
		}
		
		return (botMessage != null) ? botMessage.getMessage() : null;
		
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
    public long success(Bot bot) {
    	String tenantId = DataSourceKeyHolder.getDataSourceKey();
    	
    	String botKey = String.format(BotContracts.BOT_KEY, tenantId, bot.getBotId());
    	if( !redisTemplate.hasKey(botKey) ) {
    		return 0L;
    	}
    	
    	HashOperations hashOp = redisTemplate.opsForHash();
    	return hashOp.increment(botKey, Columns.DAAP_SUCCESS_CNT, 1);

    }
	
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public long fail(Bot bot) {
    	String tenantId = DataSourceKeyHolder.getDataSourceKey();
    	
    	String botKey = String.format(BotContracts.BOT_KEY, tenantId, bot.getBotId());
    	if( !redisTemplate.hasKey(botKey) ) {
    		return 0L;
    	}

    	HashOperations hashOp = redisTemplate.opsForHash();
    	return hashOp.increment(botKey, Columns.DAAP_FAIL_CNT, 1);
    }
	
	
    public interface BotContracts {

    	/**
    	 * Bot redis key
    	 */
		public static final String BOT_KEY = "%s:bot:%s";
		
		public static final String BOT_MESSAGE_KEY = "%s:bot:%s:%s:messages";
		
		/**
		 * 
		 * @param tenantId
		 * @param botId
		 * @return
		 */
		public static String getKey(String tenantId, String botId) {
			return String.format(BOT_KEY, tenantId, botId);
		}
		
		public static String getMessageKey(String tenantId, String botId, String messageType) {
			return String.format(BOT_MESSAGE_KEY, tenantId, botId, messageType);
		}
		
		public interface Columns {
			
			public static final String TENANT_ID = "tenantId";
			/**
		     * 봇 ID
		     */
			public static final String BOT_ID = "botId";

		    /**
		     * Portal ID
		     */
			public static final String PORTAL_ID = "portalId";

		    /**
		     * 봇 이름
		     */
			public static final String BOT_NAME = "botName";

		    /**
		     * 봇 이름
		     */
			public static final String BOT_ENGLISH_NAME = "botEnglishName";

		    /**
		     * 사용여부
		     */
			public static final String USE_YN = "useYn";

		    /**
		     * 설명
		     */
			public static final String DESCRIPTION = "description";

		    /**
		     * 이미지 URL
		     */
			public static final String SMALL_ICON_URL = "smallIconUrl";

		    /**
		     * 이미지 URL
		     */
			public static final String ICON_URL = "iconUrl";
		    
		    /**
		     * 봇 기본 메시지 목록
		     */
		    public static final String BOT_MESSAGES = "botMessages";
		    
		    /**
		     * dap bot id
		     */
    		public static final String DAAP_BOT_ID = "dapBotId";
		    
		    /**
		     * dap bot nlu service url
		     */
			public static final String DAAP_NLU_SERVICE = "dapNluService";
			
			/**
			 * 실패횟수
			 */
			public static final String DAAP_FAIL_CNT = "dapFailCnt";
			
			/**
			 * 성공횟수
			 */
			public static final String DAAP_SUCCESS_CNT = "dapSuccessCnt";
			
			/**
			 * 실패 통지 차수
			 */
			public static final String DAAP_NOTI_CNT 	= "dapNotiCnt";
			
			
			public static final String STATUS = "status";

			/**
			 * bot등록일자
			 */
			public static final String BOT_UPDATE_DATE = "updateDate";
			
			
			/**
			 * 추론 최소값
			 */
			public static final String INFERENCE_MIN_SCORE = "inferenceMinScore";
			
			/**
			 * 추론 최대값
			 */
			public static final String INFERENCE_SCORE_RANGE = "inferenceScoreRange";
			
			/**
			 * 추론에서 버리는 값
			 */
			public static final String INFERENCE_CUT_SCORE = "inferenceCutScore";
			
		}
	}
}
