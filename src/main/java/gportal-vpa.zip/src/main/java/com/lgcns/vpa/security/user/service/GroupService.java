package com.lgcns.vpa.security.user.service;

import java.util.List;

import com.lgcns.vpa.security.user.model.Group;

public interface GroupService {
	
	 /**
     * 해당 사용자가 속한 그룹의 상위 그룹 목록 조회 
     * @param userId
     * @return
     */
    List<Group> selectParentGroupListByUser(String userId);
    
    /**
     * 부서명으로 부서목록 Like 검색
     * @param groupName
     * @return
     */
    List<Group> selectGroupName(String groupName);
}
