/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : JsonConverter.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <PRE>
 * Json Convert를 담당하는 Utility Class
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
public class JsonConverter <T>{
	
	private static final Logger LOG = LoggerFactory.getLogger(JsonConverter.class);
	
	/**
	 * Json Type 의 String을 Object로 변환 함
	 * @param jsonStr
	 * @param classType
	 * @return
	 */
	public T jasonStringToObject(String jsonStr, Class<T> classType) {
		
		//빈 문자열 또는 null인지 검사
		if ( !StringUtils.hasText(jsonStr) ) {
			return null;
		}
				
		T result = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
			result = objMapper.readValue(jsonStr, classType);

		} catch (Exception e) {
			e.printStackTrace();
			LOG.info(e.toString());
			return null;
		}
		
		return result;
	}
	
	/**
	 * 일차원 Json String 을 Map<String, Object> Object로 변환함
	 * @param jsonData
	 * @return
	 */
	public static Map<String, Object> jsonToMap (String jsonData) {
		
		if ( StringUtils.isEmpty(jsonData) ) {
			return null;
		}
		
		LOG.debug("jsonData:["+jsonData+"]");
		
		Map <String, Object> resultMap = null;
		
		try {
			ObjectMapper mapper = new ObjectMapper();
	        JsonNode root = mapper.readTree(jsonData);
	        
	        Iterator<String> iter = root.fieldNames();
	        
	        if (iter != null) {
	        	
	        	resultMap = new HashMap<String, Object>();
	        	
	        	while (iter.hasNext()) {
	        		String key = iter.next();
	        		JsonNode child = root.get(key);
	        		
	        		if ( child.isTextual() ) {
	        			resultMap.put(key, child.asText());
	        		}
	        		else if ( child.isInt() ) {
	        			resultMap.put(key, child.asInt());
	        		}
	        		else if ( child.isBoolean() ) {
	        			resultMap.put(key, child.asBoolean());
	        		}
	        		else if ( child.isFloat() || child.isDouble() ) {
	        			resultMap.put(key, child.asDouble());
	        		}
	        		else {
	        			resultMap.put(key, child.asText());
	        		}
	        	}
	        }
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("jsonData:["+jsonData+"] Exception:"+e.toString());
			resultMap = null;
		}
		
		if ( (resultMap != null) && (resultMap.isEmpty()) ) {
			resultMap = null;
		}
		
		LOG.debug("resultMap:["+resultMap+"]");
		return resultMap;
	}
	
	/**
	 * 일차원 JsonNode 을 Map<String, Object> Object로 변환함
	 * @param jsonNode
	 * @return
	 */
	public static Map<String, Object> jsonToMap (JsonNode jsonNode) {
		
		if ( jsonNode == null ) {
			return null;
		}
		
		LOG.debug("jsonNode:["+jsonNode.asText()+"]");
		
		Map <String, Object> resultMap = null;
		
		try {
	        Iterator<String> iter = jsonNode.fieldNames();
	        
	        if (iter != null) {
	        	
	        	resultMap = new HashMap<String, Object>();
	        	
	        	while (iter.hasNext()) {
	        		String key = iter.next();
	        		JsonNode child = jsonNode.get(key);
	        		
	        		if ( child.isTextual() ) {
	        			resultMap.put(key, child.asText());
	        		}
	        		else if ( child.isInt() ) {
	        			resultMap.put(key, child.asInt());
	        		}
	        		else if ( child.isBoolean() ) {
	        			resultMap.put(key, child.asBoolean());
	        		}
	        		else if ( child.isFloat() || child.isDouble() ) {
	        			resultMap.put(key, child.asDouble());
	        		}
	        		else {
	        			resultMap.put(key, child.asText());
	        		}
	        	}
	        }
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("jsonData:["+jsonNode .toString()+"] Exception:"+e.toString());
			resultMap = null;
		}
		
		if ( (resultMap != null) && (resultMap.isEmpty()) ) {
			resultMap = null;
		}
		
		LOG.debug("resultMap:["+resultMap+"]");
		return resultMap;
	}
	/*public static void main(String[] args) {
		long startTime, spentTime;
		String jsonData = "{\"inquiryData\":\"김가원 일정을 알려줘\",\"inquiryType\":1}";
		String jsonData1 = "{\"inquiryData\":\"김가원 일정을 알려줘\",\"inquiryType\":1, \"intentParam\":{\"userId\":\"userId01\", \"date\":\"20170520\"}}";
		JsonConverter <InquiryVO> converter = new JsonConverter<InquiryVO>();
		
		startTime = System.currentTimeMillis();
		InquiryVO result2 = (InquiryVO) converter.jasonStringToObject(jsonData, InquiryVO.class);
		spentTime = System.currentTimeMillis() - startTime;
		System.out.println("["+spentTime+" ms]:"+result2.toJson());
		
		startTime = System.currentTimeMillis();
		InquiryVO result3 = (InquiryVO) converter.jasonStringToObject(jsonData1, InquiryVO.class);
		spentTime = System.currentTimeMillis() - startTime;
		System.out.println("["+spentTime+" ms]:"+result3.toJson());
		
	}*/

}
