/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : MessengerActivity.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.channel.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.security.user.model.User;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MessengerActivity extends Activity{
	
	private User user;
	
	private String tenantId;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

}
