/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.base.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.savedrequest.NullRequestCache;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

import com.lgcns.vpa.security.ApiAuthenticationTokenFilter;
import com.lgcns.vpa.security.authentication.RestAuthenticationEntryPoint;

/**
 * <pre>
 * Web Security 설정
 * </pre>
 * @author
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 28800)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    
    @Value("#{'${security.ignored}'.split(',')}") 
    private List<String> securityIgnored;
    
    @Autowired
    private RestAuthenticationEntryPoint restAuthenticationEntryPoint;
    
    
    @Bean
    public ApiAuthenticationTokenFilter createApiAuthenticationFilter() {
    	ApiAuthenticationTokenFilter apiFilter = new ApiAuthenticationTokenFilter("/api/**");
    	//apiFilter.setAuthenticationManager(new NoOpAuthenticationManager());
    	//apiFilter.setAuthenticationSuccessHandler(new ApiAuthenticationSuccessHandler());
    	
    	return apiFilter;
	} 
    
    
    
    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication().withUser("root").password("password").authorities("USER");
    }
    
    @Override
    public void configure(WebSecurity web) throws Exception {
        for (String pattern : securityIgnored) {
            web.ignoring().antMatchers(pattern.trim());
        }
    }
    
    @Override
    public void configure(HttpSecurity http) throws Exception {
        http
            .csrf().ignoringAntMatchers("/ws/**")
                .and()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                .and()
            .exceptionHandling().authenticationEntryPoint(restAuthenticationEntryPoint)
                .and()
            .authorizeRequests()
                .antMatchers(HttpMethod.GET, "/authorize/**").permitAll()
                // @FIXME: 백도어 로그인이 불필요한 시점이 되면 아래 경로 주석으로 막으세요.
                .antMatchers(HttpMethod.GET, "/security/jwt").permitAll()
                //demo 페이지 오픈
                .antMatchers(HttpMethod.GET, "/demo").permitAll()
                .antMatchers(HttpMethod.POST, "/auth/login").permitAll()
                .antMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                //TODO Test 중료되면 삭제할 것 START
                .antMatchers(HttpMethod.POST, "/api/userAutoRun/**").permitAll()
                .antMatchers(HttpMethod.GET, "/api/userAutoRun/**").permitAll()
                //TODO Test 중료되면 삭제할 것 END
            .anyRequest().authenticated()
                .and()
            .requestCache().requestCache(new NullRequestCache())
                .and()
            .headers().frameOptions().disable()
                .and()
            .csrf().disable()
            .httpBasic().disable()
            .formLogin().disable();
        
        if (!"app".equals(System.getProperty("spring.profiles.active"))) {
            http
                .authorizeRequests()
                .antMatchers(HttpMethod.GET, "/security/jwt").permitAll()
                .antMatchers(HttpMethod.GET, "/demo").permitAll()
                .antMatchers(HttpMethod.POST, "/auth/login").permitAll();
        }
        http.addFilterBefore(createApiAuthenticationFilter(), BasicAuthenticationFilter.class);
        //http.addFilterBefore(createApiAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);
    }
}