/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SmsSendDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.push.model.UserAutoRun;

/**
 * <PRE>
 * 휴가신청 입력폼 Dialog
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 12. 18.
 */
@Component("VacationApplyDialog")
public class VacationApplyDialog extends VpaDialog {

private static final Logger LOG = LoggerFactory.getLogger(VacationApplyDialog.class);
	
	
	
	@Autowired
	private CommonResponseService commonResponeService;
	

	
	@Override
	protected boolean validator(InquiryVO data) {
		if ( (data == null) || (!StringUtils.hasText(data.getInquiryData())) ) {
			return false;
		}
		
		return true;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		return true;
	}

	@Override
	protected String processor(InquiryVO data) {
		return "Inquiry VacationApply";
	}
	
	@Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet =  null;
			
			TransferSyncVO responseVO =  new  TransferSyncVO();
			ObjectMapper mapper = new ObjectMapper();
			responseVO =  mapper.readValue(proxyResponseJsonData, TransferSyncVO.class);
			
			if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
				proxyResultSet = responseVO.getActionResult();
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				
				if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
					//Proxy에서 조회된 결과(JsonData)에서 Attachment 를 구함
					attachments = this.getAttachment(data, proxyResultSet);
					
					if ( (attachments != null) && (!attachments.isEmpty()) ) {
						
						int count = proxyResultSet.size();
						
						//Activity Message
						StringBuffer activityMessage = new StringBuffer();
						activityMessage.append(data.getInquiryData()).append(" 질의 결과 ");
						//통제경비는 항목에 TOTAL 이 있어서 전체 개수에서 1개를 제외함
						activityMessage.append("총 ").append(count-1).append("건의 경비가 조회되었습니다.");
						//resultActivity.setMessage(data.getIntentMessage());
						resultActivity.setMessage(activityMessage.toString());
						resultActivity.setAttachments(attachments);
						
					}
					else {
						LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
						
						//Data 가 없음
			        	resultActivity = this.commonResponeService.simpleResponseMessage(
								data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
								" 질의 결과 조회된 정보가 없습니다.");
					}
					
					//의도분석의 Button이 있는 경우 처리
					if ( data.getIntentButtons() != null ) {
						List<RelatedButton> buttons = data.getIntentButtons();
						List<Button> activityButtonList = super.makeActivityButtonList(buttons);
												
						if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
							resultActivity.setButtons(activityButtonList);
						}
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						"조회된 정보가 없습니다.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @return
	 */
	private List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			
			String fromMobile = null;
			String fromUserName = null;
			String toMobile = null;
			String toUserName = null;
			
			
			
			Map <String, Object> intentParam = inquiryData.getIntentParam();
			if ( intentParam != null ) {
				fromMobile = String.valueOf(intentParam .get("fromMobile"));
				fromUserName = String.valueOf(intentParam .get("fromUserName"));
				toMobile = String.valueOf(intentParam .get("toMobile"));
				toUserName = String.valueOf(intentParam .get("toUserName"));
			}
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_VACATIONAPPLY);
	        
			String title = null;
			String actionUrl = null;
			
			
			// additionalProperties 설정
            Map<String, Object> additionalProperties = new HashMap<String, Object>();
            additionalProperties.put("intentId", inquiryData.getIntentId());
            additionalProperties.put("id", inquiryData.getInquiryId());
           // additionalProperties.put("id", inquiryData.geti);
            additionalProperties.put("botId", inquiryData.getBotId());
            additionalProperties.put("toUserName", toUserName);
            additionalProperties.put("fromMobile", fromMobile);
            additionalProperties.put("fromUserName", fromUserName);
            additionalProperties.put("toMobile", toMobile);
            additionalProperties.put("toUserName", toUserName);
            
			Element element = new Element();
			element.setType(CommonCode.ELEMENT_TYPE_TEXT);
			element.setTitle(title);
			//element.setDescriptions(desciptions.toString());
			//element.setAmount(desciptions.toString());
			//element.setUnit("삭제");
			element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
			element.setAction(actionUrl);
			
			element.setAdditionalProperties(additionalProperties);
			
			attachment.addElement(element);
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
	

}
