package com.lgcns.vpa.push.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Weather {
    
    /**
     * 도시코드
     */
    private String cityCode;
    
    /**
     * 도시명
     */
    private String cityName;
    
    
    private String cityEnglishName;
    
    /**
     * 도시 전체명 (예: 서울특별시 영등포구)
     */
    private String cityAllName;
    
    private String cityAllEnglishName;
    
    /**
     * 도시 축약명 (예: 서울 영등포구)
     */
    private String cityAllDisplayName;
    
    private String cityAllDisplayEnglishName;
    
    /**
     * 검색조건 (도시코드)
     */
    private String searchCityCode;
    
    /**
     * 검색조건 (주소)
     */
    private String searchAddress;
    
    private String temperatureType;
    
    /**
     * 발표일자 (YYYYMMDD)
     */
    private String baseDate;
    
    /**
     * 발표시간 (HHMI)
     */
    private String baseTime;
    
    /**
     * 예보일자 (YYYYMMDD)
     */
    private String fcstDate;
    
    /**
     * 예보시간 (HH24MI)
     */    
    private String fcstTime;
    
    private String fcstHour;
        
    /**
     * X 좌표 (공공데이터포탈 파라미터)
     */
    private String nx;
    
    /**
     * Y 좌표 (공공데이터포탈 파라미터)
     */
    private String ny;
    
    /**
     * 하늘상태 (1:맑음, 2:구름조금, 3:구름많음, 4:흐림)
     */
    private String sky;
    
    /**
     * 하늘상태명 (1:맑음, 2:구름조금, 3:구름많음, 4:흐림)
     */
    private String skyName;
    
    /**
     * 대표날씨유형 (0:맑음, 1:흐림, 2:비, 3:눈)
     */
    private String skyType;
    
    /**
     * 대표날씨유형명 (0:맑음, 1:흐림, 2:비, 3:눈)
     */
    private String skyTypeName;
    
    /**
     * 강수확률
     */
    private String pop;
    
    /**
     * 강수상태 (0: 없음, 1: 비, 2: 비/눈, 3: 눈)
     */
    private String pty;
    
    /**
     * 강수상태명 (0: 없음, 1: 비, 2: 비/눈, 3: 눈)
     */
    private String ptyName;
    
    /**
     * 1시간 온도 (단기예보)
     */
    private String t1H;
    
    /**
     * 3시간 온도 (동네예보)
     */
    private String t3H;
    
    /**
     * 최저기온
     */
    private String tmn;
    
    /**
     * 최고기온
     */
    private String tmx;
    
    /**
     * 6시간 신적설
     */
    private String ro6;
    
    /**
     * 습도
     */
    private String reh;
    
    /*
     * 1시간 강수량 (단기예보)
     */
    private String rn1;
    
    private String uuu;
    
    private String vvv;
    
    private String vec;
    
    private String wsd;
    
    private String lgt;

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityAllName() {
        return cityAllName;
    }

    public void setCityAllName(String cityAllName) {
        this.cityAllName = cityAllName;
    }

    public String getCityAllDisplayName() {
        return cityAllDisplayName;
    }

    public void setCityAllDisplayName(String cityAllDisplayName) {
        this.cityAllDisplayName = cityAllDisplayName;
    }
    
    public String getCityEnglishName() {
        return cityEnglishName;
    }

    public void setCityEnglishName(String cityEnglishName) {
        this.cityEnglishName = cityEnglishName;
    }

    public String getCityAllEnglishName() {
        return cityAllEnglishName;
    }

    public void setCityAllEnglishName(String cityAllEnglishName) {
        this.cityAllEnglishName = cityAllEnglishName;
    }

    public String getCityAllDisplayEnglishName() {
        return cityAllDisplayEnglishName;
    }

    public void setCityAllDisplayEnglishName(String cityAllDisplayEnglishName) {
        this.cityAllDisplayEnglishName = cityAllDisplayEnglishName;
    }

    public String getSearchCityCode() {
        return searchCityCode;
    }

    public void setSearchCityCode(String searchCityCode) {
        this.searchCityCode = searchCityCode;
    }

    public String getSearchAddress() {
        return searchAddress;
    }

    public void setSearchAddress(String searchAddress) {
        this.searchAddress = searchAddress;
    }

    public String getBaseDate() {
        return baseDate;
    }

    public void setBaseDate(String baseDate) {
        this.baseDate = baseDate;
    }

    public String getBaseTime() {
        return baseTime;
    }

    public void setBaseTime(String baseTime) {
        this.baseTime = baseTime;
    }

    public String getFcstDate() {
        return fcstDate;
    }

    public void setFcstDate(String fcstDate) {
        this.fcstDate = fcstDate;
    }

    public String getFcstTime() {
        return fcstTime;
    }

    public void setFcstTime(String fcstTime) {
        this.fcstTime = fcstTime;
    }
    
    public String getFcstHour() {
        return fcstHour;
    }

    public void setFcstHour(String fcstHour) {
        this.fcstHour = fcstHour;
    }

    public String getNx() {
        return nx;
    }

    public void setNx(String nx) {
        this.nx = nx;
    }

    public String getNy() {
        return ny;
    }

    public void setNy(String ny) {
        this.ny = ny;
    }

    public String getSky() {
        return sky;
    }

    public void setSky(String sky) {
        this.sky = sky;
    }

    public String getSkyName() {
        return skyName;
    }

    public void setSkyName(String skyName) {
        this.skyName = skyName;
    }

    public String getSkyType() {
        return skyType;
    }

    public void setSkyType(String skyType) {
        this.skyType = skyType;
    }

    public String getSkyTypeName() {
        return skyTypeName;
    }

    public void setSkyTypeName(String skyTypeName) {
        this.skyTypeName = skyTypeName;
    }

    public String getPop() {
        return pop;
    }

    public void setPop(String pop) {
        this.pop = pop;
    }

    public String getPty() {
        return pty;
    }

    public void setPty(String pty) {
        this.pty = pty;
    }

    public String getPtyName() {
        return ptyName;
    }

    public void setPtyName(String ptyName) {
        this.ptyName = ptyName;
    }

    public String getT1H() {
        return t1H;
    }

    public void setT1H(String t1h) {
        t1H = t1h;
    }

    public String getT3H() {
        return t3H;
    }

    public void setT3H(String t3h) {
        t3H = t3h;
    }

    public String getTmn() {
        return tmn;
    }

    public void setTmn(String tmn) {
        this.tmn = tmn;
    }

    public String getTmx() {
        return tmx;
    }

    public void setTmx(String tmx) {
        this.tmx = tmx;
    }

    public String getRo6() {
        return ro6;
    }

    public void setRo6(String ro6) {
        this.ro6 = ro6;
    }

    public String getReh() {
        return reh;
    }

    public void setReh(String reh) {
        this.reh = reh;
    }

    public String getRn1() {
        return rn1;
    }

    public void setRn1(String rn1) {
        this.rn1 = rn1;
    }

    public String getUuu() {
        return uuu;
    }

    public void setUuu(String uuu) {
        this.uuu = uuu;
    }

    public String getVvv() {
        return vvv;
    }

    public void setVvv(String vvv) {
        this.vvv = vvv;
    }

    public String getVec() {
        return vec;
    }

    public void setVec(String vec) {
        this.vec = vec;
    }

    public String getWsd() {
        return wsd;
    }

    public void setWsd(String wsd) {
        this.wsd = wsd;
    }

    public String getLgt() {
        return lgt;
    }

    public void setLgt(String lgt) {
        this.lgt = lgt;
    }

    public String getTemperatureType() {
        return temperatureType;
    }

    public void setTemperatureType(String temperatureType) {
        this.temperatureType = temperatureType;
    } 
}
