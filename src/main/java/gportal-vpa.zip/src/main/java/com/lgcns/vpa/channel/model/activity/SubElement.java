/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SubElement.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.channel.model.activity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * <PRE>
 * 테이블 형태의 데이터일 경우 데이터 처리를 위함 Model 
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 6. 22.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value=Include.NON_EMPTY)
public class SubElement implements Serializable {
    
    private static final long serialVersionUID = -851498822073396060L;

    /**
     * 엘리먼트 유형
     */
    private String type;
    
    /**
     * 제목
     */
    private String title;
    
    /**
	 * 텍스트
	 */
	private String text;

    /**
     * 값
     */
    private String value;
    
    /**
     * 스타일 클래스
     */
    private String classNames;
    
    // 액션정보
    
    /**
     * 액션 유형 (link: 링크, inquiry: 인텐트처리)
     */
    private String actionType;
    
    /**
     * 액션
     */
    private String action;
    
    /**
     * 액션 메시지
     */
    private String actionMessage;

    private int popupWidth;
    
    private int popupHeight;
    
    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getClassNames() {
		return classNames;
	}

	public void setClassNames(String classNames) {
		this.classNames = classNames;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getActionMessage() {
		return actionMessage;
	}

	public void setActionMessage(String actionMessage) {
		this.actionMessage = actionMessage;
	}

	public int getPopupWidth() {
		return popupWidth;
	}

	public void setPopupWidth(int popupWidth) {
		this.popupWidth = popupWidth;
	}

	public int getPopupHeight() {
		return popupHeight;
	}

	public void setPopupHeight(int popupHeight) {
		this.popupHeight = popupHeight;
	}
	
}
