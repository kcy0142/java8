/* ------------------------------------------------------------------------------
 * Project       : NextEP Project
 * Source        : IntentRestService.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.service;

import com.lgcns.vpa.channel.model.Bot;

/**
 * R&D 의도 추론 Restful 호출 bean
 * @author 70399
 *
 */
public interface IntentRestService {

	/**
	 * 질의문에 대한 의도 추론 결과를 반환함
	 * @param sentence
	 * @return com.lgcns.vpa.intent.model.IntentResult<ReasonData>
	 */
	IntentReasonResult  reason(Bot bot, String sentence);

}