/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : NettyPoolClientService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.base.config.BndProxyConfig.ConnectionConfig;
import com.lgcns.vpa.base.config.BndProxyConfig.ConnectionInfo;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.nettyHandler.ClientPoolHandler;
import com.lgcns.vpa.dialog.util.TripleDESUtil;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.Channel;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.WriteBufferWaterMark;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.pool.AbstractChannelPoolHandler;
import io.netty.channel.pool.ChannelHealthChecker;
import io.netty.channel.pool.ChannelPool;
import io.netty.channel.pool.FixedChannelPool;
import io.netty.channel.pool.FixedChannelPool.AcquireTimeoutAction;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.codec.Delimiters;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.util.AttributeKey;
import io.netty.util.CharsetUtil;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.FutureListener;

/**
 * <PRE>
 * Netty Client Service 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Service
public class NettyPoolClientService {
	
	public static final AttributeKey<CompletableFuture<String>> FUTURE = AttributeKey.valueOf("future");
	private static final Logger log = LoggerFactory.getLogger(NettyPoolClientService.class);

    @Value("${bndproxy.timeout.millis}")
    private int acquireTimeoutMillis;//10000
    
    @Value("${bndproxy.maxpend.acquires}")
    private int maxPendingAcquires;//2147483647

    /**
     * write buffer크기로 최대치를 초과한 경우, 더이상 쓰기 불가하며, 
     * 최소치가 있다면, 최소치로 떨구고, 쓰기는 가능하게 됨
     * by 최환준
     */
    @Value("${bndproxy.writebuffer.high}")
    private int writeBufferHigh;//32*1024, 64*1024

    /**
     * write buffer의 크기로 최대치와 동일하게 가져가면.. 어떻게 될까?
     * by 최환준
     */
    @Value("${bndproxy.writebuffer.low}")
    private int writeBufferLow;
    
    @Value("${bndproxy.sendbuffer.size}")
    private int sendBufferSize;//1024*1024
    
    @Value("${bndproxy.receivebuffer.size}")
    private int receiveBufferSize;//1024*1024
    
    /**
     * 테넌트별 channelpool을 관리함
     */
    private Map<String, ChannelPool> channelPoolMap;
    
	@Autowired
	private ConnectionConfig connectionConfig;
	
	private EventLoopGroup eventLoopGroup;
	
	public NettyPoolClientService() {
		channelPoolMap = new HashMap<>();
	}
	 
	/**
	 * Back And Proxy Server에 Connection 초기화
	 * @param host
	 * @param port
	 * @param numberOfThreads
	 * @param numberOfConnections
	 */
	private synchronized ChannelPool openConnection(ConnectionInfo connectionInfo) {
		 
		if( channelPoolMap.containsKey(connectionInfo.getTenantId())) {
			return channelPoolMap.get(connectionInfo.getTenantId());
		}
			
		Bootstrap bootstrap = new Bootstrap();
		bootstrap.option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT);
		bootstrap.option(ChannelOption.SO_KEEPALIVE, true);
		bootstrap.option(ChannelOption.SO_SNDBUF, sendBufferSize);
		bootstrap.option(ChannelOption.SO_RCVBUF, receiveBufferSize);
	    
        bootstrap.option(ChannelOption.WRITE_BUFFER_WATER_MARK, new WriteBufferWaterMark(writeBufferLow, writeBufferHigh));
        bootstrap.option(ChannelOption.TCP_NODELAY, true);
	        
		eventLoopGroup = new NioEventLoopGroup(connectionInfo.getThreadCount());
		
	    bootstrap.group(eventLoopGroup).channel(NioSocketChannel.class)
	    	.remoteAddress(connectionInfo.getHost(), connectionInfo.getPort());
	        
		/**
		 * FixedChannelPool : enforce a maximum number of concurrent connections.-->connectionInfo.getConnectionCount
		 */
	    ChannelPool channelPool = new ProxyChannelPool(
	    		bootstrap, //연결을 위해 사용될 bootstrap
				new ProxyChannelPoolHandler(), 
				ChannelHealthChecker.ACTIVE,//eventloop에서 사용될 channel이 유효한지 확인한다.
				AcquireTimeoutAction.NEW, 	//timeout이 detect되었을 때, 신규로 만들것인지, 삭제할 것인지 설정
				acquireTimeoutMillis, 		//
				connectionInfo.getMaxConnectionCount(), //활성화된 connection최대값으로 최대값에 도달하면, connection이 pool에 반환될 때까지 channel을 얻는 것은 대기한다.
				maxPendingAcquires);		//대기중인 최대 요청건으로 초과시 오류를 던진다.
	    channelPoolMap.put(connectionInfo.getTenantId(), channelPool);
		return channelPool;
	}
	
	/**
	 * 동기식 Back And Proxy Server에 메세지 전송 요청
	 * @param requestVO
	 * @return
	 */
	public String sendToBnpSync (TransferSyncVO requestVO) throws Exception {
		StringBuilder msg = new StringBuilder(requestVO.toJson());
		msg.append("\r\n");
		log.info("sendToBnpSync : {}", requestVO);
		
		String tenantId=requestVO.getTenantId();	//터넌트 아이디 전송
		return this.sendToBnpSync(msg.toString(),tenantId);
	}
	
	/**
	 * 동기식 Back And Proxy Server에 메세지 전송 요청
	 * @param requestJsonData
	 * @return
	 */
	public String sendToBnpSync(String requestJsonData,String tenantId) throws Exception {
		
		final ConnectionInfo connectionInfo = connectionConfig.getConnectionInfo(tenantId);
		
		if( connectionInfo == null ) {
			throw new IllegalStateException(String.format("{} connection config does not exist", tenantId));
		}
		else {
			log.info("sendToBnpSync ====>>> tenantId : ["+connectionInfo.getTenantId()+"], secretKey:[" + connectionInfo.getSecretKey()+"]");
		}
		
		ChannelPool channelPool = openConnection(connectionInfo);

		long startTime = System.currentTimeMillis();
		
		//log.info("Send to {} Message [{} bytes] : {}",connectionInfo.toString(), requestJsonData.getBytes().length, requestJsonData);
		
		final CompletableFuture<String> future = new CompletableFuture<String>();
		Future<Channel> channelFuture = channelPool.acquire();
		channelFuture.addListener(new FutureListener<Channel>() {
            public void operationComplete(Future<Channel> f) {
                if (f.isSuccess()) {
                    Channel channel = f.getNow();
                    String secretKey = connectionInfo.getSecretKey();
                    String encryptedMessage=tenantId.trim()+"##"+TripleDESUtil.encrypt(requestJsonData,secretKey);
                    //log.info("Send to {} Message [{} bytes] : {} ", tenantId, encryptedMessage.getBytes().length, encryptedMessage);
                    
                    channel.attr(FUTURE).set(future);
                    channel.writeAndFlush(encryptedMessage, channel.voidPromise());
                    //channelPool.release(channel);
	            } else {
					log.error(f.cause().getMessage());
					f.cause().printStackTrace();
				}
            }
        });
        //동기처리 ==> future에서 값을 받아서 처리할 수 있음
		String resultJson = null;
        try {
        	resultJson = future.get(acquireTimeoutMillis*2, TimeUnit.MILLISECONDS);
        	log.info("Receive from {} Message [{} bytes][{} ms] : {} ", tenantId, resultJson.getBytes().length, System.currentTimeMillis()-startTime, resultJson.substring(0, Math.min(30, resultJson.length())));
        } catch (Exception e) {
        	log.error("Exception[{}] : tenant [{}] request : {}", e.getClass(), tenantId, requestJsonData);
        	e.printStackTrace();
        	future.cancel(true);
        	throw e;
        }
        
        return resultJson;
	}//sendToBnp
	
	class ProxyChannelPool extends FixedChannelPool {

		public ProxyChannelPool(Bootstrap bootstrap, 
				ProxyChannelPoolHandler handler,
				ChannelHealthChecker healthCheck, 
				AcquireTimeoutAction action, 
				int acquireTimeoutMillis,
				int maxConnections, 
				int maxPendingAcquires) {
			
			super(bootstrap, handler, healthCheck, action, acquireTimeoutMillis, maxConnections, maxPendingAcquires);
			handler.regist(this);
		}
	}
	
	class ProxyChannelPoolHandler extends AbstractChannelPoolHandler {
		private ChannelPool channelPool;
		void regist(ChannelPool channelPool) {
			this.channelPool = channelPool;
		}
		@Override
		public void channelCreated(Channel ch) throws Exception {
			ChannelPipeline pipeline = ch.pipeline();
			pipeline.addLast("framer", new DelimiterBasedFrameDecoder(Integer.MAX_VALUE, Delimiters.lineDelimiter()));
	        pipeline.addLast("stringDecoder", new StringDecoder(CharsetUtil.UTF_8));
	        pipeline.addLast("stringEncoder",  new StringEncoder(CharsetUtil.UTF_8));
	        pipeline.addLast("clientHandler", new ClientPoolHandler(channelPool));// business logic handler
		}
	}
	
	
/*	public static final AttributeKey<CompletableFuture<String>> FUTURE = AttributeKey.valueOf("future");
	private static final StringDecoder stringDecoder = new StringDecoder(CharsetUtil.UTF_8);
    private static final StringEncoder stringEncoder = new StringEncoder(CharsetUtil.UTF_8);
    private static ChannelPool channelPool0;
	private static ChannelPool channelPool1;
	private static ChannelPool channelPool2;
	private static ChannelPool channelPool3;
	private static ChannelPool channelPool4;
	private static EventLoopGroup eventLoopGroup;
	
	private static final Logger log = LoggerFactory.getLogger(NettyPoolClientService.class);
	
	@Autowired
	private ProxyTenantInfo tenantInfo;
	*/
	
	 
	/**
	 * Back And Proxy Server에 Connection 초기화
	 * @param host
	 * @param port
	 * @param numberOfThreads
	 * @param numberOfConnections
	 */
/*	 private synchronized void initConnection (String host, int port, int numberOfThreads, int numberOfConnections,String tenantId) {
		

			eventLoopGroup = new NioEventLoopGroup(numberOfThreads);
			
			Bootstrap bootstrap = new Bootstrap();
	        bootstrap.option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT);
	        bootstrap.option(ChannelOption.SO_KEEPALIVE, true);
	        //추가
	        bootstrap.option(ChannelOption.SO_SNDBUF, 1024*1024);
	        bootstrap.option(ChannelOption.SO_RCVBUF, 1024*1024);
	        bootstrap.option(ChannelOption.WRITE_BUFFER_WATER_MARK, new WriteBufferWaterMark(32*1024, 64*1024));
	        bootstrap.option(ChannelOption.TCP_NODELAY, true);
	        //추가
	        
	        
	        bootstrap.group(eventLoopGroup).channel(NioSocketChannel.class).remoteAddress(host, port);
	        
	        int acquireTimeoutMillis = 10000;
	        int maxPendingAcquires = Integer.MAX_VALUE;
	        System.out.println("=========initConnection start");
	    	if(tenantId.equals("ele")){
	    		if ( (channelPool1 != null) && (eventLoopGroup != null) ) {
					return;
				}
	    		 channelPool1 = new FixedChannelPool(bootstrap, 	//연결을 위해 사용될 bootstrap
	    				 	new AbstractChannelPoolHandler() {		
								public void channelCreated(Channel ch) throws Exception {
									ChannelPipeline pipeline = ch.pipeline();
					                // decoders
									pipeline.addLast("framer", new DelimiterBasedFrameDecoder(Integer.MAX_VALUE, Delimiters.lineDelimiter()));
					                pipeline.addLast("stringDecoder", stringDecoder);
					
					                // encoders
					                pipeline.addLast("stringEncoder", stringEncoder);
					
					                // business logic handler
					                pipeline.addLast("clientHandler", new ClientPoolHandler(channelPool1));
								}
							}, 
	    	        		ChannelHealthChecker.ACTIVE,//eventloop에서 사용될 channel이 유효한지 확인한다.
	    	        		AcquireTimeoutAction.NEW, 	//timeout이 detect되었을 때, 신규로 만들것인지, 삭제할 것인지 설정
	    	        		acquireTimeoutMillis, 		//
	    	        		numberOfConnections, 		//활성화된 connection최대값
	    	        		maxPendingAcquires);		//대기중인 최대 요청건으로 초과시 오류를 던진다.
	    	        //System.out.println("==============channelPool.toString():"+channelPool1.toString());
			}else  if(tenantId.equals("che")){
				if ( (channelPool2 != null) && (eventLoopGroup != null) ) {
					return;
				}
				 channelPool2 = new FixedChannelPool(bootstrap, 	//연결을 위해 사용될 bootstrap
						new AbstractChannelPoolHandler() {		
							public void channelCreated(Channel ch) throws Exception {
								ChannelPipeline pipeline = ch.pipeline();
				                // decoders
								pipeline.addLast("framer", new DelimiterBasedFrameDecoder(Integer.MAX_VALUE, Delimiters.lineDelimiter()));
				                pipeline.addLast("stringDecoder", stringDecoder);
				
				                // encoders
				                pipeline.addLast("stringEncoder", stringEncoder);
				
				                // business logic handler
				                pipeline.addLast("clientHandler", new ClientPoolHandler(channelPool2));
							}
						}, 
	 	        		ChannelHealthChecker.ACTIVE,//eventloop에서 사용될 channel이 유효한지 확인한다.
	 	        		AcquireTimeoutAction.NEW, 	//timeout이 detect되었을 때, 신규로 만들것인지, 삭제할 것인지 설정
	 	        		acquireTimeoutMillis, 		//
	 	        		numberOfConnections, 		//활성화된 connection최대값
	 	        		maxPendingAcquires);		//대기중인 최대 요청건으로 초과시 오류를 던진다.
	 	        //System.out.println("==============channelPoo2.toString():"+channelPool2.toString());
			}else if(tenantId.equals("lgcns")){
				if ( (channelPool3 != null) && (eventLoopGroup != null) ) {
					return;
				} 
				 channelPool3 = new FixedChannelPool(bootstrap, 	//연결을 위해 사용될 bootstrap
						 new AbstractChannelPoolHandler() {		
							public void channelCreated(Channel ch) throws Exception {
								ChannelPipeline pipeline = ch.pipeline();
				                // decoders
								pipeline.addLast("framer", new DelimiterBasedFrameDecoder(Integer.MAX_VALUE, Delimiters.lineDelimiter()));
				                pipeline.addLast("stringDecoder", stringDecoder);
				
				                // encoders
				                pipeline.addLast("stringEncoder", stringEncoder);
				
				                // business logic handler
				                pipeline.addLast("clientHandler", new ClientPoolHandler(channelPool3));
							}
						},
	 	        		ChannelHealthChecker.ACTIVE,//eventloop에서 사용될 channel이 유효한지 확인한다.
	 	        		AcquireTimeoutAction.NEW, 	//timeout이 detect되었을 때, 신규로 만들것인지, 삭제할 것인지 설정
	 	        		acquireTimeoutMillis, 		//
	 	        		numberOfConnections, 		//활성화된 connection최대값
	 	        		maxPendingAcquires);		//대기중인 최대 요청건으로 초과시 오류를 던진다.
	 	        //System.out.println("==============channelPoo3.toString():"+channelPool3.toString());
			}else if(tenantId.equals("dis")){
				if ( (channelPool4 != null) && (eventLoopGroup != null) ) {
					return;
				}
				 channelPool4 = new FixedChannelPool(bootstrap, 	//연결을 위해 사용될 bootstrap
						 new AbstractChannelPoolHandler() {		
							public void channelCreated(Channel ch) throws Exception {
								ChannelPipeline pipeline = ch.pipeline();
				                // decoders
								pipeline.addLast("framer", new DelimiterBasedFrameDecoder(Integer.MAX_VALUE, Delimiters.lineDelimiter()));
				                pipeline.addLast("stringDecoder", stringDecoder);
				
				                // encoders
				                pipeline.addLast("stringEncoder", stringEncoder);
				
				                // business logic handler
				                pipeline.addLast("clientHandler", new ClientPoolHandler(channelPool4));
							}
						},
		 	        	ChannelHealthChecker.ACTIVE,//eventloop에서 사용될 channel이 유효한지 확인한다.
	 	        		AcquireTimeoutAction.NEW, 	//timeout이 detect되었을 때, 신규로 만들것인지, 삭제할 것인지 설정
	 	        		acquireTimeoutMillis, 		//
	 	        		numberOfConnections, 		//활성화된 connection최대값
	 	        		maxPendingAcquires);		//대기중인 최대 요청건으로 초과시 오류를 던진다.
	 	        //System.out.println("==============channelPoo4.toString():"+channelPool4.toString());
			}else{
				if ( (channelPool0 != null) && (eventLoopGroup != null) ) {
					return;
				}
				 channelPool0 = new FixedChannelPool(bootstrap, 	//연결을 위해 사용될 bootstrap
						 new AbstractChannelPoolHandler() {		
							public void channelCreated(Channel ch) throws Exception {
								ChannelPipeline pipeline = ch.pipeline();
				                // decoders
								pipeline.addLast("framer", new DelimiterBasedFrameDecoder(Integer.MAX_VALUE, Delimiters.lineDelimiter()));
				                pipeline.addLast("stringDecoder", stringDecoder);
				
				                // encoders
				                pipeline.addLast("stringEncoder", stringEncoder);
				
				                // business logic handler
				                pipeline.addLast("clientHandler", new ClientPoolHandler(channelPool0));
							}
						},
	 	        		ChannelHealthChecker.ACTIVE,//eventloop에서 사용될 channel이 유효한지 확인한다.
	 	        		AcquireTimeoutAction.NEW, 	//timeout이 detect되었을 때, 신규로 만들것인지, 삭제할 것인지 설정
	 	        		acquireTimeoutMillis, 		//
	 	        		numberOfConnections, 		//활성화된 connection최대값
	 	        		maxPendingAcquires);		//대기중인 최대 요청건으로 초과시 오류를 던진다.
	 	        //System.out.println("==============channelPoo0.toString():"+channelPool0.toString());
			}
	    	
	       
	    	System.out.println("=========initConnection end");
	        System.out.println("#############################################");
			
		}//initConnection
	
	*//**
	 * 동기식 Back And Proxy Server에 메세지 전송 요청
	 * @param requestVO
	 * @return
	 *//*
	public synchronized String sendToBnpSync (TransferSyncVO requestVO) throws Exception {
		StringBuilder msg = new StringBuilder(requestVO.toJson());
		msg.append("\r\n");
		log.info("##### sendToBnpSync send  getActionId : "+requestVO.getActionId());
		log.info("##### sendToBnpSync send  getIntentId : "+requestVO.getIntentId());
		log.info("##### sendToBnpSync send  getTenantId : "+requestVO.getTenantId());
		log.info("##### sendToBnpSync send  getActionUri : "+requestVO.getActionUri());
		
		String tenantId=requestVO.getTenantId();	//터넌트 아이디 전송
		return this.sendToBnpSync(msg.toString(),tenantId);
	}
	
	*//**
	 * 동기식 Back And Proxy Server에 메세지 전송 요청
	 * @param requestJsonData
	 * @return
	 *//*
	public String sendToBnpSync(String requestJsonData,String tenantId) throws Exception {
		
		long startTime = System.currentTimeMillis();
		
		String resultJson = null;
		final CompletableFuture<String> future = new CompletableFuture<String>();
		Future<Channel> channelFuture=null;
		//System.out.println("===================sendToBnpSync tenantId:"+tenantId);
		log.info("##### NettyPoolClientService send  tenantId : "+tenantId);
		log.info("##### NettyPoolClientService send  requestJsonData  Message : "+requestJsonData);
		log.info("##### NettyPoolClientService send  requestJsonData  Message.length : "+requestJsonData.length());
       
		
        String info=tenantInfo.getTenantInfo(tenantId);
        String[] infoArray=info.split("#");
        
        String host=infoArray[0];
        String port=infoArray[1];
        String numberOfConnections=infoArray[2];
        String numberOfThreads=infoArray[3];
        
        
		if(tenantId.equals("ele")){
			if (channelPool1 == null) {
				initConnection(host, Integer.parseInt(port), Integer.parseInt(numberOfThreads), Integer.parseInt(numberOfConnections) ,tenantId);
			}
			channelFuture = channelPool1.acquire();
			
        }else  if(tenantId.equals("che")){
        	if (channelPool2 == null) {
        		initConnection(host, Integer.parseInt(port), Integer.parseInt(numberOfThreads), Integer.parseInt(numberOfConnections),tenantId );
    		}
    		channelFuture = channelPool2.acquire();
        }else if(tenantId.equals("lgcns")){
        	if (channelPool3 == null) {
        		initConnection(host, Integer.parseInt(port), Integer.parseInt(numberOfThreads), Integer.parseInt(numberOfConnections) ,tenantId);
    		}
    		channelFuture = channelPool3.acquire();
        }else if(tenantId.equals("dis")){
        	if (channelPool4 == null) {
        		initConnection(host, Integer.parseInt(port), Integer.parseInt(numberOfThreads), Integer.parseInt(numberOfConnections) ,tenantId);
    		}
    		channelFuture = channelPool4.acquire();
        }else{
        	if (channelPool0 == null) {
        		initConnection(host, Integer.parseInt(port), Integer.parseInt(numberOfThreads), Integer.parseInt(numberOfConnections),tenantId );
    		}
        	channelFuture = channelPool0.acquire();
        }
		
		
       
		channelFuture.addListener(new FutureListener<Channel>() {
            public void operationComplete(Future<Channel> f) {
                if (f.isSuccess()) {
                    Channel channel = f.getNow();
                    //Message 암호화 시작
                    String info=tenantInfo.getTenantInfo(tenantId);
                    String[] infoArray=info.split("#");
                    String secretKey=infoArray[4];
                   // String secretKey="";
                    String encryptedMessage=tenantId.trim()+"##"+TripleDESUtil.encrypt(requestJsonData,secretKey);
                   // String originalMessage=tenantId.trim()+"##"+requestJsonData;
                    //Message 암호화 끝 
                    
                    log.info("##### NettyPoolClientService send  encryptedMessage Message : "+encryptedMessage);
                    log.info("##### NettyPoolClientService send  encryptedMessage  Message.length : "+encryptedMessage.length());
                    
                    channel.attr(NettyPoolClientService.FUTURE).set(future);
                    channel.writeAndFlush(encryptedMessage, channel.voidPromise());
	            } else {
					System.out.println("====error break ======="+f.cause().getMessage());
					f.cause().printStackTrace();
				}
            }
        });
        
        //비동기처리 ==> 핸들러에서 응답을 처리함
        //channelFuture.syncUninterruptibly();
        
        
        //동기처리 ==> future에서 값을 받아서 처리할 수 있음
        try {
        	resultJson = (String) future.get(10, TimeUnit.SECONDS);
        	
        	System.out.println("### ### ### Result Message :("+(System.currentTimeMillis()-startTime)+")ms, ["+resultJson+"]");
        } catch (Exception e) {
        	log.info("Exception : ["+e.toString()+"],requestJsonData:["+requestJsonData+"],tenantId:["+tenantId+"]");
        	e.printStackTrace();
        	throw e;
        }
        
        
        return resultJson;
	}//sendToBnp
*/}
