/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SearchDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.ServersConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.channel.service.SearchService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.security.user.service.UserRoleService;

/**
 * <PRE>
 * LG CNS 통합 검색용 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 12. 19.
 */
@Component("CnsCommonSearchDialog")
public class CnsCommonSearchDialog extends VpaDialog {

	private static final Logger LOG = LoggerFactory.getLogger(CnsCommonSearchDialog.class);
	
	private static final String 
			COLLECTION_COSTANDARD 		= "costandard",
			COLLECTION_DICTIONARY 		= "dictionary",
			COLLECTION_KNOWLEDGE 		= "knowledge",
			COLLECTION_COLLABORATION 	= "collaboration",
			COLLECTION_BBS 				= "bbs",
			COLLECTION_QNA 				= "qna"; 
	
	@Autowired
	private SearchService searchService;
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private ServersConfig serversConfig;
	
	@Autowired
	private BotService botService;
	
	@Override
	protected boolean validator(InquiryVO data) {
		
		boolean isValid = true;
		
		Map<String, Object> param = data.getIntentParam();
		if ( (param == null) || (param.isEmpty()) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
					 "], 통합 검색을 위한 파라미터가 없음.");
		}
		else {
			String searchInquiry = (param.get("name") != null) ? String.valueOf(param.get("name")) : null;
			data.setSearchInquiryData(searchInquiry);
		}
		
		LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
				 "], Intent Param:["+data.getIntentParam()+"]");
		
		return true;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		boolean hasRight = false;
		
		if ( data.getReqUser() == null ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한을 검사할 Req User 정보가 없음");
			return false;
		}
		
		//인텐트별 사용자의 사용 권한 조회
		hasRight = this.userRoleService.validateUserRole(data.getReqUser(), data.getIntentId());
		
		if (!hasRight) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한 없음");
		}
		return hasRight;
	}

	@Override
	protected String processor(InquiryVO data) {
		if ( (data == null) || (data.getAction() == null) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 정보가 부정확함");
			return null;
		}
		
		String resultJsonData = null;
		List<Map<String, Object>> searchResult = null;
		
		try {
			//통합검색에 Costandard Data 요청
			//intent Parameter 의 name 값을 name의 value 를 검색어로 지정하고
			//값이 없으면 질의어를 검색어로 지정함
			
			String searchText = null;
			String collection = null;
			Map<String, Object> intentParam = data.getIntentParam();
			if ( (intentParam != null) && (intentParam.containsKey("searchText")) ) {
				searchText = (String) intentParam.get("searchText");
			}
			
			if ( data.getAction() != null ) {
				Action action = data.getAction();
				collection = action.getActionType();
			}
			
			if ( !StringUtils.isEmpty(collection) ) {
				if ( !StringUtils.isEmpty(searchText) ) {
					searchResult = this.searchService.search(data.getTenantId(), searchText, collection, null);
				}
				else {
					searchResult = this.searchService.search(data.getTenantId(), data.getInquiryData(), collection, null);
				}
				
				//조회 결과 없음
				if ( (searchResult == null) || (searchResult.isEmpty()) ) {
					//결과가 없음
					resultJsonData = CommonCode.ACTION_RESULT_NONE;
					
					LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 결과가 없음");
				}
				//조회 결과 Json 변환
				else {
					ObjectMapper objMapper = new ObjectMapper();
					resultJsonData = objMapper.writeValueAsString(searchResult);
					data.setSearchResult(searchResult);
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], collection(ActionType):["+collection+"], 정보가 부정확함");
				return null;
			}
		} catch (Exception e) {
			//오류 발생
			resultJsonData = CommonCode.ACTION_RESULT_ERROR;
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 중 오류 발생, Exception : " + e.toString());
		}
		
		return resultJsonData;
	}

	@Override
	protected Activity afterWork(InquiryVO data, String searchResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(searchResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet = data.getSearchResult();
			
			if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				
				Action action = data.getAction();
				String collection = action.getActionType();
				
				//통합 검색에서 조회된 결과로 Attachment 를 구함
				switch (collection) {
				case COLLECTION_COSTANDARD :
					attachments = this.getCoAttachment(data, proxyResultSet);
					break;
				case COLLECTION_DICTIONARY :
					attachments = this.getDicAttachment(data, proxyResultSet);
					break;
				case COLLECTION_COLLABORATION :
					attachments = this.getCollAttachment(data, proxyResultSet);
					break;
				case COLLECTION_KNOWLEDGE :
					attachments = this.getKnowAttachment(data, proxyResultSet);
					break;
				case COLLECTION_BBS :
					attachments = this.getBbsAttachment(data, proxyResultSet);
					break;
				case COLLECTION_QNA :
					attachments = this.getQnaAttachment(data, proxyResultSet);
					break;
				}
				
				if ( (attachments != null) && (!attachments.isEmpty()) ) {
					
					//int count = proxyResultSet.size();
					
					//Activity Message
					resultActivity.setMessage(data.getIntentMessage());
					resultActivity.setAttachments(attachments);
				}
				else {
					LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
					
					//Data 가 없음
		        	resultActivity = this.commonResponeService.simpleResponseMessage(
							data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
							this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
		        	
		        	StringBuffer messgeBuf = new StringBuffer();
		        	messgeBuf.append(data.getIntentMessage()).append("\n\n").append(resultActivity.getMessage());
		        	resultActivity.setMessage(messgeBuf.toString());
				}
				
				//의도분석의 Button이 있는 경우 처리
				if ( data.getIntentButtons() != null ) {
					List<RelatedButton> buttons = data.getIntentButtons();
					List<Button> activityButtonList = super.makeActivityButtonList(buttons);
					
					if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
						resultActivity.setButtons(activityButtonList);
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Activity Message
				StringBuffer activityMessage = new StringBuffer();
				activityMessage.append(data.getInquiryData()).append(" ");
				activityMessage.append(this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						activityMessage.toString());
	        	
	        	StringBuffer messgeBuf = new StringBuffer();
	        	messgeBuf.append(data.getIntentMessage()).append("\n\n").append(resultActivity.getMessage());
	        	resultActivity.setMessage(messgeBuf.toString());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
			
			StringBuffer messgeBuf = new StringBuffer();
        	messgeBuf.append(data.getIntentMessage()).append("\n\n").append(resultActivity.getMessage());
        	resultActivity.setMessage(messgeBuf.toString());
		}
		
		return resultActivity;
	}
	
	/**
	 * COSTANDARD Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	private List<Attachment> getCoAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        /*
			DOCID			string	키값
			DATE			string	날짜
			STD_ID			string	STD_ID
			TITLE			string	TITLE
			CONTENT			string	CONTENT
			VERSION			string	VERSION
			EXEC_DATE		string	EXEC_DATE
			OWNER_USER_ID	string	OWNER_USER_ID
			EMP_NM			string	EMP_NM
			WORK_AREA_CD	string	WORK_AREA_CD
			WORK_AREA_NM	string	WORK_AREA_NM
			DOC_TYPE_CD		string	DOC_TYPE_CD
			DOC_TYPE_NM		string	DOC_TYPE_NM
			URL_NM			string	URL_NM
			ALIAS			string	구분값
			*/
			String title = null, date = null, empNm = null, content = null, docTypeNm = null, urlNm = null;
			StringBuffer titleBuf = new StringBuffer();
			StringBuffer actionUrl = new StringBuffer();
			
			for (Map<String, Object> proxyResult : proxyResultSet) {
				
				titleBuf.setLength(0);
				actionUrl.setLength(0);
				
				if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
					
					title = (proxyResult.get("TITLE") != null) ? String.valueOf(proxyResult.get("TITLE")) : "";
					date = (proxyResult.get("DATE") != null) ? String.valueOf(proxyResult.get("DATE")) : "";
					empNm = (proxyResult.get("EMP_NM") != null) ? String.valueOf(proxyResult.get("EMP_NM")) : "";
					content = (proxyResult.get("CONTENT") != null) ? String.valueOf(proxyResult.get("CONTENT")) : "";
					docTypeNm = (proxyResult.get("DOC_TYPE_NM") != null) ? String.valueOf(proxyResult.get("DOC_TYPE_NM")) : "";
					urlNm = (proxyResult.get("URL_NM") != null) ? String.valueOf(proxyResult.get("URL_NM")) : "";
					
					//Title
					titleBuf.append(title);
					if ( !StringUtils.isEmpty(date) ) {
						titleBuf.append("  [").append(date);
					}
					if ( !StringUtils.isEmpty(empNm) ) {
						if ( !StringUtils.isEmpty(date) ) {
							titleBuf.append(" | ");
						}
						else {
							titleBuf.append("  [");
						}
						titleBuf.append(empNm);
					}
					if ( !StringUtils.isEmpty(date) || !StringUtils.isEmpty(empNm)) {
						titleBuf.append("]");
					}
					
					Element element = new Element();
    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
    				element.setSubtitle(docTypeNm);
    				element.setTitle(titleBuf.toString());
    				element.setDescriptions(content);
    				element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
    				element.setAction(urlNm);
    				
    				attachment.addElement(element);
        		}
			}
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}//getCoAttachment
	
	/**
	 * DICTIONARY Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	private List<Attachment> getDicAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        /*
			DOCID	string	DOCID
			TAG_ID	string	TAG_ID
			TITLE	string	TITLE
			DFIN_NO	string	DFIN_NO
			CONTENT	string	CONTENT
			STD_NM_GLOBAL	string	STD_NM_GLOBAL
			FULL_NM	string	FULL_NM
			KOR_TAG_NM	string	KOR_TAG_NM
			ENG_SHORT_NM	string	ENG_SHORT_NM
			IT_COMM_FG	string	IT_COMM_FG
			CAT_CD	string	CAT_CD
			DATE	string	DATE
			EMP_NM	string	EMP_NM
			ALIAS	string	ALIAS
			baseUrl string baseUrl
			*/
			String title = null, date = null, empNm = null, stdNmGlobal = null, content = null;
			String baseUrl = null, tagId = null;
			StringBuffer titleBuf = new StringBuffer();
			StringBuffer actionUrl = new StringBuffer();
			
			for (Map<String, Object> proxyResult : proxyResultSet) {
				
				titleBuf.setLength(0);
				actionUrl.setLength(0);
				
				if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
					
					tagId = (proxyResult.get("TAG_ID") != null) ? String.valueOf(proxyResult.get("TAG_ID")) : "";
					title = (proxyResult.get("TITLE") != null) ? String.valueOf(proxyResult.get("TITLE")) : "";
					date = (proxyResult.get("DATE") != null) ? String.valueOf(proxyResult.get("DATE")) : "";
					empNm = (proxyResult.get("EMP_NM") != null) ? String.valueOf(proxyResult.get("EMP_NM")) : "";
					content = (proxyResult.get("CONTENT") != null) ? String.valueOf(proxyResult.get("CONTENT")) : "";
					stdNmGlobal = (proxyResult.get("STD_NM_GLOBAL") != null) ? String.valueOf(proxyResult.get("STD_NM_GLOBAL")) : "";
					baseUrl = (proxyResult.get("baseUrl") != null) ? String.valueOf(proxyResult.get("baseUrl")) : "";
					
					//Title
					titleBuf.append(title);
					if ( !StringUtils.isEmpty(date) ) {
						titleBuf.append("  [").append(date);
					}
					if ( !StringUtils.isEmpty(empNm) ) {
						if ( !StringUtils.isEmpty(date) ) {
							titleBuf.append(" | ");
						}
						else {
							titleBuf.append("  [");
						}
						titleBuf.append(empNm);
					}
					if ( !StringUtils.isEmpty(date) || !StringUtils.isEmpty(empNm)) {
						titleBuf.append("]");
					}
					
					//Action Url
					if ( !StringUtils.isEmpty(baseUrl) ) {
						actionUrl.append(baseUrl).append("/searchDictionarySlp.do?method=viewDictionaryDetail&tagId=");
						actionUrl.append(tagId);
					}
					
    				Element element = new Element();
    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
    				if ( !StringUtils.isEmpty(stdNmGlobal) ) {
    					element.setSubtitle("영문명 : "+stdNmGlobal);
    				}
    				element.setTitle(titleBuf.toString());
    				element.setDescriptions(content);
    				element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
    				element.setAction(actionUrl.toString());
    				
    				attachment.addElement(element);
        		}
			}
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}//getDicAttachment
	
	/**
	 * COLLABORATION Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	private List<Attachment> getCollAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        /*
			DOCID	string	DOCID
			DATE	string	DATE
			DOC_ID	string	DOC_ID
			TITLE	string	TITLE
			CONTENT	string	CONTENT
			SHARE_TYPE	string	SHARE_TYPE
			SEC_GRADE	string	SEC_GRADE
			EMP_NO	string	EMP_NO
			EMP_NM	string	EMP_NM
			LST_UPDATE	string	LST_UPDATE
			CL_NM	string	CL_NM
			SEC_CD	string	SEC_CD
			FILE_ID	string	FILE_ID
			FILE_NAME	string	FILE_NAME
			FILE_PATH	string	FILE_PATH
			ATTACH	string	ATTACH
			SHARE_CD	string	SHARE_CD
			CL_TYPE_CD	string	CL_TYPE_CD
			CL_TYPE	string	CL_TYPE
			CORP_CD	string	CORP_CD
			PREVIEW_FG	string	PREVIEW_FG
			PRE_URL	string	PRE_URL
			URL	string	URL
			AUTH01	string	임시필드
			AUTH02	string	임시필드
			AUTH03	string	임시필드
			ALIAS	string	ALIAS
			baseUrl string baseUrl
			*/
			String title = null, date = null, empNm = null, url = null, baseUrl = null, content = null, clNm = null;
			StringBuffer titleBuf = new StringBuffer();
			StringBuffer actionUrl = new StringBuffer();
			
			for (Map<String, Object> proxyResult : proxyResultSet) {
				
				titleBuf.setLength(0);
				actionUrl.setLength(0);
				
				if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
					
					title = (proxyResult.get("TITLE") != null) ? String.valueOf(proxyResult.get("TITLE")) : "";
					content = (proxyResult.get("CONTENT") != null) ? String.valueOf(proxyResult.get("CONTENT")) : "";
					date = (proxyResult.get("DATE") != null) ? String.valueOf(proxyResult.get("DATE")) : "";
					empNm = (proxyResult.get("EMP_NM") != null) ? String.valueOf(proxyResult.get("EMP_NM")) : "";
					url = (proxyResult.get("URL") != null) ? String.valueOf(proxyResult.get("URL")) : "";
					baseUrl = (proxyResult.get("baseUrl") != null) ? String.valueOf(proxyResult.get("baseUrl")) : "";
					clNm = (proxyResult.get("CL_NM") != null) ? String.valueOf(proxyResult.get("CL_NM")) : "";
							
					//Title
					titleBuf.append(title);
					if ( !StringUtils.isEmpty(date) ) {
						titleBuf.append("  [").append(date);
					}
					if ( !StringUtils.isEmpty(empNm) ) {
						if ( !StringUtils.isEmpty(date) ) {
							titleBuf.append(" | ");
						}
						else {
							titleBuf.append("  [");
						}
						titleBuf.append(empNm);
					}
					if ( !StringUtils.isEmpty(date) || !StringUtils.isEmpty(empNm)) {
						titleBuf.append("]");
					}
					
    				//Costandard URL (Detail 조회용)
    				if ( !StringUtils.isEmpty(baseUrl) && !StringUtils.isEmpty(url) ) {    					
    					actionUrl.append(baseUrl).append(url);
    				}
    				
    				Element element = new Element();
    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
    				element.setSubtitle(clNm);
    				element.setTitle(titleBuf.toString());
    				element.setDescriptions(content);
    				element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
    				element.setAction(actionUrl.toString());
    				
    				attachment.addElement(element);
        		}
			}
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}//getCollAttachment
	
	/**
	 * KNOWLEDGE Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	private List<Attachment> getKnowAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        /*
			DOCID	string	DOCID
			DATE	string	DATE
			SRC_DOC_ID	string	SRC_DOC_ID
			SEARCH_KEY_ID	string	SEARCH_KEY_ID
			TITLE	string	TITLE
			CONTENT	string	CONTENT
			EMP_NO	string	EMP_NO
			EMP_NM	string	EMP_NM
			REG_EMP_TITLE	string	REG_EMP_TITLE
			UPT_DATE	string	UPT_DATE
			JULCH_FILE_NM	string	JULCH_FILE_NM
			WBS_FILE_NM	string	WBS_FILE_NM
			TEMPLATE_FILE_NM	string	TEMPLATE_FILE_NM
			OUTPUT_FILE_NM	string	OUTPUT_FILE_NM
			OUTPUT_REL_FILE_NM	string	OUTPUT_REL_FILE_NM
			GUIDE_FILE_NM	string	GUIDE_FILE_NM
			CHKLST_FILE_NM	string	CHKLST_FILE_NM
			JEAN_FILE_NM	string	JEAN_FILE_NM
			DISPLAY_VERSION	string	DISPLAY_VERSION
			ALIAS	string	ALIAS
			URL		string 	URL
			*/
			String title = null, date = null, empNm = null, docId = null, url = null, content = null;
			StringBuffer titleBuf = new StringBuffer();
			StringBuffer actionUrl = new StringBuffer();
			
			for (Map<String, Object> proxyResult : proxyResultSet) {
				
				titleBuf.setLength(0);
				actionUrl.setLength(0);
				
				if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
					
					title = (proxyResult.get("TITLE") != null) ? String.valueOf(proxyResult.get("TITLE")) : "";
					content = (proxyResult.get("CONTENT") != null) ? String.valueOf(proxyResult.get("CONTENT")) : "";
					date = (proxyResult.get("DATE") != null) ? String.valueOf(proxyResult.get("DATE")) : "";
					empNm = (proxyResult.get("EMP_NM") != null) ? String.valueOf(proxyResult.get("EMP_NM")) : "";
					docId = (proxyResult.get("DOCID") != null) ? String.valueOf(proxyResult.get("DOCID")) : "";
					url = (proxyResult.get("URL") != null) ? String.valueOf(proxyResult.get("URL")) : "";
					
					//Title
					titleBuf.append(title);
					if ( !StringUtils.isEmpty(date) ) {
						titleBuf.append("  [").append(date);
					}
					if ( !StringUtils.isEmpty(empNm) ) {
						if ( !StringUtils.isEmpty(date) ) {
							titleBuf.append(" | ");
						}
						else {
							titleBuf.append("  [");
						}
						titleBuf.append(empNm);
					}
					if ( !StringUtils.isEmpty(date) || !StringUtils.isEmpty(empNm)) {
						titleBuf.append("]");
					}
					
    				//Costandard URL (Detail 조회용)
    				if ( !StringUtils.isEmpty(url) ) {    					
    					actionUrl.append(url).append(docId);
    				}
    				
    				Element element = new Element();
    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
    				//element.setSubtitle("");
    				element.setTitle(titleBuf.toString());
    				element.setDescriptions(content);
    				element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
    				element.setAction(actionUrl.toString());
    				
    				attachment.addElement(element);
        		}
			}
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}//getKnowAttachment
	
	/**
	 * BBS Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	private List<Attachment> getBbsAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        /*
			DOCID	string	DOCID
			DATE	string	DATE
			ITEM_ID	string	게시글 ID
			BOARD_ID	string	게시판 ID
			ITEM_PARENT_ID	string	게시글 부모 ID
			ITEM_GROUP_ID	string	게시글 Thread의 그룹 ID
			STEP	string	같은 Thread 그룹에 속해있는 게시물들간의 순서   
			INDENTATION	string	게시물 Thread의 LEVEL
			ITEM_SEQ_ID	string	게시물 순번
			ITEM_DISPLAY	string	전사 게시판 목록의 상단 노출 여부
			TITLE	string	게시물의 제목
			CONTENT	string	게시물 TEXT 내용
			HIT_COUNT	string	게시물 조회수
			RECOMMEND_COUNT	string	게시물 추천수
			REPLY_COUNT	string	게시물의 답변 게시물의 수
			LINEREPLY_COUNT	string	게시물 한줄답변(댓글)의 수
			ATTACH_FILE_COUNT	string	게시물 첨부파일수
			START_DATE	string	게시물 게시 시작일자
			END_DATE	string	게시물 게시 종료일자
			ITEM_DELETE	string	게시물 삭제여부
			REGISTER_DEPT	string	등록자 부서
			UPDATER_DEPT	string	수정자 부서
			READ_LIST_PERMISSION	string	게시물 목록 읽기 권한여부
			READ_ITEM_PERMISSION	string	게시물 읽기 권한여부
			EMP_NO	string	등록자 ID
			EMP_NM	string	등록자 이름
			REGIST_DATE	string	등록일시
			UPDATER_ID	string	수정일 ID
			UPDATER_NAME	string	수정자 이름
			UPDATE_DATE	string	수정일시
			MAIL_COUNT	string	메일 발송 수
			MBLOG_COUNT	string	마이크로블로깅 등록 수
			IMAGE_FILE_ID	string	이미지 파일 ID
			BOARD_NAME	string	게시판명
			CATEGORY	string	CATEGORY
			ATTACH_NAME	string	ATTACH_NAME    
			ATTACH	string	ATTACH
			ALIAS	string	ALIAS
			*/
			String title = null, date = null, empNm = null, boardName = null;
			String itemId = null, content = null;
			StringBuffer titleBuf = new StringBuffer();
			String portalBbsUrl = serversConfig.getServersInfo(inquiryData.getTenantId(), "gportal", "bbs");
			
			for (Map<String, Object> proxyResult : proxyResultSet) {
				
				titleBuf.setLength(0);
				
				if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
					
					title = (proxyResult.get("TITLE") != null) ? String.valueOf(proxyResult.get("TITLE")) : "";
					content = (proxyResult.get("CONTENT") != null) ? String.valueOf(proxyResult.get("CONTENT")) : "";
					date = (proxyResult.get("DATE") != null) ? String.valueOf(proxyResult.get("DATE")) : "";
					empNm = (proxyResult.get("EMP_NM") != null) ? String.valueOf(proxyResult.get("EMP_NM")) : "";
					boardName = (proxyResult.get("BOARD_NAME") != null) ? String.valueOf(proxyResult.get("BOARD_NAME")) : "";
					itemId = (proxyResult.get("ITEM_ID") != null) ? String.valueOf(proxyResult.get("ITEM_ID")) : "";
					
					//Title
					titleBuf.append(title);
					if ( !StringUtils.isEmpty(date) ) {
						titleBuf.append("  [").append(date);
					}
					if ( !StringUtils.isEmpty(empNm) ) {
						if ( !StringUtils.isEmpty(date) ) {
							titleBuf.append(" | ");
						}
						else {
							titleBuf.append("  [");
						}
						titleBuf.append(empNm);
					}
					if ( !StringUtils.isEmpty(date) || !StringUtils.isEmpty(empNm)) {
						titleBuf.append("]");
					}
					
    				
    				Element element = new Element();
    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
    				element.setSubtitle(boardName);
    				element.setTitle(titleBuf.toString());
    				element.setDescriptions(content);
    				element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
    				element.setAction( String.format(portalBbsUrl, itemId) );
    				
    				attachment.addElement(element);
        		}
			}
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}//getBbsAttachment
	
	/**
	 * QNA Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	private List<Attachment> getQnaAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        /*
			DOCID	string	DOCID
			DATE	string	DATE
			DOC_ID	string	DOC_ID
			TITLE	string	TITLE
			CONTENT	string	CONTENT
			REPLY_CNT	string	REPLY_CNT
			EMP_NO	string	EMP_NO
			EMP_NM	string	EMP_NM
			LST_UPDATE	string	LST_UPDATE
			QTYPE	string	QTYPE
			URL	string	URL
			END_FG	string	END_FG
			ALIAS	string	ALIAS
			baseUrl	string baeUrl
			*/
			String title = null, date = null, empNm = null, qtype = null, url = null, baseUrl = null, content = null;
			StringBuffer titleBuf = new StringBuffer();
			StringBuffer actionUrl = new StringBuffer();
			
			for (Map<String, Object> proxyResult : proxyResultSet) {
				
				titleBuf.setLength(0);
				actionUrl.setLength(0);
				
				if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
					
					title = (proxyResult.get("TITLE") != null) ? String.valueOf(proxyResult.get("TITLE")) : "";
					content = (proxyResult.get("CONTENT") != null) ? String.valueOf(proxyResult.get("CONTENT")) : "";
					date = (proxyResult.get("DATE") != null) ? String.valueOf(proxyResult.get("DATE")) : "";
					empNm = (proxyResult.get("EMP_NM") != null) ? String.valueOf(proxyResult.get("EMP_NM")) : "";
					qtype = (proxyResult.get("QTYPE") != null) ? String.valueOf(proxyResult.get("QTYPE")) : "";
					url = (proxyResult.get("URL") != null) ? String.valueOf(proxyResult.get("URL")) : "";
					baseUrl = (proxyResult.get("baseUrl") != null) ? String.valueOf(proxyResult.get("baseUrl")) : "";
					
					//Title
					titleBuf.append(title);
					if ( !StringUtils.isEmpty(date) ) {
						titleBuf.append("  [").append(date);
					}
					if ( !StringUtils.isEmpty(empNm) ) {
						if ( !StringUtils.isEmpty(date) ) {
							titleBuf.append(" | ");
						}
						else {
							titleBuf.append("  [");
						}
						titleBuf.append(empNm);
					}
					if ( !StringUtils.isEmpty(date) || !StringUtils.isEmpty(empNm)) {
						titleBuf.append("]");
					}
					
    				//Costandard URL (Detail 조회용)
    				if ( !StringUtils.isEmpty(baseUrl) && !StringUtils.isEmpty(url) ) {    					
    					actionUrl.append(baseUrl).append(url);
    				}
    				
    				Element element = new Element();
    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
    				element.setSubtitle(qtype);
    				element.setTitle(titleBuf.toString());
    				element.setDescriptions(content);
    				element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
    				element.setAction(actionUrl.toString());
    				
    				attachment.addElement(element);
        		}
			}
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}//getQnaAttachment
}
