/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ActionMongoRepository.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.repository;

import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.lgcns.vpa.dialog.model.ActionMongo;

/**
 * <PRE>
 * Mongodb Test 용 repository
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Repository
public interface ActionMongoRepository extends CrudRepository<ActionMongo, String> {
	@Query("{'name' : ?0}")
	public Iterable<ActionMongo> findByMessageId (String messageId);
	
	@Query("{'reqEmpNo' : ?0, 'author' : ?1}")
	public Iterable<ActionMongo> findByReqEmpNo (int reqEmpNo);
	
	@Query("{'messageId' : ?0, 'messageGroupId' : ?1}")
	public Iterable<ActionMongo> findByMessageAndGroup (String messageId, String messageGroupId);
	
	/*@Query("{'category' : {$regex : ?0}}")
	public Iterable<ActionMongo> findByCategoryLike (String category);*/
}
