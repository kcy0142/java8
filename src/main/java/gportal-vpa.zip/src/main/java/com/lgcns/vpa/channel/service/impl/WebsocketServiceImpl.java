/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : WebsocketServiceImpl.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.channel.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.service.WebsocketService;

/**
 * <pre>
 * Websocket 서비스 구현체
 * <pre>
 * @author
 */
@Service
public class WebsocketServiceImpl implements WebsocketService {

	@Autowired
	SimpMessagingTemplate messagingTemplate; 
	
	final Logger logger = LoggerFactory.getLogger(WebsocketServiceImpl.class);
	
	/**
	 * Websocket push 알림
	 * @param activity
	 */
	public void push(Activity activity){
        messagingTemplate.convertAndSendToUser(activity.getUserId() ,"/topic/chat.messages." + activity.getBotId(), activity);
    }
	
	/**
	 * Websocket 전체 push 알림
	 * @param activity
	 */
	public void pushAll(Activity activity){
		messagingTemplate.convertAndSend("/topic/chat.notifications." + activity.getBotId(), activity);
	}
	
}
