/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : RedisMessagePublisher.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.push;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.service.ActivityService;
import com.lgcns.vpa.dialog.util.JsonUtil;

/**
 * <pre>
 * Redis 메세지 Publisher
 * <pre>
 * @author
 */
@Service
public class RedisMessagePublisher {
	
	Logger logger = LoggerFactory.getLogger(RedisMessagePublisher.class);
	@Autowired
    private RedisTemplate<String, Object> redisTemplate;
	
	@Autowired
	private ActivityService activityService;
	
	/**
	 * Redis에 메세지를 publish
	 * ChannelTopic: ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH (push)
	 * @param activity
	 */
    public void publish(Activity activity){
    	
    	if(activity.getUserId().equals("ALL")){
    		activityService.insertAllActivity(activity);
    	}else {
    		activityService.insertActivity(activity);
    	}
    	
		//Activity Object 를 Deserialize 시 오류가 발생하여 String(Json) Type 으로 변경하여 전송함 
    	String jsonActivity  = JsonUtil.toJson(activity);
    	
    	logger.info(jsonActivity);
    	redisTemplate.convertAndSend(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH, jsonActivity);
    	
        //redisTemplate.convertAndSend(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH, activity);
    }

}
