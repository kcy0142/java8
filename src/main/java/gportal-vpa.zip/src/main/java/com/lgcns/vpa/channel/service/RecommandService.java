/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : RecommandService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.channel.service;

import java.util.List;

import com.lgcns.vpa.channel.model.Recommand;


/**
 * <PRE>
 * 관리자 추천키워드 조회 Service 선언
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 7. 19.
 */
public interface RecommandService {
	
	/**
	 * 사용자에게 표시할 관리자 추천키워드를 조회
	 * @param botId
	 * @return
	 */
	public List<Recommand> getAdminRecommand(String botId);
	
	/**
	 * 사용자 직급별 관리자 추천 키워드
	 * 0 : 사원
	 * 1 : 리더
	 * 2 : 임원
	 * @param botId
	 * @param leader
	 * @return
	 */
	public List<Recommand> getAdminRecommand(String botId, int leader);
	
	/**
	 * 사용자의 가장 많이 사용한 추천어와 최근 추천키워드를 조회
	 * @param userId
	 * @param botId
	 * @param count //최대값
	 * @return
	 */
	public List<Recommand> getUserRecommand(String userId, String botId, int count);

}
