/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : Faq.java
 * Author        : 김청욱
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.query.Update;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <PRE>
 * Faq 등록
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 7. 17.
 */
@Document(collection="faq")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Faq {
	
	/**
	 * intentId
	 */
	private String intentId;
	
	/**
	 * 내용
	 */
	private String content;
	

	public Faq() {}

	public Faq(String intentId, String content) {
		super();
		
		this.intentId=intentId;
		this.content = content;
		
	}



	/**
	 * 수정용 Parameter 인 Update Object 생성
	 * @return
	 */
	public Update getUpdateObject () {
		
		Update update = new Update();
		update.set("content", this.content);
		
		return update;
	}

	/**
	 * Json Data 생성
	 * @return
	 */
	public String toJson () {
		
		String jsonString = null;
		try {
			ObjectMapper objMapper = new ObjectMapper();
		
			jsonString = objMapper.writeValueAsString(this);

		} catch (Exception e) {
			return null;
		}
		
		return jsonString;
	}



	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	
	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}
}