/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseModel;
import java.util.List;

/**
 * <pre>
 * 봇 Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Bot extends BaseModel {
	
	private String tenantId;
    /**
     * 봇 ID
     */
    private String botId;

    /**
     * Portal ID
     */
    private String portalId;

    /**
     * 봇 이름
     */
    private String botName;

    /**
     * 봇 이름
     */
    private String botEnglishName;

    /**
     * 사용여부
     */
    private String useYn;

    /**
     * 설명
     */
    private String description;

    /**
     * 이미지 URL
     */
    private String smallIconUrl;

    /**
     * 이미지 URL
     */
    private String iconUrl;
    
    /**
     * 봇 기본 메시지 목록
     */
    private List<BotMessage> botMessages;
    
    /**
     * dap bot id
     */
    private String dapBotId;
    
    /**
     * dap bot nlu service url
     */
    private String dapNluService;
    
    /**
     * dap 호출 오류 횟수
     */
    private int dapFailCnt;
    
    /**
     * 추론 임계치
     * @return
     */
    private int inferenceMinScore = 40;
    
    /**
     * 추론 범위 
     * 예) 추론 score외 유사 의도가 추론 범위내 있는 지 확인
     */
    private int inferenceScoreRange = 3;
    
    /**
     * 추론 결과에서 의미없다고 버리는 기준 점수
     */
    private int inferenceCutScore = 35;

    public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public String getPortalId() {
        return portalId;
    }

    public void setPortalId(String portalId) {
        this.portalId = portalId;
    }

    public String getBotName() {
        return botName;
    }

    public void setBotName(String botName) {
        this.botName = botName;
    }

    public String getBotEnglishName() {
        return botEnglishName;
    }

    public void setBotEnglishName(String botEnglishName) {
        this.botEnglishName = botEnglishName;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSmallIconUrl() {
        return smallIconUrl;
    }

    public void setSmallIconUrl(String smallIconUrl) {
        this.smallIconUrl = smallIconUrl;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public List<BotMessage> getBotMessages() {
        return botMessages;
    }

    public void setBotMessages(List<BotMessage> botMessages) {
        this.botMessages = botMessages;
    }

	public String getDapBotId() {
		return dapBotId;
	}

	public void setDapBotId(String dapBotId) {
		this.dapBotId = dapBotId;
	}

	public String getDapNluService() {
		return dapNluService;
	}

	public void setDapNluService(String dapNluService) {
		this.dapNluService = dapNluService;
	}

	public int getDapFailCnt() {
		return dapFailCnt;
	}

	public void setDapFailCnt(int dapFailCnt) {
		this.dapFailCnt = dapFailCnt;
	}

	public int getInferenceMinScore() {
		return inferenceMinScore;
	}

	public void setInferenceMinScore(int inferenceMinScore) {
		this.inferenceMinScore = inferenceMinScore;
	}

	public int getInferenceScoreRange() {
		return inferenceScoreRange;
	}

	public void setInferenceScoreRange(int inferenceScoreRange) {
		this.inferenceScoreRange = inferenceScoreRange;
	}

	public int getInferenceCutScore() {
		return inferenceCutScore;
	}

	public void setInferenceCutScore(int inferenceCutScore) {
		this.inferenceCutScore = inferenceCutScore;
	}
	
	public String toString() {
		return "botId : " + this.botId + 
				"inferenceCutScore : " + this.inferenceCutScore + 
				"inferenceMinScore : " + this.inferenceMinScore + 
				"inferenceScoreRange : " + this.inferenceScoreRange;
	}
}
