/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SynonymService.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.dialog.model.Synonym;
import com.lgcns.vpa.framework.multidata.annotation.MultiDataSource;


/**
 * <PRE>
 * 질의어 중 유의어를 표준 단어로 변경하기 위한 롲기 처리
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 9. 19.
 */
@Service("multi.synonymService")
public class SynonymService {
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	/**
	 * 질의어 중 표준어로 치환 대상인 단어가 있으면 변경함, 영문자는 소문자로 치환
	 * @param inquiryData
	 * @param botId
	 * @return
	 */
	public String convertToSynonym (String inquiryData, String botId) {
		
		if ( StringUtils.isEmpty(inquiryData) ||  StringUtils.isEmpty(botId) ) {
			return null;
		}
		
		//대문자로 비교함
		String newInquiryData = new String(inquiryData).toUpperCase();
		
		try {
			//유의어 정보를 읽어 온다.
			List<Synonym> resultList = listSynonym(null, botId);
			
			if ( (resultList != null) && (!resultList.isEmpty()) ) {
				
				List<Synonym> matchList = new ArrayList<Synonym>();
				int pos = 0; 
				String converTemplate = "${%s}";
				String synonymTargetUpper = null;
				
				//유의어 목록에 있는 단어를 모두 찾아서 새로운 질의문을 만듬
				for ( Synonym synonym : resultList ) {
					if ( synonym == null ) {
						continue;
					}
					
					synonymTargetUpper = synonym.getSynonymTargetDataToUpperCase();
					
					//치환 대상인 단어가 있으면 치환 대상 목록 선택(대문자로 비교함)
					if ( newInquiryData.contains(synonymTargetUpper) ) {
						matchList.add(synonym);
						newInquiryData = newInquiryData.replace(synonymTargetUpper, String.format(converTemplate, pos));
						pos++;
					}
				}
				
				//치환 대상인 단어가 있으면 치환함
				//중복 치환의 위험이 있어서 치환대상이 되는 단어는 "{0}, {1}" 식으로 matchList의 위치를 표시하여 처리함
				if ( !matchList.isEmpty() ) {
					
					pos = 0; 
					for ( Synonym synonym : matchList ) {
						newInquiryData = newInquiryData.replace(String.format(converTemplate, pos), synonym.getSynonymData());
						pos++;
					}
				}
			}//if
		} catch (Exception e) {
			//오류 발생 시 입력값을 리턴
			return inquiryData;
		}
		
		//대문자는 소문자로 치환
		return (newInquiryData != null) ? newInquiryData.toLowerCase() : null;
	}
	
	@MultiDataSource
	public List<Synonym> listSynonym(String searchWord, String botId) {
		Criteria criteria = new Criteria();
		
		if ( botId != null ) {
			criteria.andOperator(Criteria.where("botId").is(botId));
		}
		else {
			criteria.andOperator(Criteria.where("botId").exists(false));
		}
		
		if( !StringUtils.isEmpty(searchWord) ) {
			criteria.orOperator(Criteria.where("synonymTargetData").regex(searchWord),
								Criteria.where("synonymedData").regex(searchWord));
		}
		
		Query query = new Query();
		query.addCriteria(criteria);
		
		query.fields()
		//.include("botId")
		//.include("synonymId")
		.include("synonymTargetData")
		.include("synonymData");
		
		query.with(new Sort(Sort.Direction.ASC, "synonymData"));
		
		return this.mongoTemplate.find(query, Synonym.class);
	}
}
