/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SearchDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.base.config.ServersConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.BotCode;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.service.BotService;
import com.lgcns.vpa.channel.service.SearchService;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;
import com.lgcns.vpa.security.user.service.UserRoleService;

/**
 * <PRE>
 * Project 통합 검색용 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 10.
 */
@Component("ProjectSearchDialog")
public class ProjectSearchDialog extends VpaDialog {

	private static final Logger LOG = LoggerFactory.getLogger(ProjectSearchDialog.class);
	
	@Autowired
	private SearchService searchService;
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private ServersConfig serversConfig;
	
	@Autowired
	private BotService botService;
	
	@Override
	protected boolean validator(InquiryVO data) {
		
		boolean isValid = true;
		
		Map<String, Object> param = data.getIntentParam();
		if ( (param == null) || (param.isEmpty()) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
					 "], 통합 검색을 위한 파라미터가 없음.");
		}
		else {
			String searchInquiry = (param.get("name") != null) ? String.valueOf(param.get("name")) : null;
			data.setSearchInquiryData(searchInquiry);
		}
		
		LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
				 "], Intent Param:["+data.getIntentParam()+"]");
		
		return true;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		boolean hasRight = false;
		
		if ( data.getReqUser() == null ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한을 검사할 Req User 정보가 없음");
			return false;
		}
		
		//인텐트별 사용자의 사용 권한 조회
		hasRight = this.userRoleService.validateUserRole(data.getReqUser(), data.getIntentId());
		
		if (!hasRight) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],hasRight:["+hasRight+"], 권한 없음");
		}
		return hasRight;
	}

	@Override
	protected String processor(InquiryVO data) {
		if ( (data == null) || (data.getAction() == null) ) {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 정보가 부정확함");
			return null;
		}
		
		String resultJsonData = null;
		List<Map<String, Object>> searchResult = null;
		
		try {
			//통합검색에 Project Data 요청
			//intent Parameter 의 name 값을 name의 value 를 검색어로 지정하고
			//값이 없으면 질의어를 검색어로 지정함
			
			if ( !StringUtils.isEmpty(data.getSearchInquiryData()) ) {
				searchResult = this.searchService.search(data.getTenantId(), data.getSearchInquiryData(), "project", null);
			}
			else {
				searchResult = this.searchService.search(data.getTenantId(), data.getInquiryData(), "project", null);
			}
			
			//조회 결과 없음
			if ( (searchResult == null) || (searchResult.isEmpty()) ) {
				//결과가 없음
				resultJsonData = CommonCode.ACTION_RESULT_NONE;
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 결과가 없음");
			}
			//조회 결과 Json 변환
			else {
				ObjectMapper objMapper = new ObjectMapper();
				resultJsonData = objMapper.writeValueAsString(searchResult);
				data.setSearchResult(searchResult);
			}
			
		} catch (Exception e) {
			//오류 발생
			resultJsonData = CommonCode.ACTION_RESULT_ERROR;
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 중 오류 발생, Exception : " + e.toString());
		}
		
		return resultJsonData;
	}

	@Override
	protected Activity afterWork(InquiryVO data, String searchResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(searchResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 통합검색 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet = data.getSearchResult();
			
			if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				
				//통합 검색에서 조회된 결과로 Attachment 를 구함
				attachments = this.getAttachment(data, proxyResultSet);
				
				if ( (attachments != null) && (!attachments.isEmpty()) ) {
					
					int count = proxyResultSet.size();
					
					//Activity Message
					StringBuffer activityMessage = new StringBuffer();
					
					//사용자가 입력한 질의어에서 특수문자만 제거하고 그대로 보여줌
					Activity reqActivity = data.getRequestActivity();
					String preMessage = (reqActivity.getPreSynonymMessage() != null) ? StringUtils.removeSpecialChar(reqActivity.getPreSynonymMessage()) : "";
					activityMessage.append(preMessage).append(" ");
					
					if ( activityMessage.indexOf("프로젝트") < 0 ) { 
						activityMessage.append("프로젝트를 ");
					}
					
					//결과가 15건을 기준으로 메세지가 다름
					if (count <= 15) {
						activityMessage.append(String.format(this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_PROJECT_RESULT_15LESS), count));
					}
					else {
						activityMessage.append(this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_PROJECT_RESULT_15MORE));
					}
					
					//resultActivity.setMessage(data.getIntentMessage());
					resultActivity.setMessage(activityMessage.toString());
					resultActivity.setAttachments(attachments);
					
				}
				else {
					LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
					
					//Data 가 없음
		        	resultActivity = this.commonResponeService.simpleResponseMessage(
							data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
							this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
				}
				
				//의도분석의 Button이 있는 경우 처리
				if ( data.getIntentButtons() != null ) {
					List<RelatedButton> buttons = data.getIntentButtons();
					List<Button> activityButtonList = super.makeActivityButtonList(buttons);
					
					if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
						resultActivity.setButtons(activityButtonList);
					}
				}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Activity Message
				StringBuffer activityMessage = new StringBuffer();
				activityMessage.append(data.getInquiryData()).append(" ");
				activityMessage.append(this.botService.getBotMessage(data.getBotId(), BotCode.BOT_MESSAGE_TYPE_DATANONE));
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						activityMessage.toString());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	private List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        
	        /*"prjName" 	: "TITLE",
			"prjCode" 	: "BO_KEY",
			"prjType"   : "CD_NM",
			"prjPmNm" 	: "EMP_NM",
			"prjPmId" 	: "EMP_NO",
			"prjDate"   : "DATE",
			"prjUrl"	: "URL"
			prjType=제안, prjPmNm=정두훈, prjCode=LG01PJ20126826P, prjName=CIC구축 프로젝트, prjPmId=78100, prjDate=2016.10.06
			*/
			String title = null;
			StringBuffer desciptions = new StringBuffer();
			StringBuffer actionUrl = new StringBuffer();
			int count = 0;
			
			for (Map<String, Object> proxyResult : proxyResultSet) {
				
				count++;
				
				//표시개수는 15개 까지만 표시함
				if (count > 15) {
					break;
				}
				
				desciptions.setLength(0);
				actionUrl.setLength(0);
				
				if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
					
					title = String.valueOf(proxyResult.get("prjName"));
					
					//Project Type (제안, 이행 등)
    				if (proxyResult.get("prjType") != null) {
    					desciptions.append("[").append(String.valueOf(proxyResult.get("prjType"))).append("]");
    				}
    				
    				//Project Code
    				if (proxyResult.get("prjCode") != null) {
    					if (proxyResult.get("prjType") != null) {
    						desciptions.append(" ");
    					}
    					
    					desciptions.append(String.valueOf(proxyResult.get("prjCode")));
    				}
    				
    				//Project Date
    				if (proxyResult.get("prjDate") != null) {
    					if ( (proxyResult.get("prjCode") != null) ) {
    						desciptions.append(" | ");
    					}
    					
    					desciptions.append(String.valueOf(proxyResult.get("prjDate")));
    				}
    				
    				//Project PM Name
    				if (proxyResult.get("prjPmNm") != null) {
    					if ( (proxyResult.get("prjDate") != null) ) {
    						desciptions.append(" | ");
    					}
    					
    					desciptions.append(String.valueOf(proxyResult.get("prjPmNm")));
    				}
    				
    				//Project URL (Detail 조회용)
    				if (proxyResult.get("prjUrl") != null) {    					
    					String portalUrl = serversConfig.getServersInfo(inquiryData.getTenantId(), "officeplus", "url");
    					actionUrl.append(portalUrl).append(String.valueOf(proxyResult.get("prjUrl")));
    				}
    				
    				Element element = new Element();
    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
    				element.setTitle(title);
    				element.setDescriptions(desciptions.toString());
    				element.setActionType(CommonCode.INTENT_BUTTON_TYPE_LINK);
    				element.setAction(actionUrl.toString());
    				
    				attachment.addElement(element);
        		}
			}
            
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
	
}
