/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : RecommandServiceImpl.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.channel.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.base.util.DateUtils;
import com.lgcns.vpa.channel.model.Recommand;
import com.lgcns.vpa.channel.model.RecommandUserExcept;
import com.lgcns.vpa.channel.model.UserRecommand;
import com.lgcns.vpa.channel.service.RecommandService;
import com.lgcns.vpa.channel.service.RecommandUserExceptService;
import com.lgcns.vpa.framework.multidata.annotation.MultiDataSource;
import com.lgcns.vpa.intent.model.IntentMongo;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.unwind;

import static org.springframework.data.mongodb.core.aggregation.ConditionalOperators.Cond.*;

@Service("multi.recommandService")
public class RecommandServiceImpl implements RecommandService {

	private static final Logger LOG = LoggerFactory.getLogger(RecommandServiceImpl.class);
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private RecommandUserExceptService recommandUserExceptService;
	
	/**
	 * 사용자에게 표시할 관리자 추천키워드를 조회
	 * @param botId
	 * @return
	 */
	@Override
	@MultiDataSource
	public List<Recommand> getAdminRecommand (String botId) {
		
		Criteria criteria = new Criteria();
		
		if ( botId != null ) {
			criteria.andOperator(Criteria.where("botId").is(botId), Criteria.where("useYn").is("Y"));
		}
		else {
			criteria.andOperator(Criteria.where("botId").exists(false), Criteria.where("useYn").is("Y"));
		}
		
		Query query = new Query();
		query.addCriteria(criteria);
		
		query.fields()
		.include("botId")
		.include("displayOrder")
		.include("recommandId")
		.include("recommandName")
		.include("action")
		.include("actionType")
		.include("message")
		.include("useYn");
		
		query.with(new Sort(Sort.Direction.ASC, "displayOrder"));
		
		return this.mongoTemplate.find(query, Recommand.class);
	}
	
	public List<Recommand> getAdminRecommand(String botId, int leader) {
		Criteria criteria = new Criteria();
		
		if ( botId != null ) {
			criteria.andOperator(Criteria.where("botId").is(botId), Criteria.where("useYn").is("Y"));
		}
		else {
			criteria.andOperator(Criteria.where("botId").exists(false), Criteria.where("useYn").is("Y"));
		}
		
		criteria.and("targetUser").is("" + leader);
		
		Query query = new Query();
		query.addCriteria(criteria);
		
		query.fields()
		.include("botId")
		.include("displayOrder")
		.include("recommandId")
		.include("recommandName")
		.include("action")
		.include("actionType")
		.include("message")
		.include("displayYn")
		.include("type")
		.include("iconName")
		.include("useYn");
		
		query.with(new Sort(Sort.Direction.ASC, "displayOrder"));
		
		return this.mongoTemplate.find(query, Recommand.class);
	}

	
	/**
	 * 사용자 추천 키워드 조회
	 */
	public List<Recommand> getUserRecommand(String userId, String botId, int count) {
		
		Query query = new Query();
		query.addCriteria(Criteria.where("botId").is(botId)
				.and("userId").is(userId));
				
		UserRecommand userRecommand = this.mongoTemplate.findOne(query, UserRecommand.class);
		
		if( userRecommand == null ) {
			return Collections.EMPTY_LIST;
		} else {
			count = Math.min(count,  userRecommand.getIntents().size());
			return getUserRecommand(userRecommand.getIntents().subList(0, count));
		}
	}
	
	/**
	 * 추천의도로부터 키워드 조회
	 * @param intents
	 * @return
	 */
	private List<Recommand> getUserRecommand(List<String> intents ) {
		Criteria creteria = Criteria.where("intentId").in(intents);//.and("intentId").nin("INT43c84245f756478796c262dea6d01b40");
		MatchOperation matchStage = Aggregation.match(creteria);
		
		SortOperation sort = sort(new Sort(Direction.DESC, "utterances.isRepresentative"));
		GroupOperation group = group("intentId").push("intentName").as("intentName").push("$utterances").as("utterances");
		
		ProjectionOperation projectStage = 
				project().andExpression("intentName").arrayElementAt(0).as("recommandName")
				.andExpression("utterances.parsedText").arrayElementAt(0).as("action")
				.andExpression("utterances.parsedText").arrayElementAt(0).as("message");
		
		Aggregation aggregation = Aggregation.newAggregation(matchStage, unwind("utterances"), sort, group, projectStage );
		AggregationResults<Recommand> result = mongoTemplate.aggregate(aggregation, "intents", Recommand.class);
		
		return result.getMappedResults();
	}
	
	/**
	 * 많이 사용한 의도 조회
	 * @param userId
	 * @param botId
	 * @param count
	 * @param excludeIntents
	 * @return
	 */
	private Result getUserFrequentRecommand(String userId, String botId, int count, String[] excludeIntents) {
		//많이 사용한 의도
		Criteria creteria = Criteria.where("userId").is(userId)
				.and("botId").is(botId)
				.and("intentId").exists(true)
				.and("intentType").ne("0")
				.and("sentDate").gte(DateUtils.addMonth(new Date(), -1));//한달 전
		MatchOperation matchStage = Aggregation.match(creteria);
		GroupOperation groupByIntentId = group("botId", "userId", "intentId").count().as("count");
		SortOperation sortByCount = sort(new Sort(Direction.DESC, "count"));
		
		GroupOperation groupByUserId = group("botId", "userId").push("intentId").as("intents");
		ProjectionOperation projectStage = project().andInclude("botId", "userId").andExpression("intents").slice(count).as("intents");
		
		Aggregation aggregation = Aggregation.newAggregation(matchStage, groupByIntentId, sortByCount, groupByUserId, projectStage );
		AggregationResults<Result> result = mongoTemplate.aggregate(aggregation, "activities", Result.class);
		List<Result> results = result.getMappedResults();
		
		return results.isEmpty()?null:results.get(0);
	}
	
	/**
	 * 최근 의도 조회.. 자주 사용한 의도와 중복된 의도는 제외한다.
	 * @param userId
	 * @param botId
	 * @param count
	 * @param excludeIntents
	 * @return
	 */
	private Result getUserRecentRecommand(String userId, String botId, int count, String[] excludeIntents) {
		//많이 사용한 의도
		Criteria creteria = Criteria.where("userId").is(userId)
				.and("botId").is(botId)
				.and("intentId").nin(excludeIntents)
				.and("intentType").ne("0")
				.and("sentDate").gte(DateUtils.addWeek(new Date(), -1));//일주일 전

		MatchOperation matchStage = Aggregation.match(creteria);
		GroupOperation groupByIntentId = group("botId", "userId", "intentId").last("sentDate").as("lastDate");
		SortOperation sortByCount = sort(new Sort(Direction.DESC, "lastDate"));
		
		GroupOperation groupByUserId = group("botId", "userId").push("intentId").as("intents");
		ProjectionOperation projectStage = project().andInclude("botId", "userId").andExpression("intents").slice(count).as("intents");
		
		Aggregation aggregation = Aggregation.newAggregation(matchStage, groupByIntentId, sortByCount, groupByUserId, projectStage );
		AggregationResults<Result> result = mongoTemplate.aggregate(aggregation, "activities", Result.class);
		List<Result> results = result.getMappedResults();
		
		return results.isEmpty()?null:results.get(0);
	}
	
	
	class Result {
		private String botId;
		private String userId;
		private String[] intents;
		
		public String toString() {
			return botId + " " + userId + " " + Arrays.toString(intents);
		}
	}

	
}//class
