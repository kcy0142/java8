package com.lgcns.vpa.security.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.security.user.dao.GroupDao;
import com.lgcns.vpa.security.user.model.Group;
import com.lgcns.vpa.security.user.service.GroupService;

@Service("multi.groupService")
public class GroupServiceImpl implements GroupService {
	
	@Autowired
	private GroupDao groupdao;

	@Override
	public List<Group> selectParentGroupListByUser(String userId) {
		return groupdao.selectParentGroupListByUser(userId);
	}
	
	/**
     * 부서명으로 부서목록 Like 검색
     * @param groupName
     * @return
     */
	@Override
    public List<Group> selectGroupName(String groupName) {
		if ( StringUtils.isEmpty(groupName) ) {
			return null;
		}
		
		return this.groupdao.selectGroupName(groupName);
	}
}
