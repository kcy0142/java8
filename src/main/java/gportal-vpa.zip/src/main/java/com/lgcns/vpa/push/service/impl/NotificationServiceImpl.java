package com.lgcns.vpa.push.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.dialog.service.DialogHandlerService;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.PushRunService;
import com.lgcns.vpa.push.service.PushService;
import com.lgcns.vpa.push.service.TargetInfoService;
import com.lgcns.vpa.push.service.UserAutoRunService;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.security.user.service.UserService;

/**
 * <pre>
 * 시스템 알림 Service
 * </pre>
 * @author
 */
@Service("multi.notificationService")
public class NotificationServiceImpl extends PushAbstractService implements PushService {
	
    @Autowired
    RedisMessagePublisher redisMessagePublisher;
    
    @Autowired
    UserService userService;
    
    @Autowired
    private TargetInfoService targetInfoService;
    
    @Autowired
    private PushRunService pushRunService;
    
    @Override
    public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig){
    	
    	if ( (params == null) || (params.isEmpty()) || (StringUtils.isEmpty(tenantId)) ) {
    		return;
    	}
    	
    	String botId = params.get("botId");
    	String type = params.get("type");
    	String targetGroupIds = params.get("targetGroupIds");
    	
    	if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(type) || StringUtils.isEmpty(targetGroupIds) ) {
    		return;
    	}
    	
    	//Bot 유효성 검사
    	checkBotId(botId);
    	
    	//수신 대상자 그룹 정보 처리
    	String [] targetGroupIdArry = targetGroupIds.split(",");
    	
    	//Target 정보를 조회하기 위한 Parameter
    	Map<String, Object> daoParam = new HashMap<String, Object>();
    	daoParam.put("botId", botId);
    	daoParam.put("targetGroupIdList", targetGroupIdArry);
    	
    	//수신처가 모든 임직원인지 검사
    	boolean isAllEmployee = this.targetInfoService.isAllEmployee(daoParam);
    	
    	//Message Type 처리
    	if ( "0".equals(type) ) {
    		this.pushRunService.messageTypeSend(params, tenantId, isAllEmployee);
    	}
    	//의도 Type 처리
    	else if ( "1".equals(type) ) {
    		this.pushRunService.intentTypeSend(params, tenantId, isAllEmployee);
    	}
    }
	
}
