/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : IntentService.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.service;

import java.util.List;
import java.util.Map;

import com.lgcns.vpa.intent.model.IntentAnalysisResult;
import com.lgcns.vpa.intent.model.IntentMongo;

/**
 * 의도추론 서비스
 * @author 70399
 *
 */
public interface IntentService {

	/**
	 * mongodb의 intent objectid로 조회
	 * @param id
	 * @return
	 */
	IntentMongo getIntent(Object id);

	IntentMongo findByIntentId(String intentId);
	/**
	 * R&D intentid로 의도 메타정보 조회
	 * @param intentId
	 * @return
	 */
	IntentMongo findByIntentId(String intentType, String intentId);
	
	
	/**
	 * 자동완성용 문맥에 대한 intent 조회
	 * @param botId
	 * @param context
	 * @return
	 */
	List<IntentMongo> findByContext(String botId, String context, boolean smalltalkExclude);
	
	/**
	 * 자동완성용 문맥에 대한 intent 조회
	 * @param botId
	 * @param context
	 * @return
	 */
	List<IntentMongo> findByContext(String botId, String context, boolean smalltalkExclude, boolean like);

	/**
	 * 사용자 질의에 대한 의도를 추론함 
	 * 추론된 결과로 파라미터 치환정보와 관련 action정보를 반환함
	 * @param queryString
	 * @return
	 */
	IntentAnalysisResult reasonIntent(String tenantId, String botId, String userId, String queryString);

	/**
	 * 재질의 처리
	 * @param tntId
	 * @param botId
	 * @param usrId
	 * @param intentId
	 * @param entity
	 * @param value
	 * @return
	 */
	IntentAnalysisResult fillIntent(String tntId, String botId, String usrId, String intentId, String entity, Object value);
	
	/**
	 * 자동완성처럼 의도와 파라미터가 명확한 경우로 , 
	 * 의도분석을 타지않고, 파라미터 치환/매핑만 함
	 * @param tntId
	 * @param botId
	 * @param usrId
	 * @param intentId
	 * @param entity
	 * @param value
	 * @return
	 */
	IntentAnalysisResult transIntent(String tntId, String botId, String usrId, String intentId, String entity, Map<String, Object> value);
}