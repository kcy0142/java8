/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.base.config;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.CacheControl;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

/**
 * <pre>
 * Spring Boot Web MVC 설정
 * </pre>
 * @author
 */
@Configuration
@EnableWebMvc
public class WebConfig extends WebMvcConfigurerAdapter {
    /**
     * 정적 리소스 위치
     */
    @Value("${spring.resources.static-locations}")
    private String staticResourceLocations;
    
    /**
     * SPA Entry point 를 위한 HTML Resolver
     * @return
     */
    @Bean
    public InternalResourceViewResolver htmlViewResolver() {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("/");
        resolver.setSuffix(".html");
        resolver.setOrder(Ordered.LOWEST_PRECEDENCE);
        return resolver;
    }

    /**
     * 인터셉터 추가
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
    }

    @Bean
    public UserSessionListener addUserSessionListener() {
    	return new UserSessionListener();
    }
        
    /**
     * 기본 서블릿 설정
     * @param configurer
     */
    @Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }

    /**
     * 정적 리소스 패스 지정
     * @param registry
     */
    @Override 
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
         registry
             .addResourceHandler("/**")
             .setCacheControl(CacheControl.maxAge(7, TimeUnit.DAYS))
             .addResourceLocations(staticResourceLocations);   

         registry
             .addResourceHandler("/index.html")
             .setCacheControl(CacheControl.noCache())
             .addResourceLocations(staticResourceLocations + "/index.html");   
         
        super.addResourceHandlers(registry);
    }
}
