/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : IdgenService.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.base.idgen.service;

/**
 * <PRE>
 * ID 생성 서비스
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 11. 28.
 */
public interface IdgenService {

	/**
	 * ID값 얻어 오기
	 * 
	 * @return
	 */
	public String getNextId() ;
	
}
