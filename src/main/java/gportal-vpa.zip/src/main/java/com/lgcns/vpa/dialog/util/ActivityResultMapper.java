/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ActivityResultMapper.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.activity.SubElement;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.ChildMapper;
import com.lgcns.vpa.dialog.model.MapperVO;
import com.lgcns.vpa.dialog.service.DialogHandlerService;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * 응답용 Activity Object 에  Proxy Server 에서 조회된 ResultSet을 Element Object로 추가함
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 6. 20.
 */
public class ActivityResultMapper {

	private static final Logger LOG = LoggerFactory.getLogger(ActivityResultMapper.class);
	
	private final String START_KEY = "{$", END_KEY = "$}", MAPPER_PATH = "mappers", MESSAGE_PATH = "appendMessage";
	
	/**
	 * 응답용 Activity Object 에  Proxy Server 에서 조회된 ResultSet을 Element Object로 넣는다.<br/>
	 * Action 에 정의된 Mapper 가 있으면 Mapper Data 를 사용하고 없으면 기본 Element 로 처리함
	 * @param activity
	 * @param dataList
	 * @param mapper
	 * @param mapperType
	 * @param attachmentTemplateType
	 * @return
	 */
	public Activity setMappingData (Activity activity, List<Map<String, Object>> dataList, String mapper, int mapperType, String attachmentTemplateType) {
		
		if (activity == null) {
			return null;
		}
		else if ( (dataList == null) || (dataList.isEmpty()) ) {
			return activity;
		}
		
		try {
			LOG.info("mapper : =======" + mapper + "=======");
			
			if ( CommonCode.MULTI_ELEMENT_INROW == mapperType ) {
				if ( StringUtils.isEmpty(attachmentTemplateType) || ActivityCode.TEMPLATE_TYPE_TABLE.equals(attachmentTemplateType) ) {
					multiInRowMappingData (activity, dataList, mapper);
				}
				else {
					multiInRowMappingDataForList (activity, dataList, mapper);
				}
			} 
			else if ( CommonCode.SINGLE_ELEMENT_INROW == mapperType ) {
				singleInRowMappingData (activity, dataList, mapper);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return activity;
	}
	
	/**
	 * 결과 값이 Multi Row 인 데이터의 1 Row 당 1 Element로 Mapping 을 처리<br/>
	 * Attachment + List<Element> 형태로 처리함
	 * @param activity
	 * @param dataList
	 * @param jsonMapper
	 * @return
	 */
	public Activity singleInRowMappingData (Activity activity, List<Map<String, Object>> dataList, String jsonMapper) {
		
		if (activity == null) {
			return null;
		}
		else if ( (dataList == null) || (dataList.isEmpty()) ) {
			return activity;
		}
		
		List<Element> elemList = new ArrayList<Element>();
		Element element = null;
		
		//mapper data 가 있는 경우 : dataList를 mapper 값에 따라 변경하여 Activity.Attachment.element에 Set 함 
		//mapper가 없는 경우 : dataList를 Activity.Attachment.element에 Set 함
		if ( !StringUtils.hasText(jsonMapper) ) {
			
			LOG.debug("[ReplyToId]:["+activity.getReplyToId()+"] singleInRowMappingData jsonMapper data is empty");
			String popupWidth = null, popupHeight = null;
			
			for (Map<String, Object> data : dataList) {
				element = new Element();
				
				element.setId(this.convertToString(data.get(CommonCode.ELEMENT_ID)));
				element.setType(this.convertToString(data.get(CommonCode.ELEMENT_TYPE)));
				element.setTitle(this.convertToString(data.get(CommonCode.ELEMENT_TITLE)));
				element.setSubtitle(this.convertToString(data.get(CommonCode.ELEMENT_SUBTITLE)));
				element.setDescriptions(this.convertToString(data.get(CommonCode.ELEMENT_DESCRIPTION)));
				element.setText(this.convertToString(data.get(CommonCode.ELEMENT_TEXT)));
				element.setAmount(this.convertToString(data.get(CommonCode.ELEMENT_AMOUNT)));
				element.setValue(this.convertToString(data.get(CommonCode.ELEMENT_VALUE)));
				element.setUnit(this.convertToString(data.get(CommonCode.ELEMENT_UNIT)));
				element.setImageUrl(this.convertToString(data.get(CommonCode.ELEMENT_IMAGEURL)));
				element.setAction(this.convertToString(data.get(CommonCode.ELEMENT_ACTION)));
				//element.setActionParams((Map) data.get(CommonCode.ELEMENT_ACTION_PARAMS));
				element.setActionType(this.convertToString(data.get(CommonCode.ELEMENT_ACTION_TYPE)));
				
				popupWidth = this.convertToString(data.get(CommonCode.ELEMENT_POPUPWIDTH));
            	popupHeight = this.convertToString(data.get(CommonCode.ELEMENT_POPUPHEIGHT));
				
            	element.setPopupWidth( ( StringUtils.isEmpty(popupWidth) ) ? 0 : Integer.parseInt(popupWidth) );
        		element.setPopupHeight( ( StringUtils.isEmpty(popupHeight) ) ? 0 : Integer.parseInt(popupHeight) );
        		
				if ( data.containsKey(CommonCode.ELEMENT_ADDITIONAL) ) {
					Object tempMap = data.get(CommonCode.ELEMENT_ADDITIONAL);
					
					if ( tempMap instanceof Map) {
						element.setAdditionalProperties((Map<String, Object>)tempMap);
					}
				}
				
				//Action 을 비워두면 안됨, Client에서 Error 남
				if ( !StringUtils.hasText(element.getAction()) ) {
        			element.setAction(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);;
        		}
				
				elemList.add(element);
			}
		}
		else {
			
			try {
				
				LOG.debug("[ReplyToId]:["+activity.getReplyToId()+"] singleInRowMappingData jsonMapper data : " + jsonMapper);
				
				//Mapper Data 파싱하기
	            ObjectMapper mapper = new ObjectMapper();
	            JsonNode root = mapper.readTree(jsonMapper); // <=== Json String 으로 대체
	            JsonNode node = root.path(MAPPER_PATH);
	            JsonNode nodeMessage = root.path(MESSAGE_PATH); 
            
	            if ( (node != null) && (node.isArray()) ) {
	            	
	            	Map<String, Object> data = null;
	            	int size = dataList.size();
	            	
	            	String titleData = node.get(0).path(CommonCode.ELEMENT_TITLE).asText();
	            	String subtitleData = node.get(0).path(CommonCode.ELEMENT_SUBTITLE).asText();
	            	String descriptionsData = node.get(0).path(CommonCode.ELEMENT_DESCRIPTION).asText();
	            	String textData = node.get(0).path(CommonCode.ELEMENT_TEXT).asText();
	            	String valueData = node.get(0).path(CommonCode.ELEMENT_VALUE).asText();
	            	String classNamesData = node.get(0).path(CommonCode.ELEMENT_CLASSNAMES).asText();
	            	String unitData = node.get(0).path(CommonCode.ELEMENT_UNIT).asText();
	            	String imageUrlData = node.get(0).path(CommonCode.ELEMENT_IMAGEURL).asText();
	            	String amountData = node.get(0).path(CommonCode.ELEMENT_AMOUNT).asText();
	            	String actionData = node.get(0).path(CommonCode.ELEMENT_ACTION).asText();
	            	String actionTypeData = node.get(0).path(CommonCode.ELEMENT_ACTION_TYPE).asText();
                	//String idData = node.get(0).path(CommonCode.ELEMENT_ID).asText();
	            	String additionalData = node.get(0).path(CommonCode.ELEMENT_ADDITIONAL).asText();
	            	String popupWidth = node.get(0).path(CommonCode.ELEMENT_POPUPWIDTH).asText();
	            	String popupHeight = node.get(0).path(CommonCode.ELEMENT_POPUPHEIGHT).asText();
                	
	            	//Activity Message 에 추가되는 Message
	            	String appendMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
	            	
	            	for (int i = 0; i < size; i++) {
	            		
	            		data = dataList.get(i);
	                	
	            		if ( (data == null) || (data.isEmpty()) ) {
	            			continue;
	            		}
	            		
	            		//Activity Message 에 추가되는 Message Mapping
	            		if ( (i == 0) && (!StringUtils.isEmpty(appendMessage) ) ) {
	            			String mappingMessage = this.stringMapper(data, appendMessage);
	            			if (  StringUtils.isEmpty(activity.getMessage()) ) {
	            				activity.setMessage(mappingMessage);
	            			}
	            			else {
	            				StringBuffer buf = new StringBuffer(activity.getMessage());
	            				buf.append(mappingMessage);
	            				activity.setMessage(buf.toString());
	            			}
	            		}
	            		
	                	element = new Element();
	                	element.setTitle(this.stringMapper(data, titleData));
	            		element.setSubtitle(this.stringMapper(data, subtitleData));
	            		element.setDescriptions(this.stringMapper(data, descriptionsData));
	            		element.setText(this.stringMapper(data, textData));
	            		element.setValue(this.stringMapper(data, valueData));
	            		element.setClassNames(this.stringMapper(data, classNamesData));
	            		element.setUnit(this.stringMapper(data, unitData));
	            		element.setImageUrl(this.stringMapper(data, imageUrlData));
	            		element.setAmount(this.stringMapper(data, amountData));
	            		element.setActionType(actionTypeData);
	            		element.setAction(this.stringMapper(data, actionData));
	            		
	            		element.setPopupWidth( ( StringUtils.isEmpty(popupWidth) ) ? 0 : Integer.parseInt(popupWidth) );
	            		element.setPopupHeight( ( StringUtils.isEmpty(popupHeight) ) ? 0 : Integer.parseInt(popupHeight) );
	            		
	            		if ( data.containsKey(additionalData) ) {
	    					Object tempMap = data.get(additionalData);
	    					
	    					if ( tempMap instanceof Map) {
	    						element.setAdditionalProperties((Map<String, Object>)tempMap);
	    					}
	    				}
	            		
	            		
	            		//Action 을 비워두면 안됨, Client에서 Error 남
	            		if ( !StringUtils.hasText(element.getAction()) ) {
	            			element.setAction(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);;
	            		}
	            		
	            		elemList.add(element);
	            	}//for
	            	
	            }
	            else if ( nodeMessage != null ) {
	            	//Activity Message 에 추가되는 Message
	            	String appendMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
	            	
	            	Map<String, Object> data = null;
	            	int size = dataList.size();
	            	
	            	if ( (size > 0) && (!StringUtils.isEmpty(appendMessage)) ) {
	            		
	            		data = dataList.get(0);
	            		
	            		//Activity Message 에 추가되는 Message Mapping
            			String mappingMessage = this.stringMapper(data, appendMessage);
            			if (  StringUtils.isEmpty(activity.getMessage()) ) {
            				activity.setMessage(mappingMessage);
            			}
            			else {
            				StringBuffer buf = new StringBuffer(activity.getMessage());
            				buf.append(mappingMessage);
            				activity.setMessage(buf.toString());
            			}
	            	}
	            }
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error("[ReplyToId]:["+activity.getReplyToId()+"], "+e.toString());
			}
            
		}//if-else element 생성
		
		if ( (elemList != null) && (!elemList.isEmpty()) ) {
			List<Attachment> attachments = null;
					
			if ( (activity == null) || (activity.getAttachments() == null) || (activity.getAttachments().isEmpty()) ) {
				attachments = new ArrayList<Attachment>();
				attachments.add(new Attachment("template", "", elemList));
				activity.setAttachments(attachments);
			}
			else {
				attachments = activity.getAttachments();
				for (Attachment attm : attachments) {
					if (attm != null) {
						attm.setElements(elemList);
					}
				}
			}
		}
		
		return activity;
	}//setMultiRowMappingData
	
	/**
	 * 결과 값이 Single Row 인 데이터의 Multi Column을 Mapping 을 처리, Attachment Template Type 이 Table 인 경우<br/>
	 * Element + List<SubElement> 형태로 처리
	 * @param activity
	 * @param dataList
	 * @param jsonMapper
	 * @return
	 */
	public Activity multiInRowMappingData (Activity activity, List<Map<String, Object>> dataList, String jsonMapper) {
		if (activity == null) {
			return null;
		}
		else if ( (dataList == null) || (dataList.isEmpty()) ) {
			return activity;
		}
		
		List<Element> elemList = new ArrayList<Element>();
		List<SubElement> subElemList = new ArrayList<SubElement>();
		SubElement subElem = null;
		
		//jsonMapper data 가 있는 경우 : dataList를 mapper 값에 따라 변경하여 Activity.Attachment.element에 Set 함 
		//jsonMapper가 없는 경우 : dataList를 Activity.Attachment.element에 Set 함
		if ( !StringUtils.hasText(jsonMapper) ) {
			
			LOG.debug("[ReplyToId]:["+activity.getReplyToId()+"] multiInRowMappingData jsonMapper data is empty");
			String popupWidth = null, popupHeight = null;
			
			//반환된 데이터 개수 만큼 반복
			for ( Map<String, Object> data : dataList ) {
				subElem = new SubElement();
				
				subElem.setType(this.convertToString(data.get(CommonCode.ELEMENT_TYPE)));
				subElem.setTitle(this.convertToString(data.get(CommonCode.ELEMENT_TITLE)));
				subElem.setText(this.convertToString(data.get(CommonCode.ELEMENT_TEXT)));
				subElem.setValue(this.convertToString(data.get(CommonCode.ELEMENT_VALUE)));
				subElem.setAction(this.convertToString(data.get(CommonCode.ELEMENT_ACTION)));
				subElem.setActionType(this.convertToString(data.get(CommonCode.ELEMENT_ACTION_TYPE)));
				
				popupWidth = this.convertToString(data.get(CommonCode.ELEMENT_POPUPWIDTH));
				popupHeight = this.convertToString(data.get(CommonCode.ELEMENT_POPUPHEIGHT));
				
				subElem.setPopupWidth( ( StringUtils.isEmpty(popupWidth) ) ? 0 : Integer.parseInt(popupWidth) );
				subElem.setPopupHeight( ( StringUtils.isEmpty(popupHeight) ) ? 0 : Integer.parseInt(popupHeight) );
        		
				//Action 을 비워두면 안됨, Client에서 Error 남
				if ( !StringUtils.hasText(subElem.getAction()) ) {
					subElem.setAction(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);;
	    		}
				
				subElemList.add(subElem);
				
				if ( !subElemList.isEmpty() ) {
					elemList.add(new Element(subElemList));
				}
			}
		}
		else {
			try {
				
				LOG.debug("[ReplyToId]:["+activity.getReplyToId()+"] multiInRowMappingData jsonMapper data : " + jsonMapper);
				
				//Mapper Data 파싱하기
	            ObjectMapper mapper = new ObjectMapper();
	            JsonNode root = mapper.readTree(jsonMapper); // <=== Json String 으로 대체
	            JsonNode node = root.path(MAPPER_PATH);
	            JsonNode nodeMessage = root.path(MESSAGE_PATH); 
	            
	            if (node.isArray()) {
	            	
	            	//Activity Message 에 추가되는 Message
	            	String appendMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
	            	
	            	int size = node.size();
	            	//int positionData = 0;
	            	String classNamesData = null;
	            	String typeData = null;
	            	String titleData = null;
	            	String textData = null;
	            	String valueData = null;
	            	String actionTypeData = null;
	            	String actionData = null;
	            	String popupWidth = null;
	            	String popupHeight = null;
	            	
	            	List<SubElement> subList = null;
	            	boolean isFirstRow = true;
	            	
	            	//반환된 데이터 개수 만큼 반복
	            	for ( Map<String, Object> data : dataList ) {
	            		
	            		//Activity Message 에 추가되는 Message Mapping
	            		if ( isFirstRow && !StringUtils.isEmpty(appendMessage) ) {
	            			
	            			isFirstRow = false;
	            			String mappingMessage = this.stringMapper(data, appendMessage);
	            			
	            			if (  StringUtils.isEmpty(activity.getMessage()) ) {
	            				activity.setMessage(mappingMessage);
	            			}
	            			else {
	            				StringBuffer buf = new StringBuffer(activity.getMessage());
	            				buf.append(mappingMessage);
	            				activity.setMessage(buf.toString());
	            			}
	            		}
	            		
	            		subList = new ArrayList<SubElement>();
	            		
	            		for (int j = 0; j < size; j++) {
	            			
		            		//positionData = node.get(j).path("position").asInt();
		            		classNamesData = node.get(j).path(CommonCode.ELEMENT_CLASSNAMES).asText();
		            		typeData = node.get(j).path(CommonCode.ELEMENT_TYPE).asText();
		            		titleData = node.get(j).path(CommonCode.ELEMENT_TITLE).asText();
		            		textData = node.get(j).path(CommonCode.ELEMENT_TEXT).asText();
		            		valueData = node.get(j).path(CommonCode.ELEMENT_VALUE).asText();
		            		actionTypeData = node.get(j).path(CommonCode.ELEMENT_ACTION_TYPE).asText();
		            		actionData = node.get(j).path(CommonCode.ELEMENT_ACTION).asText();
		            		popupWidth = node.get(j).path(CommonCode.ELEMENT_POPUPWIDTH).asText();
			            	popupHeight = node.get(j).path(CommonCode.ELEMENT_POPUPHEIGHT).asText();
				            
		            		subElem = new SubElement();
		            		
		            		subElem.setClassNames(this.stringMapper(data, classNamesData));
		            		subElem.setType(this.stringMapper(data, typeData));
		            		subElem.setTitle(this.stringMapper(data, titleData));
		            		subElem.setText(this.stringMapper(data, textData));
		            		subElem.setValue(this.stringMapper(data, valueData));
		            		subElem.setActionType(actionTypeData);
		            		subElem.setAction(this.stringMapper(data, actionData));
		            		
		            		subElem.setPopupWidth( ( StringUtils.isEmpty(popupWidth) ) ? 0 : Integer.parseInt(popupWidth) );
		            		subElem.setPopupHeight( ( StringUtils.isEmpty(popupHeight) ) ? 0 : Integer.parseInt(popupHeight) );
		            		
		            		//Action 을 비워두면 안됨, Client에서 Error 남
		    				if ( !StringUtils.hasText(subElem.getAction()) ) {
		    					subElem.setAction(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);
		            		}
		    				
		            		subList.add(subElem);
		            	}
		            	
		            	if ( !subList.isEmpty() ) {
		            		elemList.add(new Element(subList));
		            	}
	            	}
	            	
	            }
	            else if ( nodeMessage != null ) {
	            	//Activity Message 에 추가되는 Message
	            	String appendMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
	            	
	            	Map<String, Object> data = null;
	            	int size = dataList.size();
	            	
	            	if ( (size > 0) && (!StringUtils.isEmpty(appendMessage)) ) {
	            		
	            		data = dataList.get(0);
	            		
	            		//Activity Message 에 추가되는 Message Mapping
            			String mappingMessage = this.stringMapper(data, appendMessage);
            			if (  StringUtils.isEmpty(activity.getMessage()) ) {
            				activity.setMessage(mappingMessage);
            			}
            			else {
            				StringBuffer buf = new StringBuffer(activity.getMessage());
            				buf.append(mappingMessage);
            				activity.setMessage(buf.toString());
            			}
	            	}
	            }
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error("[ReplyToId]:["+activity.getReplyToId()+"], "+e.toString());
			}
		}//if-else jsonMapper data 유무
		
		
		if ( (elemList != null) && (!elemList.isEmpty()) ) {
			
			List<Attachment> attachments = null;
					
			if ( (activity == null) || (activity.getAttachments() == null) || (activity.getAttachments().isEmpty()) ) {
				attachments = new ArrayList<Attachment>();
				attachments.add(new Attachment("template", "", elemList));
				activity.setAttachments(attachments);
			}
			else {
				attachments = activity.getAttachments();
				for (Attachment attm : attachments) {
					if (attm != null) {
						attm.setElements(elemList);
					}
				}
			}
		}
		
		return activity;
	}//setMultiMappingData
	
	/**
	 * 결과 값이 Single Row 인 데이터의 Multi Column을 Mapping 을 처리, Attachment Template Type 이 List 인 경우<br/>
	 * @param activity
	 * @param dataList
	 * @param jsonMapper
	 * @return
	 */
	public Activity multiInRowMappingDataForList (Activity activity, List<Map<String, Object>> dataList, String jsonMapper) {
		if (activity == null) {
			return null;
		}
		else if ( (dataList == null) || (dataList.isEmpty()) ) {
			return activity;
		}
		
		List<Element> elemList = new ArrayList<Element>();
		
		//jsonMapper data 가 있는 경우 : dataList를 mapper 값에 따라 변경하여 Activity.Attachment.element에 Set 함 
		//jsonMapper가 없는 경우 : dataList를 Activity.Attachment.element에 Set 함
		if ( !StringUtils.hasText(jsonMapper) ) {
			
			LOG.debug("[ReplyToId]:["+activity.getReplyToId()+"] multiInRowMappingData jsonMapper data is empty");
			String popupWidth = null, popupHeight = null;
			
			//반환된 데이터 개수 만큼 반복
			for ( Map<String, Object> data : dataList ) {
				Element element = new Element();
				
				element.setId(this.convertToString(data.get(CommonCode.ELEMENT_ID)));
				element.setType(this.convertToString(data.get(CommonCode.ELEMENT_TYPE)));
				element.setTitle(this.convertToString(data.get(CommonCode.ELEMENT_TITLE)));
				element.setSubtitle(this.convertToString(data.get(CommonCode.ELEMENT_SUBTITLE)));
				element.setDescriptions(this.convertToString(data.get(CommonCode.ELEMENT_DESCRIPTION)));
				element.setText(this.convertToString(data.get(CommonCode.ELEMENT_TEXT)));
				element.setAmount(this.convertToString(data.get(CommonCode.ELEMENT_AMOUNT)));
				element.setValue(this.convertToString(data.get(CommonCode.ELEMENT_VALUE)));
				element.setUnit(this.convertToString(data.get(CommonCode.ELEMENT_UNIT)));
				element.setImageUrl(this.convertToString(data.get(CommonCode.ELEMENT_IMAGEURL)));
				element.setAction(this.convertToString(data.get(CommonCode.ELEMENT_ACTION)));
				//element.setActionParams((Map) data.get(CommonCode.ELEMENT_ACTION_PARAMS));
				element.setActionType(this.convertToString(data.get(CommonCode.ELEMENT_ACTION_TYPE)));
				
				popupWidth = this.convertToString(data.get(CommonCode.ELEMENT_POPUPWIDTH));
            	popupHeight = this.convertToString(data.get(CommonCode.ELEMENT_POPUPHEIGHT));
				
            	element.setPopupWidth( ( StringUtils.isEmpty(popupWidth) ) ? 0 : Integer.parseInt(popupWidth) );
        		element.setPopupHeight( ( StringUtils.isEmpty(popupHeight) ) ? 0 : Integer.parseInt(popupHeight) );
        		
				if ( data.containsKey(CommonCode.ELEMENT_ADDITIONAL) ) {
					Object tempMap = data.get(CommonCode.ELEMENT_ADDITIONAL);
					
					if ( tempMap instanceof Map) {
						element.setAdditionalProperties((Map<String, Object>)tempMap);
					}
				}
				
				//Action 을 비워두면 안됨, Client에서 Error 남
				if ( !StringUtils.hasText(element.getAction()) ) {
        			element.setAction(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);;
        		}
				
				elemList.add(element);
			}
		}
		else {
			try {
				
				LOG.debug("[ReplyToId]:["+activity.getReplyToId()+"] multiInRowMappingData jsonMapper data : " + jsonMapper);
				
				//Mapper Data 파싱하기
	            ObjectMapper mapper = new ObjectMapper();
	            JsonNode root = mapper.readTree(jsonMapper); // <=== Json String 으로 대체
	            JsonNode node = root.path(MAPPER_PATH);
	            JsonNode nodeMessage = root.path(MESSAGE_PATH); 
	            
	            if (node.isArray()) {
	            	
	            	//Activity Message 에 추가되는 Message
	            	String appendMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
	            	
	            	int size = node.size();
	            	//int positionData = 0;
	            	
	            	String titleData = null;
	            	String subtitleData = null;
	            	String descriptionsData = null;
	            	String textData = null;
	            	String valueData = null;
	            	String classNamesData = null;
	            	String unitData = null;
	            	String imageUrlData = null;
	            	String amountData = null;
	            	String actionData = null;
	            	String actionTypeData = null;
                	//String idData = null;
	            	String additionalData = null;
	            	String popupWidth = null;
	            	String popupHeight = null;
	            	
	            	
	            	boolean isFirstRow = true;
	            	
	            	//반환된 데이터 개수 만큼 반복
	            	for ( Map<String, Object> data : dataList ) {
	            		
	            		//Activity Message 에 추가되는 Message Mapping
	            		if ( isFirstRow && !StringUtils.isEmpty(appendMessage) ) {
	            			
	            			isFirstRow = false;
	            			String mappingMessage = this.stringMapper(data, appendMessage);
	            			
	            			if (  StringUtils.isEmpty(activity.getMessage()) ) {
	            				activity.setMessage(mappingMessage);
	            			}
	            			else {
	            				StringBuffer buf = new StringBuffer(activity.getMessage());
	            				buf.append(mappingMessage);
	            				activity.setMessage(buf.toString());
	            			}
	            		}
	            		
	            		for (int j = 0; j < size; j++) {
	            			
	            			titleData = node.get(j).path(CommonCode.ELEMENT_TITLE).asText();
	    	            	subtitleData = node.get(j).path(CommonCode.ELEMENT_SUBTITLE).asText();
	    	            	descriptionsData = node.get(j).path(CommonCode.ELEMENT_DESCRIPTION).asText();
	    	            	textData = node.get(j).path(CommonCode.ELEMENT_TEXT).asText();
	    	            	valueData = node.get(j).path(CommonCode.ELEMENT_VALUE).asText();
	    	            	classNamesData = node.get(j).path(CommonCode.ELEMENT_CLASSNAMES).asText();
	    	            	unitData = node.get(j).path(CommonCode.ELEMENT_UNIT).asText();
	    	            	imageUrlData = node.get(j).path(CommonCode.ELEMENT_IMAGEURL).asText();
	    	            	amountData = node.get(j).path(CommonCode.ELEMENT_AMOUNT).asText();
	    	            	actionData = node.get(j).path(CommonCode.ELEMENT_ACTION).asText();
	    	            	actionTypeData = node.get(j).path(CommonCode.ELEMENT_ACTION_TYPE).asText();
	                    	//idData = node.get(0).path(CommonCode.ELEMENT_ID).asText();
	    	            	additionalData = node.get(j).path(CommonCode.ELEMENT_ADDITIONAL).asText();
	    	            	popupWidth = node.get(j).path(CommonCode.ELEMENT_POPUPWIDTH).asText();
	    	            	popupHeight = node.get(j).path(CommonCode.ELEMENT_POPUPHEIGHT).asText();
		            		//positionData = node.get(j).path("position").asInt();

				            
			            	Element element = new Element();
		            		
			            	element.setTitle(this.stringMapper(data, titleData));
		            		element.setSubtitle(this.stringMapper(data, subtitleData));
		            		element.setDescriptions(this.stringMapper(data, descriptionsData));
		            		element.setText(this.stringMapper(data, textData));
		            		element.setValue(this.stringMapper(data, valueData));
		            		element.setClassNames(this.stringMapper(data, classNamesData));
		            		element.setUnit(this.stringMapper(data, unitData));
		            		element.setImageUrl(this.stringMapper(data, imageUrlData));
		            		element.setAmount(this.stringMapper(data, amountData));
		            		element.setActionType(actionTypeData);
		            		element.setAction(this.stringMapper(data, actionData));
		            		
		            		element.setPopupWidth( ( StringUtils.isEmpty(popupWidth) ) ? 0 : Integer.parseInt(popupWidth) );
		            		element.setPopupHeight( ( StringUtils.isEmpty(popupHeight) ) ? 0 : Integer.parseInt(popupHeight) );
		            		
		            		if ( data.containsKey(additionalData) ) {
		    					Object tempMap = data.get(additionalData);
		    					
		    					if ( tempMap instanceof Map) {
		    						element.setAdditionalProperties((Map<String, Object>)tempMap);
		    					}
		    				}
			            	
		            		
		            		//Action 을 비워두면 안됨, Client에서 Error 남
		    				if ( !StringUtils.hasText(element.getAction()) ) {
		    					element.setAction(CommonCode.INTENT_BUTTON_TYPE_INQUIRY);
		            		}
		    				
		    				elemList.add(element);
		            	}
		            	
	            	}
	            	
	            }
	            else if ( nodeMessage != null ) {
	            	//Activity Message 에 추가되는 Message
	            	String appendMessage = (nodeMessage != null) ? nodeMessage.asText() : null;
	            	
	            	Map<String, Object> data = null;
	            	int size = dataList.size();
	            	
	            	if ( (size > 0) && (!StringUtils.isEmpty(appendMessage)) ) {
	            		
	            		data = dataList.get(0);
	            		
	            		//Activity Message 에 추가되는 Message Mapping
            			String mappingMessage = this.stringMapper(data, appendMessage);
            			if (  StringUtils.isEmpty(activity.getMessage()) ) {
            				activity.setMessage(mappingMessage);
            			}
            			else {
            				StringBuffer buf = new StringBuffer(activity.getMessage());
            				buf.append(mappingMessage);
            				activity.setMessage(buf.toString());
            			}
	            	}
	            }
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error("[ReplyToId]:["+activity.getReplyToId()+"], "+e.toString());
			}
		}//if-else jsonMapper data 유무
		
		
		if ( (elemList != null) && (!elemList.isEmpty()) ) {
			
			List<Attachment> attachments = null;
					
			if ( (activity == null) || (activity.getAttachments() == null) || (activity.getAttachments().isEmpty()) ) {
				attachments = new ArrayList<Attachment>();
				attachments.add(new Attachment("template", "", elemList));
				activity.setAttachments(attachments);
			}
			else {
				attachments = activity.getAttachments();
				for (Attachment attm : attachments) {
					if (attm != null) {
						attm.setElements(elemList);
					}
				}
			}
		}
		
		return activity;
	}//setMultiMappingDataForList
	
	/**
	 * data 의 null 유무를 검사하고 
	 * @param data
	 * @return
	 */
	private String convertToString (Object data) {
		
		if (data == null) {
			return null;
		}
		
		String result = null;
		
		if ( data instanceof String ) {
			result = (String) data;
		}
		else if (data instanceof Integer) {
			Integer tmp = (Integer) data;
			result = tmp.toString();
		}
		else if (data instanceof Long) {
			Long tmp = (Long) data;
			result = tmp.toString();
		}
		else if (data instanceof Float) {
			Float tmp = (Float) data;
			result = tmp.toString();
		}
		else if (data instanceof Double) {
			Double tmp = (Double) data;
			result = tmp.toString();
		}
		else {
			result = data.toString();
		}
		
		return result;
	}
	
	/**
	 * Element Action 중에서 변환해야할 변수를 실 데이터로 변환함<br/>
	 * (ex> ${AAA} 자산입니다.  ==> 1234567 자산입니다.), 단 AAA가 parameter data에 1234567로 정의되어 있어야 함.
	 * @param action
	 * @param data
	 * @return
	 */
	private String makeActionValue_12 (String action, Map<String, Object> data) {
		
		if ( !StringUtils.hasText(action) || (data == null) || (data.isEmpty()) ) {
			return action;
		}
		
		String newAction = action;
		
		int sPos = action.indexOf("${");
		int ePos = -1;
		
		String key = null, keyTemp = null;
		Object value = null;
		
		while (sPos > -1) {
			ePos = action.indexOf("}", sPos);
			
			if ( (ePos <= -1) || (sPos <= -1) ) {
				break;
			}
			else {
				//keyList.add(action.substring(sPos, ePos+1));
				key = action.substring(sPos, ePos+1);
				if ( StringUtils.hasText(key) && (key.length() > 3) ) {
					keyTemp = key.substring(2, key.length()-1);
					keyTemp = keyTemp.trim();
					
					value = data.get(keyTemp);
					//System.out.println("["+keyTemp+"],["+value+"]");
					
					if (value != null) {
						newAction = newAction.replace(key, value.toString());
					}
				}
				
				sPos = action.indexOf("${", sPos+1);
			}
		}
		
		System.out.println("==="+newAction+"===");
		return newAction;
	}
	
	/**
	 * Mapper 에 설정 정보에 따라 Map 에서 값을 조회하여 Element 값을 만듬
	 * @param data
	 * @param strData
	 * @return
	 */
	private String stringMapper ( Map<String, Object> data, String strData ) {
		
		String resultStr = new String(strData);
		List<String> keyList = new ArrayList<String>();
				
		int limitPos = strData.length()-1;
		int startPos = 0, endPos = 0;
		
		//Key 값을 가져옴
		while (true) {
			startPos = strData.indexOf(START_KEY, startPos);
			
			if (startPos < 0) {
				break;
			}
			else {
				endPos = strData.indexOf(END_KEY, startPos);
				
				if ( (endPos < 0) || (endPos+1 > limitPos) ) {
					break;
				}
				else {
					String temp = (endPos+1 == limitPos) ? strData.substring(startPos) : strData.substring(startPos, endPos+2);
					keyList.add(temp);
					startPos = endPos;
				}
			}
		}
		
		//strData mapping
		if ( !keyList.isEmpty() ) {
			String mapValue = null;
			String mapKey = null;
			for ( String key : keyList ) {
				mapKey = key.substring(2, key.length()-2);
				mapValue = this.convertToString( data.get(mapKey.trim()) );
				
				if ( !StringUtils.isEmpty(mapValue) ) {
					resultStr = resultStr.replace(key, mapValue);
				} else {//수정 최환준 값이 없는 경우 빈문자열로 처리함
					resultStr = resultStr.replace(key,"");
				}
			}
		}
		else {
			resultStr = (data.get(strData) != null) ?  this.convertToString(data.get(strData)) : "";
		}
		
		return ( (resultStr == null) || (resultStr.length() <= 0) ) ? strData : resultStr;
	}
	
}
