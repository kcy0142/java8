/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : TargetInfoServiceImpl.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.push.dao.TargetInfoDao;
import com.lgcns.vpa.push.model.TargetInfo;
import com.lgcns.vpa.push.service.TargetInfoService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * Notification 수신자 정보 처리 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 11. 22.
 */
@Service("multi.targetInfoService")
public class TargetInfoServiceImpl implements TargetInfoService {
	
	@Autowired
	private TargetInfoDao targetInfoDao;
	
	/**
	 * TargetGroup에 해당하는 TargetInfo 정보 조회
	 * @param botId
	 * @param targetGroupId
	 * @return
	 */
	public List<TargetInfo> listTargetInfo(String botId, String targetGroupId) {
		
		if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(targetGroupId) ) {
			return null;
		}
		
		return this.targetInfoDao.listTargetInfo(botId, targetGroupId);
		
	}
	
	/**
	 * Target Group에 해당하는 임직원의 사용자 Id 조회
	 * @param params
	 * @return
	 */
	public boolean isAllEmployee(Map<String, Object> params) {
		
		if ( (params == null) || (params.isEmpty()) ) {
			return false;
		}
		
		String resultStr = this.targetInfoDao.isAllEmployee(params); 
		
		return ( StringUtils.isEmpty(resultStr) ) ? false : true;
	}
	
	/**
	 * Target Group에 해당하는 임직원 정보 조회
	 * @param params
	 * @return
	 */
	public List<User> getTargetUserList(Map<String, Object> params) {
		
		if ( (params == null) || (params.isEmpty()) ) {
			return null;
		}
		
		return this.targetInfoDao.getTargetUserList(params);
	}
	
	/**
	 * 전체 직원의 정보를 조회
	 * @return
	 */
	public List<User> getAllTargetUserList() {
		
		return this.targetInfoDao.getAllTargetUserList();
	}
}
