/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.config;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseModel;

/**
 * <pre>
 * 사용자 알림 속성 설정 Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PushConfigProperty extends BaseModel {

    /**
     * 속성 ID
     */
    private String propertyId;
    
    /**
     * 상위 속성 ID
     */
    private String parentPropertyId;    
    
    /**
     * 속성 코드
     */
    private String propertyCode;    
    
    /**
     * 알림항목 ID
     */
    private String pushId;
    
    /**
     * 사용자 ID
     */
    private String userId;
    
    /**
     * 사용자 그룹 ID
     */
    private String groupId;
    
    /**
     * 레이블
     */
    private String propertyLabel;
    
    /**
     * 영문 레이블
     */
    private String propertyEnglishLabel;
    
    /**
     * 속성값
     */
    private String propertyValue;
    
    /**
     * 기본값
     */
    private String defaultPropertyValue;
    
    /**
     * 양식유형 (INPUT: 직접입력, RADIO, CHECK, SELECT: 선택)
     */
    private String formTypeCode;

    /**
     * 값 항목 목록
     */
    private List<PushConfigPropertyValue> propertyValues;
    
    /**
     * 사용자 로케일 
     */
    private String localeCode;

    public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId;
    }
    
    public String getParentPropertyId() {
        return parentPropertyId;
    }

    public void setParentPropertyId(String parentPropertyId) {
        this.parentPropertyId = parentPropertyId;
    }

    public String getPropertyCode() {
        return propertyCode;
    }

    public void setPropertyCode(String propertyCode) {
        this.propertyCode = propertyCode;
    }
    
    public String getPushId() {
        return pushId;
    }

    public void setPushId(String pushId) {
        this.pushId = pushId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getPropertyLabel() {
        return propertyLabel;
    }

    public void setPropertyLabel(String propertyLabel) {
        this.propertyLabel = propertyLabel;
    }

    public String getPropertyEnglishLabel() {
        return propertyEnglishLabel;
    }

    public void setPropertyEnglishLabel(String propertyEnglishLabel) {
        this.propertyEnglishLabel = propertyEnglishLabel;
    }

    public String getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(String propertyValue) {
        this.propertyValue = propertyValue;
    }

    public String getDefaultPropertyValue() {
        return defaultPropertyValue;
    }

    public void setDefaultPropertyValue(String defaultPropertyValue) {
        this.defaultPropertyValue = defaultPropertyValue;
    }

    public String getFormTypeCode() {
        return formTypeCode;
    }

    public void setFormTypeCode(String formTypeCode) {
        this.formTypeCode = formTypeCode;
    }

    public List<PushConfigPropertyValue> getPropertyValues() {
        return propertyValues;
    }

    public void setPropertyValues(List<PushConfigPropertyValue> propertyValues) {
        this.propertyValues = propertyValues;
    }

	public String getLocaleCode() {
		return localeCode;
	}

	public void setLocaleCode(String localeCode) {
		this.localeCode = localeCode;
	}
}
