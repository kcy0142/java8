/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ChildMapper.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.model;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * <PRE>
 * Action에 저장된 Mapping 데이터의 세부 정보를 모델링함
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 6. 22.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value=Include.NON_EMPTY)
public class ChildMapper {
	
	/**
	 * 테이블 형의 Data를 표시할 경우 위치할 컬럼의 위치를 지정함
	 */
	private int positionInRow;
	
	/**
	 * 테이블 형의 Data를 표시할 경우 데이터의 UI Style을 정의함, UI에서 인식할 수 있는 기 정의되어 있는 Style 명
	 */
	private String classNames;
	
	/**
	 * UI에 표시될 Element 의 Field 명
	 */
	public String vpaField;
	
	/**
	 * UI에 표시될 Element 의 Field 명과 Mapping 되는 Proxy 에서 반환된 Result set의 컬럼명 <br/>
	 * ex) "suject, subject2" 와 같이 복수로 지정 가능함
	 */
	public String [] dataFields;
	
	/**
	 * Action Type ("link":Link URL, "inquiry":의도)
	 */
	public String actionType;
	
	/**
	 * Action 내용
	 */
	public String action;
	
	public ChildMapper() {
		super();
	}
	
	public ChildMapper(int positionInRow, String vpaField, String [] dataFields) {
		super();
		this.positionInRow = positionInRow;
		this.vpaField = vpaField;
		this.dataFields = dataFields;
	}

	public int getPositionInRow() {
		return positionInRow;
	}
	public void setPositionInRow(int positionInRow) {
		this.positionInRow = positionInRow;
	}
	public String getClassNames() {
		return classNames;
	}
	public void setClassNames(String classNames) {
		this.classNames = classNames;
	}
	public String getVpaField() {
		return vpaField;
	}
	public void setVpaField(String vpaField) {
		this.vpaField = vpaField;
	}
	public String[] getDataFields() {
		return dataFields;
	}
	public void setDataFields(String[] dataFields) {
		this.dataFields = dataFields;
	}
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}

	public boolean isMappingVpaField ( String fieldName ) {
		
		if ( !StringUtils.hasText(this.vpaField) || !StringUtils.hasText(fieldName) ) {
			return false;
		}
		else if ( this.vpaField.equalsIgnoreCase(fieldName) ) {
			return true;
		}
		else if ( (this.dataFields == null) || (this.dataFields.length <= 0) ) {
			return false;
		}
		
		boolean result = false;
		
		for (String dataField : dataFields) {
			
			if ( StringUtils.hasText(dataField) && dataField.equalsIgnoreCase(fieldName) ) {
				result = true;
				break;
			}
		}
		
		return result;
	}
}
