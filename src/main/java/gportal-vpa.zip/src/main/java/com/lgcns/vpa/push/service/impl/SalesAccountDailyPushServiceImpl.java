/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.push.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.model.config.PushConfigProperty;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.push.service.DailyPushService;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.ActivityCode;

/**
 * <pre>
 * 주요 SI 수주현황 데일리 Push Service
 * </pre>
 * @author
 */
@Service("multi.salesAccountDailyPushService")
public class SalesAccountDailyPushServiceImpl extends PushAbstractService implements DailyPushService {

   
    
    @Autowired
    private MessageSource messageSource;
    
    @Override
    public List<Attachment> execute(Map<String, String> param, PushConfig pushConfig, Bot bot, User user, String tenantId) {
   
        
        
        TransferSyncVO transferSyncVO = new TransferSyncVO();
        transferSyncVO.setActionUri(pushConfig.getActionUri());
        transferSyncVO.setTenantId(tenantId);
        
        Map<String, Object> actionParam = new HashMap<>();
        
        actionParam.put("LOGIN_EMP_NO", user.getUserId());
        actionParam.put("LOCALE_CD", user.getLocaleCode());
        
        // CONT_PERIOD: 조회조건 (0: 3주, 1: 1주)
        List<PushConfigProperty> pushConfigProperties = pushConfig.getPushConfigProperties();
        PushConfigProperty configProperty = pushConfigProperties.stream()
                .filter(property -> "CONT_PERIOD".equals(property.getPropertyCode()))
                .findFirst().orElse(null);
        
        // 설정정보에서 조회조건 (0: 3주, 1: 1주) 로 세팅
        if (configProperty != null) {
            String value = StringUtils.isEmpty(configProperty.getPropertyValue()) ? 
                    configProperty.getDefaultPropertyValue() : configProperty.getPropertyValue();
            
            actionParam.put("CONT_PERIOD", value);
        } 
        // 설정정보가 없는 경우 0: 3주로 세팅
        else {
            actionParam.put("CONT_PERIOD", "0");
        }
        
        transferSyncVO.setActionParam(actionParam);
        
        List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
        List<Attachment> attachments = null;
     
        if (!CollectionUtils.isEmpty(proxyResultSet)) {
            Attachment attachment = new Attachment();
            attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
            attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
            attachment.setTitle(pushConfig.getPushName());
            attachment.setDescriptions(messageSource.getMessage("meesage.push.daily.sales.descriptions", null, new Locale(user.getLocaleCode())));
            
            List<Element> elements = proxyResultSet.stream().map(data -> new Element() {
                private static final long serialVersionUID = -4803937536892622504L;
                {
                    this.setTitle(StringUtils.toString(data.get("PJT_NM")));
                    this.setSubtitle(StringUtils.toString(data.get("CUST_NM")));
                    this.setDescriptions(new StringBuffer(messageSource.getMessage("meesage.push.daily.sales.sales", null, new Locale(user.getLocaleCode())))
                        .append(" ")
                        .append(StringUtils.toString(data.get("SALES_NM"))).toString());
                    this.setAmount(StringUtils.toString(data.get("CONT_AMT")));
                    this.setValue(StringUtils.toString(data.get("CONT_AMT")));
                    this.setUnit(StringUtils.toString(data.get("UNIT")));
                }
            }).collect(Collectors.toList());
            
            attachment.setElements(elements);
            attachments = Arrays.asList(attachment);
        }
        
        return attachments;
    }
}
