/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : PushAbstractService.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.dao.BotDao;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.NettyPoolClientService;
import com.lgcns.vpa.security.user.dao.UserDao;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 *  Push 알림 Abstract Service
 * </pre>
 * @author
 */
@Service("multi.pushAbstractService")
public abstract class PushAbstractService {
	
	 final Logger logger = LoggerFactory.getLogger(PushAbstractService.class);
	
	@Autowired
	private NettyPoolClientService nettyPoolClientService;
	
	@Autowired
    private UserDao userDao;
    
    @Autowired
    private BotDao botDao;

    @Autowired
    private MessageSource messageSource;

	/**
	 * Backend Proxy 서버 호출 후 응답(ActionResult) 전송
	 * Backend Proxy 정보조회시 오류발생, 결과 없음, 파라미터 매핑 오류, 권한 없음의 경우 null 리턴
	 * @param transferSyncVO
	 * @return
	 */
	public List<Map<String, Object>> callProxy(TransferSyncVO transferSyncVO) {
		
		String responseData = null;
		
		List<Map<String, Object>> proxyResultSet =  null;
		
		try {
			
			responseData = nettyPoolClientService.sendToBnpSync(transferSyncVO);
			
			if (responseData != null && StringUtils.hasText(responseData))  {
			
				/*responseData= responseData.replaceAll("\\\\", "")
						.replaceAll("\\\"\\[","[")
						.replaceAll("\\]\\\"","]");*/
				
				TransferSyncVO responseVO =  new  TransferSyncVO();
				ObjectMapper mapper = new ObjectMapper();
				responseVO =  mapper.readValue(responseData, TransferSyncVO.class);
				
				if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
					proxyResultSet = responseVO.getActionResult();
				}
				
			}
		} catch (IOException e) {
			logger.debug("###responseData###"+responseData);
			throw new RuntimeException(e);
		} catch (Exception e) {
			logger.debug("###responseData###"+responseData);
			throw new RuntimeException(e);
		}
		
		return proxyResultSet;
	}

	/**
	 * 유효한 챗봇 ID 여부 체크
	 * @param botId
	 */
    public void checkBotId(String botId){
    	Bot bot = StringUtils.isEmpty(botId) ? botDao.selectDefaultBotDetail() : botDao.selectBotDetail(botId);

		if (bot == null) {
		    throw new RuntimeException("챗봇 정보가 존재하지 않습니다.");
		}
    }
    
    /**
     * 유효한 사용자 ID 여부 체크
     * @param userId
     */
    public void checkUserId(String userId){
    	User user = userDao.selectUser(userId);
        if (user == null) {
        	throw new RuntimeException("사용자 정보가 존재하지 않습니다.");
        }
    }
    
    /**
     * push용 Activity 객체 생성
     * @param botId
     * @param userId
     * @param localeCode
     * @param message
     * @return
     */
    public Activity createPushActivity(String botId, String userId, String localeCode, String message){
    	Date date = new Date();
		Activity activity = new Activity();
		activity.setTempId(UUID.randomUUID().toString());
        activity.setBotId(botId);
        activity.setUserId(userId);
        activity.setSenderType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH);
		activity.setSentDate(date);
		activity.setUpdateDate(date);
		activity.setMessage(message);
		
		//default locale code setting
		if(StringUtils.isEmpty(localeCode)){
			localeCode=ActivityCode.DEFAULT_LOCALE_CODE;
		}
		
		List<Button> buttons = new ArrayList<Button>();
		Button button = new Button();
		button.setActionType(ActivityCode.ACTION_TYPE_FUNCTION);
		button.setAction("setting");
		button.setTitle(messageSource.getMessage("meesage.push.setting", null, new Locale(localeCode)));
		button.setIcon("fa-bell");
		buttons.add(button);
	
		activity.setButtons(buttons);
		
		return activity;		
    }
    
    /**
     * 자동 의도 실행형 Activity 생성
     * @param botId
     * @param userId
     * @param localeCode
     * @param message
     * @return
     */
    public Activity createPushIntentActivity (String botId, String userId, String localeCode, String message) {
    	Date date = new Date();
		Activity activity = new Activity();
		
		activity.setTempId(UUID.randomUUID().toString());
        activity.setBotId(botId);
        activity.setUserId(userId);
        activity.setSenderType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH);
		activity.setSentDate(date);
		activity.setUpdateDate(date);
		activity.setMessage(message);
		
		//default locale code setting
		if(StringUtils.isEmpty(localeCode)){
			localeCode=ActivityCode.DEFAULT_LOCALE_CODE;
		}
		
		return activity;
    }
}
