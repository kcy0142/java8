package com.lgcns.vpa.base.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;

public class StringUtils extends org.springframework.util.StringUtils {
	
	private static final String[] KOR_FIRST_NAME = {"남궁","황보","제갈","사공","선우"};
	private static final String[] KOR_FIRST_NAME2 = {"서문","독고","동방","망절","어금","무본","등정","황목"};
	
	public static String toString(final Object target) {
        if (target == null) {
            return null;
        }
        return target.toString();
    }

    /**
     * 알파벳 대소문자, 한글, 단모음, 단자음, 공백, -, /, (, ), @을 제외한 문자 제거
     * @param str
     * @return
     */
    public static String removeSpecialChar (String str) {
		
		if ( isEmpty(str) ) {
			return null;
		}
		
		String match = "[^a-zA-Z0-9ㄱ-ㅎㅏ-ㅣ가-힣\\-/()\\[\\]@&\\s+]";
	    String nstr = str.replaceAll(match, "");
	    
	    return nstr;
	}
    
    /**
     * 연속된 공백은 하나의 공백으로 처리
     * @param str
     * @return
     */
    public static String removeDoubleSpace (String str) {
    	if ( isEmpty(str) ) {
			return null;
		}
		
		String match = "\\s{2,}";
		String nstr = str.replaceAll(match, " ");
	    
	    return nstr;
    }
    
    /**
     * 세자리 마다 ',' 추가
     * @param data
     * @return
     */
    public static String addComma (String data) {
		
		if ( isEmpty(data) ) {
			return null;
		}
		
		StringBuffer sBuf = new StringBuffer();
		int dataLength = data.length();
		int count = 0;
		char comma = ',';
		
		for (int i = (dataLength-1) ; i >= 0; i-- ) {
			if (count == 3) {
				sBuf.insert(0, comma);
				count = 0;
			}
			
			sBuf.insert(0, data.charAt(i));
			count++;
		}
		
		return (sBuf.length() <= 0) ? null : sBuf.toString();
	}
    
    /**
     * 문자열을 delimiter 별로 구분하여 String array로 리턴하는데 값이 비어있는 문자열은 제외함
     * @param data
     * @param delimiter
     * @return
     */
    public static String[] splitExeptEmptyString ( String data, String delimiter ) {
		
		if ( isEmpty(data) ) {
			return null;
		}
		
		String [] resultTemp = delimitedListToStringArray(data, delimiter);
		String [] result = null;
		
		//비어있는 값 제거
		if ( (resultTemp != null) && (resultTemp.length > 0) ) {
			
			List<String> removeEmptyValue = new ArrayList<String>();
			
			for ( String tmp : resultTemp ) {
				if ( !isEmpty(tmp) ) {
					removeEmptyValue.add(tmp);
				}
			}
			
			if ( !removeEmptyValue.isEmpty() ) {
				result = removeEmptyValue.toArray(new String[0]);
			}
		}
		
		return result; 
	}
	
    /**
     * 문자열 Array 중에서 Random 번째 문자열을 리턴함 
     * @param dataArray
     * @return
     */
	public static String getRamdomString ( String [] dataArray ) {
		
		if ( (dataArray == null) || (dataArray.length <= 0) ) {
			return null;
		}
		else if ( dataArray.length == 1 ) {
			return dataArray[0];
		}
		else {
			int index = new Random().nextInt(dataArray.length);
			return dataArray[index];
		}
	}
	
	/**
	 * 입력된 문자 중 숫자만 리턴함
	 * @param str
	 * @return
	 */
	public static String removeNotNumeric (String str) {
		
		if ( isEmpty(str) ) {
			return null;
		}
		
		String match = "[^0-9]";
	    String nstr = str.replaceAll(match, "");
	    
	    return ( isEmpty(nstr) ) ? null : nstr;
	}
	
	/**
	 * 숫자로만 이루어진 문자열이 전화번호 형식일 경우 구분자를 넣어서 리턴함, 해당하지 않을 경우 null을 리턴함
	 * @param data
	 * @return
	 */
	public static String getPhoneNumberPattern ( String data ) {
		
		if ( isEmpty(data) ) {
			return null;
		}
		
		//공백과 "-" 제거
		String numericData = data.replace(" ", "");
		numericData = data.replace("-", "");
		
		if ( isEmpty(numericData) || !org.apache.commons.lang3.StringUtils.isNumeric(numericData) ) {
			return null;
		}
		
		
		int size = numericData.length();
		StringBuffer resultBuf = new StringBuffer();
		final String delimeter = "-", seoulNumber = "02";
		
		switch ( size ) {
		case 2 : // 02 -> 02
			if ( numericData.startsWith(seoulNumber) ) {
				resultBuf.append(numericData);
			}
			
			break;
		case 3 : //010 -> 010, 032 -> 032
		case 4 : //1234 -> 1234
			resultBuf.append(numericData);
			break;
		case 5 : //02000 -> 02-000
			if ( numericData.startsWith(seoulNumber) ) {
				resultBuf.append(numericData.substring(0, 2)).append(delimeter).append(numericData.substring(2));
			}
			
			break;
		case 6 : //000000 -> 000-000, 020000 -> 02-0000
			if ( numericData.startsWith(seoulNumber) ) {
				resultBuf.append(numericData.substring(0, 2)).append(delimeter).append(numericData.substring(2));
			}
			else {
				resultBuf.append(numericData.substring(0, 3)).append(delimeter).append(numericData.substring(3));
			}
			
			break;
		case 7 : //000000 -> 000-0000
			resultBuf.append(numericData.substring(0, 3)).append(delimeter).append(numericData.substring(3));
			break;
		case 8 : //00000000 -> 0000-0000
			resultBuf.append(numericData.substring(0, 4)).append(delimeter).append(numericData.substring(4));
			break;
		case 9 : //020000000 -> 02-000-0000
			if ( numericData.startsWith(seoulNumber) ) {
				resultBuf.append(numericData.substring(0, 2)).append(delimeter).append(numericData.substring(2, 5));
				resultBuf.append(delimeter).append(numericData.substring(5));
			}
			
			break;
		case 10 : //0000000000 -> 000-000-0000, 0200000000 -> 02-0000-0000
			if ( numericData.startsWith(seoulNumber) ) {
				resultBuf.append(numericData.substring(0, 2)).append(delimeter).append(numericData.substring(2, 6));
				resultBuf.append(delimeter).append(numericData.substring(6));
			}
			else {
				resultBuf.append(numericData.substring(0, 3)).append(delimeter).append(numericData.substring(3, 6));
				resultBuf.append(delimeter).append(numericData.substring(6));
			}
			
			break;
		case 11 : //00000000000 -> 000-0000-0000
			resultBuf.append(numericData.substring(0, 3)).append(delimeter).append(numericData.substring(3, 7));
			resultBuf.append(delimeter).append(numericData.substring(7));
			break;
		}
		
		return (resultBuf.length() <= 0) ? null : resultBuf.toString();
	}
	
	/**
	 * 전화번호 Pattern 인지 검사
	 */
	public static boolean isPhonePattern ( String data ) {
		
		if ( isEmpty(data) ) {
			return false;
		}
		
		boolean isPhonePattern = false;
		
		//전화번호 검사식
		String regexTel = "^\\d{2,3}-\\d{3,4}-\\d{4}$";
		isPhonePattern = Pattern.matches(regexTel, data);
		
		return isPhonePattern;
	}
	
	/**
	 * 핸드폰번호 Pattern 인지 검사
	 */
	public static boolean isMobilePattern ( String data ) {
		
		if ( isEmpty(data) ) {
			return false;
		}
		
		boolean isMobilePattern = false;
		
		//휴대번호 검사식
		String regexMobile = "^01(?:0|1[6-9])-(?:\\d{3}|\\d{4})-\\d{4}$";
		isMobilePattern = Pattern.matches(regexMobile, data);
		
		return isMobilePattern;
	}
	
	/**
	 * 숫자롬난 이루어진 String 인지 검사
	 * @param data
	 * @return
	 */
	public static boolean isNumericPattern ( String data ) {
		
		if ( isEmpty(data) ) {
			return false;
		}
		
		boolean isNumericPattern = false;
		
		if ( org.apache.commons.lang3.StringUtils.isNumeric(data) ) {
			isNumericPattern = true;
		}
		
		return isNumericPattern;
	}
	
	/**
	 * 이름 중 성씨를 골라낸다.
	 * @param name
	 * @return
	 */
	public static String getFirstNameKor( String name ) {
    	
    	if ( StringUtils.isEmpty(name) ) {
    		return null;
    	}
    	
    	String resultName = null;
    	
    	// 주로 쓰이는 두글자 성씨
    	for ( String fName : KOR_FIRST_NAME ) {
    		if ( name.startsWith(fName) ) {
    			resultName = fName;
    			break;
    		}
    	}
    	
    	// 희귀한 두글자 성씨는 이름이 4글자 이상인 경우
    	if ( (resultName == null) || (name.length() > 3) ) {
    		for ( String fName : KOR_FIRST_NAME2 ) {
        		if ( name.startsWith(fName) ) {
        			resultName = fName;
        			break;
        		}
        	}
    	}
    	
    	// 그 이외는 첫글자 1자를 성씨로
    	resultName = (resultName == null) ? name.substring(0, 1) : resultName;
    	
    	return resultName;
    	
    }
	
}
