/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : ProxyTenantInfo.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

/**
 * <PRE>
 * test
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 6. 22.
 */
package com.lgcns.vpa.dialog.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * <PRE>
 * proxy별 테넌트  설정 정보
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 6. 22.
 */

//@Component
public class ProxyTenantInfo {

	
	@Value("${default.host}")
	private String host;
	
	@Value("${default.port}")
	private String port;
	
	@Value("${default.connection.count}")
	private String numberOfConnections;
	
	@Value("${default.thread.count}")
	private String numberOfThreads;
	
	@Value("${default.secretKey}")
	private String secretKey;
	
	//ele proxy info
	@Value("${ele.host}")
	private String host1;

	@Value("${ele.port}")
	private String port1;

	@Value("${ele.connection.count}")
	private String numberOfConnections1;

	@Value("${ele.thread.count}")
	private String numberOfThreads1;

	@Value("${ele.secretKey}")
	private String secretKey1;

	//che proxy info
	@Value("${che.host}")
	private String host2;

	@Value("${che.port}")
	private String port2;

	@Value("${che.connection.count}")
	private String numberOfConnections2;

	@Value("${che.thread.count}")
	private String numberOfThreads2;

	@Value("${che.secretKey}")
	private String secretKey2;
	
	//lgcns proxy info
	@Value("${lgcns.host}")
	private String host3;

	@Value("${lgcns.port}")
	private String port3;

	@Value("${lgcns.connection.count}")
	private String numberOfConnections3;

	@Value("${lgcns.thread.count}")
	private String numberOfThreads3;
	
	@Value("${lgcns.secretKey}")
	private String secretKey3;

	//lgdis proxy info
	@Value("${lgdis.host}")
	private String host4;

	@Value("${lgdis.port}")
	private String port4;

	@Value("${lgdis.connection.count}")
	private String numberOfConnections4;

	@Value("${lgdis.thread.count}")
	private String numberOfThreads4;


	@Value("${lgdis.secretKey}")
	private String secretKey4;
	
	
	
	public String getTenantInfo(String tenantId){
		
		
		String tenantInfo="";
		//System.out.println("=========getTenantInfo tenantId:"+tenantId);
		
		if(tenantId.equals("ele")){
			tenantInfo=host1.trim()+"#"+port1.trim()+"#"+numberOfConnections1.trim()+"#"+numberOfThreads1.trim()+"#"+secretKey1.trim();
		}else  if(tenantId.equals("che")){
			tenantInfo=host2.trim()+"#"+port2.trim()+"#"+numberOfConnections2.trim()+"#"+numberOfThreads2.trim()+"#"+secretKey2.trim();
		}else if(tenantId.equals("lgcns")){
			tenantInfo=host3.trim()+"#"+port3.trim()+"#"+numberOfConnections3.trim()+"#"+numberOfThreads3.trim()+"#"+secretKey3.trim();
		}else if(tenantId.equals("dis")){
			tenantInfo=host4.trim()+"#"+port4.trim()+"#"+numberOfConnections4.trim()+"#"+numberOfThreads4.trim()+"#"+secretKey4.trim();
		}else{
			tenantInfo=host.trim()+"#"+port.trim()+"#"+numberOfConnections.trim()+"#"+numberOfThreads.trim()+"#"+secretKey.trim();
		}
		//System.out.println("=========getTenantInfo tenantInfo:"+tenantInfo);
		return tenantInfo;
	
	}
}

