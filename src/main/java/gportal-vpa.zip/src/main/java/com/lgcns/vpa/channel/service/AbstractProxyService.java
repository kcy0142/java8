package com.lgcns.vpa.channel.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.NettyPoolClientService;
import com.lgcns.vpa.push.service.PushAbstractService;

public class AbstractProxyService {
    
    final Logger logger = LoggerFactory.getLogger(PushAbstractService.class);
   
   @Autowired
   private NettyPoolClientService nettyPoolClientService;
   
   /**
    * Backend Proxy 서버 호출 후 응답(ActionResult) 전송
    * Backend Proxy 정보조회시 오류발생, 결과 없음, 파라미터 매핑 오류, 권한 없음의 경우 null 리턴
    * @param transferSyncVO
    * @return
    */
   public List<Map<String, Object>> callProxy(TransferSyncVO transferSyncVO) {
       String responseData = null;
       List<Map<String, Object>> proxyResultSet =  null;
       
       try {
           responseData = nettyPoolClientService.sendToBnpSync(transferSyncVO);
           if (responseData != null && StringUtils.hasText(responseData))  {
               TransferSyncVO responseVO =  new  TransferSyncVO();
               ObjectMapper mapper = new ObjectMapper();
               responseVO =  mapper.readValue(responseData, TransferSyncVO.class);
               
               if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
                   proxyResultSet = responseVO.getActionResult();
               }
               
           }
       } catch (IOException e) {
           throw new RuntimeException(e);
       } catch (Exception e) {
           throw new RuntimeException(e);
       }
       
       return proxyResultSet;
   }
}
