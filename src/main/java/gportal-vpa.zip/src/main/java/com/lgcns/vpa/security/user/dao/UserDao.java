package com.lgcns.vpa.security.user.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.lgcns.vpa.security.user.model.User;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserDao {
    /**
     * 사용자 조회
     * @return
     * @throws Exception
     */
    User selectUser(String userId);

    /**
     * 사용자목록 조회
     * @return
     * @throws Exception
     */
    List<User> selectUserList();
    
    /**
     * 사용자 기본 정보 조회 
     * 개체명 사전 구성사용
     * @return
     */
    List<User> selectUserProfileList();
}
