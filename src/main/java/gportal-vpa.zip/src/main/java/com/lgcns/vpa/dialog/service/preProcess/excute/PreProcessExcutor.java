/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : PreProcessExcutor.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.preProcess.excute;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.dialog.model.InquiryVO;

/**
 * <PRE>
 * Multi Tenant 별 전 처리를 위한 부모 Class 
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 10. 24.
 */
public abstract class PreProcessExcutor {
	
	public Activity execute ( InquiryVO inquiry ) {
		return preProcess( inquiry );
	}
	
	protected abstract Activity preProcess ( InquiryVO inquiry );
	
}
