package com.lgcns.vpa.push.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.channel.service.ConfigService;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.model.PushHistory;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.push.service.PushService;

/**
 * <pre>
 * 일정 시작 시간 도래 Push 알림 Service
 * </pre>
 * @author
 */
@Service("multi.plannerPushService")
public class PlannerPushServiceImpl extends PushAbstractService implements PushService {
	
	@Autowired
    private ConfigService configService;
    
    @Autowired
    RedisMessagePublisher redisMessagePublisher;

    @Autowired
    private MongoTemplate mongoTemplate;
    
    
    @Autowired
    private MessageSource messageSource;
	
    @Override
    public void execute(Map<String, String> params, String tenantId, PushConfig pushConfig){
    	
    	String botId = params.get("botId");
    	
    	checkBotId(botId);
		
    	List<PushConfig> pushConfigList = configService.retrievePushConfigAllUserList(pushConfig.getPushId(), null);

		TransferSyncVO transferSyncVO =  new TransferSyncVO();
		transferSyncVO.setActionUri(pushConfig.getActionUri());
		transferSyncVO.setTenantId(tenantId);
		
		//mongodb에 실행 이력 저장(초기값 설정)
		PushHistory push=new PushHistory();
		push.setBotId(botId);
		push.setPushId(pushConfig.getPushId());
		push.setJobGroup(tenantId);
		push.setJobName("PlannerBatch");
		push.setResponseCount(0);
		push.setExecuteCount(0);
		push.setSentDate(new Date());
		
		List<Map<String, Object>> proxyResultSet = callProxy(transferSyncVO);
		
		int count=0;
		if(proxyResultSet != null){

			Map<String, List<Map<String, Object>>> groupedResultMap =
					proxyResultSet.stream().collect(Collectors.groupingBy(w -> StringUtils.toString(w.get("targetUserId"))));
			
			for( String key : groupedResultMap.keySet() ){
				
				List<Map<String, Object>> dataList = groupedResultMap.get(key);
				
				String targetUserId = key;
				
				if(pushConfigList.stream().anyMatch(t -> t.getUserId().equals(targetUserId))){
					
					String localeCode = pushConfigList.stream()
							.filter(x -> targetUserId.equals(x.getUserId()))
							.map(PushConfig::getLocaleCode)
							.findAny()
							.orElse(ActivityCode.DEFAULT_LOCALE_CODE);
					
					String message = messageSource.getMessage("message.push.planner.message", null, new Locale(localeCode));
					
					Activity activity = createPushActivity(botId, targetUserId, localeCode, message);
					
					Attachment attachment = new Attachment();
					
					attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
					attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_PLANNER);
					
					for(Map<String, Object> data: dataList){
						String startDate = StringUtils.toString(data.get("startDate"));
						String endDate = StringUtils.toString(data.get("endDate"));
						String facility = StringUtils.toString(data.get("facility")); //예약한 회의실명
						String place = StringUtils.toString(data.get("place")); //직접등록한 장소명
						String title = StringUtils.toString(data.get("title"));
						String scheduleId = StringUtils.toString(data.get("scheduleId"));
						String actionUrl = StringUtils.toString(data.get("actionUrl"));
						String schedulePublic = StringUtils.toString(data.get("schedulePublic"));
						String icon = StringUtils.toString(data.get("icon"));
						
						String description = !StringUtils.isEmpty(facility) ? facility : ( !StringUtils.isEmpty(place) ? place : "");
						
						if(!StringUtils.isEmpty(facility) && !StringUtils.isEmpty(place)){
							description = facility + "/" + place;
						}
						
						Element element = new Element();
						element.setActionType(ActivityCode.ACTION_TYPE_LINK);
						element.setAction(actionUrl);
						element.setId(scheduleId);
						element.setDescriptions(description);
						element.setTitle(title);
						element.setSubtitle(startDate+" ~ "+endDate);
						
						Map<String,Object> additionalProperties = new HashMap<String, Object>();
						additionalProperties.put("kind", icon);
						additionalProperties.put("public", schedulePublic);
						
						element.setAdditionalProperties(additionalProperties);
						attachment.addElement(element);
						
					}
					
					activity.addAttachment(attachment);
					redisMessagePublisher.publish(activity);
					count=count+1;
				}
				
	        }
			push.setResponseCount(proxyResultSet.size());
			push.setExecuteCount(count);
			
		}
		
		//data가 없어도 배치 수행후 초기값 저장
		mongoTemplate.save(push, "pushHistory");
    	
	}
	
}
