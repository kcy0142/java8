/* ------------------------------------------------------------------------------
 * Project       : NextEP Framework Project
 * Source        : RestConfig.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.base.config;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.fasterxml.jackson.databind.node.MissingNode;
import com.lgcns.vpa.base.config.MongoConfig.MongoDataSourceProperty;

/**
 * R&D 의도 추론 Restful API 호출
 * TODO restful api 의 uri는 tenant / bot에 설정된 정보를 읽어오도록 수정
 * @author 70399
 *
 */
@Configuration
public class RestConfig implements ApplicationContextAware{
	final Logger logger = LoggerFactory.getLogger(RestConfig.class);
	
	private ApplicationContext context;
	private Map<String, RestfulApi> cache = new HashMap<>();
	
	@Bean(value="apiService") 
	public RestTemplate apiService() {
		RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
		
		//한글 처리
    	MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter(); 
    	HttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter(Charset.forName("UTF-8")); 
    	List<HttpMessageConverter<?>> httpMessageConverter = new ArrayList(); 
    	httpMessageConverter.add(mappingJackson2HttpMessageConverter); 
    	httpMessageConverter.add(stringHttpMessageConverter); 
    	restTemplate.setMessageConverters(httpMessageConverter);
    	
    	return restTemplate;
    	
	}
	
	@Bean(value="nluService")
    public RestTemplate nluService() {
        return new RestTemplate(clientHttpRequestFactory());
    }

    private ClientHttpRequestFactory clientHttpRequestFactory() {
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
        factory.setConnectionRequestTimeout(30 * 1000);
        factory.setReadTimeout(30 * 1000);
        factory.setConnectTimeout(30 * 1000);
        
        return factory;
    }

    @Bean(name="searchApi") 
    public SearchApi searchApi() {
    	return new SearchApi();
    }
    
    @Bean(name="autoSuggestApi")
	public AutoSuggestApi autoSuggestApi() {
		return new AutoSuggestApi();
	}

    @Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.context = context;
	}
    
    private RestfulApiSchem loadSchem(String templ) throws Exception {
    	
		Resource resource = context.getResource(templ);
		if( !resource.exists() ) {
			return null;
		}
		ObjectMapper om = new ObjectMapper();	
		JsonNode schema = null;
		try {
			schema = om.readTree(resource.getInputStream());
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("service template incorrect " + templ);
		}
		
		JsonNode pathNode = schema.path(RestfulApiSchem.SCHEM_PATH);
		if( !pathNode.getNodeType().equals(JsonNodeType.STRING)) {
			throw new Exception("service template path incorrect " + templ);
		}
		
		JsonNode paramNode = schema.path(RestfulApiSchem.SCHEM_PARAM);
		JsonNodeType nodeType = paramNode.getNodeType();
		if( !nodeType.equals(JsonNodeType.MISSING) && !nodeType.equals(JsonNodeType.OBJECT)) {
			throw new Exception("service template param incorrect " + templ);
		}
		
		return new RestfulApiSchem(
				pathNode.asText(),
				om.convertValue(paramNode, Map.class));
			
	}

    @ConfigurationProperties
    public class SearchApi {
    	private Map<String, Map<String, Map>> search;

		public Map<String, Map<String, Map>> getSearch() {
			return search;
		}

		public void setSearch(Map<String, Map<String, Map>> search) {
			this.search = search;
		}
		
		public RestfulApi getApi(String tenantId, String collection) {
			
			String apiKey  = tenantId + "." + collection;
			if( search == null || !search.containsKey(tenantId) ) {
				return null;
			}
			
			RestfulApi api = cache.get(apiKey);
			
			if( api == null ) {
				Map<String, Map> searchInfos = search.get(tenantId);
				
				if( searchInfos == null ) {
					return null;
				}
				
				Map<String, String> apiDetail = searchInfos.get(collection);
				
				api = new RestfulApi(apiDetail.get(RestfulApi.API_URL));
				String templ   = apiDetail.get(RestfulApi.API_TEMP);
				
				if( !StringUtils.isEmpty(templ)) {
					try {
						api.schem = loadSchem(templ);
					}catch(Exception e) {
						logger.error(e.getMessage());
					}
				}
				cache.put(apiKey, api);
			}
			
			return api;
		}
		
		@PostConstruct
		public void init() {
			System.out.println("*****************************");
			System.out.println(search);
			System.out.println("*****************************");
			
		}
    	
    }
    
    @ConfigurationProperties
    public class AutoSuggestApi {
    	
    	private Map<String, Map<String, Map>> autosuggest;
    	
		public Map<String, Map<String, Map>> getAutosuggest() {
			return autosuggest;
		}
		
		public void setAutosuggest(Map<String, Map<String, Map>> autosuggest) {
			this.autosuggest = autosuggest;
		}

		public Map<String, RestfulApi> getApi(String tenantId) {
			
			if( autosuggest == null || !autosuggest.containsKey(tenantId) ) {
				return Collections.EMPTY_MAP;
			}
			
			Map<String, Map> autosuggestInfos = autosuggest.get(tenantId);

			Map<String, RestfulApi> apiList = new HashMap<>();
			

			for( Entry<String, Map> apiInfo : autosuggestInfos.entrySet() ) {
				
				String apiKey = tenantId + "." + apiInfo.getKey();
				RestfulApi api = cache.get(apiKey);
				if( api != null ) {
					apiList.put(apiInfo.getKey(), api);
					continue;
				}
				Map<String, String> apiDetail = apiInfo.getValue();
				String title   = apiDetail.get(RestfulApi.API_TITLE);
				String url     = apiDetail.get(RestfulApi.API_URL);
				String templ   = apiDetail.get(RestfulApi.API_TEMP);
				
				api = new RestfulApi(title, url);
				
				if( !StringUtils.isEmpty(templ)) {
					try {
						api.schem = loadSchem(templ);
					}catch(Exception e) {
						logger.error(e.getMessage());
						continue;
					}
				}
				cache.put(apiKey, api);

				apiList.put(apiInfo.getKey(), api);
			}
			return apiList;
		}
		
		
		@PostConstruct
		public void init() {
			System.out.println("*****************************");
			System.out.println(autosuggest);
			System.out.println("*****************************");
			
		}
    }
    
    public class RestfulApi {
    	final static String API_TITLE = "title";
    	final static String API_URL	  = "url";
    	final static String API_TEMP  = "template";
    	
    	private String title;
		private String url;
		private RestfulApiSchem schem;
		
		public RestfulApi(String url) {
			this.url = url;
		}
		public RestfulApi(String title, String url) {
			this.title = title;
			this.url = url;
		}
		public String getTitle() {
			return this.title;
		}

		public String getUrl() {
			return this.url;
		}

		public RestfulApiSchem getSchem() {
			return this.schem;
		}
		
    }
    
    public class RestfulApiSchem {
    	final static String SCHEM_PATH 	= "path";
    	final static String SCHEM_PARAM = "params";
    	private String path;
    	private Map<String, String> params;
    	
    	public RestfulApiSchem(String path, Map<String, String> params) {
    		this.path 	= path;
    		this.params = params;
    	}
    	
    	public String getPath() {
    		return this.path;
    	}
    	
    	public Map<String, String> getParams() {
    		return this.params;
    	}
    }
}
