package com.lgcns.vpa.base.model;

import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

public abstract class BaseModel implements Serializable {
	
	private static final long serialVersionUID = 4220461820168818960L;
	
    private String registerId;

    private String registerName;

    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private Date registDate;

    private String updaterId;

    private String updaterName;

    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private Date updateDate;

    public String getRegisterId() {
        return registerId;
    }

    public void setRegisterId(String registerId) {
        this.registerId = registerId;
    }

    public String getRegisterName() {
        return registerName;
    }

    public void setRegisterName(String registerName) {
        this.registerName = registerName;
    }

    public Date getRegistDate() {
        return registDate;
    }

    public void setRegistDate(Date registDate) {
        this.registDate = registDate;
    }

    public String getUpdaterId() {
        return updaterId;
    }

    public void setUpdaterId(String updaterId) {
        this.updaterId = updaterId;
    }

    public String getUpdaterName() {
        return updaterName;
    }

    public void setUpdaterName(String updaterName) {
        this.updaterName = updaterName;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
