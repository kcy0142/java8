/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserAutoRunServiceImpl.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgcns.vpa.base.idgen.service.IdgenService;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.dialog.service.DialogHandlerService;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.push.RedisMessagePublisher;
import com.lgcns.vpa.push.dao.UserAutoRunDao;
import com.lgcns.vpa.push.model.UserAutoRun;
import com.lgcns.vpa.push.service.UserAutoRunService;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.security.user.service.UserService;

/**
 * <pre>
 * 개인별 자동 실행 Service 구현
 * </pre>
 * @author 김가원
 * @version v1.0 2017. 11. 28.
 */
@Service("multi.userAutoRunService")
@Transactional
public class UserAutoRunServiceImpl implements UserAutoRunService{

	/**
	 * Redis WebSocket 정보를 조회하기 위한 KEY String
	 */
	public static final String WEBSOCKET_CODE_KEY 	= "webscoket:%s";
	
	public static final int RESULT_STATUS_WAIT = 0,
							RESULT_STATUS_SUCCESS = 1,
							RESULT_STATUS_FAILURE = 2,
							PROCESS_STATUS_WAITING = 0,
							PROCESS_STATUS_RUNNING = 1;
	
	@Autowired
    private RedisTemplate<String, Object> redisTemplate;
	
	@Autowired
	private IdgenService idgenService;
	
	@Autowired
	private UserAutoRunDao userAutoRunDao;
	
	@Autowired
	private UserService userService;
	
	@Autowired
    private DialogHandlerService dialogHandlerService;
	
	@Autowired
    private RedisMessagePublisher redisMessagePublisher;
	
	@Override
	public List<UserAutoRun> list(String botId, String userId) {
		
		if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(userId) ) {
			return null;
		}
		
		return this.userAutoRunDao.list(botId, userId);
	}

	@Override
	public UserAutoRun retrieve(String botId, String userAutoRunId) {
		
		if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(userAutoRunId) ) {
			return null;
		}
		
		return this.userAutoRunDao.retrieve(botId, userAutoRunId);
	}

	@Override
	public String create(UserAutoRun userAutoRun) {
		
		String newUserAutoRunId = this.idgenService.getNextId();
		userAutoRun.setUserAutoRunId(newUserAutoRunId);
		
		this.userAutoRunDao.create(userAutoRun);
		
		return newUserAutoRunId;
	}

	@Override
	public void delete(String botId, String userAutoRunId) {
		
		if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(userAutoRunId) ) {
			return;
		}
		
		this.userAutoRunDao.delete(botId, userAutoRunId);
	}

	@Override
	public List<UserAutoRun> listFireTarget(String botId, User reqUser) {
		
		if ( StringUtils.isEmpty(botId) || (reqUser == null) ) {
			return null;
		}
		
		//30분 간격으로 실행되기 때문에 현재시간보다 5분 후의 것부터
		//이전 시간에 실행되어야 한 건들을 모두 대상으로 함
		long nextRunTimeEnd = System.currentTimeMillis() + 300000L;//현재시간 + 5분
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("botId", botId);
		params.put("nextRunTimeEnd", nextRunTimeEnd);
		
		List<UserAutoRun> list = this.userAutoRunDao.listFireTarget(params);
		
		if ( (list != null) && (!list.isEmpty()) ) {
			this.updateProcessStatusFireTarget(botId, nextRunTimeEnd, reqUser);
		}
		
		return list;
	}

	@Override
	public void updateProcessStatusFireTarget(Map<String, Object> params) {
		
		if ( (params == null) || (params.isEmpty()) ) {
			return;
		}
		
		this.userAutoRunDao.updateProcessStatusFireTarget(params);
	}
			
	@Override
	public void updateProcessStatusFireTarget(String botId, long nextRunTimeEnd, User reqUser) {
		
		if ( StringUtils.isEmpty(botId) || (reqUser == null) ) {
			return;
		}
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("botId", botId);
		params.put("updaterId", reqUser.getUserId()); 
		params.put("updaterName", reqUser.getUserName()); 
		params.put("processStatus", PROCESS_STATUS_RUNNING);
		//params.put("nextRunTimeStart", nextRunTimeStart);
		params.put("nextRunTimeEnd", nextRunTimeEnd);
		
		this.userAutoRunDao.updateProcessStatusFireTarget(params);
	}

	@Override
	public void updateResultStatus(UserAutoRun userAutoRun) {
		
		if ( userAutoRun == null ) {
			return;
		}
		
		this.userAutoRunDao.updateResultStatus(userAutoRun);
		
	}

	@Override
	@Async("threadPoolTaskExecutor")
	public void startAutoRunJob(String botId, String tenantId, User reqUser) {
		
		if ( StringUtils.isEmpty(botId) || StringUtils.isEmpty(tenantId) || (reqUser == null) ) {
			return;
		}
		
		//TenantId 지정
    	DataSourceKeyHolder.setDataSourceKey(tenantId);
		
		//TODO
		//1. 현재 시간의 자동 실행 목록을 조회
		//2. 조회된 자동 실행 목록의 진행 상태를 RUNNING 으로 변경
		//===> 자동 실행 건별로 반복
		//3. 목록의 개인 정보를 조회
		//4. 해당 의도를 자동 실행
    	//5. 실행결과(응답)를 PubSub으로 전송
		
		//현재 시간의 자동 실행 목록을 조회
		//조회된 자동 실행 목록의 진행 상태를 RUNNING 으로 변경
		List<UserAutoRun> listFireTarget = this.listFireTarget(botId, reqUser);
		
		if ( (listFireTarget == null) || (listFireTarget.isEmpty()) ) {
			return;
		}
		
		User targetUser = null;
		StringBuffer msgBuf = new StringBuffer();
			
		for ( UserAutoRun uar : listFireTarget ) {
			
			if ( uar == null ) {
				continue;
			}
			
			//목록의 개인 정보를 조회
			targetUser = this.userService.selectUser(uar.getUserId());
			
			//사용자 정보가 없으면 데이터를 삭제함
			if ( targetUser == null ) {
				try {
					this.delete(botId, uar.getUserAutoRunId());
				} catch(Exception e) {
					e.printStackTrace();
				}
				
				continue;
			}
			
			//자동 실행 목록의 대상 사용자의 WebSocket의 연결 상태 검사
			boolean isWebSocketAlive = this.isWebSocketAlive(uar.getUserId());
			
			if (!isWebSocketAlive) {
				//자동 실행이 완료되면 해당 UserAutoRun의 상태를 완료로 변경
				this.autoRunSuccess(uar, reqUser);
				
				continue;
			}
			
			try {
				//의도 실행
				Activity reqActivity = createPushIntentActivity(botId, targetUser.getUserId(), null, uar.getInquiry());
				Activity activity = dialogHandlerService.syncInquiry(reqActivity, targetUser, tenantId);
				
				//의도 분석이 완료 되었을 경우만 발송
				if ( (activity != null) && (!ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_ERROR.equals(activity.getSubtype())) ) {
					
    				activity.setId(reqActivity.getId());
    				activity.setSenderType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
    				activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH);
    				activity.setSentDate(reqActivity.getSentDate());
    				activity.setUpdateDate(reqActivity.getUpdateDate());
    				
    				msgBuf.setLength(0); //msgBuf 초기화
    				msgBuf.append(activity.getMessage());
    				msgBuf.append("\n\n 자동 알림 설정에 따른 정보를 알려드립니다.");
    				
    				activity.setMessage(msgBuf.toString());
    				
    				this.redisMessagePublisher.publish(activity);
				}
				
				//자동 실행이 완료되면 해당 UserAutoRun의 상태를 완료(마지막 성공)로 변경
				this.autoRunSuccess(uar, reqUser);
				
			} catch (Exception e) {
				// 자동 실행이 완료되면 해당 UserAutoRun의 상태를 완료(마지막 실패)로 변경
				this.autoRunFailure(uar, reqUser);
				e.printStackTrace();
			}
		}//for
	}
	
	@Override
	public boolean isWebSocketAlive (String userId) {
    	boolean isAlive = false;
    	
    	String key = String.format(WEBSOCKET_CODE_KEY, userId);
		//String webSocketSessionId = (String)redisTemplate.opsForHash().get(key, "webSocketSessionId");
		//String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
		
		String sessionId = (String)redisTemplate.opsForHash().get(key, "sessionId");
		String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
		
		if( redisTemplate.hasKey(sessionIdKey) ) {
			isAlive = true;
		}
		    	
    	return isAlive;
    }
	
	@Override
	@Async("threadPoolTaskExecutor")
	public void runningUserAutoRunInit (String botId, String tenantId, User reqUser) {
		
		if ( StringUtils.isEmpty(botId) ) {
			return;
		}
		
		//1. 현재 processStatus = Running 인 UserAutoRun Data를 조회함
		//2. processStatus = Waiting 으로 변경하고 nextRunTime 을 현재 시간 이후로 설정함
		
		//TenantId 지정
    	DataSourceKeyHolder.setDataSourceKey(tenantId);
    	
    	List<UserAutoRun> listRunning = this.userAutoRunDao.listAllRunning(botId);
		
		if ( (listRunning == null) || (listRunning.isEmpty()) ) {
			return;
		}
		
		try {
			User targetUser = null;
			StringBuffer msgBuf = new StringBuffer();
			
			for ( UserAutoRun uar : listRunning ) {
				if ( uar == null ) {
					continue;
				}
				
				//목록의 개인 정보를 조회
				targetUser = this.userService.selectUser(uar.getUserId());
				
				//사용자 정보가 없으면 데이터를 삭제함
				if ( targetUser == null ) {
					try {
						//this.userAutoRunDao.delete(botId, uar.getUserAutoRunId());
						this.delete(botId, uar.getUserAutoRunId());
					} catch(Exception e) {
						e.printStackTrace();
					}
					
					continue;
				}
				
				//실패 상태로 초기화
				this.autoRunFailure(uar, reqUser);
			}
		} catch (Exception e) {
			
		}
	}
	
	/**
     * 자동 의도 실행형 Activity 생성
     * @param botId
     * @param userId
     * @param localeCode
     * @param message
     * @return
     */
    private Activity createPushIntentActivity (String botId, String userId, String localeCode, String message) {
    	Date date = new Date();
		Activity activity = new Activity();
		
		activity.setTempId(UUID.randomUUID().toString());
        activity.setBotId(botId);
        activity.setUserId(userId);
        activity.setSenderType(ActivityCode.ACTIVITY_TYPE_MESSAGE);
		activity.setSubtype(ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH);
		activity.setSentDate(date);
		activity.setUpdateDate(date);
		activity.setMessage(message);
		
		//default locale code setting
		if(StringUtils.isEmpty(localeCode)){
			localeCode=ActivityCode.DEFAULT_LOCALE_CODE;
		}
		
		return activity;
    }
    
    /**
     * 자동 실행 성공 표시 및 다음 실행 시간 갱신
     * @param uas
     * @param reqUser
     */
    private void autoRunSuccess( UserAutoRun uar, User reqUser ) {
		
    	uar.setResultStatus(RESULT_STATUS_SUCCESS); //마지막 실행 상태 성공(1)
    	uar.setProcessStatus(PROCESS_STATUS_WAITING);//현재 상태 대기(0)
    	uar.setNextRunTime(uar.nextExcutionTimeLong());
    	uar.setUpdaterId(reqUser.getUserId());
    	uar.setUpdaterName(reqUser.getUserName());
		
		this.userAutoRunDao.updateResultStatus(uar);
    }
    
    /**
     * 자동 실행 실패 표시 및 다음 실행 시간 갱신
     * @param uas
     * @param reqUser
     */
    private void autoRunFailure( UserAutoRun uar, User reqUser ) {
		
    	uar.setResultStatus(RESULT_STATUS_FAILURE); //마지막 실행 상태 실패(2)
    	uar.setProcessStatus(PROCESS_STATUS_WAITING);//현재 상태 대기(0)
    	uar.setNextRunTime(uar.nextExcutionTimeLong());
    	uar.setUpdaterId(reqUser.getUserId());
    	uar.setUpdaterName(reqUser.getUserName());
		
		this.userAutoRunDao.updateResultStatus(uar);
    }
	
}
