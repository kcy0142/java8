/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.dao;

import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.BotMessage;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <pre>
 * 봇 관리 Dao
 * </pre>
 * @author
 */
@Mapper
@Repository
public interface BotDao {
    
    /**
     * 봇 정보 조회
     * @param botId
     * @return
     */
    Bot selectBotDetail(String botId);

    /**
     * 해당(PORTAL)의 기본 봇 조회
     * @return
     */
    Bot selectDefaultBotDetail();
    
    /**
     * user 봇 조회
     * @return
     */
    Bot selectUserBotDetail(@Param("tenantId") String tenantId, @Param("userId") String userId);
    
    /**
     *Demo 의 기본 봇 조회
     * @return
     */
    Bot selectDemoBotDetail();

    /**
     * 해당(PORTAL)의 봇 리스트 조회
     * @return
     */
    List<Bot> selectBotList();
    
    /**
     * 봇 기본 메시지 1건 조회 (인사, 오류 등)
     * @param botMessage
     * @return
     */
    BotMessage selectRandomBotMessageByType(BotMessage searchCondition);
    
    /**
     * 봇 메시지 목록
     * @param botId
     * @return
     */
    List<BotMessage> selectBotMessageList(String botId);
    
    /**
     * 봇 메시지 유형별 목록
     */
    List<BotMessage> selectBotMessageListByType(@Param("botId") String botId, @Param("messageType") String messageType);
}
