package com.lgcns.vpa.push.service;

import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.security.user.model.User;

public interface ConversationDailyPushService {
    Activity executeDailyPush(Bot bot, User user, String tenantId);
}
