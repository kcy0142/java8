/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : UserFeedback.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

/**
 * <PRE>
 * test
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 9. 28.
 */
package com.lgcns.vpa.channel.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * <PRE>
 * 사용자 의견  Modeling Object
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 9. 28.
 */
@Document(collection="userFeedback")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserFeedback {

	@Id
	private String id;
	/**
	 * 봇 ID
	 */
	private String botId;

	/**
	 * 사용자 ID
	 */
	private String userId;
	
	/**
	 * 좋아요 피드백
	 */
	private String feedback;

	/**
	 * 좋아요 피드백 등록일시
	 */
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private Date feedbackDate;

	/**
	 * 좋아요 피드백 타입
	 */
	private String feedbackType;

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public Date getFeedbackDate() {
		return feedbackDate;
	}

	public void setFeedbackDate(Date feedbackDate) {
		this.feedbackDate = feedbackDate;
	}

	public String getFeedbackType() {
		return feedbackType;
	}

	public void setFeedbackType(String feedbackType) {
		this.feedbackType = feedbackType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	

}
