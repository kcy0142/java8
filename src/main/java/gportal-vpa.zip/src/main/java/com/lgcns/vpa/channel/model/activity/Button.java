/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.activity;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * <pre>
 * 액티비티 버튼 Model
 * </pre>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Button implements Serializable {

	private static final long serialVersionUID = 4220461820168818969L;
	
    /**
     * 버튼유형
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String type;

    /**
     * 버튼 제목
     */
    private String title;

    // 액션정보
    
    /**
     * 액션 유형 (link: 링크, inquiry: 인텐트처리)
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String actionType;
    
    /**
     * 액션
     */
    private String action;
        
    /**
     * 액션 파라미터
     */
    private Map<String, Object> actionParams;
    
    /**
     * 아이콘 (Font Awesome class)
     */
    private String icon;
    
    private int popupWidth;
    
    private int popupHeight;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public Map<String, Object> getActionParams() {
        return actionParams;
    }

    public void setActionParams(Map<String, Object> actionParams) {
        this.actionParams = actionParams;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public int getPopupWidth() {
        return popupWidth;
    }

    public void setPopupWidth(int popupWidth) {
        this.popupWidth = popupWidth;
    }

    public int getPopupHeight() {
        return popupHeight;
    }

    public void setPopupHeight(int popupHeight) {
        this.popupHeight = popupHeight;
    }
}
