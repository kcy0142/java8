/* ------------------------------------------------------------------------------
 * Project       : NextEP Project
 * Source        : DataSourceKeyHolder.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.framework.multidata;

import java.util.Stack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

/**
 * multi-datasource routing을 위한 key를 저장하는 
 * @author 70399
 *
 */
public class DataSourceKeyHolder {
	
	protected static final Logger log = LoggerFactory.getLogger(DataSourceKeyHolder.class);
	
	private static final ThreadLocal<DataSourceKey> DATASOURCE_KEY_HOLDER = new ThreadLocal<DataSourceKey>();
	
	public static void setDataSourceKey(String dataSourceKey) {
		Assert.notNull(dataSourceKey, "DataSourceKey must not be null");
		
		DATASOURCE_KEY_HOLDER.set(new DataSourceKey(dataSourceKey));
		
		log.debug(String.format("DataSourceKeyHolder : \"%s\" is set in DATASOURCE_KEY_HOLDER...", dataSourceKey));
	}

	public static DataSourceKey getRawDataSourceKey() {
		return DATASOURCE_KEY_HOLDER.get();
	}
	
	public static String getDataSourceKey() {
		DataSourceKey dataSourceKey = DATASOURCE_KEY_HOLDER.get();
		if( dataSourceKey == null ) {
			return null;
		} else {
			return dataSourceKey.key;
		}
	}

	public static void clearDataSourceKey() {
		DATASOURCE_KEY_HOLDER.remove();
	}
	
	public static class DataSourceKey {
		private int refCnt;
		private String key;
		
		DataSourceKey(String key) {
			this.refCnt = 0;
			this.key = key;
		}
		
		public int increaseReference() {
			return ++this.refCnt;
		}
		
		public int decreaseReference() {
			if(this.refCnt < 1 ) {
				return 0;
			} else {
				return --this.refCnt;
			}
		}
		
		public String toString() {
			return "key : " + key + " ref : " + refCnt;
		}
	}
	
}