/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : RedisMessageSubscriber.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.push;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.core.RedisTemplate;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.service.WebsocketService;
import com.lgcns.vpa.dialog.util.JsonConverter;

/**
 * <pre>
 * Redis 메세지 Subscriber
 * <pre>
 * @author
 */
public class RedisMessageSubscriber implements MessageListener {
	
	final Logger logger = LoggerFactory.getLogger(RedisMessageSubscriber.class);
	 
	@Autowired
	 WebsocketService websocketService;
	
	@Autowired
    private RedisTemplate<String, Object> redisTemplate;
	 
	 /**
	  * Redis 메세지 Subscribe하여 websocket에 push
	  * ChannelTopic: ActivityCode.ACTIVITY_SUBTYPE_MESSAGE_PUSH (push)
	  * @param message
	  * @param pattern
	  */
	@Override
	public void onMessage(Message message, byte[] pattern) {
		
		Activity activity = null;
		Object obj = redisTemplate.getValueSerializer().deserialize(message.getBody());
		
		if ( obj instanceof Activity ) {
			activity = (Activity) obj;
		}
		else if ( obj instanceof String ) {
			JsonConverter<Activity> conv = new JsonConverter<Activity>();
			activity = conv.jasonStringToObject((String) obj, Activity.class);
		}
		
		if ( activity != null) {
			if(activity.getUserId().equals("ALL")){
				websocketService.pushAll(activity);
			}else{
				websocketService.push(activity);
			}
		}
	 }

}
