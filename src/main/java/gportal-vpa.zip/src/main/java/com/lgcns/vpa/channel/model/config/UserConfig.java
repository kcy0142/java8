/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseModel;

/**
 * <pre>
 * 사용자 설정 Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserConfig extends BaseModel {

    /**
     * 사용자 ID
     */
    private String userId;

    /**
     * 항상표시여부
     */
    private String alwaysDisplayYn;

    /**
     * 알림사용여부
     */
    private String notificationYn;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAlwaysDisplayYn() {
        return alwaysDisplayYn;
    }

    public void setAlwaysDisplayYn(String alwaysDisplayYn) {
        this.alwaysDisplayYn = alwaysDisplayYn;
    }

    public String getNotificationYn() {
        return notificationYn;
    }

    public void setNotificationYn(String notificationYn) {
        this.notificationYn = notificationYn;
    }

}
