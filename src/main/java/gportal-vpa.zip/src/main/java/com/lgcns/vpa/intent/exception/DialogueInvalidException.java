/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : DialogueInvalidException.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.exception;

public class DialogueInvalidException extends IntentException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3009535081394608720L;

	public DialogueInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
