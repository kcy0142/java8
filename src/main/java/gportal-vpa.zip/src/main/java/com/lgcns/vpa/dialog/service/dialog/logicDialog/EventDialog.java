/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : EventDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Button;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.model.TransferSyncVO;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.util.JsonConverter;
import com.lgcns.vpa.dialog.util.ParameterChecker;
import com.lgcns.vpa.intent.model.Intent.RelatedButton;

/**
 * <PRE>
 * 일정조회 Intent 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 8. 4.
 */
@Component("EventDialog")
public class EventDialog extends LogicDialog {
	
	private static final Logger LOG = LoggerFactory.getLogger(EventDialog.class);
    
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Value("${spring.profiles.active}")
    private String profiles;
	
    @Override
	protected boolean validator(InquiryVO data) {
		Action action = data.getAction();
		boolean isValid = false;
		
		//Parameter validator
		if (action != null) {
			if ( !StringUtils.hasText(action.getActionUri()) ) {
				isValid = true;
			}
			else {
				isValid = true;
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				Date date = null;
				Map<String, Object> newIntentParam = null; 
						
				//Intent Parameter 에서 누락된 Parameter 는 각 Type 의 기본 값으로 Parameter 값을 설정함
				if ( action.getActionUri().startsWith("sql-stored") ) {
					newIntentParam = ParameterChecker.parameterValidator(action.getActionUri(), data.getIntentParam());
				}
				else {
					newIntentParam = data.getIntentParam();
					newIntentParam = (newIntentParam == null) ? new HashMap<String, Object>() : newIntentParam;
				}
				
				if ( newIntentParam.get("date") != null ) {
					
					if ( newIntentParam.get("date") instanceof Date ) {
						date =  (Date)newIntentParam.get("date");
						newIntentParam.put("date", sdf.format(date));
					}
					else {
						date = new Date(System.currentTimeMillis());
						newIntentParam.put("date", sdf.format(date));
					}
					
				}
				else {
					date = new Date(System.currentTimeMillis());
					newIntentParam.put("date", sdf.format(date));
				}
				
				data.setIntentParam(newIntentParam);
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+
						 "], actionUri:["+action.getActionUri()+"], Intent Param:["+data.getIntentParam()+"]");
			}
		}
		else {
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],isValid:["+isValid+"], Validation을 수행할 action 정보가 없음");
		}
		
		return isValid;
	}
    
    @Override
	protected Activity afterWork(InquiryVO data, String proxyResponseJsonData) {
		
		if ( data == null ) {
			LOG.info("inquiryId:[null],질의어:[null], 응답을 생성할 질의 정보가 없음");
			return null;
		}
		
		if ( StringUtils.isEmpty(proxyResponseJsonData) ) {
			//Proxy Json 결과가 없음
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 정보 조회 결과가 없음( JSON 결과가 없음 )");
			
			return null;
		}
		
		Activity resultActivity = null;
        
		try {
			
			resultActivity = Activity.createBotMessage(data.getBotId(), data.getReqUserId());
	        
			List<Attachment> attachments = null;
			List<Map<String, Object>> proxyResultSet =  null;
			
			TransferSyncVO responseVO =  new  TransferSyncVO();
			ObjectMapper mapper = new ObjectMapper();
			responseVO =  mapper.readValue(proxyResponseJsonData, TransferSyncVO.class);
			
			//if ( responseVO != null && responseVO.getActionResult() != null && !responseVO.getActionResult().isEmpty()) {
			if ( responseVO != null ) {
				proxyResultSet = responseVO.getActionResult();
				
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"],proxyResultSet:["+proxyResultSet+"]");
				
				//if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
					//Proxy에서 조회된 결과(JsonData)에서 Attachment 를 구함
					attachments = this.getAttachment(data, proxyResultSet);
					
					if ( (attachments != null) && (!attachments.isEmpty()) ) {
						
						int count = (proxyResultSet == null) ? 0 : proxyResultSet.size();
						
						//Activity Message
						StringBuffer activityMessage = new StringBuffer();
						activityMessage.append(data.getIntentMessage()).append(" ");
						activityMessage.append("총 ").append(count).append("건이 조회 되었습니다.");
						//resultActivity.setMessage(data.getIntentMessage());
						resultActivity.setMessage(activityMessage.toString());
						resultActivity.setAttachments(attachments);
						
					}
					else {
						LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Attachment 정보가 없음");
						
						//Data 가 없음
			        	resultActivity = this.commonResponeService.simpleResponseMessage(
								data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
								" 질의 결과 조회된 정보가 없습니다.");
					}
					
					//의도분석의 Button이 있는 경우 처리
					if ( data.getIntentButtons() != null ) {
						List<RelatedButton> buttons = data.getIntentButtons();
						List<Button> activityButtonList = super.makeActivityButtonList(buttons);
						
						if ( (activityButtonList !=null) && (!activityButtonList.isEmpty()) ) {
							resultActivity.setButtons(activityButtonList);
						}
					}
				//}
			}
			else {
				LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], Proxy 조회 결과가 없음");
				
				//Data 가 없음
	        	resultActivity = this.commonResponeService.simpleResponseMessage(
						data.getReqMessageId(),data.getBotId(),data.getReqUserId(),data.getReqIp(),data.getReqDeviceType(),
						"조회된 정보가 없습니다.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.info("inquiryId:["+data.getInquiryId()+"],질의어:["+data.getInquiryData()+"], 응답을 생성하는 중 오류 발생, Exception : " + e.toString());
			
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		if ( resultActivity == null ) {
			//오류가 발생환 경우
			resultActivity = this.commonResponeService.errorWarning(data);
		}
		
		return resultActivity;
	}
	/**
	 * Attachment List를 구함
	 * @param inquiryData
	 * @param proxyResultSet
	 * @return
	 */
	@Override
	protected List<Attachment> getAttachment (InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet) throws Exception {
		
		if ( inquiryData == null ) {
			return null;
		}
		/*if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}*/
		
		Attachment attachment = null;
				
		try {
			
			String userId = null;
			String date = null;
			Map <String, Object> intentParam = inquiryData.getIntentParam();
			if ( intentParam != null ) {
				userId = String.valueOf(intentParam .get("userId"));
				date = String.valueOf(intentParam .get("date"));
			}
			
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_PLANNER);

		    LocalDate now = LocalDate.now();
		    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd").withLocale(Locale.KOREAN);
		    
	        // 페이지 블럭 네비게이션 적용
	        attachment.setBlockPagingType(ActivityCode.PAGING_TYPE_PAGER);
	        attachment.setBlockDataType(ActivityCode.BLOCK_DATA_TYPE_DATE);
	        
	        // 조회된 일자를 기본으로 표시함
	        if ( !StringUtils.isEmpty(date) ) {
	        	attachment.setCurrentBlock(date);
	        }
	        // 조회일자가 없으면 오늘 일자
	        else {
	        	attachment.setCurrentBlock(formatter.format(now));
	        }
	        
	        // 페이징 정보
	        // FIXME: RequestContextHolder 말고, Server 정보 가지고올 방법 없나?
	        String restUrl = "local".equals(this.profiles) ? "http://localhost:8080/api/dailog/event/%s?startDt=${currentBlock}" : "/api/dailog/event/%s?startDt=${currentBlock}";
            attachment.setBlockDataUrl(String.format(restUrl, userId));
	        
            if ( (proxyResultSet != null) && (!proxyResultSet.isEmpty()) ) {
	            String block = null, id = null, title = null, subtitle = null, action = null, publicYn = null, kind = null, readYn = null, descriptions = null;
	            
	            // 오늘 일정이 존재하는 경우  
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		block = ( proxyResult.get("BASE_DT") != null ) ? String.valueOf(proxyResult.get("BASE_DT")) : "";
	        		id = ( proxyResult.get("ID") != null ) ? String.valueOf(proxyResult.get("ID")) : "";
	        		title = ( proxyResult.get("TITLE") != null ) ? String.valueOf(proxyResult.get("TITLE")) : "";
	        		subtitle = ( proxyResult.get("SUBTITLE") != null ) ? String.valueOf(proxyResult.get("SUBTITLE")) : "";
	        		action = ( proxyResult.get("ACTION") != null ) ? String.valueOf(proxyResult.get("ACTION")) : "";
	        		publicYn = ( proxyResult.get("PUBLIC_YN") != null ) ? String.valueOf(proxyResult.get("PUBLIC_YN")) : "";
	        		readYn = ( proxyResult.get("READ_YN") != null ) ? String.valueOf(proxyResult.get("READ_YN")) : ""; 
	        		kind = ( proxyResult.get("ICON") != null ) ? String.valueOf(proxyResult.get("ICON")) : "";
	        		descriptions = ( proxyResult.get("DESCRIPTIONS") != null ) ? String.valueOf(proxyResult.get("DESCRIPTIONS")) : "";
	        		
	        		// additionalProperties 설정
	                Map<String, Object> additionalProperties = new HashMap<String, Object>();
	                additionalProperties.put("publicYn", publicYn);
	                additionalProperties.put("readYn", readYn);
	                additionalProperties.put("kind", kind);
	                
	        		Element element = new Element();
	        		element.setBlock(block);// 페이지 블럭 ID
	        		element.setId(id);
	        		element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	        		element.setCorpCode(inquiryData.getCompanyCode());
	        		element.setTitle(title);
	        		element.setDescriptions(descriptions);
	        		element.setSubtitle(subtitle);
	        		element.setActionType(ActivityCode.ACTION_TYPE_LINK);
	        		
	        		if ( "Y".equalsIgnoreCase(readYn) ) {
	        			element.setAction(action);
	        		}
	        		else {
	        			element.setAction("");
	        		}
	        		element.setAdditionalProperties(additionalProperties);
	        		
	        		attachment.addElement(element);
	        	}
            }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}
}
