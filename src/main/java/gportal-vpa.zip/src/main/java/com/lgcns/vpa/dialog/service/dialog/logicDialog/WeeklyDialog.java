/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : WeeklyDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.dialog.logicDialog;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.InquiryVO;

/**
 * <PRE>
 * 주간보고 목록 조회 처리를 위한 Dialog 구현
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 9. 5.
 */
@Component("WeeklyDialog")
public class WeeklyDialog extends LogicDialog {

	@Override
	protected List<Attachment> getAttachment(InquiryVO inquiryData, List<Map<String, Object>> proxyResultSet)
			throws Exception {
		
		if ( (inquiryData == null) || (proxyResultSet == null) ) {
			return null;
		}
		
		Attachment attachment = null;
				
		try {
			attachment = new Attachment();
	        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
	        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_LIST);
	        //attachment.setTitle(inquiryData.getIntentMessage());
	        
	        // 통제경비 현황이 없는 경우
	        if (CollectionUtils.isEmpty(proxyResultSet)) {
	            attachment.setDescriptions("등록된 주간보고가 없습니다.");
	            
	        }
	        // 통제경비 현황이 존재하는 경우    
	        else {
	        	
	        	String id = null, title = null, userName = null, regEmpNo = null, regDt = null, viewUrl = null, editUrl = null;
	        	String regDateStr = null;
	        	StringBuffer descBuf = null;
	        	SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd hh:mm");
	        	Date regDate = null;
	        	
	        	for (Map<String, Object> proxyResult : proxyResultSet) {
	        		 
	        		if ( (proxyResult != null) && (!proxyResult.isEmpty()) ) {
	        			
	        			regEmpNo = (proxyResult.get("REG_EMP_NO") != null) ? String.valueOf(proxyResult.get("REG_EMP_NO")) : "";
	        			id = (proxyResult.get("REPORT_ID") != null) ? String.valueOf(proxyResult.get("REPORT_ID")) : ""; 
	        			title = (proxyResult.get("REPORT_TITLE") != null) ? String.valueOf(proxyResult.get("REPORT_TITLE")) : ""; 
	        			userName = (proxyResult.get("REG_EMP_NM") != null) ? String.valueOf(proxyResult.get("REG_EMP_NM")) : "";
	        			regDt = (proxyResult.get("REG_DT") != null) ? String.valueOf(proxyResult.get("REG_DT")) : "";
	        			viewUrl = (proxyResult.get("VIEW_URL") != null) ? String.valueOf(proxyResult.get("VIEW_URL")) : "";
	        			editUrl = (proxyResult.get("EDIT_URL") != null) ? String.valueOf(proxyResult.get("EDIT_URL")) : "";
	        			    				
	        			try {
	        				regDate = new Date(Long.parseLong(regDt));
	        				regDateStr = sdf.format(regDate);
	        			} catch (Exception e) {
	        				regDateStr = null;
	        			}
	        			descBuf = new StringBuffer();
	        			
	        			if ( !StringUtils.isEmpty(userName) ) {
	        				descBuf.append(userName);
	        			}
	        			
	        			if ( !StringUtils.isEmpty(regDateStr) ) {
	        				if ( !StringUtils.isEmpty(userName) ) {
	        					descBuf.append(" ");
	        				}
	        				
	        				descBuf.append(regDateStr);
	        			}
	        			
	    				Element element = new Element();
	    				element.setType(CommonCode.ELEMENT_TYPE_TEXT);
	    				element.setId(id);
	    				element.setTitle(title);
	    				element.setDescriptions(descBuf.toString());
	    				
	    				//Edit URL이 있으면 우선 적용하고 없으면 View URL 적용
	    				if ( !StringUtils.isEmpty(editUrl) ) {
	    					element.setAction(editUrl);
	    				}
	    				else {
	    					element.setAction(viewUrl);
	    				}
	    				element.setActionType(ActivityCode.ACTION_TYPE_LINK);
	    				
	    				attachment.addElement(element);
	        		}
	        	}//for
	        }
		} catch (Exception e) {
			throw e;
		}
		
        return Arrays.asList(attachment);
	}

}
