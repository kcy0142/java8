/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : IdgenServiceImpl.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.base.idgen.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lgcns.vpa.base.idgen.dao.IdgenDao;
import com.lgcns.vpa.base.idgen.service.IdgenService;

/**
 * <PRE>
 * ID 생성 서비스 구현체
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 11. 28.
 */
@Service("multi.IdgenService")
@Transactional
public class IdgenServiceImpl implements IdgenService {

	/**
	 * 아이디생성 Dao
	 */
	@Autowired
	private IdgenDao idgenDao;

	public String getNextId() {
		return idgenDao.getNextId();
	}
	
}
