/* ------------------------------------------------------------------------------
 * Project       : HUBTREE Framework Project
 * Source        : SearchServiceImpl.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.channel.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.lgcns.vpa.base.config.RestConfig.AutoSuggestApi;
import com.lgcns.vpa.base.config.RestConfig.RestfulApi;
import com.lgcns.vpa.base.config.RestConfig.RestfulApiSchem;
import com.lgcns.vpa.base.config.RestConfig.SearchApi;
import com.lgcns.vpa.channel.service.SearchService;

@Service("searchService")
public class SearchServiceImpl implements SearchService {

	@Autowired
	private AutoSuggestApi autoSuggest;
	
	@Autowired
	private SearchApi searchApi;
	
	@Autowired
	private RestTemplate apiService;
	
	private ObjectMapper om = new ObjectMapper();
	
	@Override
	public List<Map<String, Object>> search(String tenantId, String query, Map<String, String> options) {
		return search(tenantId, query, "default", options);
	}

	@Override
	public List<Map<String, Object>> search(String tenantId, String query, String collection, Map<String, String> options) {
		RestfulApi api = searchApi.getApi(tenantId, collection);
		try {
			String responseStr = call(api.getUrl(), query, collection, options);
			JsonNode node = om.readTree(responseStr);
			return convert(node, api.getSchem());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return Collections.EMPTY_LIST;
	}
	
	private String call(String url, String query, String collection, Map<String, String> options) throws UnsupportedEncodingException {
    	
    	UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(String.format(url, query, collection));
    	if ( options != null ) {
	    	for( Entry<String, String> param : options.entrySet() ) {
	        	uriBuilder.queryParam(param.getKey(), param.getValue());
	    	}
    	}
    	
    	URI uri = uriBuilder.build().encode("UTF-8").toUri();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(new MediaType("text", "plain", Charset.forName("UTF-8")));
		
		ResponseEntity<String> result = apiService.exchange(
				uri, 
    			HttpMethod.GET, 
    			new HttpEntity<String>("parameters", headers), 
    			String.class);//,
    			//options);
    	
		if( result != null && result.getStatusCode().equals(HttpStatus.OK) ) {
			return result.getBody();
		} else {
			return "";
		}
    }
	
	private List<Map<String, Object>> convert(JsonNode root, RestfulApiSchem schem) {
    	
    	JsonNode payloadNode = root;
    	if( schem != null && !StringUtils.isEmpty(schem.getPath()) ) {
    		payloadNode = root.get(schem.getPath());
    	}
    	
    	List<Map<String, Object>> list = new ArrayList<>();
    	switch(payloadNode.getNodeType()) {
    	case MISSING : 
    	case NULL : 
    		break;
    	case ARRAY : 
    		ArrayNode array = (ArrayNode)payloadNode;
    		if( array.size() == 0 ) {
    			break;
    		}
			List<Map<String, Object>> searchList = om.convertValue(payloadNode, new TypeReference<List<Map<String, Object>>>(){});
			
			for( Map<String, Object> search : searchList ) {
				Map<String, Object> item = new HashMap<>();
				for( Entry<String, String> params : schem.getParams().entrySet()) {
					item.put(params.getKey(), search.getOrDefault(params.getValue(), ""));
				}
				list.add(item);
			}
    		break;
    	case OBJECT : 
    		Map<String, Object> search = om.convertValue(payloadNode, new TypeReference<Map<String, Object>>(){});
    		Map<String, Object> item = new HashMap<>();
			for( Entry<String, String> params : schem.getParams().entrySet()) {
				item.put(params.getKey(), (String)search.get(params.getValue()));
			}
			list.add(item);
		default : //exception을 던질까?
			throw new IllegalStateException("json format check");
    	}
    	return list;    	
    }

	
}
