package com.lgcns.vpa.push.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.lgcns.vpa.base.util.I18nUtils;
import com.lgcns.vpa.channel.model.Bot;
import com.lgcns.vpa.channel.model.activity.ActivityCode;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.channel.model.activity.Element;
import com.lgcns.vpa.channel.model.config.PushConfig;
import com.lgcns.vpa.framework.multidata.DataSourceKeyHolder;
import com.lgcns.vpa.push.dao.WeatherDao;
import com.lgcns.vpa.push.model.City;
import com.lgcns.vpa.push.model.Weather;
import com.lgcns.vpa.push.service.DailyPushService;
import com.lgcns.vpa.push.service.PushAbstractService;
import com.lgcns.vpa.security.user.model.User;

/**
 * <pre>
 * 데일리 알림 Service
 * </pre>
 * @author
 */
@Service("multi.weatherDailyPushService")
public class WeatherDailyPushServiceImpl extends PushAbstractService implements DailyPushService {
    
	private static final Logger LOG = LoggerFactory.getLogger(WeatherDailyPushServiceImpl.class);
	
    @Autowired
    private WeatherDao weatherDao;
        
    /**
     * 기본 도시 코드 (서울시 영등포구: 1156000000)
     * 마곡 이전하면 바꾸시길...
     */
    private static String DEFAULT_CITY_CODE;
    
    @Value("${weather.default.tenant}")
	private String lgCnsTenantId;
    
    @Value("${weather.default-city-code}")
    public void setDefaultCityCode(String cityCode) {
        DEFAULT_CITY_CODE = cityCode;
    }
    
    @Override
    public List<Attachment> execute(Map<String, String> param, PushConfig pushConfig, Bot bot, User user, String tenantId) {

        Attachment attachment = new Attachment();
        attachment.setType(ActivityCode.ATTACHMENT_TYPE_TEMPLATE);
        attachment.setTemplateType(ActivityCode.TEMPLATE_TYPE_CUSTOM_WEATHER);
        
        Element element = new Element();
        
        try {
        	
        	// 날씨정보는 LGCns DataSource 를 사용하여 정보를 가져옴
			//TenantId 지정
	    	DataSourceKeyHolder.setDataSourceKey(this.lgCnsTenantId);
        	
        	// 1. 로그인 사용자의 근무지 주소 조회
            Weather weatherCondition = new Weather();
            String cityCode = DEFAULT_CITY_CODE;
            
	        if (!StringUtils.isEmpty(user.getOfficeBasicAddress())) {
	            City officeLocation = weatherDao.selectCityByOfficeAddress(user.getOfficeBasicAddress());
	            
	            if (officeLocation != null && !StringUtils.isEmpty(officeLocation.getCityCode())) {
	                cityCode = officeLocation.getCityCode();
	            }
	        }
	        
	        weatherCondition.setSearchCityCode(cityCode);
	                        
	        // 2. 해당 지역의 초단기 실황 조회
	        Weather weatherGrib = weatherDao.selectWeatherByCityCode(weatherCondition);
	        
	        // 날씨정보가 존재하지 않는 지역의 경우 대표주소로 조회한다.
	        if (weatherGrib == null) {
	            weatherCondition.setSearchCityCode(DEFAULT_CITY_CODE);
	            weatherGrib = weatherDao.selectWeatherByCityCode(weatherCondition);
	                    
	            if (weatherGrib != null && !I18nUtils.isDefaultLocaleCode(user.getLocaleCode())) {
	                weatherGrib.setCityAllDisplayName(weatherGrib.getCityAllDisplayEnglishName());
	            }
	        }
	              
	        element.addAdditionalProperty("weather", weatherGrib);
        
        	// 3. 해당 지역의 동네예보 조회
        
            List<Weather> forecasts = weatherDao.selectForecastWeatherListByCityCode(weatherCondition);
            if (!CollectionUtils.isEmpty(forecasts)) {
                element.addAdditionalProperty("forecasts", forecasts);   
            }    
        } catch (Exception e) {
        	LOG.error(e.toString());
	    } finally {
			// 사용자의 원래 TenantId 지정
	    	DataSourceKeyHolder.setDataSourceKey(tenantId);
		}
        
        attachment.addElement(element);
     
        return Arrays.asList(attachment);
    }
}
