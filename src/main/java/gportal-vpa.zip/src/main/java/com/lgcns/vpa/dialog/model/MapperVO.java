/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : MapperVO.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * <PRE>
 * Action에 저장된 Mapping Data를 모델링
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 6. 22.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value=Include.NON_EMPTY)
public class MapperVO {
	
	/**
	 * mapperType, single Type, multi Type 으로 구분
	 * @see com.lgcns.vpa.dialog.common.SINGLE_ELEMENT_INROW, com.lgcns.vpa.dialog.common.MULTI_ELEMENT_INROW
	 */
	public int mapperType;
	
	/**
	 * Action에 정의된 mapper
	 * ex) JSON : "{\"mappers\":[{\"positionInRow\":0, \"classNames\":\"noti\", \"vpaField\":\"title\", \"dataFields\":[\"subject\", \"subject2\"], "actionType":"inquiry", "action":"${ASSET_NO} 자산번호 조회"},"
				   + "{\"positionInRow\":1, \"classNames\":\"noti\", \"vpaField\":\"userId\", \"dataFields\":[\"empNo\", \"empNo2\"]},"
				   + "{\"positionInRow\":2, \"classNames\":\"noti\",\"vpaField\":\"text\", \"dataFields\":[\"text\", \"text2\"]},"
				   + "{\"positionInRow\":3, \"classNames\":\"noti\",\"vpaField\":\"userName\", \"dataFields\":[\"userName\", \"userName2\", \"empNm\", \"empNm2\"]}]}
	 */
	public List<ChildMapper> mappers;
	
	
	public int getMapperType() {
		return mapperType;
	}

	public void setMapperType(int mapperType) {
		this.mapperType = mapperType;
	}

	public List<ChildMapper> getMappers() {
		return mappers;
	}

	public void setMappers(List<ChildMapper> mappers) {
		this.mappers = mappers;
	}

	/**
	 * Proxy 를 통해서 조회된 Data와 UI의 Field 명을 Mapping 하여 반환함
	 * @param fieldName
	 * @return
	 */
	public String getVpaField (String fieldName) {
		
		if ( !StringUtils.hasText(fieldName) ) {
			return null;
		}
		else if ( (mappers == null) || mappers.isEmpty() ) {
			return fieldName;
		}
		
		ChildMapper childMapper = this.getChildMapper(fieldName);
		
		return ( childMapper != null ) ? childMapper.getVpaField() : fieldName;
	}
	
	/**
	 * Proxy 를 통해서 조회된 Data의 Mapping Object를 반환함
	 * @param fieldName
	 * @return
	 */
	public ChildMapper getChildMapper (String fieldName) {
		
		if ( !StringUtils.hasText(fieldName) ) {
			return null;
		}
		else if ( (mappers == null) || mappers.isEmpty() ) {
			return null;
		}
		
		ChildMapper resuldChild = null;
		for (ChildMapper child : mappers) {
			if ( (child != null) && child.isMappingVpaField(fieldName) ) {
				resuldChild = child;
				break;
			}
		}
		
		return resuldChild;
	}
	
	/**
	 * Child Mapper 추가
	 * @param child
	 */
	public void addChild (ChildMapper child) {
		if (this.mappers == null) {
			this.mappers = new ArrayList<ChildMapper>();
		}
		
		this.mappers.add(this.mappers.size(), child);
	}
	
	/**
	 * Child Mapper의 개수를 조회
	 * @return
	 */
	public int childMapperCounter () {
		return ( (this.mappers == null) || (this.mappers.isEmpty()) ) ? 0 : this.mappers.size();
	}
}
