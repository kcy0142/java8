/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : SmsSendController.java
 * Author        : 김청욱
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.push.web;

import java.util.HashMap;
import java.util.Map;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.base.web.BaseController;
import com.lgcns.vpa.push.service.SmsSendService;

/**
 * <PRE>
 * SMS 발송 Controller
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 12. 15.
 */
@RestController
@CrossOrigin(value="*")
@RequestMapping(value="/api/sms")
public class SmsSendController extends BaseController {

	final Logger logger = LoggerFactory.getLogger(SmsSendController.class);
	
	@Autowired
	private SmsSendService smsSendService; 
	

	
	/**
	 * SMS 발송
	 * @param botId
	 * @param params
	 * @return
	 */
	@RequestMapping(value="/userSend", method=RequestMethod.POST)
	@ResponseBody
	public Map<String, String> sendSms (
					@RequestBody Map<String, Object> params) {
		
		if ( (params == null) || (params.isEmpty()) ) {
			throw new RuntimeException("정보가 유효하지 않습니다.");
		}
		
		String actionType = (params.get("actionType") != null) ? (String) params.get("actionType") : "user";
		String toGroup = (params.get("toGroup") != null) ? (String) params.get("toGroup") : null;
		String toGroupName = (params.get("toGroupName") != null) ? (String) params.get("toGroupName") : null;
		
		
		String botId = (params.get("botId") != null) ? (String) params.get("botId") : null;
		String id = (params.get("id") != null) ? (String) params.get("id") : null;
		String fromUserName = (params.get("fromUserName") != null) ? (String) params.get("fromUserName") : null;
		String fromMobile = (params.get("fromMobile") != null) ? (String) params.get("fromMobile") : null;
		String toUserName = (params.get("toUserName") != null) ? (String) params.get("toUserName") : null;
		String toMobile = (params.get("toMobile") != null) ? (String) params.get("toMobile") : null;
		String sendMessage = (params.get("sendMessage") != null) ? (String) params.get("sendMessage") : null;
		
		
         
		//save는 발송,cancel 은 취소
		String target = (params.get("target") != null) ? (String) params.get("target") : null;
		//String userId = (params.get("userId") != null) ? (String) params.get("userId") : null;
		
		System.out.println("##### actionType:"+actionType);
		System.out.println("##### botId:"+botId);
		System.out.println("##### fromUserName:"+fromUserName);
		System.out.println("##### fromMobile:"+fromMobile);
		System.out.println("##### toUserName:"+toUserName);
		System.out.println("##### toMobile:"+toMobile);
		System.out.println("##### toGroup:"+toGroup);
		System.out.println("##### toGroupName:"+toGroupName);
		System.out.println("##### sendMessage:"+sendMessage);
		System.out.println("##### target:"+target);
		
		
		//this.logger.info(String.format("botId:[%s], fromUserName:[%s], fromMobile:[%s] toUserName:[%s] toMobile:[%s] sendMessage:[%s] ", 
		//				 botId, fromUserName, fromMobile, toUserName, toMobile,sendMessage));
		
		//전송일 경우에만 validate 처리
		if(target.equals("save")){
			//Parameter Validation
			if(actionType.equals("user")){
				if ( StringUtils.isEmpty(fromUserName) || StringUtils.isEmpty(fromMobile) || StringUtils.isEmpty(toUserName) || StringUtils.isEmpty(toMobile) || StringUtils.isEmpty(sendMessage)) {
					throw new RuntimeException("정보가 유효하지 않습니다.");
				}	
				
			}else if(actionType.equals("group")){
				if ( StringUtils.isEmpty(fromUserName) || StringUtils.isEmpty(fromMobile) || StringUtils.isEmpty(toGroup)  || StringUtils.isEmpty(sendMessage)) {
					throw new RuntimeException("정보가 유효하지 않습니다.");
				}
			}
			
		}
		
		//SMS 발송 파라미터 시작
		
		Map<String, Object> actionParam = new HashMap<String, Object>();
		actionParam.put("botId",botId); 	//botId 
		actionParam.put("replyToId",id); 	//replyToId
		actionParam.put("target",target); 	//target  save는 발송,cancel 은 취소
		
		actionParam.put("actionType",actionType); 	//actionType:user,group 
		actionParam.put("toGroup",toGroup); 	//그룹 아이디 
		actionParam.put("toGroupName",toGroupName); 	//그룹 이름
		
		
		
		actionParam.put("toUserName",toUserName); 	//수신자 
		actionParam.put("tranPhone",StringUtils.replace(toMobile, "-", "")); 	//수신자 전화번호
		actionParam.put("tranCallback", fromUserName);							//발신자 
		actionParam.put("returnNo",StringUtils.replace(fromMobile, "-", "")); 	//발신자 번호 
		
		actionParam.put("content", 	sendMessage);			//메세지 내용 
		actionParam.put("group", 	"ep");				//wl(무선랜)==>LGT
		actionParam.put("rVal", 	"ok");				//wl(무선랜)==>LGT
		
		
		
		Map<String, String> resultMap=smsSendService.execute(actionParam, getTenantId());
	
		return resultMap;
	}
	
	
}
