/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.lgcns.vpa.base.model.BaseModel;

/**
 * <pre>
 * 이벤트 Model
 * </pre>
 * @author
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Event extends BaseModel {    
    /**
     * 이벤트 ID
     */
    private String eventId;
    
    /**
     * 이벤트명
     */
    private String eventName;
    
    /**
     * 이벤트설명
     */
    private String eventDescription;
    
    /**
     * 봇 ID
     */
    private String botId;
    
    /**
     * 시작일자
     */
    private String startDate;
    
    /**
     * 종료일자
     */
    private String endDate;
    
    /**
     * 표시유형 (1: 메시지, 2: 애니메이션, 3: 애니메이션 + 메시지)
     */
    private String displayType;
    
    /**
     * 메시지
     */
    private String message;
    
    private String englishMessage;
    
    /**
     * 애니메이션 유형 (IMAGE: 이미지, CLASS: CSS 클래스, SCRIPT: 리액트 클래스)
     */
    private String animationType;
    
    /**
     * 애니메이션 소스
     */
    private String animation;
    
    /**
     * 애니메이션 제목
     */
    private String animationTitle;
    
    private String animationEnglishTitle;
    
    /**
     * 애니메이션 컨텐츠
     */
    private String animationContent;
    
    private String animationEnglishContent;
    
    /**
     * 애니메이션 버튼
     */
    private String animationButton;
    
    private String animationEnglishButton;

    /**
     * 애니메이션 버튼 링크
     */
    private String animationButtonUrl;
       
    /**
     * 애니메이션 타임아웃 (ms, -1: 타임아웃 없음)
     */
    private int animationTimeout;
    
    /**
     * 사용여부
     */
    private String useYn;
    
    /**
     * 우선순위 (0-9, 0:최우선, 9:최하)
     */
    private String priority;

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public String getBotId() {
        return botId;
    }

    public void setBotId(String botId) {
        this.botId = botId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getDisplayType() {
        return displayType;
    }

    public void setDisplayType(String displayType) {
        this.displayType = displayType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getEnglishMessage() {
        return englishMessage;
    }

    public void setEnglishMessage(String englishMessage) {
        this.englishMessage = englishMessage;
    }

    public String getAnimationType() {
        return animationType;
    }

    public void setAnimationType(String animationType) {
        this.animationType = animationType;
    }

    public String getAnimation() {
        return animation;
    }

    public void setAnimation(String animation) {
        this.animation = animation;
    }

    public String getAnimationTitle() {
        return animationTitle;
    }

    public void setAnimationTitle(String animationTitle) {
        this.animationTitle = animationTitle;
    }

    public String getAnimationEnglishTitle() {
        return animationEnglishTitle;
    }

    public void setAnimationEnglishTitle(String animationEnglishTitle) {
        this.animationEnglishTitle = animationEnglishTitle;
    }

    public String getAnimationContent() {
        return animationContent;
    }

    public void setAnimationContent(String animationContent) {
        this.animationContent = animationContent;
    }

    public String getAnimationEnglishContent() {
        return animationEnglishContent;
    }

    public void setAnimationEnglishContent(String animationEnglishContent) {
        this.animationEnglishContent = animationEnglishContent;
    }

    public String getAnimationButton() {
        return animationButton;
    }

    public void setAnimationButton(String animationButton) {
        this.animationButton = animationButton;
    }

    public String getAnimationEnglishButton() {
        return animationEnglishButton;
    }

    public void setAnimationEnglishButton(String animationEnglishButton) {
        this.animationEnglishButton = animationEnglishButton;
    }

    public String getAnimationButtonUrl() {
        return animationButtonUrl;
    }

    public void setAnimationButtonUrl(String animationButtonUrl) {
        this.animationButtonUrl = animationButtonUrl;
    }

    public int getAnimationTimeout() {
        return animationTimeout;
    }

    public void setAnimationTimeout(int animationTimeout) {
        this.animationTimeout = animationTimeout;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }
}
