package com.lgcns.vpa.push.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.lgcns.vpa.push.model.City;
import com.lgcns.vpa.push.model.Weather;

@Repository
@Mapper
public interface WeatherDao {
    
	/**
	 * 사무실 주소로 Like 검색
	 * @param searchAddress
	 * @return
	 */
    public City selectCityByOfficeAddress(String searchAddress);
    
    /**
     * 검색어(지역 또는 주소)로 일치 검색
     * @param searchAddress
     * @return
     */
    public City selectCityBySearchNameEqual(String searchAddress);
    
    /**
     * 검색어(지역 또는 주소)로 Like 검색
     * @param searchAddress
     * @return
     */
    public City selectCityBySearchNameLike(String searchAddress);
    
    public Weather selectWeatherByCityCode(Weather searchCondition);
    
    public List<Weather> selectForecastWeatherListByCityCode(Weather searchCondition);
    
    public List<Weather> selectForecastWeatherListToday(Weather searchCondition);
    
}
