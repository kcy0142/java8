package com.lgcns.vpa.security.user.service.impl;

import com.lgcns.vpa.security.user.dao.UserDao;
import com.lgcns.vpa.security.user.model.User;
import com.lgcns.vpa.security.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("multi.userService")
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userdao;

	public User selectUser(String userId) {
		return this.userdao.selectUser(userId);
	}

	public List<User> selectUserList() {
		return this.userdao.selectUserList();
	}
}
