package com.lgcns.vpa.base.config;

import java.util.Collections;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <pre>
 * 연계서버 정보 Properties
 * </pre>
 * @author
 */
@Configuration
@ConfigurationProperties
public class ServersConfig {
    private Map<String, Map<String, Map<String, String>>> servers;

    public Map<String, Map<String, Map<String, String>>> getServers() {
        return servers;
    }

    public void setServers(Map<String, Map<String, Map<String, String>>> servers) {
        this.servers = servers;
    }
    
    public Map<String, Map<String, String>> getServersByTenantId(String tenantId) {
        if (servers == null || !servers.containsKey(tenantId)) {
            return Collections.emptyMap();
        }
        return servers.get(tenantId);
    }
    
    public Map<String, String> getServersInfoMap(String tenantId, String groupKey) {
        Map<String, Map<String, String>> serversMap = getServersByTenantId(tenantId);
        if (serversMap == null) {
            return null;
        }
        return serversMap.get(groupKey);
    }
    
    public String getServersInfo(String tenantId, String groupKey, String key) {
        Map<String, String> serversInfoMap = getServersInfoMap(tenantId, groupKey);
        if (serversInfoMap == null) {
            return null;
        }
        return serversInfoMap.get(key);
    }
    
    @Bean
    ServersConfig serversConfigBean() {
        return new ServersConfig();
    }
}