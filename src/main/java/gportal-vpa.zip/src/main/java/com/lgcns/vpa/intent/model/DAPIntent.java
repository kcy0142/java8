/* ------------------------------------------------------------------------------
 * Project       : Next EP Framework Project
 * Source        : DAPIntent.java
 * Author        : 최환준
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */
package com.lgcns.vpa.intent.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DAPIntent {
	private String userId;
	private String botId;
	
	private String sentence;
	
	public DAPIntent() {
	}

	public DAPIntent(String userId, String botId) {
		this.userId = userId;
		this.botId = botId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getSentence() {
		return this.sentence;
	}
	
	public void setSentence(String sentence) {
		this.sentence = sentence;
	}
}
