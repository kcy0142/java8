package com.lgcns.vpa.security;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.core.env.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import com.lgcns.vpa.intent.entity.EntityDictionary;
import com.lgcns.vpa.security.authentication.model.UserDetailsImpl;
import com.lgcns.vpa.security.authentication.util.IpAddressUtils;
import com.lgcns.vpa.security.authentication.util.JWTUtils;
import com.lgcns.vpa.security.user.model.User;
import static com.lgcns.vpa.intent.entity.EntityDictionary.UserContracts;

public class ApiAuthenticationTokenFilter extends GenericFilterBean {

	private static final Logger logger = LoggerFactory.getLogger(ApiAuthenticationTokenFilter.class);
	
	public final String HEADER_SECURITY_TOKEN = "X-Auth-Token"; 
	
	@Autowired
	EntityDictionary entity;
	
	@Autowired
	Environment env;
	
    public ApiAuthenticationTokenFilter(String defaultFilterProcessesUrl) {
    	
    }
	
	private Authentication authUserByToken(String token, String ipaddress, String tenantId) {
        
		// 1. 토큰 유효성 검사
        if (!JWTUtils.validateToken(token, ipaddress)) {
            throw new AuthenticationServiceException("Invalid Authorization Code.");
        }

        // 2. 인증처리
        
        // 2.1. 토큰 디코딩
        String userId = JWTUtils.getSubjectFromToken(token);

        logger.info("===================================================");
        logger.info("authorization_code is valid.");
        logger.info("userId: " + userId);
        logger.info("tenantId: " + tenantId);
        
        logger.info("===================================================");            

        if( StringUtils.isEmpty(userId)) {
        	throw new AuthenticationServiceException("Invalid Authentication.");
        } 
        // 2.2. 인증처리 (Spring Security)
        Map<String, Object> map = entity.findUser(tenantId, userId);
        
        if( map == null || map.isEmpty() ) {
        	throw new AuthenticationServiceException("Invalid Authentication.");
        }
        
        User user = new User();
        user.setUserId(userId);
        user.setTenantId(tenantId);
        user.setUserName((String)map.get(UserContracts.Columns.USER_NAME));
        user.setJobTitleName((String)map.get(UserContracts.Columns.USER_TITLE));
    	user.setAttr1((String)map.get(UserContracts.Columns.CORP_CODE));
        user.setLeader((Integer)map.get(UserContracts.Columns.LEADER));
        
        UserDetailsImpl userDetails = new UserDetailsImpl(user, Arrays.asList(new SimpleGrantedAuthority("ROLE_USER")), tenantId);

        return new UsernamePasswordAuthenticationToken(userDetails, "", userDetails.getAuthorities());
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		final HttpServletRequest httpRequest = (HttpServletRequest)request;
		
		String token = httpRequest.getHeader(HEADER_SECURITY_TOKEN);
        logger.info("token found:"+token);
        if( !StringUtils.isEmpty(token) ) {
	        String ipaddress = IpAddressUtils.getClientIpAddress(httpRequest);
	        logger.info("ipaddress:"+ipaddress);
	        
	        String tenantId = env.getProperty(httpRequest.getServerName());
	        logger.info("tenantId:"+tenantId);
	
	        Authentication authentication = authUserByToken(token, ipaddress, tenantId);
	        
	        if (authentication == null || !authentication.isAuthenticated()) {
	            throw new AuthenticationServiceException("Invalid Authentication.");
	        }
	        
	        // 3. 인증결과 저장
	        SecurityContextHolder.getContext().setAuthentication(authentication);
        }
        chain.doFilter(request, response);
	}
}
