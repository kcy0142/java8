/* 
 * Copyright (C) 2017 LG CNS Inc.
 * All rights reserved.
 *
 * 모든 권한은 LG CNS(http://www.lgcns.com)에 있으며,
 * LG CNS의 허락없이 소스 및 이진형식으로 재배포, 사용하는 행위를 금지합니다.
 */

package com.lgcns.vpa.channel.model.activity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * <pre>
 * 액티비티 첨부 Model
 * </pre>
 * @param
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Attachment implements Serializable {
    
	private static final long serialVersionUID = 4220461820168818968L;
	
    /**
     * Attachment ID
     */
    private String id;
    
    /**
     * 액티비티 ID
     */
    private String activityId;
	
    /**
     * Attachment 유형
	 * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String type = ActivityCode.ATTACHMENT_TYPE_TEMPLATE;

    /**
     * Attachment Template 유형
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String templateType;
    
    /**
     * Attachment 타이틀 (제목)
     */
    private String title;
    
    /**
     * Attachment 텍스트 (본문)
     */
    private String text;

    /**
     * Attachment 설명
     */
    private String descriptions;
        
    /**
     * Attachment 데이터
     */
    private List<Element> elements;
    
	/**
	 * Attachment 헤더 데이터 (테이블 형태에서 사용)
	 */
	private List<Element> headers;
	
    /**
     * Attachment 바디 데이터 (테이블 형태에서 사용)
     */
    private List<List<Element>> bodies;
	
    /**
     * 버튼 리스트
     */
    private List<Button> buttons;
    
    /**
     * 확장 속성
     */
    private Map<String, Object> additionalProperties;

    // 페이징, 네비게이션
    
    /**
     * 페이징 유형
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode
     */
    private String pagingType = ActivityCode.PAGING_TYPE_MORE;
    
    private int listSize = ActivityCode.PAGING_DEFAULT_LIST_SIZE;
    
    private int maxListSize = ActivityCode.PAGING_DEFAULT_MAX_LIST_SIZE;
    
    private int offsetSize = ActivityCode.PAGING_DEFAULT_OFFSET_SIZE;
    
    // 페이지 블럭
    
    /**
     * 블럭 페이징 유형 (플래너 이전/다음 일자, 빈회의실 등)
     */
    private String blockPagingType;
    
    /**
     * 기본 페이지 블럭
     * 예: 일정 20170718
     */
    private String defaultBlock;
    
    /**
     * 기본 페이지 블럭명
     * 예: 일정 2017년 12월 1일
     */
    private String defaultBlockName;
    
    /**
     *  현재 페이지 블럭
     */
    private String currentBlock;
    
    /**
     * 현재 페이지 블럭명
     */
    private String currentBlockName;
    
    /**
     * 페이지 블럭 데이터 유형 (일자: DATE, 시간: HOUR, 숫자: NUMBER)
     * @see com.lgcns.vpa.channel.model.activity.ActivityCode 
     */
    private String blockDataType;
    
    /**
     * 페이지 블럭 데이터 URL (REST)
     */
    private String blockDataUrl;
    
    /**
     * 전체보기(팝업) URL
     * 예: VRB 개최현황
     */
    private String popupUrl;
    
    private int popupWidth;
    
    private int popupHeight;
    
    /**
     * 메모 등 Client 의 Function 을 자동 실행 할 경우 사용하는 함수명 (가급적 사용 지양)
     * 예: memo, organizationTree
     */
    private String function;
    
    /**
     * 멀티미디어 소스
     */
    private String src;
            
    public Attachment() {
    }
    
    public Attachment(String type, List<Element> elements) {
        this.type = type;
        this.elements = elements;
    }
	
	public Attachment(String type, String subType, List<Element> elements) {
		this.type = type;
		this.elements = elements;
	}
	
	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

    public String getTemplateType() {
        return templateType;
    }

    public void setTemplateType(String templateType) {
        this.templateType = templateType;
    }
    
    public String getSubtype() {
        return templateType;
    }

    public void setSubtype(String subtype) {
        this.templateType = subtype;
    }    
    
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(String descriptions) {
        this.descriptions = descriptions;
    }
    
    public String getPagingType() {
        return pagingType;
    }

    public void setPagingType(String pagingType) {
        this.pagingType = pagingType;
    }
    
    public int getListSize() {
        return listSize;
    }

    public void setListSize(int listSize) {
        this.listSize = listSize;
    }

    public int getMaxListSize() {
        return maxListSize;
    }

    public void setMaxListSize(int maxListSize) {
        this.maxListSize = maxListSize;
    }

    public int getOffsetSize() {
        return offsetSize;
    }

    public void setOffsetSize(int offsetSize) {
        this.offsetSize = offsetSize;
    }
    
    public String getBlockPagingType() {
        return blockPagingType;
    }

    public void setBlockPagingType(String blockPagingType) {
        this.blockPagingType = blockPagingType;
    }

    public String getDefaultBlock() {
        return defaultBlock;
    }

    public void setDefaultBlock(String defaultBlock) {
        this.defaultBlock = defaultBlock;
    }

    public String getDefaultBlockName() {
        return defaultBlockName;
    }

    public void setDefaultBlockName(String defaultBlockName) {
        this.defaultBlockName = defaultBlockName;
    }

    public String getCurrentBlock() {
        return currentBlock;
    }

    public void setCurrentBlock(String currentBlock) {
        this.currentBlock = currentBlock;
    }

    public String getCurrentBlockName() {
        return currentBlockName;
    }

    public void setCurrentBlockName(String currentBlockName) {
        this.currentBlockName = currentBlockName;
    }

    public String getBlockDataType() {
        return blockDataType;
    }

    public void setBlockDataType(String blockDataType) {
        this.blockDataType = blockDataType;
    }

    public String getBlockDataUrl() {
        return blockDataUrl;
    }

    public void setBlockDataUrl(String blockDataUrl) {
        this.blockDataUrl = blockDataUrl;
    }

    public String getPopupUrl() {
        return popupUrl;
    }

    public void setPopupUrl(String popupUrl) {
        this.popupUrl = popupUrl;
    }

    public int getPopupWidth() {
        return popupWidth;
    }

    public void setPopupWidth(int popupWidth) {
        this.popupWidth = popupWidth;
    }

    public int getPopupHeight() {
        return popupHeight;
    }

    public void setPopupHeight(int popupHeight) {
        this.popupHeight = popupHeight;
    }
    
    public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}
	
	public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public List<Element> getElements() {
		return elements;
	}

	public void setElements(List<Element> elements) {
		this.elements = elements;
	}

	public Attachment addElement(Element element) {
		if (this.elements == null) {
			this.elements = new ArrayList<>();
		}
		this.elements.add(element);
		return this;
	}

    public List<Element> getHeaders() {
        return headers;
    }

    public void setHeaders(List<Element> headers) {
        this.headers = headers;
    }

    public Attachment addHeader(Element header) {
        if (this.headers == null) {
            this.headers = new ArrayList<>();
        }
        this.headers.add(header);
        return this;
    }
    
    public List<List<Element>> getBodies() {
        return bodies;
    }

    public void setBodies(List<List<Element>> bodies) {
        this.bodies = bodies;
    }

    public List<Button> getButtons() {
        return buttons;
    }

    public void setButtons(List<Button> buttons) {
        this.buttons = buttons;
    }

    public Attachment addButton(Button button) {
        if (this.buttons == null) {
            this.buttons = new ArrayList<>();
        }
        this.buttons.add(button);
        return this;
    }

	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

	public Attachment addAdditionalProperty(String key, Object value) {
		if (this.additionalProperties == null) {
			this.additionalProperties = new HashMap<>();
		}
		this.additionalProperties.put(key, value);
		return this;
	}
}
