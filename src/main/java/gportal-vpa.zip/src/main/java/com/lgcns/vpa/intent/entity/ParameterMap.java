package com.lgcns.vpa.intent.entity;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.fasterxml.jackson.databind.node.MissingNode;
import com.fasterxml.jackson.databind.node.NumericNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.lgcns.vpa.intent.entity.EntityDictionary.EntityContracts;
import com.lgcns.vpa.intent.exception.DuplicateEntityException;
import com.lgcns.vpa.intent.util.JacksonUtils;

/**
 * 입/출력 파라미터를 담을 개체
 * @author 70399
 *
 */
public class ParameterMap {
	
	/**
	 * 파라미터 경로를 파싱하기 위한 정규식으로 
	 * user.name --> user node의 자식 노드인 name 반환
	 * user[0].name --> user node가 배열인 경우
	 */
	private static final Pattern KEY_PATTERN = Pattern.compile("([a-zA-Z_0-9]+)(?:\\[(\\d+)\\]){0,1}");
	
	/**
	 * ISON FORMAT
	 */
	private static final SimpleDateFormat  DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
	
	/**
	 * 경로는 2depth로 한정함
	 */
	private static final int PATH_DEPTH = 2;
	
	
	/**
	 * 최상위 노드
	 */
	private ObjectNode rootNode;
	
	
	public ParameterMap() {
		
		rootNode = JacksonUtils.createNode();
		
	}
	
	public ParameterMap(ObjectNode rootNode) {
		this.rootNode = rootNode;
	}
	
	/**
	 * json path로 받은 JsonNode를 반환한다.
	 * user.name --> user node의 자식 노드인 name 반환
	 * user[0].name --> user node가 배열인 경우
	 * @param path
	 * @return
	 */
	public JsonNode getNode(String path) {
		Object[] keys = parse(path);
		JsonNode node = rootNode;
		for( int i = 0 ; i < keys.length; i *= 2) {
			if( keys[i + 0] == null ) {
				break;
			}
			node = node.path((String)keys[i + 0]);
			if( node == null ) {
				return MissingNode.getInstance();
			}
			if( node.isArray() ) {
				//배열인데, index를 지정하지 않은 경우, 
				ArrayNode array = (ArrayNode)node;
				if( !StringUtils.isEmpty(keys[i + 1]) ) {
					node = node.get((Integer)keys[i + 1]);
				} else {
					if( array.size() == 1) {
						node = node.get(0);
					} else {
						break;
					}
				}
			} 
			i++;
		}
		
		return node;
	}
	
	public boolean existNode(String parent) {
		JsonNode node = getNode(parent);
		JsonNodeType type = node.getNodeType();
		if(type.equals(JsonNodeType.NULL)||type.equals(JsonNodeType.MISSING)) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * 해당 경로에 JsonNode가 존재하는 지 확인
	 * @param path
	 * @return
	 */
	public boolean existNode(String parent, String child) {
		JsonNode node = getNode(parent);
		JsonNodeType type = node.getNodeType();
		if(type.equals(JsonNodeType.NULL)||type.equals(JsonNodeType.MISSING)) {
			return false;
		}
		
		if( StringUtils.isEmpty(child) ) {
			return true;
		}
		
		if( node.isArray() ) {
			ArrayNode array = (ArrayNode)node;
			return array.get(0).has(child);
		} else {
			return node.has(child);
		}
	}
	
	public List<String> getList(String path) {
		
		if( StringUtils.isEmpty(path) ) {
			return null;
		}
		
		List<String> list = new ArrayList<>();
		JsonNode node = getNode(path);
		
		if( !node.isArray() ) {
			list.add(JacksonUtils.getString(node));
		} else {
			ArrayNode array = (ArrayNode)node;
			for(int i = 0; i < array.size(); i++ ) {
				list.add(JacksonUtils.getString(array.get(i)));
			}
		}
		
		return list;
		
	}
	/**
	 * 해당 경로의 JsonNode의 문자열 값을 반환한다.
	 * @param path
	 * @return
	 */
	public String getString(String path) {
		
		if( StringUtils.isEmpty(path) ) {
			return null;
		}
		
		JsonNode node = getNode(path);
		
		if(node.isArray()) {
			throw new DuplicateEntityException(path, path + " is duplidate ");
		}

		return JacksonUtils.getString(node);
	}
	
	/**
	 * 해당 경로의 JsonNode의 문자열 값을 반환한다.
	 * 만일 값이 없는 경우, default 값을 반환한다.
	 * @param path
	 * @param defaultValue
	 * @return
	 */
	public String getString(String path, String defaultValue) {
		String result = getString(path);
		if( StringUtils.isEmpty(result) ) {
			return defaultValue;
		}
		
		return result;
	}
	
	public Map<String, Object> getMap(String path) {
		JsonNode node = getNode(path);
		
		JsonNodeType type = node.getNodeType();
		if(type.equals(JsonNodeType.NULL)||type.equals(JsonNodeType.MISSING)) {
			return null;
		}
		
		return JacksonUtils.toMap(node);
	}
	
	public Date getDate(String path) {
		try {
			return new Date(getLong(path));
		}catch(Exception e) {
		}
		return new Date();
	}
	/**
	 * 해당 경로의 숫자값을 반환한다.
	 * @param path
	 * @return
	 */
	public long getLong(String path) {
		JsonNode node = getNode(path);
		if( node.getNodeType() != JsonNodeType.NUMBER) {
			throw new IllegalStateException(path + " value is not long");
		}
		
		NumericNode number = (NumericNode)node;
		return number.asLong();
	}
	
	/**
	 * 해당 경로의 JsonNode가 존재하지 않으면 기본값을 제시한다. 
	 * @param path
	 * @param defaultValue
	 * @return
	 */
	public long getLong(String path, long defaultValue) {
		
		if( getNode(path) == null) {
			return defaultValue;
		}
		
		return getLong(path);
	}
	

	public boolean add(String key, String value) {
		return add(key, new TextNode(value));
	}
	
	/**
	 * 경로에 map으로 들어온 데이터를 추가한다.
	 * @param key
	 * @param map
	 * @return
	 */
	public boolean add(String key, Map<String, Object> map) {
		JsonNode child = JacksonUtils.read(map);
		
		if( child == null ) {
			return false;
		}
		return add(key, child);
	}

	/**
	 * 경로에 JsonNode를 child로 추가한다.
	 * 만일 부모 key가 존재하지 않는 경우, 새로 생성하며, 
	 * 부모가 배열 node라면 add한다.
	 * @param key
	 * @param childNode
	 * @return
	 */
	private boolean add(String key, JsonNode childNode) {
		
		JsonNode parent = rootNode.get(key);
		if( parent == null ) {
			ArrayNode newParent = rootNode.putArray(key);
			newParent.add(childNode);
			return true;
		}
		
		if( parent instanceof ArrayNode) {
			((ArrayNode) parent).add(childNode);
		} else {
			throw new IllegalStateException("key does not array node");
		}
		
		return true;
	}
	
	public int size(String key) {
		JsonNode parent = rootNode.get(key);
		if( parent instanceof ArrayNode) {
			return ((ArrayNode) parent).size();
		} else {
			return 1;
		}
	}
	
	/**
	 * key의 node를 json 문자열로 대체한다.
	 * @param key
	 * @param jsonString
	 * @return
	 */
	public boolean set(String key, String jsonString) {
		JsonNode child = JacksonUtils.read(jsonString);
		if( child == null ) {
			return false;
		}
		return set(key, child);
	}
	
	/**
	 * key의 node를 입력된 map으로 대체한다.
	 * @param key
	 * @param map
	 * @return
	 */
	public boolean set(String key, Map<String, Object> map) {
		JsonNode child = JacksonUtils.read(map);
		if( child == null ) {
			return false;
		}
		return set(key, child);
	}

	/**
	 * key의 node를 입력된 JsonNode로 대체한다.
	 * @param key
	 * @param childNode
	 * @return
	 */
	private boolean set(String key, JsonNode childNode) {
		ObjectNode parent = (ObjectNode)rootNode.get(key);
		if( parent == null ) {
			rootNode.set(key, childNode);
			return true;
		}
		 
		Iterator<Entry<String, JsonNode>> children = childNode.fields();
		while( children.hasNext() ) {
			Entry<String, JsonNode> child = children.next();
			if( parent.has(child.getKey()) ) {
				parent.replace(child.getKey(), child.getValue());
			} else {
				parent.set(child.getKey(), child.getValue());
			}
		}
		
		return true;
	}
	
	/**
	 * key의 노드를 삭제한다.
	 * @param key
	 * @return
	 */
	public boolean remove(String key) {
		JsonNode removed = rootNode.remove(key);
		
		if( removed == null ) {
			return true;
		} else {
			JsonNodeType type = removed.getNodeType();
			return !(type.equals(JsonNodeType.NULL)||type.equals(JsonNodeType.MISSING));
		}
	}
	
	public void setDate(String path, Date value) {
		setString(path, DATE_FORMAT.format(value));
	}
	/**
	 * path가 없는 경우, node를 생성하고, 
	 * path가 있는 경우, node의 값을 변경한다.
	 * @param path
	 * @param value
	 */
	public void setString(String path, String value) {
		Object[] keys = parse(path);
		JsonNode parent;
		String fieldName;
		if( keys[2] != null ) {
			fieldName = (String)keys[2];
			parent = rootNode.path((String)keys[0]);
			
		} else {
			fieldName = path;
			parent = rootNode;
		}
		
		ObjectNode object = null;
        switch(parent.getNodeType()) {
	        case ARRAY :
	        	object = (ObjectNode)parent.get((Integer)keys[1]);
                object.set(fieldName, TextNode.valueOf(value));
	        	break;
	        case MISSING :
	        	parent = rootNode.putObject((String)keys[0]);
	        case OBJECT : 
        		object = (ObjectNode) parent;
                object.set(fieldName, TextNode.valueOf(value));
        		break;
        	default : 
        		rootNode.remove((String)keys[0]);
        		parent = rootNode.putObject((String)keys[0]);
        		object = (ObjectNode) parent;
                object.set(fieldName, TextNode.valueOf(value));
                break;
        }
	}
	
	/**
	 * 입력된 경로를 파싱한 배열을 리턴한다.
	 * node가 배열인 경우를 고려하여 
	 * [[key, index], [key, index]]구조임
	 * @param path
	 * @return
	 */
	public static Object[] parse(String path) {
		
		Matcher matcher = KEY_PATTERN.matcher(path);
		Object[] result = new Object[PATH_DEPTH * 2];

		int i = 0;
		while(matcher.find()) {
			String key = matcher.group(1);
			String idx = matcher.group(2);
			
			if( !StringUtils.isEmpty(key) )
				result[i++] = key;
			else 
				result[i++] = "";
			
			if( !StringUtils.isEmpty(idx) ) {
				result[i++] = Integer.parseInt(idx); 	
			} else {
				result[i++] = "";
			}
		}
		return result;
	}
	
	public static ParamValue getParamValue(String path) {
		return new ParamValue(path);
	}
	
	public String toString() {
		String str = JacksonUtils.toString(rootNode);
		return str != null? str : rootNode.asText();
		
	}
	
	public static class ParamValue {
		public boolean isEntity;
		public String value;
		public String entity;//entity명, entity_index, entity attribute
		public String entity0;//상요
		public String entity_0;
		public String attribute;
		
		public ParamValue(String value) {
			isEntity = value != null && value.startsWith("$");
			
			if( isEntity ) {
				this.value = value.substring(1);
				
				Object[] p 	= ParameterMap.parse(this.value);
				entity 		= (String)p[0];
				entity0  	= p[0] + (StringUtils.isEmpty(p[1])?"":"[" + p[1] + "]");
				entity_0 	= p[0] + "_" + p[1];
				
				attribute = (String)p[2];
			} else {
				this.value = value;
			}
		}
	}
	
}