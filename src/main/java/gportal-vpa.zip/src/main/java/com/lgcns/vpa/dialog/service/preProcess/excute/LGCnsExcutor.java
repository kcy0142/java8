/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : LGCnsExcutor.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */

package com.lgcns.vpa.dialog.service.preProcess.excute;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.lgcns.vpa.base.config.DialogConfig;
import com.lgcns.vpa.base.util.StringUtils;
import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.channel.model.activity.Attachment;
import com.lgcns.vpa.dialog.common.CommonCode;
import com.lgcns.vpa.dialog.model.Action;
import com.lgcns.vpa.dialog.model.InquiryVO;
import com.lgcns.vpa.dialog.service.ActionService;
import com.lgcns.vpa.dialog.service.CommonResponseService;
import com.lgcns.vpa.dialog.service.dialog.VpaDialog;
import com.lgcns.vpa.dialog.util.DialogUtil;
import com.lgcns.vpa.security.user.model.User;

/**
 * <PRE>
 * LG CNS 전처리 로직
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 10. 24.
 */
@Component("LGCnsExcutor")
public class LGCnsExcutor extends PreProcessExcutor {

	@Autowired
	private ApplicationContext context;
	
	@Autowired
	private ActionService actionService;
	
	@Autowired
	private CommonResponseService commonResponeService;
	
	@Autowired
	private DialogConfig dialogConfig;
	
	@Override
	protected Activity preProcess(InquiryVO inquiry) {
		
		//응답용 Activity
		Activity activityResult = null;
		//질의가 요청된 Activity
		Activity activity = inquiry.getRequestActivity();
		//요청된 질의문
		String inquiryData = inquiry.getInquiryData();
		//질의 요청자
		User reqUser = inquiry.getReqUser();
		//TenantId
		String tenantId = inquiry.getTenantId();
		
		String inquiryDataTrim = inquiryData.trim();
		String preSynonymTrim = activity.getPreSynonymMessage().trim();
		
		//질의어 중 $로 시작하는 질의어는 시스템 검색
		if ( preSynonymTrim.startsWith("$") && (preSynonymTrim.length() >= 2) ) {
			String searchSystemMenu = preSynonymTrim.substring(1);
			if ( !StringUtils.isEmpty(searchSystemMenu) ) {
				activityResult = preSearchSystemMenu(activity, reqUser, tenantId, searchSystemMenu.trim());
			}
		}
		//질의어 중 $로 시작하지 않는 질의어는 전처리
		else {
			
			VpaDialog dialog = null;
			
			//Properties 정보에서 전처리 수행할 최대 글자수 정보를 읽어온다.
			String limitCharCount = this.dialogConfig.getDialogInfo(tenantId, "preIntent", "limitCharCount");
			limitCharCount = ( StringUtils.isEmpty(limitCharCount) ) ? "13" : limitCharCount.trim();
			int limitCharCountInt = 0;
			
			try {
				limitCharCountInt = Integer.parseInt(limitCharCount);
			} catch (Exception ex) {
				limitCharCountInt = 13;
			}
					
			if ( StringUtils.isEmpty(inquiryData) || (inquiryDataTrim.length() < 2)) {
				//질의어 수가 적어서 처리하지 않음 메세지 리턴
				activityResult = this.commonResponeService.createTooShortInquiry(inquiry);
			}
			
			//TODO 임시 : 전화, 전화번호로 종료되는 질의어는 limitCharCountInt 자가 초과 되어도 전처리 실행
			//NLU 개체명 식별이 정상화 되면 제거
			else if ( (inquiryDataTrim.length() <= limitCharCountInt) || (inquiryData.endsWith("전화번호")) || (inquiryData.endsWith("전화")) || (inquiryData.endsWith("연락처")) ) {
				//2~13 글자의 질의어는 전 처리 (임직원 검색, Intent Context에 연관 Intent 검색 
				dialog = (VpaDialog) context.getBean("PreIntentDialog");
				activityResult = dialog.action(inquiry, true);
				
				//Context 가 1개인 경우에는 글자수에 관계없이 의도분석 진행 (단 질의어는 대표 질의어로 변경됨)
				//Context 가 1개인 경우에 SmallTalk 이면 바로 응답함
				if ( (activityResult != null) && (CommonCode.PREINQUERY_INTENT_ONLYONE.equals(activityResult.getDialogLog())) ) {
					inquiry.setInquiryData(activityResult.getMessage());
					activityResult = null;
				}
				else {
					// 2글자 미만의 검색어로 전처리에서 결과가 없으면 검색어가 짧다고 Error 메세지 리턴
					if ( (inquiryDataTrim.length() < 2) && (activityResult == null) ) {
						//질의어 수가 적어서 처리하지 않음 메세지 리턴
						activityResult = this.commonResponeService.createTooShortInquiry(inquiry);
					}
				}//if-else 전처리 결과 Context 가 1개 이면
			}//if-else 글자수가 13개 이하이면
			
			//TODO 생일자 시험
			if ( (inquiryDataTrim.endsWith("생일") || inquiryDataTrim.endsWith("생일 조회") ||
				  inquiryDataTrim.endsWith("기념일") || inquiryDataTrim.endsWith("기념일 조회") ||
				  inquiryDataTrim.endsWith("근속기념") || inquiryDataTrim.endsWith("근속기념 조회") || 
				  inquiryDataTrim.endsWith("축하") || inquiryDataTrim.endsWith("축하해")) && (activityResult == null) ) {
				dialog = (VpaDialog) context.getBean("CongratulationDialog");
				activityResult = dialog.action(inquiry, true);
				
				if ( activityResult != null ) {
					activityResult.setSubtype(CommonCode.SUBTYPE_PREINTENT);
				}
			}
			//생일자 시험 End
			
			// 질의어가 "담당자" 또는 "담당" 으로 끝나면
			if ( (inquiryDataTrim.endsWith("담당자") || inquiryDataTrim.endsWith("담당") ) && (activityResult == null) ) {
				int startPos = inquiryDataTrim.lastIndexOf("담당");
				
				//질의어 중 "담당자" 또는 "담당" 앞에 어떤 글씨가 있으면
				if (startPos != 0) {
					
					String searchContactWord = inquiryDataTrim.substring(0, startPos);
					
					if ( !StringUtils.isEmpty(searchContactWord) ) {
						activityResult = preSearchContact (activity, reqUser, tenantId, searchContactWord.trim());
					}
					
				}//if  질의어 중 "담당자" 또는 "담당" 앞에 어떤 글씨가 있으면 
			}//if-else 질의어가 "담당자" 또는 "담당" 으로 끝나면
			
			// 질의어가 "시스템" 또는 "시스템 메뉴" 또는 "시스템 맵" 또는 "시스템맵" 으로 끝나면
			if ( (inquiryDataTrim.endsWith("시스템") || inquiryDataTrim.endsWith("시스템 조회") || inquiryDataTrim.endsWith("시스템조회") ||
				  inquiryDataTrim.endsWith("시스템맵") || inquiryDataTrim.endsWith("시스템 맵") || 
				  inquiryDataTrim.endsWith("시스템메뉴") || inquiryDataTrim.endsWith("시스템 메뉴") ) && (activityResult == null) ) {
				
				int startPos = inquiryDataTrim.lastIndexOf("시스템");
				
				//질의어 중 "시스템" 또는 "시스템 메뉴" 또는 "시스템 맵" 또는 "시스템맵" 으로 끝나면
				if (startPos != 0) {
														
					String searchSystemMenu = inquiryDataTrim.substring(0, startPos);
					
					if ( !StringUtils.isEmpty(searchSystemMenu) ) {
						activityResult = preSearchSystemMenu(activity, reqUser, tenantId, searchSystemMenu.trim());
						
						//결과가 없으면 사용자가 입력한 질의어에서 한번 더 검색
						if ( activityResult == null ) {
							startPos = activity.getPreSynonymMessage().lastIndexOf("시스템");
							searchSystemMenu = activity.getPreSynonymMessage().substring(0, startPos);
							activityResult = preSearchSystemMenu(activity, reqUser, tenantId, searchSystemMenu.trim());
						}
					}
					
				}//if  질의어 중 "시스템" 또는 "시스템 메뉴" 또는 "시스템 맵" 또는 "시스템맵" 앞에 어떤 글씨가 있으면 
			}//if-else 질의어가 "시스템" 또는 "시스템 메뉴" 또는 "시스템 맵" 또는 "시스템맵" 으로 끝나면
			
			//질의어 중 "메뉴" 또는 "메뉴 조회" 또는 "메뉴조회" 로 끝나면
			else if ( (inquiryDataTrim.endsWith("메뉴") || inquiryDataTrim.endsWith("메뉴 조회") || inquiryDataTrim.endsWith("메뉴조회") )
					&& ( !inquiryDataTrim.contains("아침") && !inquiryDataTrim.contains("저녁") && !inquiryDataTrim.contains("회식")  && !inquiryDataTrim.contains("점심") )
					&& (activityResult == null) ) {
				
				int startPos = inquiryDataTrim.lastIndexOf("메뉴");
				
				//질의어 중 "메뉴" 또는 "메뉴 조회" 또는 "메뉴조회" 로 끝나면
				if (startPos != 0) {
														
					String searchSystemMenu = inquiryDataTrim.substring(0, startPos);
					
					if ( !StringUtils.isEmpty(searchSystemMenu) ) {
						activityResult = preSearchSystemMenu(activity, reqUser, tenantId, searchSystemMenu.trim());
						
						//결과가 없으면 사용자가 입력한 질의어에서 한번 더 검색
						if ( activityResult == null ) {
							startPos = activity.getPreSynonymMessage().lastIndexOf("메뉴");
							searchSystemMenu = activity.getPreSynonymMessage().substring(0, startPos);
							activityResult = preSearchSystemMenu(activity, reqUser, tenantId, searchSystemMenu.trim());
						}
					}
					
				}//if  질의어 중 //질의어 중 "메뉴" 또는 "메뉴 조회" 또는 "메뉴조회" 로 끝나면 
			}
			
			// 질의어가 숫자, 전화번호로 이루어 진 경우 결과가 없으면
			// 전화번호 못찾음 안내메세지 리턴
			if ( (activityResult == null) &&
				 (StringUtils.isNumericPattern(inquiry.getInquiryData()) || 
				  StringUtils.isPhonePattern(inquiry.getInquiryData()) ||
				  StringUtils.isMobilePattern(inquiry.getInquiryData())) ) {
				
				activityResult = this.commonResponeService.cannotUnderstandPhoneType(inquiry);
				activityResult.setSubtype(CommonCode.SUBTYPE_PREINTENT);
			}
		}//if-else 질의어가 $로 시작하는지 여부
		
		return activityResult;
	}
	
	/**
	 * 담당자 조회 전처리 로직 구현
	 * @param activity
	 * @param reqUser
	 * @param tenantId
	 * @param searchContactWord
	 * @return
	 */
	private Activity preSearchContact (Activity activity, User reqUser, String tenantId, String searchContactWord) {
		
		//Properties 정보에서 담당자 조회 관련 IntentId 정보를 읽어온다.
		String searchContactIntentId = this.dialogConfig.getDialogInfo(tenantId, "intentId", "searchContact");
		
		if ( StringUtils.isEmpty(searchContactIntentId) ) {
			return  null;
		}
		
		String inquiryData = activity.getMessage().toLowerCase();
		String botId = activity.getBotId();
		String reqActivityId = activity.getId();
		String reqIp = activity.getUserIp();
		String reqDeviceType = activity.getDeviceType();
		String companyCode = reqUser.getAttr1();
		
		//질의에 대한 처리를 담당하는 Object 생성
		InquiryVO inquiry = new InquiryVO(reqUser, inquiryData, reqIp, reqDeviceType);
		inquiry.setRequestActivity(activity);
		inquiry.setInquiryId(reqActivityId);
		inquiry.setCompanyCode( (StringUtils.hasText(companyCode)) ? companyCode : "LG01" );
		inquiry.setTenantId( (StringUtils.hasText(tenantId)) ? tenantId : "lgcns" );
		inquiry.setBotId(botId);
		inquiry.setReqUser(reqUser);
		
		//Intent Parameter 정보 처리, companyCode, title
		Map<String , Object> param = new HashMap<String, Object>();
		param.put("companyCode", inquiry.getCompanyCode());
		param.put("title", searchContactWord);
		
		inquiry.setIntentParam(param);
		
		//Action 정보 처리
		Action action = this.actionService.getActionByIntentId(searchContactIntentId);
		
		if (action == null) {
			return null;
		}
		else {
			//Action 질의문의 개행문자, 탭문자를 공백문자로 치환
			action.setActionUri( DialogUtil.makeActionUriForRun(action.getActionUri()) );
			
			inquiry.setAction(action);
		}
		
		VpaDialog dialog = (VpaDialog) context.getBean("SearchContactDialog");
		Activity activityResult = dialog.action(inquiry, true);
		
		//결과가 없으면 의도분석 처리
		if ( activityResult != null ) {
			
			activityResult.setSubtype(CommonCode.SUBTYPE_PREINTENT);
			List <Attachment> attmList = activityResult.getAttachments();
			
			if (attmList == null) {
				activityResult = null;
			}
			else {
				Attachment attm = attmList.get(0);
				if (attm == null) {
					activityResult = null;
				}
				else {
					if ( (attm.getElements() == null) || (attm.getElements().isEmpty()) ) {
						activityResult = null;
					}
				}
			}
		}//if-else, 담당자 조회 결과 없으면
		
		return activityResult;
	}
	
	/**
	 * 시스템 메뉴 조회 전처리 로직 구현
	 * @param activity
	 * @param reqUser
	 * @param tenantId
	 * @param searchSystemMenu
	 * @return
	 */
	private Activity preSearchSystemMenu (Activity activity, User reqUser, String tenantId, String searchSystemMenu) {
		
		//Properties 정보에서 시스템메뉴 조회 관련 IntentId 정보를 읽어온다.
		String searchSystemMenuId = this.dialogConfig.getDialogInfo(tenantId, "intentId", "searchSystemMenu");
				
		if ( StringUtils.isEmpty(searchSystemMenuId) ) {
			return  null;
		}
		
		String inquiryData = activity.getMessage().toLowerCase();
		String botId = activity.getBotId();
		String reqActivityId = activity.getId();
		String reqIp = activity.getUserIp();
		String reqDeviceType = activity.getDeviceType();
		String companyCode = reqUser.getAttr1();
		
		//질의에 대한 처리를 담당하는 Object 생성
		InquiryVO inquiry = new InquiryVO(reqUser, inquiryData, reqIp, reqDeviceType);
		inquiry.setRequestActivity(activity);
		inquiry.setInquiryId(reqActivityId);
		inquiry.setCompanyCode( (StringUtils.hasText(companyCode)) ? companyCode : "LG01" );
		inquiry.setTenantId( (StringUtils.hasText(tenantId)) ? tenantId : "lgcns" );
		inquiry.setBotId(botId);
		inquiry.setReqUser(reqUser);
		
		//Intent Parameter 정보 처리, companyCode, title
		Map<String , Object> param = new HashMap<String, Object>();
		//param.put("companyCode", inquiry.getCompanyCode());
		param.put("userId", reqUser.getUserId());
		param.put("searchMenu", searchSystemMenu);
		
		inquiry.setIntentParam(param);
		
		//Action 정보 처리
		Action action = this.actionService.getActionByIntentId(searchSystemMenuId);
		
		if (action == null) {
			return null;
		}
		else {
			//Action 질의문의 개행문자, 탭문자를 공백문자로 치환
			action.setActionUri( DialogUtil.makeActionUriForRun(action.getActionUri()) );
			
			inquiry.setAction(action);
		}
		
		VpaDialog dialog = (VpaDialog) context.getBean(action.getActionDialogName());
		Activity activityResult = dialog.action(inquiry, true);
		
		//결과가 없으면 의도분석 처리
		if ( activityResult != null ) {
			
			activityResult.setSubtype(CommonCode.SUBTYPE_PREINTENT);
			List <Attachment> attmList = activityResult.getAttachments();
			
			if (attmList == null) {
				activityResult = null;
			}
			else {
				Attachment attm = attmList.get(0);
				if (attm == null) {
					activityResult = null;
				}
				else {
					if ( (attm.getElements() == null) || (attm.getElements().isEmpty()) ) {
						activityResult = null;
					}
				}
			}
		}//if-else, 시스템메뉴 조회 결과 없으면
		
		return activityResult;
	}

}
