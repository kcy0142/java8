/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : LgeFaqDialog.java
 * Author        : 김가원
 * Copyright 2017 LG CNS All rights reserved
 * ------------------------------------------------------------------------------ */
package com.lgcns.vpa.dialog.service.dialog;

import org.springframework.stereotype.Component;

import com.lgcns.vpa.channel.model.activity.Activity;
import com.lgcns.vpa.dialog.model.InquiryVO;

/**
 * <PRE>
 * LGE Faq REST 응답 처리를 위한 Dialog
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 5. 31.
 */
@Component("LgeFaqDialog")
public class LgeFaqDialog extends VpaDialog {

	@Override
	protected boolean validator(InquiryVO data) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected boolean hasActionRight(InquiryVO data) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected String processor(InquiryVO data) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Activity afterWork(InquiryVO data, String procData) {
		// TODO Auto-generated method stub
		return null;
	}

}
