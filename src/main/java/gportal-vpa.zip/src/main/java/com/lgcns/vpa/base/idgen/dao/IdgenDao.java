/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : IdgenDao.java
 * Author        : hyeom
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

package com.lgcns.vpa.base.idgen.dao;

import org.apache.ibatis.annotations.Mapper;

/**
 * <PRE>
 * ID 생성 DAO
 * </PRE>
 * 
 * @author 김가원
 * @version v1.0 2017. 11. 28.
 */
@Mapper
public interface IdgenDao {

	public String getNextId() ;
}
