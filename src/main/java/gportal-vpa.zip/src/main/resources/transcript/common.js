var NULL = new Object();

function _location(place, flow) {
	//print(place + ' ' + flow);
	this.place = place;
	this.flow = flow;
}

function _day(param, y,m,d) {
	print('_day : ' + param);
	
	var day;
	if( param ) {
		day = new Date(param.value);
	} else {
		day = new Date();
	}
	
	if( y ) 
		day.setFullYear(y);
	
	if( m )
		day.setMonth(m - 1);
	
	if( d )
		day.setDate(d);
	
	return day.getTime();
	
}

function _nextDay(y, m, d) {
	
	print('_nextDay ' + y + " " + m + " " + d);

	var day = new Date();
	
	day.setFullYear(day.getFullYear() + y);
	
	day.setMonth(day.getMonth() + m);
	
	day.setDate(day.getDate() + d);
	
	return day.getTime();
}
//붙이기
function concat(func, delim, arg1, arg2, arg3) {
	var result = '';
	if( arg1 ) {
		result += arg1 + delim;
	}
	if( arg2 ) {
		result += arg2 + delim;
	}
	if( arg3 ) {
		result += arg3 + delim;
	}
	return result.substr(0, result.length - delim.length);
}
//메일 ID추출
function getMailId(func, email) {
	return email.substring(0, email.lastIndexOf("@"));
}

function getFirstName(func, name) {
	if( /[ㄱ-ㅎㅏ-ㅣ가-힣]+\s*/g.test(name) ) { 
		return name.substr(0,1);
	}else { 
		var array = name.match(/\w+\s*/g);
		return array[array.length-1]; 
	} 
}

function toLocaleDateString(func, dateStr, locale) {
	if( locale == undefined ) {
		locale = 'ko-KR';
	}
	switch( locale ) {
	case 'ko-KR' :
		return dateStr.replace(/(\d{4})(\d{2})(\d{2})/g, '$1년 $2월 $3일');
	case 'en-US' :
		return dateStr.replace(/(\d{4})(\d{2})(\d{2})/g, '$2/$3/$1');
	default : 
		return dateStr.replace(/(\d{4})(\d{2})(\d{2})/g, '$1/$2/$3');
	}
}

function toLocaleDateTimeString(func, dateStr, locale) {
	if( locale == undefined ) {
		locale = 'ko-KR';
	}
	
	
	var today = new Date();
	
	var hours = today.getHours() + 0;
	var minte = today.getMinutes();
	var ampm;
	switch( locale ) {
	case 'ko-KR' :
		var ampm = hours >=12 ? '오후' : '오전';
		break;
	default :
		var ampm = hours >=12 ? 'PM' : 'AM';
		break;
	}
	
	hours = hours % 12;
	hours = hours ? hours : 12;
	minte = minte < 10 ? '0' + minte : minte;
	
	var dar = /(\d{4})(\d{2})(\d{2})/g.exec(dateStr);
	
	switch( locale ) {
	case 'ko-KR' :
		return dar[1] + '년 ' + dar[2] + '월 ' + dar[3] + '일 ' + ampm + ' ' + hours + '시 ' + minte + '분'; 
	case 'en-US' :
		return dar[2] + '/' + dar[3] + '/' + dar[1] + ampm + ' ' + hours + '시 ' + minte + '분'; 
	default : 
		return dar[1] + '/' + dar[2] + '/' + dar[3] + ampm + ' ' + hours + '시 ' + minte + '분'; 
	}
}