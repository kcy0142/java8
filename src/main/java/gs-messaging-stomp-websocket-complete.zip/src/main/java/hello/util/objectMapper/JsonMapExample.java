/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : JsonMapExample.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

/**
 * <PRE>
 * test
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 9. 22.
 */
package hello.util.objectMapper;
 
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class JsonMapExample {

	public static void main(String[] args) {

		try {

			ObjectMapper mapper = new ObjectMapper();
			String json = "{\"name\":\"mkyong\", \"age\":29}";

			Map<String, Object> map = new HashMap<String, Object>();

			// convert JSON string to Map
			map = mapper.readValue(json, new TypeReference<Map<String, String>>(){});

			System.out.println(map);
			//{name=mkyong, age=29}

		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}