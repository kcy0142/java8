
package hello.util.objectMapper;
 

public class readMe {

	
	public static void main(String[] args) {
		
		1.

		 /*
				 {
				  "data": {
					"translations": [
					  {
						"translatedText": "Hello"
					  }
					]
				  }
				}
				*/
				 System.out.println("######json jsonNode1:"+ jsonNode.get("data"));
				 System.out.println("######json jsonNode1 translatedText:"+ jsonNode.findValuesAsText("translatedText").get(0));
				activityResult.setMessage(jsonNode.findValuesAsText("translatedText").get(0));
		2.		
		 List<Activity> activityList = mongoTemplate.find(findQuery.limit(this.validateLimitCount(limit)), Activity.class, "activities");

		        activityList.stream().filter(activity-> "push".equals(activity.getSubtype())).forEach(action->{

		===================================================================
		WebsocketController

		// 1. Message Broadcast
		// 용도 1: 사용자가 전송한 메시지의 실제 물리 ID를 할당한 후 리턴한다.
		// 용도 2: 사용자가 복수의 클라이언트에서 접속한 경우 사용자가 입력한 메시지를 해당 사용자의 전체 채널에 브로드캐스팅
		messagingTemplate.setMessageConverter(new MappingJackson2MessageConverter());
		messagingTemplate.convertAndSendToUser(principal.getName(), "/topic/chat.messages", activityRequest);

		String pushId="120000080014";
		PushConfig pushUserConfig = configService.retrievePushConfig(pushId, this.getUser().getUserId());
		System.out.println("#######pushUserConfig.getUseYn():"+pushUserConfig.getUseYn());

		Activity activityResponse =null;
		if(pushUserConfig.getUseYn().equals("Y")){
			 // 2. Dialog Handler 호출
			// VPA 업무 처리 : 응답생성기를 통과한 결과를 리턴 받는다.
			 activityResponse = dialogHandlerService.syncInquiryTrans(activityRequest, getSessionUser(), getTenantId());
		}else{
			 // 2. Dialog Handler 호출
			// VPA 업무 처리 : 응답생성기를 통과한 결과를 리턴 받는다.
			 activityResponse = dialogHandlerService.syncInquiry(activityRequest, getSessionUser(), getTenantId());
			
		}


		============================================================================================================

		/**
			 * 동기식 질의문 처리
			 * 	- activity.getType();		//액티비티 유형 (message: 메시지, notification: 알림, sent-message-response, ping-pong... )
			 *	- activity.getSubtype(); 	//액티비티 Sub 유형 (search, app 등)
			 *	- activity.getText();		//메시지
			 *	- activity.getSenderId();	//액티비티 발신자
			 *  - activity.getReceiverId(); //BotId
			 * @param activity
			 * @param user
			 * @param tenantId
			 * @return
			 */
			public Activity syncInquiryTrans (Activity activity, User reqUser, String tenantId) {
				
				if ( reqUser == null ) {
					LOG.info("syncInquiryTrans() start : reqUser:[null],tenantId:["+tenantId+"],activity:["+JsonUtil.toJson(activity)+"]");
				}
				else {
					LOG.info("syncInquiryTrans() start : reqUser:["+reqUser.getUserId()+"],tenantId:["+tenantId+"],activity:["+JsonUtil.toJson(activity)+"]");
				}
				
				if ( (activity == null) || (!StringUtils.hasText(activity.getMessage())) ) {
					return this.commonResponeService.cannotUnderstand(activity);
				}
				
				long startTime = System.currentTimeMillis();
				long spentTiemPreIntent = 0L;
				
				// DataSourceKey Setting
				DataSourceKeyHolder.setDataSourceKey(tenantId);
				
				//Dialog Object
				VpaDialog dialog = null;
				Activity activityResult = null;
				
				activityResult = Activity.createBotMessage(activity.getBotId(),reqUser.getUserId());
				//불용어 처리된 데이터 인지 표시 (좋아요/싫어요 버튼의 추가 여부 결정)
				boolean isStopWordAction = false;
						
				String activityType = (StringUtils.hasText(activity.getType())) ? activity.getType() : CommonCode.ACTIVITY_TYPE_MESSAGE;
				//String activitySubType = (StringUtils.hasText(activity.getSubtype())) ? activity.getSubtype() : CommonCode.ACTIVITY_SUBTYPE_BASIC;
				String reqUserId = reqUser.getUserId();
				String botId = activity.getBotId();
				String reqActivityId = activity.getId();
				String reqIp = activity.getUserIp();
				String reqDeviceType = activity.getDeviceType();
				String companyCode = reqUser.getAttr1();
				
				//유의어 치환 전 메세지를 저장함
				activity.setPreSynonymMessage(activity.getMessage());
				
				//trans start
				String key="AIzaSyBd0yTCA0_p6fChOWO04M98SqA_fgdV9LU";
				String source="ko";
				String target="en";
				String q=activity.getMessage();
				RestTemplate restTemplate = new RestTemplate();
				
				String param="?key="+key+"&source="+source+"&target="+target+"&q="+q;
				String paramDetect="?key="+key+"&q="+q;
				String fooResourceUrl  = "https://translation.googleapis.com/language/translate/v2/"+param;
				String fooResourceDetectUrl  = "https://translation.googleapis.com/language/translate/v2/detect"+paramDetect;
				String url  = "https://translation.googleapis.com/language/translate/v2?key=AIzaSyBd0yTCA0_p6fChOWO04M98SqA_fgdV9LU&source=ko&target=en&q=안녕";
				ResponseEntity<String> response  = restTemplate.getForEntity(fooResourceUrl , String.class);
				
				String json   = restTemplate.getForObject(fooResourceUrl , String.class);
				//String json   = restTemplate.getForObject(fooResourceDetectUrl , String.class);
				
				Map<String,String> map = new HashMap<String,String>();
				ObjectMapper mapper = new ObjectMapper();
				JsonNode jsonNode=null;
				
				System.out.println("######json:"+json);
				 try {
					  jsonNode= mapper.readTree(json);  
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 
				 
				 /*
				 {
				  "data": {
					"translations": [
					  {
						"translatedText": "Hello"
					  }
					]
				  }
				}
				*/
				 System.out.println("######json jsonNode1:"+ jsonNode.get("data"));
				 System.out.println("######json jsonNode1 translatedText:"+ jsonNode.findValuesAsText("translatedText").get(0));
				activityResult.setMessage(jsonNode.findValuesAsText("translatedText").get(0));
				//trans end
				//유의어 치환 전 특수문자 제거
				String inquiryData = activity.getMessage();
				inquiryData = (inquiryData == null) ? "" : inquiryData;
				
			
						
				//질의문의 유의어를 치환함,  모든 질의문중 영문은 소문자로 치환함
				inquiryData = synonymService.convertToSynonym(inquiryData.toLowerCase(), botId);
				activity.setMessage(inquiryData.toLowerCase());
				
				//질의에 대한 처리를 담당하는 Object 생성
				InquiryVO inquiry = new InquiryVO(reqUser, inquiryData, reqIp, reqDeviceType);
				inquiry.setRequestActivity(activity);
				//inquiry.setInquiryId(UUID.randomUUID().toString().replace("-", ""));
				inquiry.setInquiryId(reqActivityId);
				inquiry.setCompanyCode( (StringUtils.hasText(companyCode)) ? companyCode : "LG01" );
				inquiry.setTenantId( (StringUtils.hasText(tenantId)) ? tenantId : "lgcns" );
				inquiry.setBotId(botId);
				inquiry.setReqUser(reqUser);
				
				//Action Param 처리 (직전 요청이 SLOT FILLING, Parameter 중복이었을 경우)
				inquiry.setReqActionParams(activity.getActionParams());
				
			
				activityResult.setIntentLog(inquiry.getIntentLog());
				activityResult.setIntentId(inquiry.getIntentId());  //좋아요/싫어요 intent벌로 파악하기 위해
				activityResult.setIntentId("INTf8955583ed2a42b0990906b83afcdbaa");  //좋아요/싫어요 intent벌로 파악하기 위해
				activityResult.setIntentType(inquiry.getIntentType());
				
				
				activityResult.setBotId(botId);
				
				activityResult.setReplyToId(reqActivityId);
				
				
				
				//좋아요/싫어요 버튼 추가, 불용어 처리를 제외하고 모든 응답에 추가함
				if ( !isStopWordAction && (activityResult != null) ) {
					List<Button> newButtons = this.addLikeButton(activityResult.getButtons());
					if (newButtons != null) {
						activityResult.setButtons(newButtons);
					}
				}
				
				long spentTime = System.currentTimeMillis()-startTime;
				if ( activityResult != null ) {
					activityResult.setSpentTime(spentTime);
					activityResult.setSpentTimeIntent(inquiry.getSpentTimeIntent());
					activityResult.setSpentTimeProxy(inquiry.getSpentTimeProxy());
					activityResult.setSpentTimePreIntent(spentTiemPreIntent);
					
					//사용자 질의 중 유의어 치환 전 메세지 처리
					activityResult.setPreSynonymMessage(activity.getPreSynonymMessage());
					
					//사용자 질의 중 유의어 치환 된 메세지 처리
					activityResult.setRequestMessage(inquiry.getInquiryData());
					
				
				}
				LOG.info("syncInquiry() FINISHED inquiryId:["+inquiry.getInquiryId()+"],소요시간:["+(spentTime)+"ms],ACTIVITY JSON=======" + JsonUtil.toJson(activityResult)+"=======");
				
				return activityResult;
			}//syncInquiry end
			
			
			
			
			
			
			
			=======================================================================
			
			79273

		120000080014


		https://translation.googleapis.com/language/translate/v2/detect?key=AIzaSyBd0yTCA0_p6fChOWO04M98SqA_fgdV9LU&q=%EC%95%88%EB%85%95


		  /**
		     * 사용자의 알림 설정 조회
		     * @param botId
		     * @param userId
		     * @param pushTypeCode
		     * @return
		     */
		    @Override
		    public PushConfig retrievePushConfig(String pushId, String userId) {
		        return configDao.selectPushConfig(pushId, userId);
		    }


			
			  @Autowired
		    private ConfigService configService;
			

		PushConfig pushUserConfig = configService.retrievePushConfig(pushConfig.getPushId(), userId);
				
				if(pushUserConfig.getUseYn().equals("Y")){
					Activity activity = createPushActivity(botId, userId, pushUserConfig.getLocaleCode(), message);
					
					Attachment attachment = new Attachment();
					
					
			
		9:21:32.125 INFO  jdbc.resultsettable - 
		|-------------|--------|-------------|--------------|------------------|-------|---------------|---------------|----------------------------------|----------------------------------|-----------|------------------------|------------|-------------------------------------|----------|------------|------------|--------------|----------------------|-----------|-------------|----------------------|
		|bot_id       |user_id |push_id      |push_name     |push_english_name |use_yn |default_use_yn |push_type_code |display_description               |display_english_description       |display_yn |description             |system_code |worker_name                          |action_id |action_name |register_id |register_name |regist_date           |updater_id |updater_name |update_date           |
		|-------------|--------|-------------|--------------|------------------|-------|---------------|---------------|----------------------------------|----------------------------------|-----------|------------------------|------------|-------------------------------------|----------|------------|------------|--------------|----------------------|-----------|-------------|----------------------|
		|120000080013 |79273   |120000080014 |오늘의 날씨        |Weather           |N      |Y              |DAILY          |OfficePlus Blog에 등록된 근무지 기준 현재 날씨 |OfficePlus Blog에 등록된 근무지 기준 현재 날씨 |Y          |오늘의 날씨                  |VA          |multi.weatherDailyPushService        |[null]    |[null]      |79273       |최승백           |2018-01-08 09:20:56.0 |79273      |최승백          |2018-01-08 09:20:56.0 |
		|120000080013 |79273   |120000080015 |축하합니다         |Congratulation    |Y      |Y              |DAILY          |생일, 결혼기념일, 장기근속 소식 알림             |생일, 결혼기념일, 장기근속 소식 알림             |Y          |지인들의 생일, 결혼기념일, 진급소식 알림 |VA          |multi.congratulationDailyPushService |[null]    |[null]      |79273       |최승백           |2018-01-08 09:20:56.0 |79273      |최승백          |2018-01-08 09:20:56.0 |
		|120000080013 |79273   |120000080016 |오늘 일정 조회      |Schedules         |Y      |Y              |DAILY          |오늘의 전체 일정 리스트                     |오늘의 전체 일정 리스트                     |Y          |오늘 일정 조회                |EP          |multi.plannerDailyPushService        |[null]    |[null]      |79273       |최승백           |2018-01-08 09:20:56.0 |79273      |최승백          |2018-01-08 09:20:56.0 |
		|12000008001

		==========================
		package com.messenger.translation.web;

		import java.util.HashMap;
		import java.util.Map;

		import org.slf4j.Logger;
		import org.slf4j.LoggerFactory;
		import org.springframework.http.ResponseEntity;
		import org.springframework.stereotype.Controller;
		import org.springframework.util.StringUtils;
		import org.springframework.web.bind.annotation.RequestMapping;
		import org.springframework.web.bind.annotation.RequestParam;
		import org.springframework.web.bind.annotation.ResponseBody;
		import org.springframework.web.client.RestTemplate;

		import com.fasterxml.jackson.databind.ObjectMapper;




		@Controller

		public class TransController {

			private static final Logger LOG = LoggerFactory.getLogger(TransController.class);
			
			@RequestMapping("/translation.do")
			@ResponseBody
			public String commentList1 (@RequestParam(name="key", required=false) String key,
					@RequestParam(name="source", required=false) String source,
					@RequestParam(name="userID", required=false) String userID,
					@RequestParam(name="userIP", required=false) String userIP,
					@RequestParam(name="target", required=false) String target,
					@RequestParam(name="q", required=false) String q)  {
				
			
				//http://localhost:8080/translation.do??key=AIzaSyBd0yTCA0_p6fChOWO04M98SqA_fgdV9LU&source=ko&target=en&q=%EB%A1%9C%EB%B4%87et=en&q=안녕
				RestTemplate restTemplate = new RestTemplate();
//				
//				if(StringUtils.isEmpty(key)){
//					key="AIzaSyBd0yTCA0_p6fChOWO04M98SqA_fgdV9LU";
//				}
				if(StringUtils.isEmpty(source)){
					source="ko";
				}
				if(StringUtils.isEmpty(target)){
					target="en";
				}
				if(StringUtils.isEmpty(q)){
					q="안녕";
				}
				
				//System.out.println("###TRANS PARAM===> userID:"+userID+",userIP:"+userIP+",key:"+key+",source:"+source+",target:"+target+",q:"+q);
				
				//http://10.64.151.198:8080/translation.do??key=AIzaSyBd0yTCA0_p6fChOWO04M98SqA_fgdV9LU&source=ko&target=en&q=%EB%A1%9C%EB%B4%87
				//http://localhost:8080/translation.do??key=AIzaSyBd0yTCA0_p6fChOWO04M98SqA_fgdV9LU&source=ko&target=en&q=%EB%A1%9C%EB%B4%87
				
				String param="?key="+key+"&source="+source+"&target="+target+"&q="+q;
				String fooResourceUrl  = "https://translation.googleapis.com/language/translate/v2/"+param;
				String url  = "https://translation.googleapis.com/language/translate/v2?key=AIzaSyBd0yTCA0_p6fChOWO04M98SqA_fgdV9LU&source=ko&target=en&q=안녕";
				ResponseEntity<String> response  = restTemplate.getForEntity(fooResourceUrl , String.class);
				
				String json   = restTemplate.getForObject(fooResourceUrl , String.class);
				
				Map<String,String> map = new HashMap<String,String>();
				ObjectMapper mapper = new ObjectMapper();
				
				LOG.info("###TRANS PARAM===> userID:"+userID+",userIP:"+userIP+",key:"+key+",source:"+source+",target:"+target+",q:"+q+",result:"+json);

				
				return json;
			}
			

		}


		{
		  "data": {
		    "translations": [
		      {
		        "translatedText": "Hello"
		      }
		    ]
		  }
		}
		========================================================================


			

			
			 @Override
		    public   List<Activity> getRedisAllSessionTest( String botId) {
		    	List<Activity> activities = new ArrayList<>();
		    	//StringBuilder msg = new StringBuilder();
		    	Query query = new Query();
				
		    	Conversation conversatoin=new Conversation();
		    	
		    	Calendar start = new GregorianCalendar();
		    	start.add(Calendar.DATE, -1);
		    	start.set(Calendar.HOUR_OF_DAY, 0); 
		    	start.set(Calendar.MINUTE, 0);
		    	start.set(Calendar.SECOND, 0);

		    	Calendar end = new GregorianCalendar();
		    	end.add(Calendar.DATE, -1);
		    	end.set(Calendar.HOUR_OF_DAY, 23); 
		    	end.set(Calendar.MINUTE, 59);
		    	end.set(Calendar.SECOND, 59);
		    	
		    	conversatoin.setEnterDate(start.getTime());
		    	conversatoin.setDailyPushDate(end.getTime());
		    	
				query.addCriteria(Criteria.where("enterDate").gte(conversatoin.getEnterDate()).lte(conversatoin.getDailyPushDate()));
				
				
				//msg.append("################# start tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MIN)+", end tme:"+LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.MAX)+"\n");
						
				query.fields()
				.include("userId");
				
				List<String> conversationList =mongoTemplate.find(query, String.class,"conversations");
				ObjectMapper objectMapper = new ObjectMapper();
				
				JsonNode jsonNode = null ;
				HashOperations<String, String, Object> hashOper = redisTemplate.opsForHash();
				
				//msg.append("################# conversationList.size():"+conversationList.size()+"\n");
				
				List<String> listOfUser = new ArrayList<String>();
				
				
				int cnt=0;
				int no=0;
				for(String userInfo : conversationList){
					Activity activity =new Activity();
					no=no+1;
					try {
						jsonNode = objectMapper.readTree(userInfo);
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					String userId = jsonNode.get("userId").asText();
					listOfUser.add(userId);
					
					// 웹소켓 연결정보를 REDIS에서 삭제한다.
					String key = String.format("webscoket:%s", userId);
					String message="";
					 
					String webSocketSessionId = (String)redisTemplate.opsForHash().get(key, "webSocketSessionId");
					String sessionId = (String)redisTemplate.opsForHash().get(key, "sessionId");

					
						
					String webSocketSessionIdKey = String.format("webscoketsession:%s", webSocketSessionId);
					String sessionIdKey = String.format("spring:session:sessions:%s", sessionId);
						 
						 
					if( redisTemplate.hasKey(sessionIdKey) ) {
						message="session is expired";
					 	cnt=cnt+1;
					}else{
						message="session has no existed";
					}
					activity.setUserId(userId);
					activity.setMessage("################# No:"+no+",userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+",msg:"+message);
				    activities.add(activity);
					//msg.append("################# No:"+no+",userId:"+userId+",webSocketSessionId:"+webSocketSessionId+",sessionId:"+sessionId+",msg:"+msg+"\n");
					 
				}
				
				//msg.append("######## session expired count:"+cnt+"\n");
				
		    	//return msg.toString();
		    	return activities;
		    	
		    }
			
			============================================
			    List<Activity> activityList = mongoTemplate.find(findQuery.limit(this.validateLimitCount(limit)), Activity.class, "activities");

		        activityList.stream().filter(activity-> "push".equals(activity.getSubtype())).forEach(action->{
		        	
		        	//System.out.println("######action.getId():"+action.getId());
		        	//System.out.println("######action.getBotId():"+action.getBotId());
		        	//System.out.println("######action.getUserId():"+action.getUserId());
		        	//이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다.2018.01.09
		        	//james
		        	
		        	//System.out.println("###########################이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다##########################");
		        	Query findPushQuery = new Query();
		        	Criteria criteriaPush = Criteria.where("userId").is(action.getUserId());
		        	criteriaPush.and("subtype").is("push");
		        	criteriaPush.and("readDate").exists(false);
		        	criteriaPush.and("_id").is(new ObjectId(action.getId()));
		        	

		        	findPushQuery.addCriteria(criteriaPush);

		        	Update update = new Update();
		        	update.set("readDate", new Date());
		        	mongoTemplate.updateFirst(findPushQuery, update, Activity.class, "activities");
		        	//이전대화 이력중에 push메시지가 있으면 그건 읽음 처리한다.2018.01.09
		        	
		        });
	}

	
}

