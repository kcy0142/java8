
package hello.objectMapper;

import java.io.IOException;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonFactory;

import com.fasterxml.jackson.core.JsonGenerator;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;

import com.fasterxml.jackson.databind.JsonNode;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class testJacksonJSON {

	/**
	 * 
	 * @param args
	 * 
	 */

	static class NodeLinks

	{
		private Nodes nodes[];
		private Links links[];

		public static final class Nodes

		{
			private String name, group;

			public String getGroup() {
				return group;
			}

			public void setGroup(String group) {
				this.group = group;
			}

			public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}

			@Override

			public String toString()

			{

				StringBuilder stbuld = new StringBuilder("Nodes : \n");

				stbuld.append("name :" + name)

						.append("\t").append("group :").append(group).append("\n");

				return stbuld.toString();

			}

		}

		public static final class Links

		{
			private String source, target, value;

			public String getSource() {

				return source;

			}

			public void setSource(String source) {

				this.source = source;

			}

			public String getTarget() {

				return target;

			}

			public void setTarget(String target) {

				this.target = target;

			}

			public String getValue() {

				return value;

			}

			public void setValue(String value) {

				this.value = value;

			}

			@Override

			public String toString()

			{

				StringBuilder stbuld = new StringBuilder("Links : \n");

				stbuld.append("source :" + source)

						.append("\t").append("target :").append(target)

						.append("\t").append("value :").append(value).append("\n");

				return stbuld.toString();

			}

		}

		public Nodes[] getNodes() {

			return nodes;

		}

		public void setNodes(Nodes nodes[]) {

			this.nodes = nodes;

		}

		public Links[] getLinks() {

			return links;

		}

		public void setLinks(Links links[]) {

			this.links = links;

		}

	}

	public static void main(String[] args) {

		try {

			ObjectMapper mapper = new ObjectMapper(); // 재사용 가능하고 전체코드에서 공유함.

			String user_json = "{\"name\" : { \"first\" : \"Joe\", \"last\" : \"Sixpack\" }, "

					+ " \"gender\" : \"MALE\", "

					+ " \"verified\" : false, "

					+ " \"userImage\" : \"Rm9vYmFyIQ==\" " + "      } ";

			User user = mapper.readValue(user_json, User.class);

			System.out.println("First name : " + user.getName().getFirst());

			System.out.println("Last name : " + user.getName().getLast());

			System.out.println("Gender : " + user.getGender());

			System.out.println("Verified : " + user.isVerified());

			user.getName().setFirst("ChangeJoe");

			user.getName().setLast("ChangeSixpack");

			String jsonStr = mapper.writeValueAsString(user);

			System.out.println("Simple Binding : " + jsonStr);
			 System.out.println("====차기 UPDATE========");
			// 직접 raw 데이터를 입력해서 JSON형태로 출력하는 방법.

			Map<String, Object> userData = new HashMap<String, Object>();

			Map<String, String> nameStruct = new HashMap<String, String>();

			nameStruct.put("first", "RawJoe");

			nameStruct.put("last", "Sixpack");

			userData.put("name", nameStruct);

			userData.put("gender", "MALE");

			userData.put("verified", Boolean.FALSE);

			userData.put("userImage", "Rm9vYmFyIQ==");

			jsonStr = mapper.writeValueAsString(userData);

			System.out.println("Raw Data : " + jsonStr);
			 System.out.println("====차기 UPDATE========");
			// Tree 모델 예제

			ObjectMapper m = new ObjectMapper();

			// mapper.readTree(source), mapper.readValue(source,
			// JsonNode.class); 둘중 하나 사용가능.

			JsonNode rootNode = m.readTree(user_json);

			JsonNode nameNode = rootNode.path("name");

			String lastName = nameNode.path("last").textValue();

			((ObjectNode) nameNode).put("last", "inputLast");

			jsonStr = m.writeValueAsString(rootNode);

			System.out.println("Tree Model : " + jsonStr);

			
			 System.out.println("====차기 UPDATE========");
			
			ObjectMapper mapperaa = new ObjectMapper();
			  
	         HashMap<String, String> map = new HashMap<String, String>();
	         map.put("name", "steave");
	         map.put("age", "32");
	         map.put("job", "baker");
	  
	         String tester=mapperaa.writeValueAsString(map);
	         System.out.println(map);
	         System.out.println("tester:"+tester);
	         System.out.println(mapper.writeValueAsString(map));
	         
	         
	         System.out.println("============");
	           
	         Map<Integer, String> map1 = new HashMap<>();
	         map1.put(1, "foo");
	         map1.put(2, "bar");
	         map1.put(3, "baz");
	         String result = map1.entrySet()
	             .stream()
	             .map(entry -> entry.getKey() + " - " + entry.getValue())
	             .collect(Collectors.joining(", "));
	         System.out.println(result);
	         
	         System.out.println("============");
	         
	         ObjectMapper mapper2 = new ObjectMapper();
	         String json = "{ \"color\" : \"Black\", \"type\" : \"FIAT\" }";
	         JsonNode jsonNode= mapper2.readTree(json);
	         String color = jsonNode.get("color").asText();
	         // Output: color -> Black
	         
	         System.out.println("color:"+color);
	         
	         System.out.println("============");
	         
	         String json1 = "{ \"color\" : \"Black\", \"type\" : \"BMW\" }";
	         Map<String, Object> map3 =  mapper.readValue(json1, new TypeReference<Map<String,Object>>(){});
	         System.out.println("color1:"+map3.get("color")  );
	         
	         System.out.println("============");
	         ObjectMapper mappera = new ObjectMapper();
	         HashMap<String, String> mapa = new HashMap<String, String>();
	  
	         String jsn = "{\"age\":\"32\",\"name\":\"steave\",\"job\":\"baker\"}";
	         
	         mapa = mappera.readValue(jsn,new TypeReference<HashMap<String, String>>() {});        
	         
	         System.out.println(mapa.get("age"));


	 
	         System.out.println("============");
	         
	         ObjectMapper mapper5 = new ObjectMapper();
	         
	         // map -> json
	         ArrayList<HashMap<String, String>> list 
	                 = new ArrayList<HashMap<String,String>>(); 
	         
	         HashMap<String, String> map5 = new HashMap<String, String>();
	         map5.put("name", "steave");
	         map5.put("age", "32");
	         map5.put("job", "baker");
	         list.add(map5);
	         
	         map5 = new HashMap<String, String>();
	         map5.put("name", "matt");
	         map5.put("age", "25");
	         map5.put("job", "soldier");
	         list.add(map5);
	         
	         String test5=mapper5.writeValueAsString(list);
	         System.out.println(mapper5.writeValueAsString(list));
	         System.out.println("test5:"+test5);
	  
	         
	         // json -> map
	         String jsn5 = "[{\"age\":\"32\",\"name\":\"steave\",\"job\":\"baker\"},"
	                 + "{\"age\":\"25\",\"name\":\"matt\",\"job\":\"soldier\"}]";
	         list = mapper5.readValue(jsn5,new TypeReference<ArrayList<HashMap<String, String>>>() {});        
	         
	         System.out.println(list);

	         System.out.println("============");
	         
	         Map<String, Object> map8 = new HashMap<String, Object>();
	         map8.put("park", "17");
	         map8.put("kim", "15");
	         map8.put("lee", "23");
	         map8.put("an", "11");
	         map8.put("jin", "54");

	         ObjectMapper om = new ObjectMapper();

	         om.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true); //key로 정렬 설정

	         String jsonStra = om.writeValueAsString(map8); // map을 json 형태의 string으로 변환

	         System.out.println(jsonStra);
	         System.out.println(" 다른 방법으로는 Map의 구현체를 TreeMap으로 변환하면 별다른 설정을 하지 않고도 key로 정렬된 형태로 변환할 수 있다.");


	         System.out.println("============");
	         
	         System.out.println("======https://blog.naver.com/tommybee/221108272989======");


	          
	         String nodeLinksJson = 
	               "{"
	             + "   \"nodes\":["
	             + "      {\"name\": \"123\", \"group\": 1},"
	             + "      {\"name\": \"456\",  \"group\": 2},"
	             + "      {\"name\": \"789\", \"group\": 3}"
	             + "   ],"
	             + "   \"links\":["
	             + "      {\"source\": 0, \"target\": 1, \"value\": 15},"
	             + "      {\"source\": 0, \"target\": 2, \"value\": 15},"
	             + "      {\"source\": 1, \"target\": 0, \"value\": 15},"
	             + "      {\"source\": 2, \"target\": 0, \"value\": 15}"
	             + "   ]"
	             + "}";

	            ObjectMapper mapper9 = new ObjectMapper();

	            NodeLinks nodeLinks = mapper9.readValue(nodeLinksJson, NodeLinks.class);

	            NodeLinks.Links[] links = nodeLinks.getLinks();

	            

	            for(int i = 0; i < links.length; i++){
	             System.out.println(links[i]);
	            }
	            

	            NodeLinks.Nodes[] nodes = nodeLinks.getNodes();

	            for(int i = 0; i < nodes.length; i++){
	             System.out.println(nodes[i]);
	           }
	            
	            
	            /* result
	            First name : Joe
	            Last name : Sixpack
	            Gender : MALE
	            Verified : false
	            Simple Binding : {"name":{"first":"ChangeJoe","last":"ChangeSixpack"},"gender":"MALE","verified":false,"userImage":"Rm9vYmFyIQ=="}
	            ====차기 UPDATE========
	            Raw Data : {"userImage":"Rm9vYmFyIQ==","gender":"MALE","name":{"last":"Sixpack","first":"RawJoe"},"verified":false}
	            ====차기 UPDATE========
	            Tree Model : {"name":{"first":"Joe","last":"inputLast"},"gender":"MALE","verified":false,"userImage":"Rm9vYmFyIQ=="}
	            ====차기 UPDATE========
	            {name=steave, job=baker, age=32}
	            tester:{"name":"steave","job":"baker","age":"32"}
	            {"name":"steave","job":"baker","age":"32"}
	            ============
	            1 - foo, 2 - bar, 3 - baz
	            ============
	            color:Black
	            ============
	            color1:Black
	            ============
	            32
	            ============
	            [{"name":"steave","job":"baker","age":"32"},{"name":"matt","job":"soldier","age":"25"}]
	            test5:[{"name":"steave","job":"baker","age":"32"},{"name":"matt","job":"soldier","age":"25"}]
	            [{name=steave, job=baker, age=32}, {name=matt, job=soldier, age=25}]
	            ============
	            {"an":"11","jin":"54","kim":"15","lee":"23","park":"17"}
	                          다른 방법으로는 Map의 구현체를 TreeMap으로 변환하면 별다른 설정을 하지 않고도 key로 정렬된 형태로 변환할 수 있다.
	            ============
	            ======https://blog.naver.com/tommybee/221108272989======
	            Links : 
	            source :0	target :1	value :15

	            Links : 
	            source :0	target :2	value :15

	            Links : 
	            source :1	target :0	value :15

	            Links : 
	            source :2	target :0	value :15

	            Nodes : 
	            name :123	group :1

	            Nodes : 
	            name :456	group :2

	            Nodes : 
	            name :789	group :3

	             */

	            

		} catch (JsonParseException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} catch (JsonMappingException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} catch (IOException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}

}

class User {

	public enum Gender {
		MALE, FEMALE
	};

	public static class Name {

		private String _first, _last;

		public String getFirst() {
			return _first;
		}

		public String getLast() {
			return _last;
		}

		public void setFirst(String s) {
			_first = s;
		}

		public void setLast(String s) {
			_last = s;
		}

	}

	private Gender _gender;

	private Name _name;

	private boolean _isVerified;

	private byte[] _userImage;

	public Name getName() {
		return _name;
	}

	public boolean isVerified() {
		return _isVerified;
	}

	public Gender getGender() {
		return _gender;
	}

	public byte[] getUserImage() {
		return _userImage;
	}

	public void setName(Name n) {
		_name = n;
	}

	public void setVerified(boolean b) {
		_isVerified = b;
	}

	public void setGender(Gender g) {
		_gender = g;
	}

	public void setUserImage(byte[] b) {
		_userImage = b;
	}

}
