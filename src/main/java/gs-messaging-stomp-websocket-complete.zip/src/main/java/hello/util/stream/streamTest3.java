
package hello.util.stream;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class streamTest3 {

	
	

	public static void main(String[] args) {
		
		 List<Employee> people = Employee.getEmpList();
		 
		 List<String> list = people.stream().map(Employee::getName).collect(Collectors.toList());
		 
		// List<Map<String, Object>> listMap = people.stream().map(Employee::getName).collect(Collectors.toList());
		 
		 System.out.println("All employees list:" + list);
		 //All employees list:[A, B, C, D]

	}

	
}

