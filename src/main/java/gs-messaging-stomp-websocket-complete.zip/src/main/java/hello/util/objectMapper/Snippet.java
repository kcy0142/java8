
package hello.util.objectMapper;
 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
 
public class Snippet {
	public static void main(String[] args) {
		Map<String, ArrayList<Object>> map = new HashMap<>();
		ArrayList<Object> list1 = new ArrayList<>();
		list1.add("a");
		list1.add("b");
		list1.add("c");
 
		ArrayList<Object> list2 = new ArrayList<>();
		list2.add("d");
		list2.add("e");
		list2.add("f");
		map.put("one", list1);
		map.put("two", list2);
 
		ObjectMapper mapper = new ObjectMapper();
		String json ="";
		try {
			 json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(map);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(json);
		System.out.println("========================");
		
		for(Entry<String, ArrayList<Object>> en : map.entrySet()){
			for(Object obj : en.getValue()){
				System.out.println(obj);
			}
		}
		System.out.println("========================");
		for(Entry ent:map.entrySet()) {
			    		for(Object obj: Arrays.asList(ent.getValue())) {
			          System.out.println(obj.toString());
			    		}
		}
		System.out.println("========================");
		// the outer loop is iterating over the map 
		for (Map.Entry<String, ArrayList<Object>> entry : map.entrySet()) { 
		     
			 // getting the key
			 String myKey = entry.getKey();
			 // getting the value (your list)
			 ArrayList<Object> myList =  entry.getValue();
			// using the key  
			System.out.println("the key is :"+myKey);
		 
			// the inner loop iterate over the List  
			for(Object obj: myList){
				// here you have the o 
				System.out.println(obj);
			}    
		 }
		
		
		System.out.println("####################################");
		
		String [] nexen={"윤석민","윤석민3"};
		Map<String, Object> map1=new HashMap<String,Object>();
		map1.put("team", "넥센");
		map1.put("data", nexen);
		
		String [] samsung={"윤석민33","윤석민2"};
		Map<String,Object> map2=new HashMap<String,Object>();
		map2.put("team", "삼성");
		map2.put("data", samsung);


		String [] kia={"윤석민"};
		Map<String,Object> map3=new HashMap<String,Object>();
		map3.put("team", "기아");
		map3.put("data", kia);

		List<Map<String, Object>> list=new ArrayList<Map<String,Object>>();
		list.add(map1);
		list.add(map2);
		list.add(map3);


		//view를 손대지 않아도 된다.
		for(Map<String,Object> map9 : list){
			System.out.print(map9.get("team")+":");
			String[] player=(String [])map9.get("data");
			for(String str:player){
			System.out.print(str+" ");
			}
			System.out.println();
		}


	}
}
