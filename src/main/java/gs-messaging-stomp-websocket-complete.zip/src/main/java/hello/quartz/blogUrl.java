
package hello.quartz;
 


public class blogUrl {

	private String url="http://www.leafcats.com/93";
}

