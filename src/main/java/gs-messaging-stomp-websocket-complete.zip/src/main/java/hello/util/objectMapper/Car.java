
package hello.util.objectMapper;

import java.util.List;

public class Car {
	 
    private String color;
    private String type;
    
    private List carList;
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
 
	public Car(String color,String type) {
		this.color = color;
		this.type = type;

	}
	public List getCarList() {
		return carList;
	}
	public void setCarList(List carList) {
		this.carList = carList;
	}
}

