
package hello.util.mkyong.java8;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class InputController {

	

	public static void main(String[] args) {
		
		Map<String, List<Object>> employeeMap = new HashMap<String, List<Object>>();
        EmployeeBaseData base_data1 = new EmployeeBaseData("e774801");
        EmployeeBaseData base_data2 = new EmployeeBaseData("e774802");
        List<Object> valSetOne = new ArrayList<Object>();
        List<Object> valSetTwo = new ArrayList<Object>();
        valSetOne.add(base_data1);
        valSetTwo.add(base_data2);
        employeeMap.put("e774801", valSetOne);
        employeeMap.put("e774802", valSetTwo);
        for(Map.Entry<String, List<Object>> entry : employeeMap.entrySet()){
            String key = entry.getKey();
            List<Object> value= entry.getValue();
            
        }
        
        System.out.println("================================");
        
        Map<String, List<EmployeeBaseData >> employeeMap1 = new HashMap<String, List<EmployeeBaseData >>();

        EmployeeBaseData base_data11 = new EmployeeBaseData("e774801");
        EmployeeBaseData base_data12 = new EmployeeBaseData("e774802");

        List<EmployeeBaseData > valSetOne1 = new ArrayList<>();
        List<EmployeeBaseData > valSetTwo1 = new ArrayList<>();

        valSetOne1.add(base_data11);
        valSetTwo1.add(base_data12);

        employeeMap1.put("e774801", valSetOne1);
        employeeMap1.put("e774802", valSetTwo1);

        for(Map.Entry<String, List<EmployeeBaseData>> entry : employeeMap1.entrySet()){
            String key = entry.getKey();
            List<EmployeeBaseData> value = entry.getValue();

            // access objects here:
            for (EmployeeBaseData a : value) {
                a.getOvertime();
                System.out.println("================================"+ a.getOvertime());
            }
        }
        
       /* List<Integer> overtimes = 
        	    employeeMap.values()
        	               .stream()
        	               .flatMap(Collection::stream)
        	               .map(EmployeeBaseData::getOvertime)
        	               .collect(Collectors.toList());*/
	}

	
}

