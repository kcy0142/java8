
package hello.util.mkyong.java8;
 

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.lang3.text.WordUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonMapExample {

	public static void main(String[] args) {

		try {

			ObjectMapper mapper = new ObjectMapper();
			String json = "{\"name\":\"mkyong\", \"age\":29}";

			Map<String, Object> map = new HashMap<String, Object>();

			// convert JSON string to Map
			map = mapper.readValue(json, new TypeReference<Map<String, String>>(){});

			System.out.println(map);
			
			System.out.println("=====================================");
			
			ObjectMapper mapper2 = new ObjectMapper();
			String json2 = "";

			Map<String, Object> map2 = new HashMap<String, Object>();
			map2.put("name", "mkyong");
			map2.put("age", 29);

			// convert map to JSON string
			json2 = mapper2.writeValueAsString(map2);

			System.out.println(json);

			json = mapper2.writerWithDefaultPrettyPrinter().writeValueAsString(map2);

			// pretty print
			System.out.println(json);
			System.out.println("=====================================");
			ObjectMapper mapper3 = new ObjectMapper();

			Map<String, Object> map3 = new HashMap<String, Object>();
			map3.put("name", "mkyong");
			map3.put("age", 29);

			List<Object> list3 = new ArrayList<>();
			list3.add("msg 1");
			list3.add("msg 2");
			list3.add("msg 3");

			map3.put("messages", list3);

			// write JSON to a file
			mapper3.writeValue(new File("c:\\user.json"), map3);
			
			System.out.println("=====================================");
			
			ObjectMapper mapper4 = new ObjectMapper();

			// read JSON from a file
			Map<String, Object> map4 = mapper4.readValue(
					new File("c:\\user.json"),
					new TypeReference<Map<String, Object>>() {
			});

			json = mapper4.writerWithDefaultPrettyPrinter().writeValueAsString(map4);
			System.out.println(json);
			System.out.println(map4.get("name"));
			System.out.println(map4.get("age"));

			@SuppressWarnings("unchecked")
			ArrayList<String> list4 = (ArrayList<String>) map4.get("messages");

			for (String msg4 : list4) {
				System.out.println(msg4);
			}
			System.out.println("=====================================");
			
			ObjectMapper mapper5 = new ObjectMapper();

			Map<String, Object> map5 = new HashMap<String, Object>();
			map5.put("name", "mkyong");
			map5.put("age", 29);

			List<Object> list5 = new ArrayList<>();
			
			list5.add("msg 1");
			list5.add("msg 2");
			list5.add("msg 3");
			
			map5.put("messages", list5);
			
			List<Object> list6 = new ArrayList<>();
			
			Map<String, Object> mapTest1 = new HashMap<String, Object>();
			mapTest1.put("aa", "1");
			mapTest1.put("bb", "abcd");
			mapTest1.put("cc", "가나다라");
			list6.add(mapTest1);
			
			Map<String, Object> mapTest2 = new HashMap<String, Object>();
			mapTest2.put("aa", "11");
			mapTest2.put("bb", "abcd1");
			mapTest2.put("cc", "가나다라1");
			list6.add(mapTest2);
			
			map5.put("item", list6);
			
			// write JSON to a file
			mapper5.writeValue(new File("c:\\user2.json"), map5);
			
			System.out.println("=====================================");
			String json7="";
			ObjectMapper mapper7 = new ObjectMapper();

			// read JSON from a file
			Map<String, Object> map7 = mapper7.readValue(
					new File("c:\\user2.json"),
					new TypeReference<Map<String, Object>>() {
			});

			json7 = mapper7.writerWithDefaultPrettyPrinter().writeValueAsString(map7);
			String json7_1 = mapper2.writeValueAsString(map7);
			
			System.out.println(json7_1);//{"item":[{"aa":"1","bb":"abcd","cc":"가나다라"},{"aa":"11","bb":"abcd1","cc":"가나다라1"}],"name":"mkyong","messages":["msg 1","msg 2","msg 3"],"age":29}
			System.out.println(json7);
			System.out.println(map7.get("name"));
			System.out.println(map7.get("age"));

			System.out.println("=====messages=====");
			@SuppressWarnings("unchecked")
			ArrayList<String> list7 = (ArrayList<String>) map7.get("messages");
			
			for (String msg7 : list7) {
				System.out.println(msg7);
			}
			System.out.println("=====item=====");
			
			@SuppressWarnings("unchecked")
			ArrayList<Map<String, Object>> list8 = (ArrayList<Map<String, Object>>) map7.get("item");

			for (Map<String, Object> msg8 : list8) {
				System.out.println(msg8.get("aa")+",bb:"+msg8.get("bb"));
				
				
			}
			
		
			
			System.out.println("=============================");
			
			Map<String, ArrayList<Object>> map8 = new HashMap<>();
			ArrayList<Object> list1 = new ArrayList<>();
			list1.add("a");
			list1.add("b");
			list1.add("c");
	 
			ArrayList<Object> list2 = new ArrayList<>();
			list2.add("d");
			list2.add("e");
			list2.add("f");
			map8.put("one", list1);
			map8.put("two", list2);
	 
			ObjectMapper mapper8 = new ObjectMapper();
			String json8 ="";
			try {
				 json8 = mapper8.writerWithDefaultPrettyPrinter().writeValueAsString(map8);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(json8);
			System.out.println("========================");
			
			for(Entry<String, ArrayList<Object>> en : map8.entrySet()){
				for(Object obj : en.getValue()){
					System.out.println(obj);
				}
			}
			System.out.println("========================");
			for(Entry ent:map8.entrySet()) {
				    		for(Object obj: Arrays.asList(ent.getValue())) {
				          System.out.println(obj.toString());
				    		}
			}
			System.out.println("========================");
			// the outer loop is iterating over the map 
			for (Map.Entry<String, ArrayList<Object>> entry : map8.entrySet()) { 
			     
				 // getting the key
				 String myKey = entry.getKey();
				 // getting the value (your list)
				 ArrayList<Object> myList =  entry.getValue();
				// using the key  
				System.out.println("the key is :"+myKey);
			 
				// the inner loop iterate over the List  
				for(Object obj: myList){
					// here you have the o 
					System.out.println(obj);
				}    
			 }

			

			
			System.out.println("=============================");
			
			
			
			
			
			
			
			System.out.println("####################################");
			
			String [] nexen={"윤석민","윤석민3"};
			Map<String, Object> base1=new HashMap<String,Object>();
			base1.put("team", "넥센");
			base1.put("data", nexen);
			
			String [] samsung={"윤석민33","윤석민2"};
			Map<String,Object> base2=new HashMap<String,Object>();
			base2.put("team", "삼성");
			base2.put("data", samsung);


			String [] kia={"윤석민"};
			Map<String,Object> base3=new HashMap<String,Object>();
			base3.put("team", "기아");
			base3.put("data", kia);

			List<Map<String, Object>> baseList=new ArrayList<Map<String,Object>>();
			baseList.add(base1);
			baseList.add(base2);
			baseList.add(base3);


			//view를 손대지 않아도 된다.
			for(Map<String,Object> map9 : baseList){
				System.out.print(map9.get("team")+":");
				String[] player=(String [])map9.get("data");
				for(String str:player){
				System.out.print(str+" ");
				}
				System.out.println();
			}
			
		    List<Map<String, String>> congratulations = null;
	        
	        if (!StringUtils.isEmpty(baseList)) {
	            congratulations = baseList.stream().map(data -> new HashMap<String, String>() {
	                private static final long serialVersionUID = -4803937536892622504L;
	                {                   
	                    for (Map.Entry<String, Object> entry : data.entrySet()) {
	                        String camelCaseKey = WordUtils.capitalizeFully(entry.getKey(), new char[]{'_'}).replaceAll("_", "");
	                        camelCaseKey = camelCaseKey.substring(0, 1).toLowerCase() + camelCaseKey.substring(1);
	                        this.put(camelCaseKey, String.valueOf(entry.getValue()));
	                    }
	                }
	            }).collect(Collectors.toList());
	        }
			
	        System.out.println("#################################### congratulations:"+congratulations);
	        
			System.out.println("####################################");
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
