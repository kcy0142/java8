
package hello.util.mkyong.java8;

public class EmployeeBaseData {
	public EmployeeBaseData(String sid) {
		this.sid = sid;

	}

	private String sid;
	private int actualHours = 10;
	private int regularHours = 9;
	private int overtime = 1;

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public int getActualHours() {
		return actualHours;
	}

	public void setActualHours(int actualHours) {
		this.actualHours = actualHours;
	}

	public int getRegularHours() {
		return regularHours;
	}

	public void setRegularHours(int regularHours) {
		this.regularHours = regularHours;
	}

	public int getOvertime() {
		return overtime;
	}

	public void setOvertime(int overtime) {
	    this.overtime = overtime;
	}
}