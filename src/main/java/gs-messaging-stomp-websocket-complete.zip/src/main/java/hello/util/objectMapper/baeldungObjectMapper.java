/* ------------------------------------------------------------------------------
 * Project       : NextEP Project VPA System
 * Source        : baeldungObjectMapper.java
 * Author        : 김청욱
* Copyright 2017 LG CNS All rights reserved
*------------------------------------------------------------------------------ */

/**
 * <PRE>
 * test
 * </PRE>
 * 
 * @author 김청욱
 * @version v1.0 2017. 9. 22.
 */
package hello.util.objectMapper;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class baeldungObjectMapper {

	public static void main(String[] args) {
		
		ObjectMapper objectMapper = new ObjectMapper();
		Car car = new Car("yellow", "renault");
		try {
			objectMapper.writeValue(new File("target/car.json"), car);
			
			String carAsString = objectMapper.writeValueAsString(car);

			System.out.println("=====carAsString;"+carAsString);//=====carAsString;{"color":"yellow","type":"renault"}
			
			//String json = "{ \"color\" : \"Green\", \"type\" : \"Kia\" }";
			//Car car2 = objectMapper.readValue(json, Car.class);  

			
			String json2 = "{ \"color\" : \"Black\", \"type\" : \"FIAT\" }";
			JsonNode jsonNode = objectMapper.readTree(json2);
			String color = jsonNode.get("color").asText();
			System.out.println("=====color:"+color);
			
			/*String jsonCarArray = "[{ \"color\" : \"Black\", \"type\" : \"BMW\" }, { \"color\" : \"Red\", \"type\" : \"FIAT\" }]";
			List<Car> listCar = objectMapper.readValue(jsonCarArray, new TypeReference<List<Car>>(){});
			System.out.println("=====listCar;"+listCar);*/
			
			String jsona = "{ \"color\" : \"Black\", \"type\" : \"BMW\" }";
			Map<String, Object> map = objectMapper.readValue(jsona, new TypeReference<Map<String,Object>>(){});
			System.out.println("=====map;"+map);
			
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}
}

