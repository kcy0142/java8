//1. List to Map – Collectors.toMap()
//Create a list of the Hosting objects, and uses Collectors.toMap to convert it into a Map.

package hello.util.mkyong.java8;
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class TestListMap {

    public static void main(String[] args) {

        List<Hosting> list = new ArrayList<>();
        list.add(new Hosting(1, "liquidweb.com", 80000));
        list.add(new Hosting(2, "linode.com", 90000));
        list.add(new Hosting(3, "digitalocean.com", 120000));
        list.add(new Hosting(4, "aws.amazon.com", 200000));
        list.add(new Hosting(5, "mkyong.com", 1));

        Map<String, ArrayList<Object>> map = new HashMap<>();
		ArrayList<Object> list1 = new ArrayList<>();
		list1.add("a");
		list1.add("b");
		list1.add("c");
 
		ArrayList<Object> list2 = new ArrayList<>();
		list2.add("d");
		list2.add("e");
		list2.add("f");
		map.put("one", list1);
		map.put("two", list2);
		
		/*Map<String, Object> mapa = list.stream().collect(Collectors.toMap(Function.identity(), s->s));
		mapa.forEach((x, y) -> System.out.println("Key: " + x +", value: "+ y));
*/
		
		Map<Integer, String> result22 = list.stream().collect(
	                Collectors.toMap(Hosting::getId, Hosting::getName));

	    System.out.println("Result 22 : " + result22);
	        
        // key = id, value - websites
        Map<Integer, String> result1 = list.stream().collect(
                Collectors.toMap(Hosting::getId, Hosting::getName));

        System.out.println("Result 1 : " + result1);
        //Result 1 : {1=liquidweb.com, 2=linode.com, 3=digitalocean.com, 4=aws.amazon.com, 5=mkyong.com}
      
        // key = name, value - websites
        Map<String, Long> result2 = list.stream().collect(
                Collectors.toMap(Hosting::getName, Hosting::getWebsites));

        System.out.println("Result 2 : " + result2);
        //Result 2 : {liquidweb.com=80000, mkyong.com=1, digitalocean.com=120000, aws.amazon.com=200000, linode.com=90000}

        // Same with result1, just different syntax
        // key = id, value = name
        Map<Integer, String> result3 = list.stream().collect(
                Collectors.toMap(x -> x.getId(), x -> x.getName()));

        System.out.println("Result 3 : " + result3);
        //Result 3 : {1=liquidweb.com, 2=linode.com, 3=digitalocean.com, 4=aws.amazon.com, 5=mkyong.com}
    }
}