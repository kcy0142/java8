
package com.proxy.example;
 




import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BndProxyConfig1 {
	
	
	@Bean
	public ConnectionConfig1 connectionConfig1() {
		return new ConnectionConfig1();
	}
	
	@ConfigurationProperties
    public class ConnectionConfig1 {
		
		static final String BND_HOST = "host";
		static final String BND_PORT = "port";
		
		// static 은 클래스의 인스턴스들이 공유해야할 정보에 붙여주고
		//final 을 static 에 덧붙이면 변경이 불가능한 공유정보가 됩니다.

		
		
		static final String BND_CONN_CNT = "connection.count";
		static final String BND_THRD_CNT = "thread.count";
		static final String BND_SECR_KEY = "secretKey";
		
		private Map<String, Map<String, String>> bndproxy1;
		
		
		
		public Map<String, Map<String, String>> getBndproxy1() {
			return bndproxy1;
		}

		public void setBndproxy1(Map<String, Map<String, String>> bndproxy1) {
			this.bndproxy1 = bndproxy1;
		}
		
		
		
		
		
		/**
		 * 설정 오류인 경우 연결 생성을 하지 않느다.
		 * @param tenantId
		 * @return
		 * @throws Exception
		 */
		public ConnectionInfo1 getConnectionInfo1(String tenantId) {
			if( !bndproxy1.containsKey(tenantId) ) {
				return null;
			}
			
			Map<String, String> bndconfig = bndproxy1.get(tenantId);
			
			ConnectionInfo1 connectionInfo = new ConnectionInfo1();
			connectionInfo.tenantId     = tenantId;
			connectionInfo.host 		= bndconfig.get(BND_HOST);
			connectionInfo.port 		= Integer.parseInt(bndconfig.get(BND_PORT));
			connectionInfo.connectionCount = Integer.parseInt(bndconfig.get(BND_CONN_CNT));
			connectionInfo.threadCount 	= Integer.parseInt(bndconfig.get(BND_CONN_CNT));
			connectionInfo.secretKey	= bndconfig.get(BND_SECR_KEY);
			
			return connectionInfo;
		}

		

				
	}   
	
	public class ConnectionInfo1 {
		private String tenantId;
		private String host;
		private int port;
		private int connectionCount;
		private int threadCount;
		private String secretKey;
		
		public String getTenantId() {
			return tenantId;
		}
		
		public String getHost() {
			return host;
		}
		public int getPort() {
			return port;
		}
		public int getMaxConnectionCount() {
			return connectionCount;
		}
		public int getThreadCount() {
			return threadCount;
		}
		public String getSecretKey() {
			return secretKey;
		}
		
		public String toString() {
			return String.format("ConnectionInfo "
					+ "[host : %s,port : %d, max_connection_count : %d, max_thread_count : %d, secret key : %s",
					host, port, connectionCount, threadCount, secretKey);
		}
	}
}