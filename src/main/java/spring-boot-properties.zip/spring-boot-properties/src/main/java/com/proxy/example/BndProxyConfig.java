
package com.proxy.example;
 




import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/*

bndproxy.naver.host=127.0.0.1
bndproxy.naver.port=8900
bndproxy.naver.connection.count=100
bndproxy.naver.thread.count=100
bndproxy.naver.secretKey=navertest
 */

@Configuration
public class BndProxyConfig {
	
	
	@Bean
	public ConnectionConfig connectionConfig() {
		return new ConnectionConfig();
	}
	
	@ConfigurationProperties
    public class ConnectionConfig {
		
		static final String BND_HOST = "host";
		static final String BND_PORT = "port";
		
		// static 은 클래스의 인스턴스들이 공유해야할 정보에 붙여주고
		//final 을 static 에 덧붙이면 변경이 불가능한 공유정보가 됩니다.

		
		
		static final String BND_CONN_CNT = "connection.count";
		static final String BND_THRD_CNT = "thread.count";
		static final String BND_SECR_KEY = "secretKey";
		
		private Map<String, Map<String, String>> bndproxy;

		public Map<String, Map<String, String>> getBndproxy() {
			return bndproxy;
		}

		public void setBndproxy(Map<String, Map<String, String>> bndproxy) {
			this.bndproxy = bndproxy;
		}
		
		/**
		 * 설정 오류인 경우 연결 생성을 하지 않느다.
		 * @param tenantId
		 * @return
		 * @throws Exception
		 */
		public ConnectionInfo getConnectionInfo(String tenantId) {
			if( !bndproxy.containsKey(tenantId) ) {
				return null;
			}
			
			Map<String, String> bndconfig = bndproxy.get(tenantId);
			
			ConnectionInfo connectionInfo = new ConnectionInfo();
			connectionInfo.tenantId     = tenantId;
			connectionInfo.host 		= bndconfig.get(BND_HOST);
			connectionInfo.port 		= Integer.parseInt(bndconfig.get(BND_PORT));
			connectionInfo.connectionCount = Integer.parseInt(bndconfig.get(BND_CONN_CNT));
			connectionInfo.threadCount 	= Integer.parseInt(bndconfig.get(BND_CONN_CNT));
			connectionInfo.secretKey	= bndconfig.get(BND_SECR_KEY);
			
			return connectionInfo;
		}
				
	}   
	
	public class ConnectionInfo {
		private String tenantId;
		private String host;
		private int port;
		private int connectionCount;
		private int threadCount;
		private String secretKey;
		
		public String getTenantId() {
			return tenantId;
		}
		
		public String getHost() {
			return host;
		}
		public int getPort() {
			return port;
		}
		public int getMaxConnectionCount() {
			return connectionCount;
		}
		public int getThreadCount() {
			return threadCount;
		}
		public String getSecretKey() {
			return secretKey;
		}
		
		public String toString() {
			return String.format("ConnectionInfo "
					+ "[host : %s,port : %d, max_connection_count : %d, max_thread_count : %d, secret key : %s",
					host, port, connectionCount, threadCount, secretKey);
		}
	}
}