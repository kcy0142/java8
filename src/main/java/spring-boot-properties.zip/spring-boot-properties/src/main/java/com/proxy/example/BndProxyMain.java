
package com.proxy.example;
 


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



import java.util.Map;

import javax.annotation.PostConstruct;

import com.proxy.example.BndProxyConfig.ConnectionConfig;
import com.proxy.example.BndProxyConfig.ConnectionInfo;

import com.proxy.example.BndProxyConfig1.ConnectionConfig1;
import com.proxy.example.BndProxyConfig1.ConnectionInfo1;

@SpringBootApplication
public class BndProxyMain {

    private static Logger logger = LoggerFactory.getLogger(BndProxyMain.class);

    @Autowired
	public  ConnectionConfig connectionConfig;
    
    @Autowired
  	public  ConnectionConfig1 connectionConfig1;
    
   
	
	 public static void main(String[] args) {
	        SpringApplication.run(BndProxyMain.class, args);
	    }

	 public void BandProxyTest() {
	        System.out.println("constructor of App");
	    }
	 
	 @PostConstruct
	    public void init() {
	        System.out.println("###########BndProxyMain Calling starter.init");
	        String tenantId="naver";
	        ConnectionInfo connectionInfo= connectionConfig.getConnectionInfo(tenantId);
	        
	        Map<String, Map<String, String>> connectionInfoAll=  connectionConfig.getBndproxy();
	        
	        
	        
	        System.out.println("connectionInfo===========tenantId:"+tenantId+",host:"+connectionInfo.getHost());
	        
	        
	        String tenantId1="daum";
	        ConnectionInfo connectionInfo2= connectionConfig.getConnectionInfo(tenantId1);
	        System.out.println("connectionInfo===========tenantId:"+tenantId1+",host:"+connectionInfo2.getHost());
	        
	        System.out.println("Map<String, Map<String, String>> connectionInfoAll=  connectionConfig.getBndproxy()");
	        System.out.println("connectionInfo All===========:"+connectionInfoAll);
	        
	        System.out.println("===================================================");
	        String tenantIdTest="naver";
	        ConnectionInfo1 connectionInfoTest= connectionConfig1.getConnectionInfo1(tenantIdTest);
	        
	        System.out.println("connectionInfo===========tenantId:"+tenantIdTest+",host:"+connectionInfoTest.getHost());
	        
	        System.out.println("===================================================");
	        
	       
	        
	    }

}
